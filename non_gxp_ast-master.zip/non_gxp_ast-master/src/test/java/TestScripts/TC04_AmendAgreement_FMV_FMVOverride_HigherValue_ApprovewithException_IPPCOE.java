package TestScripts;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.AggregateSpendManagementUtils;
import Components.OneASTUtil;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.InitiationPage;

public class TC04_AmendAgreement_FMV_FMVOverride_HigherValue_ApprovewithException_IPPCOE extends BaseClass
{
	public String agreementNumber;
	public String status;
	@Test(priority = 0,description = "Aggregate Spend Management")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "Doc1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "7");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "Sindhu Vankadari");
			reportDetails.put("Name of Automation Test Script Author", "502616489");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "Doc1234567");
		reportDetails.put("Requirement ID", "");
	}
	
	/**
	 * Step No : 10
	 */
	
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{	
			OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
			PDFResultReport.addStepDetails(
					"Login to the Appliaction as Super User entering the valid credentials and \n"
							+ "Click on login button present in the page\n"
							+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
							+ "username : <Super user 1>\n" + "password: <pswd 1>",
					"Login page with title 'Aggregate Spend Management' should get displayed.",
					"Login page with title 'Aggregate Spend Management' get displayed.", "PASS", "N");
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	
	/**
	 * Step No : 20
	 * @throws Exception 
	 */
	@Test(priority = 2)
	public void clickOnAgreementAndSelectNewConsultingAgrseement() throws Exception
	{
		
		OneASTUtil.amendAgreementandSearchOptions(ExcelReport.testData.get("TC04_searchType_AmendAgreement"));
				
	}

	
	@Test(priority=3)
	public void amendDetails() throws Exception{
		
		OneASTUtil.selectSectiontoAmend(ExcelReport.testData.get("TC04_AmendDetails"));
		
		PDFResultReport.addStepDetails("Select 'Yes' radio button for the below fields and click on [Next] button in 'Work Header' section.\n"
                            +"- FMV Rate and /or Agreement Hours.", 
                            
                            "1. The screen should be navigated to 'Business Information'  page.\n"
                            +"2. The 'Business Information' section should contain 2 sub -sections and all the fields should be populated from the parent Agreement.\n"
                            +"- Legal Enity \n"
                            + "- Spend category", 
                            
                            "1. The screen should be navigated to 'Business Information'  page.\n"
                                    +"2. The 'Business Information' section should contain 2 sub -sections and all the fields should be populated from the parent Agreement.\n"
                                    +"- Legal Enity \n"
                                    + "- Spend category", "PASS", "Y");
		
	}

	
	@Test(priority=4)
	public void amendBusinessInformation() throws Exception
	{
		OneASTUtil.enterTheValuesInBusinessInformationTab("ASIA-APAC", "ASEAN", "Malaysia",
				"Global Services", "Global Parts",
				"950110-GETSCO-MEDICAL SYST - Malaysia and New Zealand", "", "", "Yes", ExcelReport.testData.get("TransactionOwnerUserName"),"", "Speaking Engagement", "Educational Non-CME");
			
		
		PDFResultReport.addStepDetails("Modify the required below fields under 'Paying legal entity' section: \n"
					+"1.Pole:'ASIA-APAC' \n"
					+ "2.Region:'ASEAN' \n"
					+ "3.Paying Country : 'Malaysia' \n"
					+ "4.Business :'Global Services'\n"
					+ "5.Modality :'Global Parts' \n"
					+ "6.Legal Entity :'950110-GETSCO-MEDICAL SYST - Malaysia and New Zealand'\n"
					+ "7.Select 'yes' for Are you submitting the request on behalf of others? \n"
					+ "8.Transaction Owner \n", 
					
					"Should be able to modify all the mandatory fields", 
					"Able to modify all the mandatory fields", "PASS", "N");
		
		PDFResultReport.addStepDetails("Enter below fields under 'Spend Details' section: \n"
					+"Spend Type:'Consulting(default)' \n"
					+"Spend Category:'Speaking Engagement' \n"
					+"Spend Sub Category:'Educational Non-CME'", 
					"Should be able to modify all the mandatory fields", 
					"Able to modify all the mandatory fields", "PASS", "Y");		
		
	}
	
	@Test(priority=5)
	public void amendServiceDetails() throws Exception{
		
		OneASTUtil.amendServiceDetails();
		OneASTUtil.amendContractTerm();
		OneASTUtil.amendFMVDetails("Yes","high");
		
		
	}
	
	@Test(priority=6)
	public void submitAmendWorkflow(){
		
		ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
				BaseClass.driver);
		
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		
		//new Actions(BaseClass.driver).moveToElement(initiationPage.certification_Section).build().perform();
		((JavascriptExecutor) BaseClass.driver).executeScript(
				"arguments[0].scrollIntoView(true);",
				initiationPage.certification_Section);
		
		if(BaseClass.text(initiationPage.certification_Language).contains("By submitting this Agreement request, I certify that this Agreement")){
			
			PDFResultReport.addStepDetails("Verify the 'Certification Language' below all the sections.", 
					
					"The below 'Certication language should be displayed \n"

					+"By submitting this Agreement request, I certify that this Agreement, including any interactions with a health care professional (HCP), health care organization (HCO), or government official (GO), is a bona fide need of the Company. "
					+ "I further certify that anything of value that is offered or provided in this interaction is not for the purpose of encouraging a HCP, HCO, or GO to prescribe, purchase, order, refer, use, or recommend GE Healthcare (GEHC) products or services, nor is the interaction targeted towards or used as a reward for purchasing GEHC products or services."
					+ "Last, I certify that this proposed interaction complies with all GEHC policies that apply to this type of interaction, GEHC Codes of Conduct applicable to this region and P&L, and the GE Code of Conduct (“The Spirit and Letter”).", 
					
					"The below 'Certication language should be displayed \n"

					+"By submitting this Agreement request, I certify that this Agreement, including any interactions with a health care professional (HCP), health care organization (HCO), or government official (GO), is a bona fide need of the Company. "
					+ "I further certify that anything of value that is offered or provided in this interaction is not for the purpose of encouraging a HCP, HCO, or GO to prescribe, purchase, order, refer, use, or recommend GE Healthcare (GEHC) products or services, nor is the interaction targeted towards or used as a reward for purchasing GEHC products or services."
					+ "Last, I certify that this proposed interaction complies with all GEHC policies that apply to this type of interaction, GEHC Codes of Conduct applicable to this region and P&L, and the GE Code of Conduct (“The Spirit and Letter”).", 
					"PASS", "Y");
		}
			
		BaseClass.click(consultingAgreementPage.submitButton);
		BaseClass.waitForObj(8000);		
	
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
			
		PDFResultReport.addStepDetails("Click on [Submit] button", "'Wf should be assigned for Transaction Owner Approval and below Confirmation message should get displayed \n"
				+"'Agreement A-XXXX has been sent for Approval. Any change in status will be communicated via email. \n"

				+"Thank you' \n", 
				
				"'Agreement"+ agreementNumber + " has been sent for Approval. Any change in status will be communicated via email. \n"

				+"Thank you' \n", "PASS", "Y");
		
		BaseClass.switchToDefaultFrame();
		
		BaseClass.click(approvalPage.close);
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		String pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
		String transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
		
		String[] transactionOwner1 = transactionOwner.split(",");
		
		if(status.equalsIgnoreCase("Pending-Approval") && transactionOwner1[1].contains(pendingWith)){
			
			PDFResultReport.addStepDetails("Open the Agreement in Review mode.", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
					+"2. The Pending with should  display Transaction owner's name.", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
							+"2. The Pending with should  display Transaction owner's name.", "PASS", "Y");
		}
	}
	 

	@Test(priority=7)
	public void transactionOwnerApproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		
		BaseClass.switchToDefaultFrame();
		
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("TransactionOwnerUserName");
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		BaseClass.waitForObj(2000);
		BaseClass.click(approvalPage.approvalFlowLink);	
		BaseClass.waitForObj(2000);
		
				
		PDFResultReport.addStepDetails("Login with the Transaction owner for application and open the workflow ", 
				"1. The Agreement should be present in the dashboard of the Transaction owner. \n"
				+"2.  The 'Additional Comments' section should be displayed along with 'Certification language.", 
				"1. The Agreement should be present in the dashboard of the Transaction owner. \n"
						+"2.  The 'Additional Comments' section should be displayed along with 'Certification language.",  "PASS", "Y");
				
		BaseClass.waitForObj(2000);		
		
		set(approvalPage.additionalComments,"Approve by Transaction Manager");
		
		BaseClass.click(approvalPage.approveButton);
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("Enter the Comments in the 'Additional Comments' section and click on [Approve] button.", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				
				+ "2. The Agreement should be pending with  Direct Manager of the Agreement ", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				+ "2. The Agreement is pending with IPPCOE of the Agreement ", "PASS", "Y");
		
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
		BaseClass.waitForObj(5000);	
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		String pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
		String IPPCOE = text(approvalPage.workDetails.get(ApprovalPage.IPP_COE));
		
		if(status.equalsIgnoreCase("Pending-Approval") && IPPCOE.contains(pendingWith)){
			
			PDFResultReport.addStepDetails("Open the Agreement in Review mode.", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
					+"2. The Pending with should  display IPPCOE name", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
							+"2. The Pending with should  display IPPCOE name", "PASS", "Y");
		}
		
	}
	
	@Test(priority=7)
	public void poleLeaderApproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		
		BaseClass.switchToDefaultFrame();
		
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("poleLeader");
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		BaseClass.waitForObj(2000);
		BaseClass.click(approvalPage.approvalFlowLink);	
		BaseClass.waitForObj(2000);
			
	
		PDFResultReport.addStepDetails("Login with the Pole Leader for application and open the workflow ", 
				"1. The Agreement should be present in the dashboard of the Pole Leader. \n"
				+"2.  The 'Additional Comments' section should be displayed along with 'Certification language.", 
				"1. The Agreement is present in the dashboard of the Pole Leader. \n"
						+"2.  The 'Additional Comments' section should be displayed along with 'Certification language.",  "PASS", "Y");
			
		set(approvalPage.additionalComments,"Approve by Pole Leader");
		
		BaseClass.click(approvalPage.approveButton);
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("Enter the Comments in the 'Additional Comments' section and click on [Approve] button.", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				
				, 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				, "PASS", "Y");
		
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
		BaseClass.waitForObj(5000);	
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		String pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
		String IPPCOE = text(approvalPage.workDetails.get(ApprovalPage.IPP_COE));
		
		if(status.equalsIgnoreCase("Pending-Approval") && IPPCOE.contains(pendingWith)){
			
			PDFResultReport.addStepDetails("Open the Agreement in Review mode.", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
					+"2. The Pending with should  display IPPCOE name", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
							+"2. The Pending with should  display IPPCOE name", "PASS", "Y");
		}
		
	}
	
	@Test(priority=9)
	public void ippCOEapproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName");
		
		status=OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		if(status.equalsIgnoreCase("Pending-Approval")){
			
			PDFResultReport.addStepDetails("Login with the IPPCOE application and open the workflow",
					"Status should be Updated to Pending-Approval ",
					"Status is Updated to Pending-Approval ","PASS","Y");			
		}	
		
				
			
		
		BaseClass.click(approvalPage.approvalFlowLink);
		
		if(BaseClass.getAttributeValue(approvalPage.AmendContractterm_IPPDCOE_ReadOnly, "class").contains("dataValueRead") &&
			BaseClass.getAttributeValue(approvalPage.AmendServiceDetails_IPPDCOE_ReadOnly, "class").contains("dataValueRead") &&
			BaseClass.getAttributeValue(approvalPage.AmendFMVDetails_IPPDCOE_ReadOnly, "class").contains("dataValueRead") &&
			OneASTUtil.isElementPresent(approvalPage.hoursFromAgreementalreadyFinalized) && OneASTUtil.isElementPresent(approvalPage.originalAmendmentLanguage)
			&& OneASTUtil.isElementPresent(approvalPage.ceritification_IPPCOE)){
			
		PDFResultReport.addStepDetails("Verify the details present in Agreement when it is with IPPCOE Approval.", 
				
							"1.  The fields in 'Select section to edit' screen should be populated in read-only mode. \n"
							+"2. 'Original Agreement language' section should be populated in read-only mode with below banner \n"
							+"No Changes made to Original Contract language' \n"
							+"3. 'ORIGINAL CONTACTED DATES' section with dates entered in Amend Agreement. \n"
							+"4. 'EDITED CONTRACT DATES' section with dates populated from parent Agreement. \n"
							+"5. '• Hours from agreement already finalized ' section with o Number of hours from the parent agreement that were already finalized. \n"
							+"6. 'Certification language' should be displayed.", 
							
							"1.  The fields in 'Select section to edit' screen is populated in read-only mode. \n"
									+"2. 'Original Agreement language' section is populated in read-only mode with below banner \n"
									+"No Changes made to Original Contract language' \n"
									+"3. 'ORIGINAL CONTACTED DATES' section with dates entered in Amend Agreement. \n"
									+"4. 'EDITED CONTRACT DATES' section with dates populated from parent Agreement. \n"
									+"5. '• Hours from agreement already finalized ' section with o Number of hours from the parent agreement that were already finalized. \n"
									+"6. 'Certification language' should be displayed.", "PASS", "Y");
			}
		
		OneASTUtil.clickOnOtherActionsAndSelectApprovewithException("FMV review (consulting)", "Approve with Exception");
				
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);	
		
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
		BaseClass.waitForObj(5000);	
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		String pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
		String directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
		
		if(status.equalsIgnoreCase("Pending-Approval") && directManager.contains(pendingWith)){
			
			PDFResultReport.addStepDetails("Open the Agreement in Review mode.", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
					+"2. The Pending with should  display Direct Manager name", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
							+"2. The Pending with should  display Manager name", "PASS", "Y");
		}
		
		
	}
	
	@Test(priority=10)
	public void directManagerApproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("DirectManagerName");
		String status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		BaseClass.click(approvalPage.approvalFlowLink);
		
		if(status.equalsIgnoreCase("Pending-Approval")){
			
			PDFResultReport.addStepDetails("Login with the Direct Manager application and open the workflow",
					"Status should be Updated to Pending-Approval ",
					"Status is Updated to Pending-Approval ","PASS","Y");
			
		}
		
		OneASTUtil.clickOnOtherActionsAndSelectDelegateToAnAdditionalApprover("502757733", "Delegate this request");
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
		BaseClass.waitForObj(5000);	
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		String pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
		String directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
		
		if(status.equalsIgnoreCase("Pending-Approval") && directManager.contains(pendingWith)){
			
			PDFResultReport.addStepDetails("Open the Agreement in Review mode.", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
					+"2. The Pending with  and Direct Manager fields should  display the name of delegated Direct Manager.", 
					
					"1. The status of the Agreement should be displayed as 'Pending Approval'\n"
							+"2. The Pending with  and Direct Manager fields display the name of delegated Direct Manager.", "PASS", "Y");
		}

				
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("'Click on logout from the user dropdown", 
				"'User should be logged out of the application",
				"'User should be logged out of the application", "PASS", "Y");
	}
	
	@Test(priority=11)
	public void delegatedDirectManagerApproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			
		OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
		String status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		BaseClass.click(approvalPage.approvalFlowLink);
		
		if(status.equalsIgnoreCase("Pending-Approval")){
			
			PDFResultReport.addStepDetails("Login with the Direct Manager application and open the workflow",
					"Status should be Updated to Pending-Approval ",
					"Status is Updated to Pending-Approval ","PASS","Y");
			
		}
		
		BaseClass.set(approvalPage.additionalComments, "Approve by Delegated Direct manager");	
		
		BaseClass.click(approvalPage.approveButton);
		BaseClass.waitForObj(5000);	
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		
		PDFResultReport.addStepDetails("'Enter the Comments in the 'Additional Comments' section and click on [Approve] button.", 
				
				"'The Agreement should be Approved by the Direct Manager and below message should be displayed. \n"

				+"Agreement A-xxx  has been sent for Approval. Any change in status will be communicated via email. \n"

				+"Thank you", 
				
				"'The Agreement is Approved by the Direct Manager and below message is displayed. \n"

				+"Agreement "+agreementNumber +"  has been sent for Approval. Any change in status will be communicated via email. \n"

				+"Thank you", "PASS", "Y");
		
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
		BaseClass.waitForObj(5000);	
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		String pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
		String IPP_COE = text(approvalPage.workDetails.get(ApprovalPage.IPP_COE));
		
		if(status.equalsIgnoreCase("Pending-Activation") && IPP_COE.contains(pendingWith)){
			
			PDFResultReport.addStepDetails("Open the Agreement in Review mode.", 
					
					"1. The status of the Agreement should be displayed as 'Pending Activation'\n"
					+"2. The Pending with  and Direct Manager fields should  display the name of IPP COE.", 
					
					"1. The status of the Agreement is displayed as 'Pending IPP_COE'\n"
							+"2. The Pending with  and Direct Manager fields display the name of IPP COE.", "PASS", "Y");
		}

				
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("'Click on logout from the user dropdown", 
				"'User should be logged out of the application",
				"'User should be logged out of the application", "PASS", "Y");
	}
	
	@Test(priority=11)
	public void activateAgreement(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		
		OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName");
		
		PDFResultReport.addStepDetails("'Login as IPPCOE and verify the details", 
				
				"'1. The below fields should be enabled for the IPPCOE  to be edited: \n"
				+"- Effective date \n"
				+"- Expiration date\n"
				+"2. A mandatory upload with  'Signed Agreement' label should be present.", 
				
				"'1. The below fields are enabled for the IPPCOE  to be edited: \n"
						+"- Effective date \n"
						+"- Expiration date\n"
						+"2. A mandatory upload with  'Signed Agreement' label should be present.", "PASS", "Y");
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		OneASTUtil.activateAgreement("TestData.xlsx", "Pending-Activation");	
			
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
		BaseClass.waitForObj(5000);	
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
			
		if (status.equalsIgnoreCase("Resolved-Completed"))
		{
			PDFResultReport
					.addStepDetails(
							"Review the details, click on the link.\r"
									+ "Enter the expiration date, upload the documents and click on [Submit]",
							"Below confirmation message should be displayed and\n"
									+ "'The Agreement should be Activated successfully and below message should get displayed. \n"
									+"Agreement A-xxxhas been Activated. \n"
									+ "Thank you", "Below confirmation message is displayed and\r"
											+ "'The Agreement should be Activated successfully and below message should get displayed. \n"
											+"Agreement "+agreementNumber+" has been Activated. \n"
											+ "Thank you \n"
									+ "The status is changed to Resolved-Completed Agreement "
								,
							"PASS", "Y");
		}
		
		BaseClass.click(approvalPage.commentsTab);
		
		waitForObj(5000);
		
		PDFResultReport.addStepDetails("'Verify the Comments section.", 
				
				"'The Comments section should contain all the records of Approvers with Comments entered in 'Additional Comments' section", 

				"'The Comments section should contain all the records of Approvers with Comments entered in 'Additional Comments' section", "PASS", "Y");
		
		switchToDefaultFrame();
		waitForObj(3000);
		
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(driver,
				AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		waitForObj(3000);
	}


}

	
	
	
	



