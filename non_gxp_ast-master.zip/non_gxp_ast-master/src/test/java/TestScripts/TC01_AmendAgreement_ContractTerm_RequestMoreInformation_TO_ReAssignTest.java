package TestScripts;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.AggregateSpendManagementUtils;
import Components.CommonUtils;
import Components.LoginUtils;
import Components.OneASTUtil;
import Components.PeagDesignerStudioHomePageUtils;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.AggregateSpendManagementPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.HomePage;
import ObjectRepository.InitiationPage;
import ObjectRepository.LogInPage;
import ObjectRepository.OneASTHomePage;
import ObjectRepository.PeagDesignerStudioHomePage;
public class TC01_AmendAgreement_ContractTerm_RequestMoreInformation_TO_ReAssignTest extends BaseClass
{
	public String agreementNumber;
	public HomePage homePage;
	public ArrayList<String> tabs;
	public String eventId;
	public String caseId;
	public String userOne = ExcelReport.testData.get("userName");
	public String userTwo = ExcelReport.testData.get("userTwo");
	String status;
	@Test(priority = 0,description = "Aggregate Spend Management Tool POC")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "Doc1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "7");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "Sindhu Vankadari");
			reportDetails.put("Name of Automation Test Script Author", "502616489");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "Doc1234567");
		reportDetails.put("Requirement ID", "");
	}
	
	/**
	 * Step No : 10
	 */
	
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{	
			OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
			
			PDFResultReport
			.addStepDetails(
					"Login to the Appliaction as Super User entering the valid credentials and \n"
							+ "Click on login button present in the page\n"
							+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
							+ "username : <Super user 1>\n" + "password: <pswd 1>",
					"Login page with title 'Aggregate Spend Management' should get displayed.",
					"Login page with title 'Aggregate Spend Management' get displayed.", "PASS", "N");
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	
	/**
	 * Step No : 20
	 * @throws Exception 
	 */
	@Test(priority = 2)
	public void clickOnAgreementAndSelectNewConsultingAgrseement() throws Exception
	{
		
		OneASTUtil.amendAgreementandSearchOptions(ExcelReport.testData.get("TC01_searchType_AmendAgreement"));
		
		
	}

	
	@Test(priority=3)
	public void amendDetails() throws Exception{
		
		OneASTUtil.selectSectiontoAmend(ExcelReport.testData.get("TC01_AmendDetails"));
		
		
		PDFResultReport.addStepDetails("Select \"Yes\" for Amend Contract term and click on Next button", 
				"1. The screen should be navigated to the 'Business Information' section.\n"
				+ "2. The 'Business Information' section should contain 2 sub -sections\n"
				+ "- Legal Enity \n"
				+ "- Spend category", 
				"1. The screen is navigated to the 'Business Information' section.\n"
						+ "2. The 'Business Information' section contain 2 sub -sections\n"
						+ "- Legal Enity \n"
						+ "- Spend category", "PASS", "Y");
	}

	
	@Test(priority=4)
	public void amendBusinessInformation() throws Exception
	{
	
		OneASTUtil.enterTheValuesInBusinessInformationTab("ASIA-APAC", "Japan", "Japan",
				"Global Marketing", "Global Marketing",
				"710110-GE Healthcare Japan Corporation", "", "", "Yes",ExcelReport.testData.get("superUserUserName"), "", "Advisory Services", "Regulatory Advice");
		
		//OneASTUtil.requestOnBehalfofOthers("Yes");
		
		PDFResultReport.addStepDetails("Modify the required below fields under 'Paying legal entity' section: \n"
					+ "2.Region:'ANZ' \n"
					+ "3.Paying Country \n"
					+ "4.Business \n"
					+ "5.Modality \n"
					+ "6.Legal Entity \n"
					+ "7.Select 'yes' for Are you submitting the request on behalf of others? \n"
					+ "8.Transaction Owner \n", 
					"Should be able to modify all the mandatory fields", 
					"Able to modify all the mandatory fields", "PASS", "N");
		
		PDFResultReport.addStepDetails("Enter below fields under 'Spend Details' section: \n"
					+"Spend Type:'Consulting(default)' \n"
					+"Spend Category:'Advisory Services' \n"
					+"Spend Sub Category:'Regulatory Advice'", 
					"Should be able to modify all the mandatory fields", 
					"Able to modify all the mandatory fields", "PASS", "Y");		
		
	}
	
	@Test(priority=5)
	public void amendServiceDetails() throws Exception{
		
		OneASTUtil.amendServiceDetails();
		OneASTUtil.amendContractTerm();
		OneASTUtil.amendFMVDetails("No","high");
		
	}
	
	@Test(priority=6)
	public void reassignandSubmitAmendWorkflow(){
		
		ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
				BaseClass.driver);
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
	
		OneASTUtil.clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.REASSIGN);
		BaseClass.waitForObj(4000);
		
		PDFResultReport.addStepDetails("Verify  Reassign option from the Other Actions dropdown and click on Reassign", 
				"Reassign this request To should get displayed", 
				"Reassign this request To get displayed", "PASS", "Y");

		BaseClass.set(approvalPage.reAssignSSO, ExcelReport.testData.get("TransactionOwnerUserName"));
		BaseClass.waitForObj(2000);
		BaseClass.click(approvalPage.searchButtonForReassign);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(8000);
		((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
				initiationPage.radioButtonForTransactionOwner);

		BaseClass.waitForObj(2000);		
		PDFResultReport.addStepDetails("Enter the SSO ID in Reassign To field and click on search button", "Search results should get displayed", 
				"Search results get displayed", "PASS", "Y");
		
		BaseClass.click(initiationPage.submitButtonForTransactionOwner);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(8000);				
		
		BaseClass.set(approvalPage.reasonForReassigningthisItemtoanotherUser,"Assigning to some other user");
		
		BaseClass.click(initiationPage.nextButton);
		
		PDFResultReport.addStepDetails("Click on Ok button", "WF get transfer to selected  super user", 
				"WF get transfer to selected  super user", "PASS", "Y");
	
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		OneASTUtil.loginandclickonOneASTRadioButton("TransactionOwnerUserName");
	
		BaseClass.waitForObj(2000);
		
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);

		BaseClass.waitForObj(2000);
		
		BaseClass.click(approvalPage.approvalFlowLink);
			
		if(status.equalsIgnoreCase("Pending-AgreementInitiation"))	{
		
		PDFResultReport.addStepDetails("Login with the Reassigned Transaction owner for application and open the workflow ", 
				"Status should be Updated to Pending-AgreementIntiation", "Status is Updated to Pending-AgreementIntiation", "PASS", "Y");
		}
		
		BaseClass.click(consultingAgreementPage.submitButton);
		BaseClass.waitForObj(8000);		
	//	isElementPresent(approvalPage.confirmationMsg);
		
		PDFResultReport.addStepDetails("Click on [Submit] button", "'Wf should be assigned for Transaction Owner Approval and below Confirmation message should get displayed \n"
				+"'Agreement A-XXXX has been sent for Approval. Any change in status will be communicated via email. \n"

				+"Thank you' \n", 
				
				"'Agreement"+ agreementNumber + " has been sent for Approval. Any change in status will be communicated via email. \n"

				+"Thank you' \n", "PASS", "Y");
		
		BaseClass.switchToDefaultFrame();
		
		BaseClass.click(approvalPage.close);
	}
	 

	@Test(priority=7)
	public void amendAgreement_requestForInfo(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");	
		BaseClass.waitForObj(2000);
		String status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		BaseClass.click(approvalPage.approvalFlowLink);
		
		if(status.equalsIgnoreCase("Pending-Approval"))	{
		
		PDFResultReport.addStepDetails("Open the workflow ", 
				"Status should be Updated to Pending-Approval ", "Status is Updated to Pending-Approval ", "PASS", "Y");
		}	
		
		OneASTUtil.clickOnOtherActionsAndSelectRequestForMoreInformation("Clarification Required","Test Request for Infor");
		
		PDFResultReport.addStepDetails("Enter the below fields 'Reason' and 'Requested info'  and click on [Submit] button", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				+ "2. The Agreement should be sent to Intiation", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you \n"
				+ "2. The Agreement is sent to Intiation", "PASS", "Y");
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		BaseClass.waitForObj(2000);
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
		BaseClass.waitForObj(2000);	
		
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		OneASTUtil.loginandclickonOneASTRadioButton("TransactionOwnerUserName");
	
		BaseClass.waitForObj(2000);
				
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
				
		BaseClass.click(approvalPage.approvalFlowLink);	
		
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		
		BaseClass.select(initiationPage.spendCategoryDropDown, "Product Training");
		BaseClass.waitForObj(5000);
		
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);				
		
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		
		BaseClass.click(approvalPage.submitButton);
		BaseClass.waitForObj(8000);
		
		//new Actions(BaseClass.driver).moveToElement(approvalPage.)
		PDFResultReport.addStepDetails("Modify the Required changes and Navigate to 'Summary tab' and click on [Submit] button", 
				
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				+ "2. The Agreement should be pending with TO of the Agreement.", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you \n"
				+ "2. The Agreement is pending with TO of the Agreement.", "PASS", "Y");
		
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
				
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("Login with the Transaction owner for application and open the workflow ", 
				"Status should be Updated to Pending-Approval ", 
				"Status is Updated to Pending-Approval ", "PASS", "Y");
				
		BaseClass.click(approvalPage.approvalFlowLink);	
		BaseClass.waitForObj(2000);
		
		BaseClass.click(approvalPage.approveButton);
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("Click on Approve button", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				
				+ "2. The Agreement should be pending with  Direct Manager of the Agreement ", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				+ "2. The Agreement is pending with IPPCOE of the Agreement ", "PASS", "Y");
		
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
		BaseClass.waitForObj(5000);		
		
	}
	
	@Test(priority=8)
	public void ippCOEapproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName");
		
		status=OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		new Actions(BaseClass.driver).moveToElement(approvalPage.IPPCOEName).build().perform();
		System.out.println(BaseClass.text(approvalPage.IPPCOEName));		
		
		BaseClass.click(approvalPage.approvalFlowLink);
		
		if(status.equalsIgnoreCase("Pending-Approval")){
			
			PDFResultReport.addStepDetails("Login with the IPPCOE application and open the workflow",
					"Status should be Updated to Pending-Approval ",
					"Status is Updated to Pending-Approval ","PASS","Y");			
		}
		
		BaseClass.click(approvalPage.approveButton);
		
		BaseClass.waitForObj(5000);
		
		
		PDFResultReport.addStepDetails("Click on Approve button", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				
				+ "2. The Agreement should be pending with  Direct Manager of the Agreement ", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				+ "2. The Agreement is pending with  Direct Manager of the Agreement ", "PASS", "Y");
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);		
		
	}
	
	@Test(priority=9)
	public void directManagerApproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("DirectManagerName");
		String status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		BaseClass.click(approvalPage.approvalFlowLink);
		
		if(status.equalsIgnoreCase("Pending-Approval")){
			
			PDFResultReport.addStepDetails("Login with the Direct Manager application and open the workflow",
					"Status should be Updated to Pending-Approval ",
					"Status is Updated to Pending-Approval ","PASS","Y");
			
		}
		
		BaseClass.click(approvalPage.approveButton);
		
		BaseClass.waitForObj(5000);
		
		
		PDFResultReport.addStepDetails("Click on Approve button", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				
				+ "2. The Agreement should be pending with IPPCOE of the Agreement ", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				+ "2. The Agreement is pending with  IPPCOE of the Agreement ", "PASS", "Y");
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
				
		
	}
	
	@Test(priority=10)
	public void activateAgreement(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName");
	
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);		
		
		if(status.equalsIgnoreCase("Pending-Approval")){
			
			PDFResultReport.addStepDetails("Login with the IPPCOE application and open the workflow",
					"Status should be Updated to Pending-Approval ",
					"Status is Updated to Pending-Approval ","PASS","Y");
			
		}		
		
		OneASTUtil.activateAgreement("TestData.xlsx",status);
				
		PDFResultReport.addStepDetails("Upload the Required document and click on [Submit] button", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				
				+ "2. The Agreement status should be resolved completed", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				+ "2. The Agreement status is resolved completed", "PASS", "Y");
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("Click on logout from the user dropdown", 
				"User should be logged out of the application", "User should be logged out of the application", "PASS", "Y");
		
				
	}
	
	


}
