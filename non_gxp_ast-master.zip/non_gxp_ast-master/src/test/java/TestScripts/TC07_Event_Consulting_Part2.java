package TestScripts;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.CommonUtils;
import Components.LoginUtils;
import Components.OneASTHomePageUtils;
import Components.OneASTUtil;
import Components.PeagDesignerStudioHomePageUtils;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.AggregateSpendManagementPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.HomePage;
import ObjectRepository.InitiationPage;
import ObjectRepository.LogInPage;
import ObjectRepository.OneASTHomePage;
import ObjectRepository.PeagDesignerStudioHomePage;
public class TC07_Event_Consulting_Part2 extends BaseClass
{
	public String eventNumber="E-338450",statusOfEvent;
	public HomePage homePage;
	public ArrayList<String> tabs;
	public ApprovalPage approvalPage;
	public LogInPage loginPage;
	public AggregateSpendManagementPage aggregateSpendManagementPage;
	public InitiationPage initiationPage;
	public AggregateSpendManagementNonUSPage aggregateSpendManagementNonUSPage;
	public PeagDesignerStudioHomePage peagDesignerStudioHomePage;
	public String additionalApprovar;
	public OneASTHomePage oneASTHomePage;
	public ConsultingAgreementPage consultingAgreementPage;
	public String ComplianceSSO;
	@Test(priority = 0,description = "")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "DOC1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "1");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "502616490");
			reportDetails.put("Name of Automation Test Script Author", "Pavan Yarlagadda");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "DOC1234567");
		reportDetails.put("Requirement ID", "");
	}
	/**
	 * Step No : 10
	 */
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{
			/*loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Login to the Appliaction as Super User entering the valid credentials and \n"
									+ "Click on login button present in the page\n"
									+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
									+ "username : 502618771\n" + "password: rules",
							"1.Login page with titleAggregate Spend Managementshould get displayed.\n"
									+ "2.The page should contain the text The Paying legal Entity of your interaction is based in with below two radio buttons:\n"
									+ " AST\n" + " Korea Tracking Code",
							"Aggregate Spend Management page is displayed.", "PASS", "N");*/
			LogInPage loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "userName", "password");
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Login to the Appliaction as Super User entering the valid credentials and \n"
									+ "Click on login button present in the page\n"
									+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
									+ "username : 502618771\n" + "password: rules",
							"Aggregate Spend Management page shall be displayed.",
							"Aggregate Spend Management page is displayed.", "PASS", "N");
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			AggregateSpendManagementPage aggregateSpendManagementPage = new AggregateSpendManagementPage(
					driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			PDFResultReport.addStepDetails("Select OneAST User portal from launch icon\n"
					+ "(In case you logged in as Admin, else OneAST page directly opened)",
					" AST page should get displayed.", " AST page is get displayed.", "PASS", "N");
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
	
			approvalPage = new ApprovalPage(driver);
		
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfEvent.equalsIgnoreCase("Pending-PORequisition"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the transaction owner.\n"
										+ "3.The Status of the Workflow should be Pending-PORequisition.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the super owner.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
			click(approvalPage.approvalFlowLink);	
			BaseClass.waitForObj(2000);
			if(text(approvalPage.sspPONumberReceived_Status).equalsIgnoreCase("SSP PO Number Received")){
				
				System.out.println("SSP PO Number: " +text(approvalPage.sspPONumber));
			}
			click(approvalPage.submitButton);
			BaseClass.waitForObj(2000);
		
			if (initiationPage.confirmationMessageOnSubmission
					.getText()
					.trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ " Has Been Submitted For Further Process"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on [Submit] button",
								"Wf should be assigned for Transaction Owner Approval and below Confirmation message should get displayed\n"
										+ " Event E-XXXX has been submitted for Approval.\n"
										+ "Any change in status will be communicated via email.\n"
										+ "Thank you",
								"Wf is assigned for Transaction Owner Approval and below Confirmation message should get displayed\n"
										+ " "
										+ initiationPage.confirmationMessageOnSubmission.getText()
										+ "", "PASS", "Y");
			}
			OneASTUtil.closeEventOrAgreement();	
		
			//Pending-Finalize/Reconcile
		
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfEvent.equalsIgnoreCase("Pending-Finalize/Reconcile"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the ippcoe .\n"
										+ "3.The Status of the Workflow should be Pending-Finalize/Reconcile.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the ippcoe .\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
			"PASS", "Y");
			}
						
			click(approvalPage.approvalFlowLink);	
			BaseClass.waitForObj(2000);
			
			/**
			 * Finalize CR(S)
			 */
	
			OneASTUtil.finalizeCRs();
		
			BaseClass.waitForObj(2000);
			/**
			 * Finalize/Reconcile Budget
			 */
			
			OneASTUtil.finalizeRecouncilBudgetSubmittion("All Attendees");
			BaseClass.waitForObj(2000);
			
			/**
			 *   Uploads
			 */
			OneASTUtil.clickOnUploadsTabAndUploadTheFilesInFinalizeReconcile("TestData.xlsx");
			BaseClass.waitForObj(2000);
			BaseClass.click(initiationPage.nextButton);
			BaseClass.waitForObj(2000);
			
			if (initiationPage.confirmationMessageOnSubmission
					.getText()
					.trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ " has been submitted for Proof of Delivery approval. Any change in status will be communicated via email."))
			{
				PDFResultReport
						.addStepDetails(
								"Click on [Submit] button",
								"Wf should be assigned for IPPCOE Approval and below Confirmation message should get displayed\n"
										+ " Event E-XXXX has been submitted for Proof of Delivery Approval.\n"
										+ "Any change in status will be communicated via email.\n"
										+ "Thank you",
								"Wf is assigned for IPPCOE Approval and below Confirmation message should get displayed\n"
										+ " "
										+ initiationPage.confirmationMessageOnSubmission.getText()
										+ "", "PASS", "Y");
			}
			OneASTUtil.closeEventOrAgreement();
			OneASTUtil.logOutFromAppalication();
		
					
			/**
			 *    Pending-ProofOfDelivery
			 */
			
			
			OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName"); 
			waitForObj(5000);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			waitForObj(2000);
			OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();
			waitForObj(2000);
			OneASTUtil.selectDateOfApprovalFromCalender(0);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(2000);
			click(initiationPage.submitButton);
			
			if (initiationPage.confirmationMessageOnSubmission
					.getText()
					.trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ " has been submitted for Proof of Delivery approval. Any change in status will be communicated via email."))
			{
				PDFResultReport
						.addStepDetails(
								"Click on [Submit] button",
								"Wf should be assigned for IPPCOE Approval and below Confirmation message should get displayed\n"
										+ " Event E-XXXX has been submitted for Proof of Delivery Approval.\n"
										+ "Any change in status will be communicated via email.\n"
										+ "Thank you",
								"Wf is assigned for IPPCOE Approval and below Confirmation message should get displayed\n"
										+ " "
										+ initiationPage.confirmationMessageOnSubmission.getText()
										+ "", "PASS", "Y");
			}
			
			OneASTUtil.closeEventOrAgreement();
			OneASTUtil.logOutFromAppalication();
			
			waitForObj(15000);
			
			OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName"); 
			waitForObj(2000);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			
			statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfEvent.equalsIgnoreCase("Pending-Closure"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the ippcoe .\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the ippcoe .\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
										"PASS", "Y");
			}
		
			OneASTUtil.closeEventOrAgreement();
			OneASTUtil.logOutFromAppalication();
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
