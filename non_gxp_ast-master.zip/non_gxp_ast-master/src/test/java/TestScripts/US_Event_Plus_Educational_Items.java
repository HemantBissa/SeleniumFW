package TestScripts;

import java.util.ArrayList;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.AggregateSpendManagementUtils;
import Components.CommonUtils;
import Components.LoginUtils;
import Components.PeagDesignerStudioHomePageUtils;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.AggregateSpendManagementPage;
import ObjectRepository.AggregateSpendManagementUSPage;
import ObjectRepository.HomePage;
import ObjectRepository.LogInPage;
import ObjectRepository.PeagDesignerStudioHomePage;

public class US_Event_Plus_Educational_Items extends BaseClass
{
	public HomePage homePage;
	public ArrayList<String> tabs;
	public String eventId;
	public String caseId;
	public String userOne = ExcelReport.testData.get("userName");
	public String userTwo = ExcelReport.testData.get("userTwo");
	@Test(priority = 0, description = "US Event Plus Educational Items")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "Doc1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "7");
		if(ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		}else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "Pavan Yarlagadda");
			reportDetails.put("Name of Automation Test Script Author", "502616490");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "Doc1234567");
		reportDetails.put("Requirement ID", "");
	}
	@Test(priority = 1)
	public void uSEventPlusEducationalItems()
	{
		try
		{
			/**
			 * Step No : 10
			 */
			LogInPage loginPage = new LogInPage(driver);
			BaseClass.launchApplication(ExcelReport.testData.get("url"));
			/*launchApp(ExcelReport.testData.get("url"));*/
			PDFResultReport.addStepDetails(
					"Login to the portal with the Requester " + ExcelReport.testData.get("url")
							+ " with the SSO.",
					"Login page should be displayed. ", "'Login page is displayed. ", "PASS", "Y");
			/**
			 * Step No : 20
			 */
			LoginUtils.loginIntoApplication(loginPage, "userName", "password");
			waitForObj(10000);
			homePage = new HomePage(driver);
			if(getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				PDFResultReport.addStepDetails(
						"Enter SSOID <User1> and password.\n" + "Click on the [Login] button.\n"
								+ "Click on the Launch link dropdown and \n"
								+ "Click on the Launch portal option",
						"Aggregate Spend Management page shall be displayed in a new tab.",
						"Aggregate Spend Management page is displayed in a new tab.", "PASS", "Y");
			}
			/**
			 * Step No : 30
			 */
			AggregateSpendManagementPage aggregateSpendManagementPage = new AggregateSpendManagementPage(
					driver);
			click(aggregateSpendManagementPage.usRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			AggregateSpendManagementUSPage aggregateSpendManagementUSPage = new AggregateSpendManagementUSPage(
					driver);
			waitForObj(5000);
			boolean searchBox = isElementPresent(aggregateSpendManagementUSPage.searchBox);
			boolean workFlow = isElementPresent(aggregateSpendManagementUSPage.menuLinks.get(0));
			boolean recipients = isElementPresent(aggregateSpendManagementUSPage.menuLinks.get(1));
			boolean switchApplication = isElementPresent(
					aggregateSpendManagementUSPage.menuLinks.get(2));
			boolean myWork = isElementPresent(
					aggregateSpendManagementUSPage.linksInDashboard.get(0));
			boolean reAssignedWorkFlow = isElementPresent(
					aggregateSpendManagementUSPage.linksInDashboard.get(1));
			boolean myItems = isElementPresent(
					aggregateSpendManagementUSPage.linksInDashboard.get(2));
			boolean links = isElementPresent(
					aggregateSpendManagementUSPage.linksInDashboard.get(3));
			if(searchBox && workFlow && reAssignedWorkFlow && recipients && switchApplication
					&& myItems && myWork && links == true)
			{
				PDFResultReport.addStepDetails("Select United States and click on Submit button.",
						"User should be logged in to Aggregate Spend Management portal.\n"
								+ "In the Portal the following  will be displayed\n"
								+ "Search box,\n" + "Workflow,\n" + "Recipients,\n"
								+ "Switch to Application\n" + "Recent Items on the left My Work,\n"
								+ "Reassigned Items,\n" + "My Items,\n" + "and Links",
						"User is logged in to Aggregate Spend Management portal.\n"
								+ "In the Portal the following are displayed\n" + "Search box,\n"
								+ "Workflow,\n" + "Recipients,\n" + "Switch to Application\n"
								+ "Recent Items on the left My Work,\n" + "Reassigned Items,\n"
								+ "My Items,\n" + "and Links",
						"PASS", "Y");
			}else
			{
				PDFResultReport.addStepDetails("Select United States and click on Submit button.",
						"User should be logged in to Aggregate Spend Management portal.\n"
								+ "In the Portal the following  will be displayed\n"
								+ "Search box,\n" + "Workflow,\n" + "Recipients,\n"
								+ "Switch to Application\n" + "Recent Items on the left My Work,\n"
								+ "Reassigned Items,\n" + "My Items,\n" + "and Links",
						"In the Portal the following are not displayed\n" + "Search box,\n"
								+ "Workflow,\n" + "Recipients,\n" + "Switch to Application\n"
								+ "Recent Items on the left My Work,\n" + "Reassigned Items,\n"
								+ "My Items,\n" + "and Links",
						"PASS", "Y");
			}
			/**
			 * Step No : 40
			 */
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.WORK_FLOW,
					AggregateSpendManagementNonUSPage.EVENT, true,
					AggregateSpendManagementNonUSPage.NEW_EVENTS_PLUS);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			eventId = text(aggregateSpendManagementUSPage.eventId);
			System.out.println("Event Id is : " + eventId);
			BaseClass.switchFrame(aggregateSpendManagementUSPage.pegaGadgetFrame0);
			System.out.println("Switched to the Frame '0' Successfully");
			PDFResultReport.addStepDetails(
					"Select the radio button Non-US \n" + "Click on [Submit] button \n"
							+ "Click on the Workflow link - Event - New EventPlus option",
					"New Event shall be open in a new tab with Case ID as E-XXXXXX and \n"
							+ "status of Event shall be displayed as Pending-EventInitiation",
					"New Event is opened in a new tab with Case ID as " + eventId
							+ " and status of event is displayed with "
							+ text(aggregateSpendManagementUSPage.statusOfObject) + "",
					"PASS", "Y");
			/**
			 * Step No : 50
			 */
			select(aggregateSpendManagementUSPage.eventPlusTypeDropDown, "Educational Items");
			click(aggregateSpendManagementUSPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			boolean coveredRecipients = isElementPresent(
					aggregateSpendManagementUSPage.tabsUnderWorkFlows.get(0));
			String coveredRecipientsText = text(
					aggregateSpendManagementUSPage.tabsUnderWorkFlows.get(0));
			if(coveredRecipients
					&& coveredRecipientsText.equalsIgnoreCase("Covered Recipients") == true)
			{
				PDFResultReport.addStepDetails(
						"Select EventsPlus Type as Educational Items from the drop down,\n"
								+ "then click on Submit button",
						"The Covered Recipients tab will be displayed",
						"The " + coveredRecipientsText + " tab is displayed", "PASS", "Y");
			}else
			{
				PDFResultReport.addStepDetails(
						"Select EventsPlus Type as Educational Items from the drop down,\n"
								+ "then click on Submit button",
						"The Covered Recipients tab will be displayed",
						"The Covered Recipients tab is not displayed", "PASS", "Y");
			}
			/**
			 * Step No : 60
			 */
			set(aggregateSpendManagementUSPage.lastName, "test");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			click(aggregateSpendManagementUSPage.buttons.get(1));				
			waitForObj(5000);
			PDFResultReport.addStepDetails(
					"Enter Last Name and Last Name of CR Individual and click on search.",
					"'Search results should get display.", "'Search results is display.",
					"PASS", "Y");
			/**
			 * Step No : 70	
			 */
			click(AggregateSpendManagementUtils.selectRadioButtonFromSearchResultTable(
					"100006819927", false, StringUtils.EMPTY));  //100006819264
			//click(aggregateSpendManagementUSPage.individualSearchresultsTableRadioButton.get(0));
			waitForObj(5000);
			click(aggregateSpendManagementUSPage.okButtonInModalPopUp);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			click(aggregateSpendManagementUSPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			boolean educationalItems = isElementPresent(
					aggregateSpendManagementUSPage.tabsUnderWorkFlows.get(1));
			String educationalItemsTab = text(
					aggregateSpendManagementUSPage.tabsUnderWorkFlows.get(1));
			if(educationalItems
					&& educationalItemsTab.equalsIgnoreCase("Educational Items") == true)
			{
				PDFResultReport.addStepDetails(
						"Select the CR from Search result and click on Next Button",
						"The Educational Items tab will be displayed",
						"The "+educationalItemsTab+" tab is be displayed", "PASS", "Y");
			}
			else
			{
				PDFResultReport.addStepDetails(
						"Select the CR from Search result and click on Next Button",
						"The Educational Items tab will be displayed",
						"The Educational Items tab is not be displayed", "PASS", "Y");
			}
			/**
			 * Step No : 80
			 */
			select(aggregateSpendManagementUSPage.businessDropDown, "HCIT");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(aggregateSpendManagementUSPage.businessDropDown, "Select...");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(aggregateSpendManagementUSPage.businessDropDown, "HCIT");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			click(aggregateSpendManagementUSPage.questionMarkImg);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			select(aggregateSpendManagementUSPage.modalityDropDown, "HCIT");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(aggregateSpendManagementUSPage.modalityDropDown, "Select...");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(aggregateSpendManagementUSPage.modalityDropDown, "HCIT");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(aggregateSpendManagementUSPage.subModalityDropDown, "HCIT");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(aggregateSpendManagementUSPage.productDropDown, "Investigational");
			waitForObj(3000);
			if(!defaultDropDownSelectedItem(aggregateSpendManagementUSPage.businessDropDown)
					.equalsIgnoreCase("")
					&& !defaultDropDownSelectedItem(aggregateSpendManagementUSPage.modalityDropDown)
							.equalsIgnoreCase("")
					&& !defaultDropDownSelectedItem(
							aggregateSpendManagementUSPage.subModalityDropDown).equalsIgnoreCase("")
					&& !defaultDropDownSelectedItem(aggregateSpendManagementUSPage.productDropDown)
							.equalsIgnoreCase("") == true)
				PDFResultReport
						.addStepDetails(
								"Select BMPS under Business and Product section \n"
										+ "Verify that BMPS values are displayed with selected values",
								"BMPS values shall be displayed with selected values",
								"BMPS values are displayed with selected values\n" + "Business: "
										+ defaultDropDownSelectedItem(
												aggregateSpendManagementUSPage.businessDropDown)
										+ " \n" + "Modality:"
										+ defaultDropDownSelectedItem(
												aggregateSpendManagementUSPage.modalityDropDown)
										+ " \n" + "SubModality: "
										+ defaultDropDownSelectedItem(
												aggregateSpendManagementUSPage.subModalityDropDown)
										+ " \n" + "Product: "
										+ defaultDropDownSelectedItem(
												aggregateSpendManagementUSPage.productDropDown)
										+ "",
								"PASS", "Y");
			/**
			 * Step No : 90
			 */
			click(aggregateSpendManagementUSPage.plusIconToAdd);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			click(aggregateSpendManagementUSPage.transactionCalender);
			waitForObj(5000);
			BaseClass.isElementPresent(aggregateSpendManagementUSPage.todayLink);
			/*waitUntilElementDispalyed(driver, aggregateSpendManagementUSPage.todayLink);*/
			click(aggregateSpendManagementUSPage.todayLink);
			waitForObj(5000);
			select(aggregateSpendManagementUSPage.categoryDropDown, "Education");
			waitForObj(5000);
			set(aggregateSpendManagementUSPage.quantity, "1");
			waitForObj(2000);
			new Actions(driver).moveToElement(aggregateSpendManagementUSPage.currency).build().perform();
			BaseClass.isElementPresent(aggregateSpendManagementUSPage.quantity);
			/*waitUntilElementDispalyed(driver, aggregateSpendManagementUSPage.quantity);*/
			set(aggregateSpendManagementUSPage.valuePerItem, "1");
			new Actions(driver).moveToElement(aggregateSpendManagementUSPage.currency).build().perform();
			BaseClass.isElementPresent(aggregateSpendManagementUSPage.valuePerItem);
			/*waitUntilElementDispalyed(driver, aggregateSpendManagementUSPage.valuePerItem);*/
			click(aggregateSpendManagementUSPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			PDFResultReport.addStepDetails(
					"Click on + symbol and provide the Transaction details.\n"
							+ "Click on the next button \n" + "Verify that \n"
							+ "Quote for Value of Item and \n"
							+ "Request from Organizer/CR are displayed as mandtory attachments",
					"Uploads tab shall be displayed with \n" + "Quote for Value of Item and \n"
							+ "Request from Organizer/CR are displayed as mandtory attachments",
					"Uploads tab is displayed with \n" + "Quote for Value of Item and \n"
							+ "Request from Organizer/CR are displayed as mandtory attachments",
					"PASS", "PASS");
		}catch (Exception e)
		{
			e.printStackTrace();
			e.getMessage();
		}
	}
}