package TestScripts;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.AggregateSpendManagementUtils;
import Components.OneASTUtil;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;

public class TC02_AmendAgreement_ServicePayments_Reject_DM extends BaseClass
{
	public String agreementNumber;
	public String status;
	
	@Test(priority = 0,description = "Aggregate Spend Management Tool POC")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "Doc1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "7");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "Sindhu Vankadari");
			reportDetails.put("Name of Automation Test Script Author", "502616489");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "Doc1234567");
		reportDetails.put("Requirement ID", "");
	}
	
	/**
	 * Step No : 10
	 */
	
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{	
			OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
			PDFResultReport.addStepDetails(
					"Login to the Appliaction as Super User entering the valid credentials and \n"
							+ "Click on login button present in the page\n"
							+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
							+ "username : <Super user 1>\n" + "password: <pswd 1>",
					"Login page with title 'Aggregate Spend Management' should get displayed.",
					"Login page with title 'Aggregate Spend Management' get displayed.", "PASS", "N");
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	
	/**
	 * Step No : 20
	 * @throws Exception 
	 */
	@Test(priority = 2)
	public void clickOnAgreementAndSelectNewConsultingAgrseement() throws Exception
	{
		
		OneASTUtil.amendAgreementandSearchOptions(ExcelReport.testData.get("TC02_searchType_AmendAgreement"));
		
		
	}

	
	@Test(priority=3)
	public void amendDetails() throws Exception{
		
		OneASTUtil.selectSectiontoAmend(ExcelReport.testData.get("TC02_AmendDetails"));
		
		
		PDFResultReport.addStepDetails("Select \"Yes\" for Amend  'Service Payments'", 
				"1. The screen should be navigated to the 'Business Information' section.\n"
				+ "2. The 'Business Information' section should contain 2 sub -sections\n"
				+ "- Legal Enity \n"
				+ "- Spend category", 
				"1. The screen is navigated to the 'Business Information' section.\n"
						+ "2. The 'Business Information' section contain 2 sub -sections\n"
						+ "- Legal Enity \n"
						+ "- Spend category", "PASS", "Y");
	}

	
	@Test(priority=4)
	public void amendBusinessInformation() throws Exception
	{
	
		
		OneASTUtil.enterTheValuesInBusinessInformationTab("Americas", "Canada", "Canada",
		"Detection & Guidance Solutions (DGS)", "Interventional",
		"050179-General Electric Canada", "Innova IGS 620", "Covered", "Yes", ExcelReport.testData.get("TransactionOwnerUserName"),"", "Product Input", ""); 
		
		PDFResultReport.addStepDetails("Modify the required below fields under 'Paying legal entity' section: \n"
					+"1.Pole:'Americas' \n"
					+ "2.Region:'Canada' \n"
					+ "3.Paying Country \n"
					+ "4.Business \n"
					+ "5.Modality \n"
					+ "6.Legal Entity \n"
					+ "7.Select 'yes' for Are you submitting the request on behalf of others? \n"
					+ "8.Transaction Owner \n", 
					"Should be able to modify all the mandatory fields", 
					"Able to modify all the mandatory fields", "PASS", "N");
		
		PDFResultReport.addStepDetails("Enter below fields under 'Spend Details' section: \n"
					+"Spend Type:'Consulting(default)' \n"
					+"Spend Category:'Product Input' \n"
					+"Spend Sub Category:'Review or Input for publication'", 
					"Should be able to modify all the mandatory fields", 
					"Able to modify all the mandatory fields", "PASS", "Y");		
		
	}
	
	@Test(priority=5)
	public void amendServiceDetails() throws Exception{
		
		OneASTUtil.amendServiceDetails();
		OneASTUtil.amendContractTerm();
		OneASTUtil.amendFMVDetails("no","high");
				
	}
	
	@Test(priority=6)
	public void submitAmendWorkflow(){
		
		ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
				BaseClass.driver);
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			
		BaseClass.click(consultingAgreementPage.submitButton);
		BaseClass.waitForObj(8000);		
	//	isElementPresent(approvalPage.confirmationMsg);
		
		PDFResultReport.addStepDetails("Click on [Submit] button", "'Wf should be assigned for Transaction Owner Approval and below Confirmation message should get displayed \n"
				+"'Agreement A-XXXX has been sent for Approval. Any change in status will be communicated via email. \n"

				+"Thank you' \n", 
				
				"'Agreement"+ agreementNumber + " has been sent for Approval. Any change in status will be communicated via email. \n"

				+"Thank you' \n", "PASS", "Y");
		
		BaseClass.switchToDefaultFrame();
		
		BaseClass.click(approvalPage.close);
	}
	 

	@Test(priority=7)
	public void transactionOwnerApproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("TransactionOwnerUserName");
				
		status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("Login with the Transaction owner for application and open the workflow ", 
				"Status should be Updated to Pending-Approval ", 
				"Status is Updated to Pending-Approval ", "PASS", "Y");
				
		BaseClass.click(approvalPage.approvalFlowLink);	
		BaseClass.waitForObj(2000);
		
		BaseClass.click(approvalPage.approveButton);
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("Click on Approve button", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				
				+ "2. The Agreement should be pending with  Direct Manager of the Agreement ", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				+ "2. The Agreement is pending with IPPCOE of the Agreement ", "PASS", "Y");
		
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
		BaseClass.waitForObj(5000);		
		
	}
	
	@Test(priority=8)
	public void ippCOEapproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName");
		
		status=OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		new Actions(BaseClass.driver).moveToElement(approvalPage.IPPCOEName).build().perform();
		System.out.println(BaseClass.text(approvalPage.IPPCOEName));		
		
		BaseClass.click(approvalPage.approvalFlowLink);
		
		if(status.equalsIgnoreCase("Pending-Approval")){
			
			PDFResultReport.addStepDetails("Login with the IPPCOE application and open the workflow",
					"Status should be Updated to Pending-Approval ",
					"Status is Updated to Pending-Approval ","PASS","Y");			
		}
		
		BaseClass.click(approvalPage.approveButton);
		
		BaseClass.waitForObj(5000);
		
		
		PDFResultReport.addStepDetails("Click on Approve button", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				
				+ "2. The Agreement should be pending with  Direct Manager of the Agreement ", 
				"1. The Agreement should be submitted successfully and below message should be displayed. \n"

				+ "Agreement "+agreementNumber +" has been submitted for Approval. Any change in status will be communicated via email. \n"

				+ "Thank you"
				+ "2. The Agreement is pending with  Direct Manager of the Agreement ", "PASS", "Y");
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);		
		
	}
	
	@Test(priority=9)
	public void directManagerApproval(){
		
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.loginandclickonOneASTRadioButton("DirectManagerName");
		String status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
		
		BaseClass.click(approvalPage.approvalFlowLink);
		
		if(status.equalsIgnoreCase("Pending-Approval")){
			
			PDFResultReport.addStepDetails("Login with the Direct Manager application and open the workflow",
					"Status should be Updated to Pending-Approval ",
					"Status is Updated to Pending-Approval ","PASS","Y");
			
		}
		
		OneASTUtil.clickOnOtherActionsAndSelectReject("Duplicate Workflow Request", "Reject the agreement");
		
		OneASTUtil.isElementPresent(approvalPage.confirmationMsg);
		
		String msg = text(approvalPage.rejectMsg);
		
		status = BaseClass.text(approvalPage.status);
		
		if(msg.contains("rejected") && status.equalsIgnoreCase("Resolved-Rejected")){
			
			System.out.println("Agreement Rejected");
		}else{
			
			System.out.println("Agreement not rejected");
		}
		
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
			AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("'Click on logout from the user dropdown", 
				"'User should be logged out of the application",
				"'User should be logged out of the application", "PASS", "Y");
	}
	
	
	
	


}
