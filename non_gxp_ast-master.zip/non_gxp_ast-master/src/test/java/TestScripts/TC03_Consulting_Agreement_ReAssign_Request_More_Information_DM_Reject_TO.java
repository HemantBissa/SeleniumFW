package TestScripts;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.AggregateSpendManagementUtils;
import Components.CommonUtils;
import Components.JdbcConnection;
import Components.LoginUtils;
import Components.OneASTHomePageUtils;
import Components.OneASTUtil;
import Components.PeagDesignerStudioHomePageUtils;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.AggregateSpendManagementPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.HomePage;
import ObjectRepository.InitiationPage;
import ObjectRepository.LogInPage;
import ObjectRepository.OneASTHomePage;
import ObjectRepository.PeagDesignerStudioHomePage;
public class TC03_Consulting_Agreement_ReAssign_Request_More_Information_DM_Reject_TO extends
		BaseClass
{
	public static String agreementNumber;
	public HomePage homePage;
	public ArrayList<String> tabs;
	public String ippCoe;
	public String caseId;
	public String created;
	public String startDate;
	public String status;
	public String createdBy;
	public String pendingWith;
	public String transactionOwner;
	public String directManager;
	public String complainceEscalation;
	public ApprovalPage approvalPage;
	public LogInPage loginPage;
	public AggregateSpendManagementPage aggregateSpendManagementPage;
	public ConsultingAgreementPage consultingAgreementPage;
	public InitiationPage initiationPage;
	public AggregateSpendManagementNonUSPage aggregateSpendManagementNonUSPage;
	public PeagDesignerStudioHomePage peagDesignerStudioHomePage;
	public String additionalApprovar;
	public OneASTHomePage oneASTHomePage;
	@Test(priority = 0,description = "Verify that Super User(Requestor) is able to create the new Consulting Agreement -Product Training.\n"
			+ "1. Add new CR  Org and Add new Service provider\n"
			+ "2. Product Training - Masters Series\n"
			+ "3. Request on behalf of No\n"
			+ "4. Pole - ASIA APAC Region - South Asia\n"
			+ "5. Request more Info - DM and Reject at TO")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "DOC1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "1");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "502616490");
			reportDetails.put("Name of Automation Test Script Author", "Pavan Yarlagadda");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "DOC1234567");
		reportDetails.put("Requirement ID", "");
	}
	/**
	 * Step No : 10
	 */
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "superUserUserName", "password");
			waitForObj(8000);
			PDFResultReport
					.addStepDetails(
							"Login to the Appliaction as Super User entering the valid credentials and \n"
									+ "Click on login button present in the page\n"
									+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
									+ "username : 502618771\n" + "password: rules",
							"1.Login page with titleAggregate Spend Managementshould get displayed.\n"
									+ "2.The page should contain the text The Paying legal Entity of your interaction is based in with below two radio buttons:\n"
									+ "â€¢ AST\n" + "â€¢ Korea Tracking Code",
							"Aggregate Spend Management page is displayed.", "PASS", "N");
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			PDFResultReport.addStepDetails("Select OneAST User portal from launch icon\n",
					" AST page should get displayed.", " AST page is get displayed.", "PASS", "N");
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(18000);
			/**
			 * Step No : 30
			 */
			OneASTHomePageUtils.selectItemFromMenuPanelInOneASTHomePage(BaseClass.driver,
					OneASTHomePage.AGREEMENT, OneASTHomePage.NEW_CONSULTING_AGREEMENT, false, "");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.switchToDefaultFrame();
			agreementNumber = OneASTUtil.getEventOrAgreementNumber();
			OneASTUtil.agreementNumber = agreementNumber;
			System.out.println("Agreement Number :: " + agreementNumber);
			consultingAgreementPage = new ConsultingAgreementPage(BaseClass.driver);
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);
			PDFResultReport
					.addStepDetails(
							"Navigate to Workflow --> Agreement --> New Consulting Agreement",
							"1.A Consulting Agreement with case id <A-xxx> should be created \n"
									+ "And radio buttons with below labels should get displayed in Select CR page.\n"
									+ "	i.Individual\n" + "	ii.Organization\n"
									+ "2.The status of the Agreement should be displayed as New.",
							"1.A Consulting Agreement with case id "
									+ agreementNumber
									+ " is created \n"
									+ "And radio buttons with below labels is displayed in Select CR page.\n"
									+ "	i.Individual\n"
									+ "	ii.Organization\n"
									+ "2.The status of the Agreement is displayed as "
									+ BaseClass
											.text(consultingAgreementPage.statusOfAgreementOrEvent)
									+ ".", "PASS", "Y");
			/**
			 * Step No : 40
			 */
			consultingAgreementPage = new ConsultingAgreementPage(BaseClass.driver);
			switchToDefaultFrame();
			BaseClass.waitForObj(5000);
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);
			BaseClass.click(consultingAgreementPage.organizationRadioButton);
			BaseClass.click(consultingAgreementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			boolean crOrganizationTab = isElementPresent(consultingAgreementPage.crOrganizationTab);
			System.out.println("Tab Status : " + crOrganizationTab);
			status = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (crOrganizationTab && status.trim().equalsIgnoreCase("Pending-AgreementInitiation"))
			{
				PDFResultReport
						.addStepDetails(
								"Select the Organization radio button and click on [Submit] button.",
								"1)The screen should navigate to CR Organization Search page with below tabs.\n"
										+ "	1.CR Organization\n"
										+ "	2.History.\n"
										+ "2)The status of the Agreement should be displayed as Pending-AgreementInitiation",
								"1)The screen is navigate to CR Organization Search page with below tabs.\n"
										+ "	1.CR Organization\n" + "	2.History.\n"
										+ "2)The status of the Agreement is displayed as "
										+ text(consultingAgreementPage.statusOfAgreementOrEvent)
										+ "", "PASS", "Y");
			}
			/**
			 * Step No : 50
			 */
			// TODO
			/**
			 * Step No : 60
			 */
			initiationPage = new InitiationPage(driver);
			BaseClass.click(initiationPage.addNewOrganizationButton);
			BaseClass.waitForObj(8000);
			String title = BaseClass.text(initiationPage.titleAddNewCRIndividual);
			if (title.equalsIgnoreCase("Add New CR Organization"))
			{
				PDFResultReport
						.addStepDetails(
								"Create a new CR organization by clicking on 'Add New Organization' button ",
								"Add New CR Organization overlay should open with below fields: Organization Type Section\n"
										+ "a) Organization Type â€“ mandatory drop down Name Section\n"
										+ "b) Name of Organization â€“ mandatory open text field\b"
										+ "c) Department/Section - open text field Contact Section\n"
										+ "d) Country/State - mandatory drop down\n"
										+ "e) Address â€“ mandatory open text field\n"
										+ "f) City - open text field\n"
										+ "g) Postal Code â€“ mandatory open text field\n"
										+ "h) Phone â€“ non-mandatory 2 labels one is a drop down with values select, work & home and another blank open text box\n"
										+ "i) E-mail â€“ non-mandatory 2 labels one is a drop down with values select, work & home and another blank open text box",
								"Add New CR Organization overlay is opened with below fields: Organization Type Section\n"
										+ "a) Organization Type â€“ mandatory drop down Name Section\n"
										+ "b) Name of Organization â€“ mandatory open text field\b"
										+ "c) Department/Section - open text field Contact Section\n"
										+ "d) Country/State - mandatory drop down\n"
										+ "e) Address â€“ mandatory open text field\n"
										+ "f) City - open text field\n"
										+ "g) Postal Code â€“ mandatory open text field\n"
										+ "h) Phone â€“ non-mandatory 2 labels one is a drop down with values select, work & home and another blank open text box\n"
										+ "i) E-mail â€“ non-mandatory 2 labels one is a drop down with values select, work & home and another blank open text box",
								"PASS", "Y");
				/**
				 * Step No : 70
				 */
				BaseClass.select(initiationPage.organizationType, "Association");
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.organizationName, "AutomationTest");
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.countryAddNewIndividual, "Australia");
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.addressAddNewIndividual, "Sydney");
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.cityAddNewIndividual, "Sydney");
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.postalCodeAddNewIndividual, "02ES20");
				BaseClass.waitForObj(5000);
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				BaseClass.waitForObj(8000);
				consultingAgreementPage = new ConsultingAgreementPage(BaseClass.driver);
				boolean error = OneASTUtil.isElementPresent(consultingAgreementPage.errorMessage);
				System.out.println("Error Message :: " + error);
				if (error == true)
				{
					BaseClass.click(initiationPage.submitButtonForTransactionOwner);
					BaseClass.waitForObj(8000);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(8000);
				}
			}
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Enter all the details and click on [Submit].",
							"The new CR should be added under Selected Organziations Label.\n"
									+ "The search results of the CR Organization should be displayed with below fields\n"
									+ "1) Organization Name\n"
									+ "2) Street Address\n"
									+ "3) City\n"
									+ "4) Country/State\n"
									+ "5) Unique HCP Identifier/NPI Also, the CR should be added to the database.\n"
									+ "Can be checked using below query:\n"
									+ "select * from ORGANIZATIONDEMOGRAPHICS where ORGANIZATIONNAME= ;",
							"The new CR is added under Selected Organziations Label.\n"
									+ "The search results of the CR Organization is displayed with below fields\n"
									+ "1) Organization Name\n"
									+ "2) Street Address\n"
									+ "3) City\n"
									+ "4) Country/State\n"
									+ "5) Unique HCP Identifier/NPI Also, the CR should be added to the database.\n"
									+ "Can be checked using below query:\n"
									+ "select * from ORGANIZATIONDEMOGRAPHICS where ORGANIZATIONNAME= ;",
							"PASS", "N");
			/**
			 * Step No : 80
			 */
			click(consultingAgreementPage.submitButtonInSearchResultPage);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			status = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (status.equalsIgnoreCase("Pending-AgreementInitiation"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on Next button",
								"1.The screen should navigate to Business Information tab\n"
										+ "The status of the Agreement should be displayed as Pending Agreement Initiation",
								"1.The screen is navigate to Business Information tab\n"
										+ "The status of the Agreement is displayed as Pending Agreement Initiation",
								"PASS", "N");
			}
			/**
			 * Step No : 90
			 */
			waitForObj(8000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			waitForObj(8000);
			select(initiationPage.poleDropDown, "ASIA-APAC");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			select(initiationPage.regionDropDown, "South Asia");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			select(initiationPage.spendCategoryDropDown, "Product Training");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			select(initiationPage.spendSubTypeDropDown, "Masters Series (GEHC Catalog Course)");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			PDFResultReport.addStepDetails("Enter the Pole as ASIA APAC   and\n"
					+ "Region as South Asia in Legal Entity section \n"
					+ "Spend category as Product Training ,\n"
					+ "Spend Sub Category as Masters Series",
					"The mentioned selections should be made", "The mentioned selections is made",
					"PASS", "Y");
			/**
			 * Step No : 100
			 */
			select(initiationPage.payingCountryDropDown, "India");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			select(initiationPage.businessDropDown, "Surgery");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			String[] modalityValues = { "Select...", "Surgery" };
			List<WebElement> modalityDropDownValues = new Select(initiationPage.modalityDropDown)
					.getOptions();
			System.out.println(modalityDropDownValues.size());
			int count = 0;
			for(int i = 0;i < modalityDropDownValues.size();i++)
			{
				if (modalityDropDownValues.get(i).getText().contains(modalityValues[i]))
				{
					System.out.println("Value is verified in Master data table"
							+ modalityDropDownValues.get(i).getText());
					count++;
				}
			}
			if (count == 2)
				System.out.println(count);
			PDFResultReport.addStepDetails(
					"Verify the values in the below dropdowns on the selection made\n"
							+ "Modality\n" + "Legal Entity\n"
							+ "when business is selected as 'Surgery'",
					"The values should be verified in Master data table ",
					"The values is verified in Master data table ", "PASS", "N");
			/**
			 * Step No : 110
			 */
			consultingAgreementPage = new ConsultingAgreementPage(BaseClass.driver);
			switchToDefaultFrame();
			BaseClass.waitForObj(5000);
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);
			initiationPage = new InitiationPage(driver);
			select(initiationPage.modalityDropDown, "Surgery");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			select(initiationPage.legalEntityDropDown, "800110-GE BE Private Ltd");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			/*select(initiationPage.productDropDown, "Investigational");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			select(initiationPage.productIndicatorDropDown, "None");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);*/
			BaseClass.click(initiationPage.onBehalfOfOtherNoRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			PDFResultReport.addStepDetails("Select Modality,Legal Entity from the dropdown.\n"
					+ "Select Request on behalf of others? as No and\n" + "Click  [Next]",
					"The scren should be navigated to Supporting Information tab",
					"The scren is navigated to Supporting Information tab", "PASS", "N");
			/**
			 * Step No : 120
			 */
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
			BaseClass.waitForObj(8000);
			boolean alert = BaseClass.isAlertPresent();
			System.out.println("Alert Status: " + alert);
			BaseClass.handleAlert();
			BaseClass.waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Click on [Next] without entering mandatory values in the Supporting Information tab",
							"System should throw error saying Values cannot be blank",
							"System is throw error saying Values cannot be blank", "PASS", "N");
			BaseClass.waitForObj(5000);
			/**
			 * Step No : 130
			 */
			switchToDefaultFrame();
			BaseClass.waitForObj(5000);
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);
			initiationPage = new InitiationPage(driver);
			set(initiationPage.businessJustificationForEngagementTextField,
					"Business Justification for EngagementRequired");
			set(initiationPage.gehcProductOrServicesIncludedTextField,
					"GEHC Products/Services Included");
			set(initiationPage.consultantQualificationSummaryTextField,
					"Consultant Qualification Summary");
			set(initiationPage.payMentDetailsTextField, "Payment Details");
			set(initiationPage.serviceToBeProvidedTextArea, "SERVICE TO BE PROVIDED");
			waitForObj(8000);
			PDFResultReport
					.addStepDetails(
							"1)Fields that should display under Supporting Information tab\n"
									+ "	a) Business Justification for   Engagement *\n"
									+ "	b)GEHC Products/Services Included\n"
									+ "	c)Consultant Qualification Summary *\n"
									+ "	d) SERVICE TO BE PROVIDED *\n"
									+ "	e)Payment Details*\n"
									+ "2)Enter all the mandatory information in the supporting information tab and click [Next]",
							"User should be able to enter mutiple SERVICE TO BE PROVIDED by clicking on + symbol.\n"
									+ "Screen must be navigated to Agreement details tab",
							"User is able to enter mutiple SERVICE TO BE PROVIDED by clicking on + symbol.\n"
									+ "Screen is navigated to Agreement details tab", "PASS", "Y");
			waitForObj(5000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			/**
			 * Step No : 140
			 */
			set(initiationPage.agreementTitleTextField, "Consulting Agreement");
			OneASTUtil.selectBothEffectiveandExpirationDateFromCalender();
			BaseClass.click(initiationPage.willServiceCompensationBePaidYesRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			BaseClass.waitForObj(5000);
			OneASTUtil.addServiceProvider("GE ID", "100002198702");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			PDFResultReport
					.addStepDetails(
							"1.Enter all the required fields in Covered Recipients and Enter the actual effective date sections.\n"
									+ "2.Select the Yes radio button for the question Will the service compensation be paid? in Service Compensation Q&A section and\n"
									+ "Select service provider by clicking on Add Service Provider ( search the CR individual by GE ID)",
							"1.The fields should be entered successfully.\n"
									+ "2.Screen must be navigated to Fair Market Value tab and the FMV questions should be populated.\n"
									+ "	a)Number of Years of Experience (Post-Residency for Physicians)*\n"
									+ "	b)Number of Invited Lectures/Presentations Made in Past 5 Years*\n"
									+ "	c)Number of Peer-Reviewed Publications in Past 5 Years*\n"
									+ "	d)Currency in which the Speaker/Consultant is to be paid*",
							"1.The fields is entered successfully.\n"
									+ "2.Screen is navigated to Fair Market Value tab and the FMV questions are populated.\n"
									+ "	a)Number of Years of Experience (Post-Residency for Physicians)*\n"
									+ "	b)Number of Invited Lectures/Presentations Made in Past 5 Years*\n"
									+ "	c)Number of Peer-Reviewed Publications in Past 5 Years*\n"
									+ "	d)Currency in which the Speaker/Consultant is to be paid*",
							"PASS", "N");
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			/**
			 * Step NO : 150
			 */
			BaseClass.waitForObj(8000);
			String currency = text(initiationPage.defaultCurrency);
			/*PDFResultReport
					.addStepDetails(
							"1)Enter the required below FMV questions and click [Calculate] to calculate the Hourly FMV rate.\n"
									+ "Country* -Speciality/Role*\n"
									+ "Number of Years of Experience (Post-Residency for Physicians)*\n"
									+ "Number of Invited Lectures/Presentations Made in Past 5 Years*\n"
									+ "Number of Invited Lectures/Presentations Made in Past 5 Years*\n"
									+ "Currency in which the Speaker/Consultant is to be paid*\n"
									+ "2)Verify if the Hourly rate is correctly calculated.",
							"1)Hourly rate should be calculated based on the selection made and display under HOURLY/OVERRIDE RATE section.\n"
									+ "2)User below query to retreive the hourly rate",
							"1)Hourly rate is calculated based on the selection made and display under HOURLY/OVERRIDE RATE section.\n"
									+ "Hourly rate " + text(initiationPage.hourlyRate) + "",
							"PASS", "Y");*/
			/**
			 * Step No : 160
			 */
			//new Actions(driver).moveToElement(initiationPage.hourlyRate).build().perform();
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			String serviceRate = text(initiationPage.serviceRate);
			String[] serviceRate1 = serviceRate.split(Character.toString(currency.charAt(0)));
			System.out.println(serviceRate1[0]);
			String preparationRate = text(initiationPage.serviceRate);
			String[] preparation1 = preparationRate.split(Character.toString(currency.charAt(0)));
			System.out.println(preparation1[0]);
			String travelRate = text(initiationPage.serviceRate);
			String[] travelRate1 = travelRate.split(Character.toString(currency.charAt(0)));
			System.out.println(travelRate1[0]);
			String serviceHours = "2.00";
			String preparationHours = "2.00";
			String travelHours = "2.00";
			/*BaseClass.set(initiationPage.serviceHours, serviceHours);
			BaseClass.waitForObj(8000);
			BaseClass.set(initiationPage.preparationHours, preparationHours);
			BaseClass.waitForObj(8000);
			BaseClass.set(initiationPage.travelHours, travelHours);
			BaseClass.waitForObj(8000);
			new Actions(BaseClass.driver).moveToElement(initiationPage.preparationHours).click()
					.build().perform();*/
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			String actualTotalHours = String.format("%.1f",
					Double.parseDouble(BaseClass.text(initiationPage.totalNoOfHours)));
			System.out.println("Actual Total Hours " + actualTotalHours);
			if (Double.parseDouble(actualTotalHours) == Double.parseDouble(serviceHours)
					+ Double.parseDouble(preparationHours) + Double.parseDouble(travelHours))
			{
				PDFResultReport
						.addStepDetails(
								"Enter the valid value in the 'Number of Hours' field under the 'service', 'preparation' and 'travel' sections.",
								"Total Service Amount, 'Total Preparation Amount' & 'Total Travel Amount' should be Service Rate * No of Hours",
								"Total Service Amount, 'Total Preparation Amount' & 'Total Travel Amount' is Service Rate * No of Hours",
								"PASS", "Y");
			}
			/**
			 * Step No : 170
			 */
			String totalCompensationAmount = text(initiationPage.serviceRate);
			String[] actualTotalCompensationAmount = totalCompensationAmount.split(Character
					.toString(currency.charAt(0)));
			if (Double.parseDouble(actualTotalHours) == Double.parseDouble(serviceHours)
					+ Double.parseDouble(preparationHours) + Double.parseDouble(travelHours)
					&& Double.parseDouble(serviceRate1[0]) + Double.parseDouble(preparation1[0])
							+ Double.parseDouble(travelRate1[0]) == Double
							.parseDouble(actualTotalCompensationAmount[0]))
			{
				PDFResultReport
						.addStepDetails(
								"Verify if the Total hours and Total Compensation Amount is displayed correctly",
								"The Total hours and Total Compensation Amount fields should get populated accordingly.\n"
										+ "Total Compensation Amount should be the sum of Total Service Amount,Total Preparation Amount and Total Travel Amount",
								"The Total hours and Total Compensation Amount fields is get populated accordingly.\n"
										+ "Total Compensation Amount is the sum of Total Service Amount,Total Preparation Amount and Total Travel Amount",
								"PASS", "Y");
			}
			else
			{

				PDFResultReport
						.addStepDetails(
								"Verify if the Total hours and Total Compensation Amount is displayed correctly",
								"The Total hours and Total Compensation Amount fields should get populated accordingly.\n"
										+ "Total Compensation Amount should be the sum of Total Service Amount,Total Preparation Amount and Total Travel Amount",
								"The Total hours and Total Compensation Amount fields is get populated accordingly.\n"
										+ "Total Compensation Amount is the sum of Total Service Amount,Total Preparation Amount and Total Travel Amount",
								"PASS", "Y");
			
			}
			/**
			 * Step No : 180
			 */
			// TODO reporting is available in
			// OneASTUtil.clickOnUploadsTabAndUploadTheFiles();
			/**
			 * Step No : 190
			 */
			waitForObj(8000);
			OneASTUtil.clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(8000);
			PDFResultReport.addStepDetails(
					"Upload the required documents and click on [Next] button.",
					"Screen should be navigated to Summary tab",
					"Screen is navigated to Summary tab", "PASS", "Y");
			/**
			 * Step No : 200
			 */
			PDFResultReport
					.addStepDetails(
							"Verify the Summary tab",
							"All the details that were entered in the previous tabs should populate correctly in the Summary tab",
							"All the details that were entered in the previous tabs is populate correctly in the Summary tab",
							"PASS", "Y");
			waitForObj(5000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,250)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			js.executeScript("window.scrollBy(0,500)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			waitForObj(5000);
			js.executeScript("window.scrollBy(0,750)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			js.executeScript("window.scrollBy(0,900)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			waitForObj(5000);
			/**
			 * Step No : 210
			 */
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
					initiationPage.nextButton);
			waitForObj(5000);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",
					initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",
					initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			PDFResultReport.addStepDetails("Click on [Submit] button in the Summary tab",
					"The Agreement should be submitted successfully and below message should get displayed.\n"
							+ "Agreement A-xxx has been sent for Approval.\n"
							+ "Any change in status will be communicated via email.\n"
							+ "Thank you",
					"The Agreement is submitted successfully and below message is get displayed.\n"
							+ "Agreement " + agreementNumber + " has been sent for Approval.\n"
							+ "Any change in status will be communicated via email.\n"
							+ "Thank you", "PASS", "N");
			approvalPage = new ApprovalPage(driver);
			boolean approvalLink = OneASTUtil.isElementPresent(By
					.xpath("//a[contains(@href,'OA')]"));
			if (approvalLink)
			{
				click(approvalPage.approvalFlowLink);
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				waitForObj(8000);
			}
			boolean additionalCommentsTextArea = OneASTUtil.isElementPresent(By
					.name("$PpyWorkPage$pAdditionalCommentsCertApproval"));
			if (additionalCommentsTextArea)
			{
				set(approvalPage.additonalCommentesTextArea, "Please approve.");
				waitForObj(5000);
				click(approvalPage.approveButton);
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				waitForObj(8000);
			}
			boolean confirmationMessage = OneASTUtil
					.isElementPresent(approvalPage.confirmationMessage);
			System.out.println(confirmationMessage);
			/**
			 * Step No : 220
			 */
			switchToDefaultFrame();
			System.out.println("Swithed to default Frame");
			waitForObj(8000);
			approvalPage = new ApprovalPage(driver);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",
					approvalPage.closeTab);
			waitForObj(5000);
			oneASTHomePage = new OneASTHomePage(BaseClass.driver);
			BaseClass.set(oneASTHomePage.searchTextField, agreementNumber);
			BaseClass.waitForObj(5000);
			BaseClass.click(oneASTHomePage.searchButtonField);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			BaseClass.waitForObj(8000);
			approvalPage = new ApprovalPage(driver);
			switchFrame(approvalPage.pegaGadet0Ifr);
			BaseClass.waitForObj(5000);
			status = BaseClass.text(approvalPage.status);
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Click on [Submit] button in the Summary tab\n"
									+ "Verify below fields in work header section:\n"
									+ "1.Case ID\n" + "2.Status\n" + "3.Transaction Owner\n"
									+ "4.Created\n" + "5.Created  By\n" + "6.IPP COE\n"
									+ "7.Event Start Date\n" + "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ pendingWith + "\n" + "9.Direct Manager: Direct manager name "
									+ directManager + "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
			/**
			 * Step No : 230
			 */
			PDFResultReport.addStepDetails(
					"Review the details, click on the link and click [Approve] button",
					"The workflow should be Approved by T.O and submitted for IPP COE aproval",
					"The workflow is Approved by T.O and submitted for IPP COE aproval", "PASS",
					"Y");
			/**
			 * Step No : 240
			 */
			String pendingWithUser = JdbcConnection.swapTwoString(pendingWith);
			String pendingUser = JdbcConnection.conversionOfAlphabets(pendingWithUser);
			String[] pendingWithTheUser = JdbcConnection
					.connectToDataBaseAndGetRequiredData(pendingUser);
			System.out.println(pendingWithTheUser[0]);
			ippCoe = pendingWithTheUser[0];
			switchToDefaultFrame();
			waitForObj(5000);
			AggregateSpendManagementNonUSPage aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(
					driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			waitForObj(5000);
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			OneASTUtil.loginIntoApplication(loginPage, ippCoe, "password");
			waitForObj(8000);
			PDFResultReport
					.addStepDetails(
							"Login to the Application as Transaction owner by entering the valid credentials and\n"
									+ "Click on [Login] Button present in the page.\n"
									+ "Login credentials:\n"
									+ "Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/o8uZcrjyYhEANdV611UguQ%5B%5B*/!STANDARD\n"
									+ "username : <Pole Leader>\n" + "password: <pswd_TO1> ",
							"The workflow should be displayed under 'My Action Items' section.",
							"The workflow is displayed under 'My Action Items' section.", "PASS",
							"N");
			/**
			 * Step No : 250
			 */
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(18000);
			driver.navigate().refresh();
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(10000);
			driver.navigate().refresh();
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(10000);
			// TODO
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(5000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(5000);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			String statusOfAgreement = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfAgreement.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <A-xxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the transaction owner.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the transaction owner.\n"
										+ "3.The Status of the Workflow is " + statusOfAgreement
										+ ".", "PASS", "Y");
			}
			/**
			 * Step No : 260
			 */
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ pendingWith + "\n" + "9.Direct Manager: Direct manager name "
									+ directManager + "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
			delegateThisRequestTo();
			loginAsDelegateApprover();
			workFlowSubmitToDirectManager();
		} catch(Exception e)
		{
			e.printStackTrace();
			e.getMessage();
		}
	}
	/**
	 * Step No : 270
	 */
	public void delegateThisRequestTo()
	{
		try
		{
			approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			initiationPage = new InitiationPage(BaseClass.driver);
			waitForObj(8000);
			for(int i = 0;i < initiationPage.mandatoryUploadsList.size();i++)
			{
				BaseClass.click(initiationPage.uploadButtonInIPPCOEApproveSection.get(i));
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.subject_Upload, "test");
				BaseClass.waitForObj(5000);
				BaseClass.click(initiationPage.attachmentButton);
				BaseClass.waitForObj(5000);
				CommonUtils.uploadFileUsingRobot("TestData.xlsx");
				BaseClass.click(initiationPage.okButtonInModalPopUp);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			}
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(8000);
			PDFResultReport
					.addStepDetails(
							"Review the details, click on the link,upload the documents and click [Approve] button",
							"The workflow should be Approved by IPP COE  and submitted for Direct Manager aproval",
							"The workflow is Approved by IPP COE  and submitted for Direct Manager aproval",
							"PASS", "N");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
		} catch(Exception e)
		{
			e.printStackTrace();
			e.getMessage();
		}
	}
	
	public void loginAsDelegateApprover()
	{
		try
		{
			/**
			 * Step No : 280
			 */
			switchToDefaultFrame();
			waitForObj(5000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			waitForObj(5000);
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			OneASTUtil.loginIntoApplication(loginPage, "212417846", "password");
			waitForObj(8000);
			PDFResultReport
					.addStepDetails(
							"Login to the Application as IPP COE by entering the valid credentials and click on [Login] Button present in the page.\n"
									+ "Login credentials:\n"
									+ "Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/o8uZcrjyYhEANdV611UguQ%5B%5B*/!STANDARD\n"
									+ "username : <Direct Manager>\n" + "password: <pswd_TO1>",
							"The workflow should be displayed under 'My Action Items' section.",
							"The workflow is displayed under 'My Action Items' section.", "PASS",
							"N");
			/**
			 * Step No : 290
			 */
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(18000);
			// TODO
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(5000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(5000);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			String statusOfAgreement = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfAgreement.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <A-xxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the  IPP COE.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the  Additional approver.\n"
										+ "3.The Status of the Workflow is " + statusOfAgreement
										+ ".", "PASS", "Y");
			}
			/**
			 * Step No : 300
			 */
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ pendingWith + "\n" + "9.Direct Manager: Direct manager name "
									+ directManager + "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
			/**
			 * Step No : 310
			 */
			approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			OneASTUtil
					.clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.REQUEST_FOR_MORE_INFORMATION);
			/*
			String delegateThisRequestTo = "Andriasik, Szilvia-212435254";
			String[] delegateThisRequesterValue = delegateThisRequestTo.split("-");
			System.out.printf(delegateThisRequesterValue[0], delegateThisRequesterValue[1]);
			additionalApprovar = delegateThisRequesterValue[1];
			select(approvalPage.delegateThisRequestToDropDown, delegateThisRequestTo);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			set(approvalPage.reasonForReassigningthisItemtoanotherUser,
					"reasonForReassigningthisItemtoanotherUser");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			additionalApprovar = getAttributeValue(approvalPage.delegateThisRequestToDropDown,
					"value");*/
			select(approvalPage.requestInfoReasonDropDown, "Additional Information Required");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			set(approvalPage.requestedInfo, "Additional Information Required");
			BaseClass.waitForObj(8000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			switchToDefaultFrame();
			waitForObj(5000);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(5000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(5000);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			statusOfAgreement = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfAgreement.equalsIgnoreCase("Pending-AgreementInitiation"))
			{
				PDFResultReport.addStepDetails(
						"Select Request for more information from Other actions dropdown.\n"
								+ "Select the reason and enter the Requested Info.\n"
								+ "Submit the Agreement.",
						"The Agreement should be resubmitted to the Super user\n"
								+ "2. The status should be updated to Pending-AgreementInitiation",
						"The Agreement is resubmitted to the Super user\n"
								+ "2. The status should be updated to Pending-AgreementInitiation",
						"PASS", "N");
			}
			/**
			 * Step No : 320
			 */
			switchToDefaultFrame();
			waitForObj(5000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			waitForObj(5000);
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "superUserUserName", "password");
			waitForObj(8000);
			PDFResultReport
					.addStepDetails(
							"Login to the Application as Super User by entering the valid credentials and click on [Login] Button present in the page.\n"
									+ "Login credentials:\n"
									+ "Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/o8uZcrjyYhEANdV611UguQ%5B%5B*/!STANDARD\n"
									+ "username : <Super User>password: <pswd_TO1>",
							"The workflow should be displayed under 'My Action Items' section.",
							"The workflow is displayed under 'My Action Items' section.", "PASS",
							"N");
			/**
			 * Step No : 330
			 */
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(18000);
			// TODO
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(5000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(5000);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			statusOfAgreement = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfAgreement.equalsIgnoreCase("Pending-AgreementInitiation"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under 'My Action Items' section (or)\n"
										+ "Search for the workflow by entering the Agreement case id <A-xxxx> .",
								"1. The workflow should get open in review mode with a link.\n"
										+ "2. The link should be enabled for the Super User.\n"
										+ "3. The Status of the Workflow should be Pending-AgreementInitiation.",
								"1. The workflow should get open in review mode with a link.\n"
										+ "2. The link should be enabled for the Super User.\n"
										+ "3. The Status of the Workflow should be Pending-AgreementInitiation.",
								"PASS", "Y");
			}
			/**
			 * Step NO : 340
			 */
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ pendingWith + "\n" + "9.Direct Manager: Direct manager name "
									+ directManager + "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
		} catch(Exception e)
		{
			e.printStackTrace();
			e.getMessage();
		}
	}
	public void workFlowSubmitToDirectManager()
	{
		try
		{
			/**
			 * Step No : 350
			 */
			switchToDefaultFrame();
			waitForObj(5000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(5000);
			approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			initiationPage = new InitiationPage(driver);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(8000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(8000);
			set(initiationPage.businessJustificationForEngagementTextField,
					"Business Justification for Engagement Required");
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(8000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(8000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(8000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(8000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(8000);
			PDFResultReport
					.addStepDetails(
							"Change any details in the Supporting information tab and [Submit] the workflow",
							"Workflow should be submitted for T.O Approval(S.U in this case)",
							"Workflow is submitted for T.O Approval(S.U in this case)", "PASS", "N");
			/**
			 * Step No : 360
			 */
			switchToDefaultFrame();
			waitForObj(5000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(5000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(5000);
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			pendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ pendingWith + "\n" + "9.Direct Manager: Direct manager name "
									+ directManager + "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
			/**
			 * Step NO : 370
			 */
			switchToDefaultFrame();
			waitForObj(5000);			
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(5000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(5000);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			String statusOfAgreement = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfAgreement.equalsIgnoreCase("Pending-Approval"))
			{
				approvalPage = new ApprovalPage(driver);
				click(approvalPage.approvalFlowLink);
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				waitForObj(5000);
				OneASTUtil.clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.REJECT);
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				waitForObj(5000);
				select(approvalPage.rejectionDescriptionDropDown, "Other");
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				waitForObj(5000);
				set(approvalPage.commentsTextFieldInReject, "Rejected");
				waitForObj(5000);
				BaseClass.click(initiationPage.nextButton);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				waitForObj(8000);
			}
			switchToDefaultFrame();
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(5000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(5000);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			statusOfAgreement = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfAgreement.equalsIgnoreCase("Resolved-Rejected"))
			{
				PDFResultReport
						.addStepDetails(
								"Select Reject from Other actions dropdown.\n"
										+ "Select the Rejection reason and enter any comments(non mandatory field).\n"
										+ "2. Submit the Agreement.",
								"Below message should display:\n"
										+ "Request A-xxxx has been rejected.\n" + "Thank you\n"
										+ "2.Status should change to Resolved-Rejected",
								"Status is changed to Resolved-Rejected", "PASS", "Y");
			}
			switchToDefaultFrame();
			waitForObj(5000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		} catch(Exception e)
		{
			e.printStackTrace();
			e.getMessage();
		}
	}
	
}
