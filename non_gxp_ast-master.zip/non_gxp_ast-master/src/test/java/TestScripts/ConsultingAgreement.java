package TestScripts;
import java.awt.AWTException;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.CommonUtils;
import Components.LoginUtils;
import Components.OneASTUtil;
import Components.PeagDesignerStudioHomePageUtils;
import ObjectRepository.AggregateSpendManagementPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.HomePage;
import ObjectRepository.LogInPage;
import ObjectRepository.PeagDesignerStudioHomePage;
public class ConsultingAgreement extends BaseClass
{
	public String agreementNumber;
	public HomePage homePage;
	public ArrayList<String> tabs;
	public String eventId;
	public String caseId;
	public String userOne = ExcelReport.testData.get("userName");
	public String userTwo = ExcelReport.testData.get("userTwo");
	@Test(priority = 0,description = "Aggregate Spend Management Tool POC")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "Doc1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "7");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "Pavan Yarlagadda");
			reportDetails.put("Name of Automation Test Script Author", "502616490");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "Doc1234567");
		reportDetails.put("Requirement ID", "");
		
		LogInPage loginPage = new LogInPage(driver);
		launchApplication(ExcelReport.testData.get("url"));
		LoginUtils.loginIntoApplication(loginPage, "userName", "password");
	}
	/**
	 * Step No : 10
	 */
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{
			
			waitForObj(5000);
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.ONE_AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				PDFResultReport
						.addStepDetails(
								"Open the browser, \n"
										+ "Enter the AST Application  URL - https://gehc-ast-dev-2.pegacloud.com/prweb/PRServlet.\n"
										+ "Enter SSOID <User1> and password.\n"
										+ "Click on the [Login] button.\n"
										+ "Click on the Launch link dropdown and \n"
										+ "Click on the Launch portal option",
								"Aggregate Spend Management page shall be displayed in a new tab.",
								"Aggregate Spend Management page is displayed in a new tab.",
								"PASS", "Y");
			}
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * Step No : 20
	 * @throws Exception 
	 */
	@Test(priority = 2)
	public void clickOnAgreementAndSelectNewConsultingAgreement() throws Exception
	{
		AggregateSpendManagementPage aggregateSpendManagementPage = new AggregateSpendManagementPage(
				driver);
		
		click(aggregateSpendManagementPage.oneASTRadioButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(3000);
		click(aggregateSpendManagementPage.submitButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(5000);
		OneASTUtil.createConsultingAgreement(ExcelReport.testData.get("selectCRType"));
		OneASTUtil.selectCRType(ExcelReport.testData.get("selectCRType"));
		
	/*	OneASTUtil.enterValuesInBusinessInformationTab("EMEA", "Europe", "France",
				"Global Marketing", "Global Marketing",
				"310110-GEMS SCS", "", "", "Yes", "", "Product Input", "");*/
		
		OneASTUtil.enterTheValuesInBusinessInformationTab("ASIA-APAC", "Japan", "Japan",
				"Global Marketing", "Global Marketing",
				"710110-GE Healthcare Japan Corporation", "", "","Yes","503031811","","Product Input", "");
		
		/*OneASTUtil.enterTheValuesInBusinessInformationTab("Americas", "United States", "United States",
				"Detection & Guidance Solutions (DGS)", "Interventional",
				"020110-GE Medical Systems (F39000)", "Innova IGS 620", "Covered", "Yes", "", "Product Input", ""); */
		
		OneASTUtil.enterValuesInSupportingInformationTab("Test", "Test", "Test", "Test", "Test");
		OneASTUtil.enterValuesInAgreementDetailsTab("Test", "Yes", "",
				ExcelReport.testData.get("selectCRType"),ExcelReport.testData.get("addNewServiceProvider"));
		OneASTUtil.clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
		OneASTUtil.clickOnSummaryTab();
		OneASTUtil.approveAndActivateAgreement("TestData.xlsx",agreementNumber);		
		
	}
}
