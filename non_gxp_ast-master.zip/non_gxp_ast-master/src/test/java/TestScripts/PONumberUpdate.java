package TestScripts;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;




import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import Components.CommonUtils;
import Components.LoginUtils;
import ObjectRepository.HomePage;
import ObjectRepository.LogInPage;

import com.csvreader.CsvWriter;

public class PONumberUpdate extends BaseClass {

	@Test
	public static void main() throws Exception {		
		
		LogInPage loginPage = new LogInPage(driver);		
		List<String> POAmounts = new ArrayList<String> () ;
		launchApplication(ExcelReport.testData.get("url"));
		LoginUtils.loginIntoApplication(loginPage, "userName", "password");
		waitForObj(5000);
		String eventID = ExcelReport.testData.get("PONumberUpdateEventID");
		HomePage homePage = new HomePage(driver);
		set(homePage.searchBox, eventID);
		click(homePage.searchButton);
		waitForObj(5000);
		
		String eventIDLink= "//div[@node_name='pzSearchResultName']//a[contains(text(),'"+eventID+"')]";
		
		BaseClass.driver.findElement(By.xpath(eventIDLink)).click();
		
		waitForObj(5000);
		
		switchFrame(homePage.frame1);
		
		for(int j=0;j<homePage.POStatus.size();j++){
			
		if(homePage.POStatus.get(j).getText().equalsIgnoreCase("Pending SSP PO Number")){
			
			//for(int i=0;i<homePage.POAmounts.size();i++){
				
				POAmounts.add(homePage.POAmounts.get(j).getText());
				System.out.println(POAmounts.get(0));
			//}
		}
		
		}
		
		switchToDefaultFrame();	
		click(homePage.close);
		
		
		List<String> POCreatedDate = new ArrayList<String> () ;
		List<String> PORevision = new ArrayList<String> () ;
		List<String> PORefID = new ArrayList<String> () ;		
		List<String> POReqNum = new ArrayList<String> () ;

	Class.forName("oracle.jdbc.driver.OracleDriver");  
	
	//step2 create  the connection object  
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.119.150.227:1521:prpc","CR","CR");  
	
	//step3 create the statement object  
	Statement stmt=con.createStatement();  
	
	//step4 execute query  
	ResultSet rs=stmt.executeQuery("select REQUISITIONNUMBER,REFERENCEID,PXCREATEDATETIME from PRPC.SSPRequisitions where referenceid like '"+eventID+"%'");  
	while(rs.next())  
	{
		//System.out.println(rs.getString(7)+"  "+rs.getString(2)+"  "+rs.getString(3));  
					
		POReqNum.add(rs.getString(1));
		PORefID.add(rs.getString(2));
		POCreatedDate.add(rs.getString(3));
		
		
	}
	
	String date1 = POCreatedDate.get(0);
	System.out.println(date1);
	//String newDate = new SimpleDateFormat("dd-MMM-yyyy").format(date);
    SimpleDateFormat sdfSource = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
    
    //parse the string into Date object
    Date date = sdfSource.parse(date1);
    
    //create SimpleDateFormat object with desired date format
    SimpleDateFormat sdfDestination = new SimpleDateFormat("dd-MMM-yy");
    
    //parse the date into another format
    date1 = sdfDestination.format(date);
    System.out.println(date1);
	
	String csvFile = System.getProperty("user.dir")
			+ "\\Resources\\AST_PO_FEED.csv";
	BufferedReader br = null;
	String line = "";
	String cvsSplitBy = "~";
	String[] country=null;
	
	try
	{
		br = new BufferedReader(new FileReader(csvFile));
		while ((line = br.readLine()) != null)
		{
			// use comma as separator
			country = line.split(cvsSplitBy);
			//System.out.println("Country [code= " + country[4] + " , name=" + country[5] + "]");
		}
	} catch(Exception e)
	{
		// TODO: handle exception
	}
	
	for (int i = 0; i < country.length; i++) {
		
		System.out.println(country[i]);
	}
	System.out.println(country[1]);
	
	String filePath = System.getProperty("user.dir")
			+ "\\Resources\\AST_PO_FEED.csv";
			
	File file = new File(filePath);
	CsvWriter csvWriter = new CsvWriter(filePath);
	boolean alreadyExists = new File(filePath).exists();

	try
	{
		//new CsvWriter(new FileWriter(filePath, true), '~');
		csvWriter.setDelimiter('~');
		if(alreadyExists)
		{
			csvWriter.write("PO_NUMBER");
			csvWriter.write("PO_REVISION");
			csvWriter.write("VENDOR_NUMBER");
			csvWriter.write("VENDOR_NAME");
			csvWriter.write("VENDOR_SITE");
			csvWriter.write("VENDOR_SITE_CODE");
			csvWriter.write("LINE_NUMBER");
			csvWriter.write("UNIT_PRICE");
			csvWriter.write("QUANTITY");
			csvWriter.write("QUANTITY_REMAINING");
			csvWriter.write("PO_AMOUNT");
			csvWriter.write("INVOICED_AMOUNT");
			csvWriter.write("REMAINING_PO_AMOUNT");
			csvWriter.write("CURRENCY");
			csvWriter.write("ORG_ID");
			csvWriter.write("PO_STATUS");
			csvWriter.write("CANCEL_FLAG");
			csvWriter.write("PO_AUTHORIZATION_STATUS");
			csvWriter.write("LAST_UPDATE_DATE");
			csvWriter.write("CREATION_DATE");
			csvWriter.write("REQUISITION_NUM");
			csvWriter.write("REQUISITION_LINE");
			csvWriter.write("REQ_DISTRIBUTION_NUM");
			csvWriter.write("REFERENCE_ID");
			csvWriter.write("REQUESTOR_EMP_NUM");
			csvWriter.write("PREPARER_EMP_NUM");						
			csvWriter.endRecord();
		}
	//	System.out.println("PO " + PONumber.get(0));
		csvWriter.write("11020232352");
		csvWriter.write(country[1]);
		csvWriter.write(country[2]);
		csvWriter.write(country[3]);
		csvWriter.write(country[4]);
		csvWriter.write(country[5]);
		csvWriter.write(country[6]);
		csvWriter.write(country[7]);
		csvWriter.write(country[8]);
		csvWriter.write(country[9]);
		csvWriter.write(POAmounts.get(0));				
		csvWriter.write(country[11]);
		csvWriter.write(country[12]);
		csvWriter.write(country[13]);				
		csvWriter.write(country[14]);
		csvWriter.write(country[15]);
		csvWriter.write(country[16]);
		csvWriter.write(country[17]);
		csvWriter.write(country[18]);
		csvWriter.write(date1);
		csvWriter.write(POReqNum.get(0));
		csvWriter.write(country[21]);
		csvWriter.write(country[22]);
		csvWriter.write(PORefID.get(0));
		csvWriter.write(country[24]);
		csvWriter.write(country[25]);		
		//csvWriter.replace(arg0, arg1, arg2)
	
		csvWriter.endRecord();
		
		
		csvWriter.flush();
		csvWriter.close();
		
		
		
		set(homePage.searchBox,"ProcessPONumberRequest");
		click(homePage.searchButton);
		waitForObj(5000);
		String serviceLink= "//div[@node_name='pzSearchResultName']//a[contains(text(),'SSPRestService Services ProcessPONumberRequest')]";
		
		BaseClass.driver.findElement(By.xpath(serviceLink)).click();
		
		waitForObj(5000);
		
		switchFrame(homePage.frame1);
		
		new Actions(BaseClass.driver).moveToElement(homePage.ActionsDropdown).click().build().perform();
		waitForObj(2000);
		
		click(homePage.Run);
		
		switchToDefaultFrame();
		switchWindow(1);
		
		click(homePage.uploadFile_RadioButton);
		waitForObj(2000);
		
		click(homePage.fileUpload);
		CommonUtils.uploadFileUsingRobot("AST_PO_FEED.csv");
		BaseClass.click(homePage.executeButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(10000);
		BaseClass.driver.close();
		BaseClass.waitForObj(2000);
		
		switchWindow(0);
		waitForObj(1000);
		click(homePage.close);
		set(homePage.searchBox,"UpdateWOWithPONumberAtFinalize");
		click(homePage.searchButton);
		waitForObj(5000);
		String updatePOLink= "//div[@node_name='pzSearchResultName']//a[contains(text(),'UpdateWOWithPONumberAtFinalize')]";
		
		BaseClass.driver.findElement(By.xpath(updatePOLink)).click();
		
		waitForObj(5000);
		switchFrame(homePage.frame1);
		
		new Actions(BaseClass.driver).moveToElement(homePage.ActionsDropdown).click().build().perform();
		waitForObj(2000);		
		click(homePage.Run);
		waitForObj(10000);
		switchWindow(2);
		click(homePage.updateWO_Run);
		waitForObj(10000);
		switchWindow(3);
		waitForObj(5000);
		String status = text(homePage.status);
		
		if(status.equalsIgnoreCase("Pass")){
			
			System.out.println("PO Number Updated Successfully");
		}else{
			
			System.out.println("PO Updation failed");
		}
		BaseClass.driver.close();
		
		switchWindow(0);
		waitForObj(1000);
		
		click(homePage.close);

	}catch (Exception e)
	{
		System.out.println("Unable to find the WebElement " + e.getMessage());
		e.printStackTrace();
	}
 }

}
