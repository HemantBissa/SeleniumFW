package TestScripts;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.AggregateSpendManagementUtils;
import Components.CommonUtils;
import Components.LoginUtils;
import Components.OneASTHomePageUtils;
import Components.OneASTUtil;
import Components.PeagDesignerStudioHomePageUtils;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.AggregateSpendManagementPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.HomePage;
import ObjectRepository.InitiationPage;
import ObjectRepository.LogInPage;
import ObjectRepository.OneASTHomePage;
import ObjectRepository.PeagDesignerStudioHomePage;
public class TC02_Consulting_Agreement_FMV_Over_Ride_Higher_Value_DelegateToAdditionalApprover_PoleLeader
		extends BaseClass
{
	public String agreementNumber;
	public HomePage homePage;
	public ArrayList<String> tabs;
	@Test(priority = 0,description = "Verify that Super User(Requestor) is able to create the new Consulting Agreement Product Input - Product Development for the Organization Covered Recipient.\n"
			+ "1.Search by GE ID / Search Ind by Last name, first name\n"
			+ "2.Product Input - Product Development\n"
			+ "3.Request on behalf of - Yes\n"
			+ "4.Pole -Americas - Region : United States\n"
			+ "5.FMV Over ride - Higher value\n"
			+ "6.Delegate to Additional Approver - Pole leader")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "DOC1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "1");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "502616490");
			reportDetails.put("Name of Automation Test Script Author", "Pavan Yarlagadda");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "DOC1234567");
		reportDetails.put("Requirement ID", "");
	}
	/**
	 * Step No : 10
	 */
	@SuppressWarnings("unused")
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{
			LogInPage loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "superUserUserName", "password");
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Login to the Appliaction as Super User entering the valid credentials and \n"
									+ "Click on login button present in the page\n"
									+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
									+ "username : 502618771\n" + "password: rules",
							"1.Login page with titleAggregate Spend Managementshould get displayed.\n"
									+ "2.The page should contain the text The Paying legal Entity of your interaction is based in with below two radio buttons:\n"
									+ "â€¢ AST\n" + "â€¢ Korea Tracking Code",
							"Aggregate Spend Management page is displayed.", "PASS", "N");
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			AggregateSpendManagementPage aggregateSpendManagementPage = new AggregateSpendManagementPage(
					driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			PDFResultReport.addStepDetails("Select OneAST User portal from launch icon\n"
					+ "(In case you logged in as Admin, else OneAST page directly opened)",
					" AST page should get displayed.", " AST page is get displayed.", "PASS", "N");
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(15000);
			/**
			 * Step No : 30
			 */
			OneASTHomePageUtils.selectItemFromMenuPanelInOneASTHomePage(BaseClass.driver,
					OneASTHomePage.AGREEMENT, OneASTHomePage.NEW_CONSULTING_AGREEMENT, false, "");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.switchToDefaultFrame();
			agreementNumber = OneASTUtil.getEventOrAgreementNumber();
			OneASTUtil.agreementNumber = agreementNumber;
			System.out.println("Agreement Number :: " + agreementNumber);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);
			PDFResultReport
					.addStepDetails(
							"Navigate to Workflow --> Agreement --> New Consulting Agreement",
							"1.A Consulting Agreement with case id <A-xxx> should be created \n"
									+ "And radio buttons with below labels should get displayed in Select CR page.\n"
									+ "	i.Individual\n" + "	ii.Organization\n"
									+ "2.The status of the Agreement should be displayed as New.",
							"1.A Consulting Agreement with case id "
									+ agreementNumber
									+ " is created \n"
									+ "And radio buttons with below labels is displayed in Select CR page.\n"
									+ "	i.Individual\n"
									+ "	ii.Organization\n"
									+ "2.The status of the Agreement is displayed as "
									+ BaseClass
											.text(consultingAgreementPage.statusOfAgreementOrEvent)
									+ ".", "PASS", "Y");
			/**
			 * Step No : 40
			 */
			consultingAgreementPage = new ConsultingAgreementPage(BaseClass.driver);
			switchToDefaultFrame();
			BaseClass.waitForObj(2000);
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);			
			BaseClass.click(consultingAgreementPage.organizationRadioButton);			
			BaseClass.click(consultingAgreementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			boolean crOrganizationTab = isElementPresent(consultingAgreementPage.crOrganizationTab);
			System.out.println("Tab Status : " + crOrganizationTab);
			String status = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (crOrganizationTab && status.trim().equalsIgnoreCase("Pending-AgreementInitiation"))
			{
				PDFResultReport
						.addStepDetails(
								"Select the Organization radio button and click on [Submit] button.",
								"1)The screen should navigate to CR Organization Search page with below tabs.\n"
										+ "	1.CR Organization\n"
										+ "	2.History.\n"
										+ "2)The status of the Agreement should be displayed as Pending-AgreementInitiation",
								"1)The screen is navigate to CR Organization Search page with below tabs.\n"
										+ "	1.CR Organization\n" + "	2.History.\n"
										+ "2)The status of the Agreement is displayed as "
										+ text(consultingAgreementPage.statusOfAgreementOrEvent)
										+ "", "PASS", "Y");
			}
			/**
			 * Step No : 50
			 */
			// TODO
			/**
			 * Step No : 60
			 */
			BaseClass.set(consultingAgreementPage.organizationNameTextField, "hospital");
			BaseClass.click(consultingAgreementPage.searchButtonInCROrganization);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					consultingAgreementPage.searchResults.get(0));
			BaseClass.waitForObj(8000);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					consultingAgreementPage.submitButtonInSearchResultPage);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			String previousOrganization = text(getElement(driver, LOCATOR_XPATH,
					String.format(ConsultingAgreementPage.CR_TABLE_CELL_VALUES, 1)));
			PDFResultReport
					.addStepDetails(
							"Select a CR by selecting the radio button next to the CR records in the list.",
							"The CR should get selected and displayed under CR Organization' label.",
							"The CR is "
									+ text(getElement(driver, LOCATOR_XPATH, String.format(
											ConsultingAgreementPage.CR_TABLE_CELL_VALUES, 1)))
									+ "get selected and displayed under CR Organization' label.",
							"PASS", "Y");
			/**
			 * Step No : 70
			 */
			click(consultingAgreementPage.nextButtonOrSubmitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			status = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (status.equalsIgnoreCase("Pending Agreement Initiation"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on Next button",
								"1.The screen should navigate to Business Information tab\n"
										+ "The status of the Agreement should be displayed as Pending Agreement Initiation",
								"1.The screen is navigate to Business Information tab\n"
										+ "The status of the Agreement is displayed as Pending Agreement Initiation",
								"PASS", "Y");
			}
			/**
			 * Step No : 80
			 */
			waitForObj(5000);
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			select(initiationPage.poleDropDown, "Americas");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(initiationPage.regionDropDown, "United States");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(initiationPage.spendCategoryDropDown, "Product Input");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(initiationPage.spendSubTypeDropDown, "Product Development (Royalty)");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			PDFResultReport.addStepDetails("Enter the Pole as Americas\n"
					+ "And Region as United States in Legal Entity section\n"
					+ "Spend category as Product Input ,\n"
					+ "Spend Sub Category as Product Development",
					"The mentioned selections should be made", "The mentioned selections is made",
					"PASS", "Y");
			select(initiationPage.payingCountryDropDown, "United States");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			/**
			 * Step No : 90
			 */
			select(initiationPage.businessDropDown, "Global Functions");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			String[] modalityValues={"Select...","GE Volunteers","Global Communications","Global Supply Chain","Human Resources"};
			List<WebElement> modalityDropDownValues=new Select(initiationPage.modalityDropDown).getOptions();
			System.out.println(modalityDropDownValues.size());
			int count=0;
			for(int i = 0;i < modalityDropDownValues.size();i++)
			{
				if (modalityDropDownValues.get(i).getText().contains(modalityValues[i]))
				{
					System.out.println("Value is verified in Master data table"+modalityDropDownValues.get(i).getText());				
					count++;
				}
			}
			if (count==5)
			System.out.println(count);
			PDFResultReport.addStepDetails(
					"Verify the values in the below dropdowns on the selection made\n"
					+ "Modality\n"
					+ "Legal Entity\n"
					+ "when business is selected as Global Functions", 
					"The values should be verified in Master data table", 
					"The values are verified in Master data table", "PASS", "N");
			/**
			 * Step No : 100
			 */
			consultingAgreementPage=new ConsultingAgreementPage(driver);
			BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
			BaseClass.waitForObj(5000);
			boolean alert = BaseClass.isAlertPresent();
			System.out.println("Alert Status: " + alert);
			BaseClass.handleAlert();
			BaseClass.waitForObj(2000);
			PDFResultReport.addStepDetails(
					"Before selecting Modality and Entity information, click on [Next]", 
					"Applictaion should through an error saying value cannot be blank", 
					"Applictaion is through an error saying value cannot be blank", "PASS", "N");
			BaseClass.waitForObj(2000);				
			/**
			 * Step No : 110
			 */
			consultingAgreementPage = new ConsultingAgreementPage(BaseClass.driver);
			switchToDefaultFrame();
			BaseClass.waitForObj(2000);
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);			
			initiationPage=new InitiationPage(driver);
			select(initiationPage.modalityDropDown, "GE Volunteers");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(initiationPage.legalEntityDropDown, "020110-GE Medical Systems (F39000)");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(initiationPage.productDropDown, "Investigational");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			select(initiationPage.productIndicatorDropDown, "None");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			BaseClass.click(initiationPage.onBehalfOfOtherYesRadioButton);
			BaseClass.waitForObj(8000);
			for(int i = 0;i < 5;i++)
			{
				BaseClass.set(initiationPage.transactionOwnerSerachBox,
						ExcelReport.testData.get("transactionsOwner"));
				BaseClass.waitForObj(2000);
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.searchButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
				boolean radioButtonForTransactionOwner = OneASTUtil.isElementPresent(By
						.name("$PldapResultsListView$ppySingleSelection"));
				if (radioButtonForTransactionOwner)
				{
					((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
							initiationPage.radioButtonForTransactionOwner);
					BaseClass.waitForObj(2000);
					((JavascriptExecutor) BaseClass.driver).executeScript(
							"arguments[0].scrollIntoView(true);",
							initiationPage.radioButtonForTransactionOwner);
					BaseClass.waitForObj(2000);
					break;
				} else
				{
					click(initiationPage.cancelButtonInModelPopUpWindow);
					BaseClass.waitForObj(5000);
				}
			}
			BaseClass.click(initiationPage.submitButtonForTransactionOwner);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			PDFResultReport.addStepDetails("Select Modality,Legal Entity from the dropdown.\n"
					+ "Select Request on behalf of others? as Yes give T.O SSO and\n"
					+ "Click  [Next]",
					"The scren should be navigated to Supporting Information tab",
					"The scren is navigated to Supporting Information tab", "PASS", "N");
			/**
			 * Step No : 120
			 */
			set(initiationPage.businessJustificationForEngagementTextField,
					"Business Justification for EngagementRequired");
			set(initiationPage.gehcProductOrServicesIncludedTextField,
					"GEHC Products/Services Included");
			set(initiationPage.consultantQualificationSummaryTextField,
					"Consultant Qualification Summary");
			set(initiationPage.payMentDetailsTextField, "Payment Details");
			set(initiationPage.serviceToBeProvidedTextArea, "SERVICE TO BE PROVIDED");
			waitForObj(8000);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.plusSymbolForServiceToBeProvided);
			waitForObj(8000);
			List<WebElement> serviceToBeProvidedTextArea = driver.findElements(By
					.xpath("//textarea[starts-with(@id,'ServiceProvided')]"));
			System.out.println(serviceToBeProvidedTextArea.size());
			if (serviceToBeProvidedTextArea.size() > 0)
			{
				set(serviceToBeProvidedTextArea.get(1), "SERVICE TO BE PROVIDED");
				waitForObj(3000);
				PDFResultReport
						.addStepDetails(
								"1)Fields that should display under Supporting Information tab\n"
										+ "	a) Business Justification for   Engagement *\n"
										+ "	b)GEHC Products/Services Included\n"
										+ "	c)Consultant Qualification Summary *\n"
										+ "	d) SERVICE TO BE PROVIDED *\n"
										+ "	e)Payment Details*\n"
										+ "2)Enter all the mandatory information in the supporting information tab and click [Next]",
								"User should be able to enter mutiple SERVICE TO BE PROVIDED by clicking on + symbol.\n"
										+ "Screen must be navigated to Agreement details tab",
								"User is able to enter mutiple SERVICE TO BE PROVIDED by clicking on + symbol.\n"
										+ "Screen is navigated to Agreement details tab", "PASS",
								"Y");
			}
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			/**
			 * Step No : 130
			 */
			set(initiationPage.agreementTitleTextField, "Consulting Agreement");
			OneASTUtil.selectBothEffectiveandExpirationDateFromCalender();
			BaseClass.click(initiationPage.willServiceCompensationBePaidYesRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			BaseClass.waitForObj(3000);
			OneASTUtil.addServiceProvider("GE ID", "100002198702");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			PDFResultReport
					.addStepDetails(
							"1.Enter all the required fields in Covered Recipients and Enter the actual effective date sections.\n"
									+ "2.Select the Yes radio button for the question Will the service compensation be paid? in Service Compensation Q&A section and\n"
									+ "Select service provider by clicking on Add Service Provider ( search the CR individual by GE ID)",
							"1.The fields should be entered successfully.\n"
									+ "2.Screen must be navigated to Fair Market Value tab and the FMV questions should be populated.\n"
									+ "	a)Number of Years of Experience (Post-Residency for Physicians)*\n"
									+ "	b)Number of Invited Lectures/Presentations Made in Past 5 Years*\n"
									+ "	c)Number of Peer-Reviewed Publications in Past 5 Years*\n"
									+ "	d) Currency in which the Speaker/Consultant is to be paid*",
							"1.The fields is entered successfully.\n"
									+ "2.Screen is navigated to Fair Market Value tab and the FMV questions are populated.\n"
									+ "	a)Number of Years of Experience (Post-Residency for Physicians)*\n"
									+ "	b)Number of Invited Lectures/Presentations Made in Past 5 Years*\n"
									+ "	c)Number of Peer-Reviewed Publications in Past 5 Years*\n"
									+ "	d) Currency in which the Speaker/Consultant is to be paid*",
							"PASS", "N");
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			/**
			 * Step NO : 140
			 */
			BaseClass.waitForObj(8000);
			String currency = text(initiationPage.defaultCurrency);
			//String hourlyRate = BaseClass.text(initiationPage.hourlyRate);
			/*PDFResultReport
					.addStepDetails(
							"1)Enter the required below FMV questions and click [Calculate] to calculate the Hourly FMV rate.\n"
									+ "Country* -Speciality/Role*\n"
									+ "Number of Years of Experience (Post-Residency for Physicians)*\n"
									+ "Number of Invited Lectures/Presentations Made in Past 5 Years*\n"
									+ "Number of Invited Lectures/Presentations Made in Past 5 Years*\n"
									+ "Currency in which the Speaker/Consultant is to be paid*\n"
									+ "2)Verify if the Hourly rate is correctly calculated.",
							"1)Hourly rate should be calculated based on the selection made and display under HOURLY/OVERRIDE RATE section.\n"
									+ "2)User below query to retreive the hourly rate",
							"1)Hourly rate is calculated based on the selection made and display under HOURLY/OVERRIDE RATE section.\n"
									+ "Hourly rate " + text(initiationPage.hourlyRate) + "",
							"PASS", "Y");*/
			//new Actions(driver).moveToElement(initiationPage.hourlyRate).build().perform();
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			/**
			 * Step NO : 150
			 */
			//BaseClass.click(initiationPage.overrideRate);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Select the checkbox Override Rate? in Fair Market Value (FMV) Compensation section.",
							"The Below fields should get populated on the selection made.\n"
									+ "â€¢ New Rate*\n" + "â€¢ Override Justification*",
							"The Below fields should get populated on the selection made.\n"
									+ "â€¢ New Rate*\n" + "â€¢ Override Justification*", "PASS", "Y");
			/**
			 * Step No : 160
			 */
			/*String[] hourlyRate1 = hourlyRate.split(Character.toString(currency.charAt(0)));
			if (Double.parseDouble(hourlyRate1[0]) > 1.00)
			{
				double newRate = Double.parseDouble(hourlyRate1[0]) + 1.00;
				BaseClass.set(initiationPage.newRate, String.valueOf(newRate));
			}
			BaseClass.set(initiationPage.overrideJustification, "Overriding the existing rate");*/
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			String serviceRate = text(initiationPage.serviceRate);
			String[] serviceRate1 = serviceRate.split(Character.toString(currency.charAt(0)));
			System.out.println(serviceRate1[0]);
			String preparationRate = text(initiationPage.serviceRate);
			String[] preparation1 = preparationRate.split(Character.toString(currency.charAt(0)));
			System.out.println(preparation1[0]);
			String travelRate = text(initiationPage.serviceRate);
			String[] travelRate1 = travelRate.split(Character.toString(currency.charAt(0)));
			System.out.println(travelRate1[0]);
			PDFResultReport
					.addStepDetails(
							"Enter the valid 'New rate' less than hourly rate and 'Override Justification'.",
							"The Hourly rates for 'Service', 'Preparation' and 'Travel' should get changed accordingly.",
							"The Hourly rates for 'Service': " + serviceRate1[0]
									+ ", 'Preparation' : " + preparation1[0] + " and 'Travel' : "
									+ travelRate1[0] + " is get changed accordingly.", "PASS", "Y");
			/**
			 * Step No : 170
			 */
			String serviceHours = "2.00";
			String preparationHours = "2.00";
			String travelHours = "2.00";
			/*BaseClass.set(initiationPage.serviceHours, serviceHours);
			BaseClass.waitForObj(5000);
			BaseClass.set(initiationPage.preparationHours, preparationHours);
			BaseClass.waitForObj(5000);
			BaseClass.set(initiationPage.travelHours, travelHours);
			BaseClass.waitForObj(5000);
			new Actions(BaseClass.driver).moveToElement(initiationPage.preparationHours).click()
					.build().perform();*/
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			String actualTotalHours = String.format("%.1f",
					Double.parseDouble(BaseClass.text(initiationPage.totalNoOfHours)));
			System.out.println("Actual Total Hours " + actualTotalHours);
			if (Double.parseDouble(actualTotalHours) == Double.parseDouble(serviceHours)
					+ Double.parseDouble(preparationHours) + Double.parseDouble(travelHours))
			{
				PDFResultReport
						.addStepDetails(
								"Enter the valid value in the 'Number of Hours' field under the 'service', 'preparation' and 'travel' sections.",
								"Total Service Amount, 'Total Preparation Amount' & 'Total Travel Amount' should be Service Rate * No of Hours",
								"Total Service Amount, 'Total Preparation Amount' & 'Total Travel Amount' is Service Rate * No of Hours",
								"PASS", "Y");
			}
			/**
			 * Step No : 180
			 */
			String totalCompensationAmount = text(initiationPage.serviceRate);
			String[] actualTotalCompensationAmount = totalCompensationAmount.split(Character
					.toString(currency.charAt(0)));
			if (Double.parseDouble(actualTotalHours) == Double.parseDouble(serviceHours)
					+ Double.parseDouble(preparationHours) + Double.parseDouble(travelHours)
					&& Double.parseDouble(serviceRate1[0]) + Double.parseDouble(preparation1[0])
							+ Double.parseDouble(travelRate1[0]) == Double
							.parseDouble(actualTotalCompensationAmount[0]))
			{
				PDFResultReport
						.addStepDetails(
								"Verify if the Total hours and Total Compensation Amount is displayed correctly",
								"The Total hours and Total Compensation Amount fields should get populated accordingly.\n"
										+ "Total Compensation Amount should be the sum of Total Service Amount,Total Preparation Amount and Total Travel Amount",
								"The Total hours and Total Compensation Amount fields is get populated accordingly.\n"
										+ "Total Compensation Amount is the sum of Total Service Amount,Total Preparation Amount and Total Travel Amount",
								"PASS", "Y");
			}
			/**
			 * Step No : 190
			 */
			// TODO reporting is available in
			// OneASTUtil.clickOnUploadsTabAndUploadTheFiles();
			/**
			 * Step No : 200
			 */
			waitForObj(5000);
			OneASTUtil.clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			waitForObj(5000);
			PDFResultReport.addStepDetails(
					"Upload the required documents and click on [Next] button.",
					"Screen should be navigated to Summary tab",
					"Screen is navigated to Summary tab", "PASS", "Y");
			/**
			 * Step No : 210
			 */
			PDFResultReport
					.addStepDetails(
							"Verify the Summary tab",
							"All the details that were entered in the previous tabs should populate correctly in the Summary tab",
							"All the details that were entered in the previous tabs is populate correctly in the Summary tab",
							"PASS", "Y");
			waitForObj(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,250)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			js.executeScript("window.scrollBy(0,500)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			waitForObj(2000);
			js.executeScript("window.scrollBy(0,750)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			js.executeScript("window.scrollBy(0,900)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			waitForObj(1000);
			/**
			 * Step No : 220
			 */
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
					initiationPage.nextButton);
			waitForObj(1000);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",
					initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			ApprovalPage approvalPage = new ApprovalPage(driver);
			boolean additionalCommentsTextArea = OneASTUtil.isElementPresent(By
					.name("$PpyWorkPage$pAdditionalCommentsCertApproval"));
			if (additionalCommentsTextArea)
			{
				set(approvalPage.additonalCommentesTextArea, "Please approve.");
				waitForObj(3000);
				click(approvalPage.approveButton);
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				waitForObj(5000);
			}
			boolean confirmationMessage = OneASTUtil
					.isElementPresent(approvalPage.confirmationMessage);
			System.out.println(confirmationMessage);
			if (confirmationMessage)
			{
				PDFResultReport.addStepDetails("Click on [Submit] button in the Summary tab",
						"The Agreement should be submitted successfully and below message should get displayed.\n"
								+ "Agreement A-xxx has been sent for Approval.\n"
								+ "Any change in status will be communicated via email.\n"
								+ "Thank you",
						"The Agreement is submitted successfully and below message is get displayed.\n"
								+ ""
								+ driver.findElement(approvalPage.confirmationMessage).getText()
								+ "", "PASS", "Y");
			}
			/**
			 * Step No : 230
			 */
			switchToDefaultFrame();
			System.out.println("Swithed to default Frame");
			waitForObj(2000);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",
					approvalPage.closeTab);
			waitForObj(2000);
			OneASTHomePage oneASTHomePage = new OneASTHomePage(BaseClass.driver);
			BaseClass.set(oneASTHomePage.searchTextField, agreementNumber);
			BaseClass.waitForObj(2000);
			BaseClass.click(oneASTHomePage.searchButtonField);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			BaseClass.waitForObj(8000);
			approvalPage = new ApprovalPage(driver);
			switchFrame(approvalPage.pegaGadet0Ifr);
			BaseClass.waitForObj(2000);
			status = BaseClass.text(approvalPage.status);
			String caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			String created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			String startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			String createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			String peendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			String transactionOwner = text(approvalPage.workDetails
					.get(ApprovalPage.TRANSACTION_OWNER));
			String directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			String complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ peendingWith + "\n"
									+ "9.Direct Manager: Direct manager name " + directManager
									+ "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
			/**
			 * Step No : 240
			 */
			switchToDefaultFrame();
			waitForObj(3000);
			AggregateSpendManagementNonUSPage aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(
					driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			waitForObj(3000);			
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "poleLeader", "password");
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Login to the Application as Transaction owner by entering the valid credentials and\n"
									+ "Click on [Login] Button present in the page.\n"
									+ "Login credentials:\n"
									+ "Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/o8uZcrjyYhEANdV611UguQ%5B%5B*/!STANDARD\n"
									+ "username : <Pole Leader>\n" + "password: <pswd_TO1> ",
							"The workflow should be displayed under 'My Action Items' section.",
							"The workflow is displayed under 'My Action Items' section.", "PASS",
							"N");
			/**
			 * Step No : 250
			 */
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(15000);
			driver.navigate().refresh();
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(10000);
			driver.navigate().refresh();
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(10000);
			// TODO
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(2000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(2000);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			String statusOfAgreement = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfAgreement.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <A-xxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the transaction owner.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the transaction owner.\n"
										+ "3.The Status of the Workflow is " + statusOfAgreement
										+ ".", "PASS", "Y");
			}
			/**
			 * Step No : 260
			 */
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			peendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ peendingWith + "\n"
									+ "9.Direct Manager: Direct manager name " + directManager
									+ "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
			/**
			 * Step No : 270
			 */
			approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			OneASTUtil.clickOnOtherActionsAndSelectDelegateToAnAdditionalApprover(
					ExcelReport.testData.get("Delegate"), "Delegate to another user");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			boolean radioButtonForTransactionOwner = OneASTUtil.isElementPresent(By
					.name("$PldapResultsListView$ppySingleSelection"));
			if (radioButtonForTransactionOwner)
			{
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.radioButtonForTransactionOwner);
				BaseClass.waitForObj(2000);				
			}
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			PDFResultReport
					.addStepDetails(
							"Select Delegate to an Additional Approver from Other actions dropdown and \n"
									+ "Enter the values in the fields populated on the selection made.\n"
									+ "2. Submit the Agreement.",
							"The Agreement should be submitted and it should be pending in the worklist of the Additional Approver to whom the delegation was made.\n"
									+ "2. Agreement should be submitted to the delegated approver",
							"The Agreement is submitted and it is pending in the worklist of the Additional Approver to whom the delegation was made.\n"
									+ "2. Agreement is submitted to the delegated approver",
							"PASS", "N");
			/**
			 * Step No : 280
			 */
			switchToDefaultFrame();
			waitForObj(3000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(
					driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			waitForObj(3000);
			driver.switchTo().window(tabs.get(0));
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(2000);
			PeagDesignerStudioHomePage peagDesignerStudioHomePage = new PeagDesignerStudioHomePage(
					driver);
			peagDesignerStudioHomePage = new PeagDesignerStudioHomePage(driver);
			System.out.println("Login User Name ::"
					+ text(peagDesignerStudioHomePage.globalMainLinks.get(5)));
			PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
					driver, text(peagDesignerStudioHomePage.globalMainLinks.get(5)),
					PeagDesignerStudioHomePage.LOG_OFF, false, StringUtils.EMPTY);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(2000);
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "AdditionalApprover", "password");
			waitForObj(5000);		
			PDFResultReport
					.addStepDetails(
							"Login to the Application as IPP COE by entering the valid credentials and click on [Login] Button present in the page.\n"
									+ "Login credentials:\n"
									+ "Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/o8uZcrjyYhEANdV611UguQ%5B%5B*/!STANDARD\n"
									+ "username : <Additonal Approver>\n" + "password: <pswd_TO1>",
							"The workflow should be displayed under 'My Action Items' section.",
							"The workflow is displayed under 'My Action Items' section.", "PASS",
							"N");
			/**
			 * Step No : 290
			 */
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(15000);
			// TODO
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(2000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(2000);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			statusOfAgreement = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfAgreement.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <A-xxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the  IPP COE.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the  Additional approver.\n"
										+ "3.The Status of the Workflow is " + statusOfAgreement
										+ ".", "PASS", "Y");
			}
			/**
			 * Step No : 300
			 */
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			peendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ peendingWith + "\n"
									+ "9.Direct Manager: Direct manager name " + directManager
									+ "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
			/**
			 * Step No : 310
			 */
			approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			set(approvalPage.additonalCommentesTextArea, "Approve");
			waitForObj(2000);
			click(approvalPage.approveButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			PDFResultReport
					.addStepDetails(
							"Review the details, click on the link and click [Approve] button",
							"The workflow should be approved and submitted for IPP COE approval.\n"
							+ "(check Master data table to know the IPP COE name)",
							"The workflow should be approved and submitted for IPP COE approval.\n"
							+ "(check Master data table to know the IPP COE name)",
							"PASS", "N");
			/**
			 * Step No : 320
			 */
			switchToDefaultFrame();
			waitForObj(3000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			waitForObj(3000);
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "IPPCOE", "password");
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Login to the Application as IPP COE by entering the valid credentials and click on [Login] Button present in the page.\n"
									+ "Login credentials:\n"
									+ "Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/o8uZcrjyYhEANdV611UguQ%5B%5B*/!STANDARD\n"
									+ "username : <IPP COE>\n" + "password: <pswd_TO1>",
							"The workflow should be displayed under 'My Action Items' section.",
							"The workflow is displayed under 'My Action Items' section.", "PASS",
							"N");
			
			
			
			
			/**
			 * Step No : 330
			 */
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(15000);
			// TODO
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(2000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(2000);
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			peendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ peendingWith + "\n"
									+ "9.Direct Manager: Direct manager name " + directManager
									+ "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
			/**
			 * Step No : 340
			 */
			approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			set(approvalPage.additonalCommentesTextArea, "Approve");
			waitForObj(2000);
			click(approvalPage.approveButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			PDFResultReport
					.addStepDetails(
							"Review the details, click on the link,upload the documents and click [Approve] button",
							"The workflow should be approved and submitted for Direct Manager approval",
							"The workflow is approved and submitted for Direct Manager approval",
							"PASS", "N");
			/**
			 * Step No : 350
			 */
			switchToDefaultFrame();
			waitForObj(3000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			waitForObj(3000);
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "DirectManagerName", "password");
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Login to the Application as Direct Manager by entering the valid credentials and click on [Login] Button present in the page.\n"
									+ "Login credentials:\n"
									+ "Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/o8uZcrjyYhEANdV611UguQ%5B%5B*/!STANDARD\n"
									+ "username : <Direct Manager>\n" + "password: <pswd_TO1>",
							"The workflow should be displayed under 'My Action Items' section.",
							"The workflow is displayed under 'My Action Items' section.", "PASS",
							"N");
			/**
			 * Step No : 360
			 */
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(15000);
			// TODO
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(2000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(2000);
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			peendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Activation\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ peendingWith + "\n"
									+ "9.Direct Manager: Direct manager name " + directManager
									+ "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
			/**
			 * Step No : 370
			 */
			approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			set(approvalPage.additonalCommentesTextArea, "Approve");
			waitForObj(2000);
			click(approvalPage.approveButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			PDFResultReport
					.addStepDetails(
							"Review the details, click on the link and click [Approve] button",
							"The workflow should be approved and submitted for IPP COE approval.",
							"The workflow is approved and submitted for IPP COE approval.",
							"PASS", "N");
			/**
			 * Step No : 380
			 */
			switchToDefaultFrame();
			waitForObj(3000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			waitForObj(3000);
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "IPPCOE", "password");
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Login to the Application as IPP COE by entering the valid credentials and click on [Login] Button present in the page.\n"
									+ "Login credentials:\n"
									+ "Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/o8uZcrjyYhEANdV611UguQ%5B%5B*/!STANDARD\n"
									+ "username : <IPP COE>\n" + "password: <pswd_TO1>",
							"The workflow should be displayed under 'My Action Items' section.",
							"The workflow is displayed under 'My Action Items' section.", "PASS",
							"N");
			/**
			 * Step No : 390
			 */
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(15000);
			// TODO
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(2000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(2000);
			caseId = text(approvalPage.workDetails.get(ApprovalPage.CASE_ID));
			created = text(approvalPage.workDetails.get(ApprovalPage.CREATED));
			startDate = text(approvalPage.workDetails.get(ApprovalPage.START_DATE));
			status = text(approvalPage.workDetails.get(ApprovalPage.STATUS));
			createdBy = text(approvalPage.workDetails.get(ApprovalPage.CREATED_BY));
			peendingWith = text(approvalPage.workDetails.get(ApprovalPage.PENDING_WITH));
			transactionOwner = text(approvalPage.workDetails.get(ApprovalPage.TRANSACTION_OWNER));
			directManager = text(approvalPage.workDetails.get(ApprovalPage.DIRECT_MANAGER));
			complainceEscalation = text(approvalPage.workDetails
					.get(ApprovalPage.COMPLIANCE_ESCALATION1));
			PDFResultReport
					.addStepDetails(
							"Verify below fields in work header section:\n" + "1.Case ID\n"
									+ "2.Status\n" + "3.Transaction Owner\n" + "4.Created\n"
									+ "5.Created  By\n" + "6.IPP COE\n" + "7.Event Start Date\n"
									+ "8.Pending with 9.Direct Manager\n"
									+ "10.Compliance Escalation",
							"Values should be displayed as below:\n"
									+ "1.Case id should be <A-xxxx>\n"
									+ "2.Status should be Pending-Approval\n"
									+ "3.Transaction Owner name should be displayed\n"
									+ "4.Created date should be correctly displayed in DD-MM-YY format\n"
									+ "5.Created By should be name of the person by whom the WF has been created\n"
									+ "6.IPP COE name should be blank\n"
									+ "7.Event Start Date should be the date when event is started in DD-MM-YY  format\n"
									+ "8.Pending with: Transaction Owner name\n"
									+ "9.Direct Manager: Direct manager name\n"
									+ "10. Compliance Escalation: Blank",
							"Values are displayed as below:\n" + "1.Case id is "
									+ caseId
									+ "\n"
									+ "2.Status is "
									+ status
									+ "\n"
									+ "3.Transaction Owner name is displayed "
									+ transactionOwner
									+ "\n"
									+ "4.Created date is correctly displayed in DD-MM-YY format "
									+ created
									+ "\n"
									+ "5.Created By is name of the person by whom the WF has been created "
									+ createdBy
									+ "\n"
									+ "6.IPP COE name is blank \n"
									+ "7.Event Start Date is the date when event is started in DD-MM-YY  format "
									+ startDate + "\n" + "8.Pending with: Transaction Owner name "
									+ peendingWith + "\n"
									+ "9.Direct Manager: Direct manager name " + directManager
									+ "\n" + "10. Compliance Escalation: Blank"
									+ complainceEscalation + "", "PASS", "Y");
				
			/**
			 * Step No : 400
			 */
			OneASTUtil.activateAgreement("TestData.xlsx", "Pending-Activation");
			switchToDefaultFrame();
			waitForObj(3000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(agreementNumber);
			switchToDefaultFrame();
			waitForObj(2000);
			switchFrame(homePage.pegaGadgetFrame);
			waitForObj(2000);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			statusOfAgreement = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfAgreement.equalsIgnoreCase("Resolved-Completed"))
			{
				PDFResultReport
						.addStepDetails(
								"Review the details, click on the link.\r"
										+ "Enter the expiration date, upload the documents and click on [Submit]",
								"Below confirmation message should be displayed and\n"
										+ "The status should change to Resolved-Completed Agreement A-xxxx has been Activated.\r"
										+ "Thank you",
								"Below confirmation message is displayed and\r"
										+ "The status is changed to Resolved-Completed Agreement "
										+ agreementNumber + " has been Activated.\r" + "Thank you",
								"PASS", "Y");
			}
			switchToDefaultFrame();
			waitForObj(3000);
			aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(driver);
			click(aggregateSpendManagementNonUSPage.closeTab);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(8000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			waitForObj(3000);
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
