package TestScripts;
import java.awt.AWTException;

import BaseClass.AutomationException;
import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.AggregateSpendManagementUtils;
import Components.CommonUtils;
import Components.OneASTHomePageUtils;
import Components.OneASTUtil;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.InitiationPage;
import ObjectRepository.OneASTHomePage;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;




public class TC01_Americas_US_DM_approval_PO_Requisition_Revise_the_Payment_method_Submit_Pending_Finalize_Reconcile extends BaseClass{
	
	public String eventNumber;
	public String status;
	public ConsultingAgreementPage consultingAgreementPage;
	public String ComplianceSSO;
	String tOwner ="";
	InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
	
	@Test(priority = 0,description = "Aggregate Spend Management")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "Doc1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "7");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "Sreekanth A");
			reportDetails.put("Name of Automation Test Script Author", "503076057");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "Doc1234567");
		reportDetails.put("Requirement ID", "");
		

	
	}
	
	
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{	
			OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
			PDFResultReport.addStepDetails(
					"Login to the Appliaction as Super User entering the valid credentials and \n"
							+ "Click on login button present in the page\n"
							+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
							+ "username : <Super user 1>\n" + "password: <pswd 1>",
					"Login page with title 'Aggregate Spend Management' should get displayed.",
					"Login page with title 'Aggregate Spend Management' get displayed.", "PASS", "N");
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@Test(priority = 2)
	public void clickOnConsultingEventAndSelectNewEventPlus() throws Exception
	{
		OneASTHomePageUtils.selectItemFromMenuPanelInOneASTHomePage(BaseClass.driver,
				OneASTHomePage.EVENT, OneASTHomePage.NEW_EVENTPLUS_EVENT, false, "");
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		
		BaseClass.waitForObj(500);	
		eventNumber = OneASTUtil.getEventOrAgreementNumber();
		System.out.println("Agreement Number :: " + eventNumber);
		
		PDFResultReport.addStepDetails("Navigate to Workflow --> Event --> New EventPlus", 
				"1. A EventPlus with case id <E-xxx> should be created  "
				+"2. Save, Submit, Other Actions dropdown , Close buttons should display at the top right.", 
				
				"1. A EventPlus with case id "+eventNumber +" is created  "
				+"2. Save, Submit, Other Actions dropdown , Close buttons is display at the top right.", "PASS", "Y");
		

				
	}
	
	@Test(priority=3)
	public void selectSpendCategoryEducationalItems(){
		
				
		initiationPage = new InitiationPage(driver);
		switchToDefaultFrame();
		BaseClass.waitForObj(1000);
		BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
		OneASTUtil.selectEventPlusSpendType("Educational Items");
		BaseClass.waitForObj(2000);
		eventNumber = OneASTUtil.getEventOrAgreementNumber();
		System.out.println("Agreement Number :: " + eventNumber);
		PDFResultReport.addStepDetails("Select Spend category as 'Educational Items' and click on [Submit] button", 
				
				"1. A new EventPlus - Educational Items <E-xxxxx> should be created and the status should be 'Pending-EventInitiation' \n"
			   +"2. 'CR Information' should get displayed with CR Inidividual, CR Organization and History. \n"
				+"3. 'Search Options' dropdown should display.", 
				
				"1. A new EventPlus - Educational Items "+eventNumber +" is created and the status is 'Pending-EventInitiation' \n"
				+"2. 'CR Information' is displayed with CR Inidividual, CR Organization and History. \n"
							+"3. 'Search Options' dropdown is display.", "PASS", "Y");
	}

	@Test(priority=5)
	public void verifyErrormessage() throws Exception{
		
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.waitForObj(4000);
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		String errorMsg = text(initiationPage.errorMessage);
		
		if(errorMsg.contains("Kindly Select an Individual/Organization")){
			
			PDFResultReport.addStepDetails("Click on Next button", 
					"The screen should display error message : \n"
					+"Kindly Select an Individual/Organization", 
					"The screen display error message : \n"
							+"Kindly Select an Individual/Organization", "PASS", "Y");
		}
	}
	
	@Test(priority=4)
	public void addIndividualsandDelete()
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		switchToDefaultFrame();
		BaseClass.waitForObj(1000);
		BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
		BaseClass.waitForObj(1000);
		OneASTUtil.selectCRType("Individual");
		BaseClass.waitForObj(2000);
		PDFResultReport.addStepDetails("","","", "PASS", "Y");
		BaseClass.waitForObj(2000);
		BaseClass.click(initiationPage.deleteIcon);
		BaseClass.waitForObj(4000);
		
	}
	
	@Test(priority=6)
	public void addIndividuals()
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		OneASTUtil.selectCRType("Individual");
		
		BaseClass.waitForObj(2000);
		OneASTUtil.addNewIndividual(initiationPage.addNewIndividualButton);
		BaseClass.waitForObj(1000);
		PDFResultReport.addStepDetails("Click on Add new individual \n","user should be able to enter all the mandatory fields \n","user is able to enter all the mandatory fields", "PASS", "Y");
		BaseClass.waitForObj(1000);
		BaseClass.mouseHover(initiationPage.crInformationBanner.get(0));
		new Actions(driver).moveToElement(initiationPage.crInformationBanner.get(0)).build().perform();
		BaseClass.waitForObj(2000);
		BaseClass.mouseHover(initiationPage.crInformationBanner.get(1));
		new Actions(driver).moveToElement(initiationPage.crInformationBanner.get(1)).build().perform();
		BaseClass.waitForObj(2000);
		click(initiationPage.nextButton);
		BaseClass.waitForObj(2000);
	}
	
	@Test(priority=7)
	public void addBusinessInformation()
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		tOwner = ExcelReport.testData.get("transactionsOwner");
		System.out.println(tOwner);
		BaseClass.waitForObj(4000);
		OneASTUtil.enterTheValuesInBusinessInformationTab("Americas", "United States", "United States",
				"Detection & Guidance Solutions (DGS)", "Interventional",
				"020110-GE Medical Systems (F39000)", "Innova IGS 540", "Covered", "Yes", tOwner,"", "",
				"Application Training");
		BaseClass.waitForObj(1000);
		PDFResultReport.addStepDetails("","","","PASS", "Y");
		BaseClass.waitForObj(2000);
		OneASTUtil.addEducationalItems();
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(8000);
		PDFResultReport
				.addStepDetails(
						"Enter below fields under Paying legal entity section:\n"
								+ "1.Pole:EMEA\n"
								+ "2.Region:EAGM\n"
								+ "3.Paying Country\n"
								+ "4.Business\n"
								+ "5.Modality\n"
								+ "6.Legal Entity\n"
								+ "7.Select yes for Are you submitting the request on behalf of others?\n"
								+ "8.Transaction Owner",
						"Should be able to enter all the mandatory fields",
						"User able to enter all the mandatory fields", "PASS", "Y");
		
		BaseClass.waitForObj(2000);
		click(initiationPage.nextButton);
		
	}
	
	@Test(priority=8)
	public void addbudgetDetails()
	{
		
		
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.waitForObj(5000);
		OneASTUtil.paymentMethodsInTheBudget("In-Kind","123","test","test",0);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.click(initiationPage.addItem);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		OneASTUtil.paymentMethodsInTheBudget("Pcard","123","test","test",1);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(2000);
		BaseClass.click(initiationPage.addItem);
		BaseClass.waitForObj(2000);
		OneASTUtil.paymentMethodsInTheBudget("Non-SSP PO","123","test","test",2);
		BaseClass.waitForObj(2000);
		BaseClass.click(initiationPage.addItem);
		BaseClass.waitForObj(2000);
		OneASTUtil.paymentMethodsInTheBudget("SSP PO","123","test","test",3);
		BaseClass.waitForObj(2000);
		PDFResultReport.addStepDetails("Select If SSP PO Payment Method involved  as No and add 6 budget lines with all payment methods and click [Next]",
				"1.When SSP PO is selected , question 'Is the vendor created in SSP?*' should be populated with Yes or No radiobuttons , \n"
				 +"2.Total Estimated Event Cost should be correctly calculated and screen should navigate to Uploads tab on clicking [Next]\n",
				 "1.When SSP PO is selected , question 'Is the vendor created in SSP?*' is populated with Yes or No radiobuttons , \n"
				+"2.Total Estimated Event Cost is correctly calculated and screen is navigated to Uploads tab on clicking [Next]\n",
						 "PASS", "Y");
		BaseClass.waitForObj(2000);
		OneASTUtil.addExpenseDetails("Educational Item","234");
		BaseClass.waitForObj(2000);
		
	}
	
	
	@Test(priority=9)
	public void addUploadswithSummary() throws AWTException
	{
		
			OneASTUtil.clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
			BaseClass.waitForObj(4000);
			click(initiationPage.nextButton);
		
			BaseClass.waitForObj(4000);
		
		
		
		if (initiationPage.summaryTab.getText().equalsIgnoreCase("Summary"))
		{
			PDFResultReport
					.addStepDetails("Upload the Required document and click on [Next] button",
							"Summary tab should get displayed", "Summary tab is displayed",
							"PASS", "Y");
		}
		
		click(initiationPage.submitButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(5000);
		if (initiationPage.confirmationMessageOnSubmission
				.getText().trim()
				.startsWith(
						"Event "
								+ eventNumber
								+ " has been submitted for Approval. Any change in status will be communicated via email."))
		{
			PDFResultReport
					.addStepDetails(
							"Verify all the details entered in the previous  screens are populated in the Summary tab and click on [Sumbit]",
							" All the details entered in the previous tab should be displayed in the Summary tab correctly, "
							+ "PO Request section should display with SSPPO details and should be in read-only.\n"
							+ " Event E-XXXX has been submitted for Approval.\n"
							+ "Any change in status will be communicated via email.\n"
							+ "Thank you",
							"Wf is assigned for Direct Manager and below Confirmation message should get displayed\n"
							+ " "
							+ initiationPage.confirmationMessageOnSubmission.getText()
							+ "", "PASS", "Y");
		}
		BaseClass.waitForObj(4000);
		
	}
	
	@Test(priority=10)
	public void logOutfromApplication()
	{
		
		try {
			System.out.println("Starting of Logout");

			
			/*AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);*/
			
			OneASTUtil.logOutFromAppalication();
			System.out.println("Ending of Logout");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Test(priority=11)
	public void directManagerApproval()
	{
		
		
		try {
			OneASTUtil.loginandclickonOneASTRadioButton("DirectManagerName"); 
			BaseClass.waitForObj(3000);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			BaseClass.waitForObj(2000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			consultingAgreementPage = new ConsultingAgreementPage(driver); 
			String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			
			if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for Super User.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the super user.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
			BaseClass.waitForObj(4000);
			OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();
			BaseClass.waitForObj(4000);
			if (initiationPage.confirmationMessageOnSubmission
					.getText()
					.trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ " Has Been Submitted For Further Process."))
		
			/**
			 *  LOG OUT From Direct Manager
			 */
				BaseClass.waitForObj(4000);
			
			OneASTUtil.logOutFromAppalication();
			
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	@Test(priority=12)
	public void getPoRequisitionstatus()
	{
		/**
		 *  LOGIN with Super User 
		 */
		
		OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
		
		BaseClass.waitForObj(3000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		
		
	}
	
	@Test(priority=13)
	public void revisepayment()
	{
		BaseClass.waitForObj(3000);
		OneASTUtil.verifyIsApprovalLinkAvailable();
		
		/**
		 *   STEP 27 
		 */
		
		OneASTUtil.clickOnOtherActionsAndSelectCoresspondingValue("Revise Payment Methods");
		BaseClass.waitForObj(2000);
		BaseClass.select(initiationPage.sspoDropdown, "Non-SSP PO");
		PDFResultReport.addStepDetails("","","", "PASS", "Y");
		BaseClass.waitForObj(4000);
		click(initiationPage.submitButton);
		BaseClass.waitForObj(2000);
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		 statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			
			if (statusOfEvent.equalsIgnoreCase("Pending-PORequisition"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for Super User.\n"
										+ "3.The Status of the Workflow should be Pending-PORequisition.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the super user.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
	
		BaseClass.waitForObj(3000);
		click(initiationPage.submitButton);
		
		BaseClass.waitForObj(4000);
		 statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			
			if (statusOfEvent.equalsIgnoreCase("Pending-Finalize/Reconcile"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The Event should be pending with Super User/ Requestor based on the Approval Matrix.\n"
										+ "2.The status of the Agreement should be 'Pending-Finalize/Reconcile'.\n"
									,
								"1.The Event is pending with Super User/ Requestor based on the Approval Matrix.\n"
										+"2.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
		
		
	}
	
	
	
		
		
		
		

}
