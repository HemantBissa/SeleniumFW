package TestScripts;

import java.awt.AWTException;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import BaseClass.AutomationException;
import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.CommonUtils;
import Components.OneASTHomePageUtils;
import Components.OneASTUtil;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.InitiationPage;
import ObjectRepository.OneASTHomePage;

public class TC01_Showsite_Agreement_Americas_UnitedStates extends BaseClass{
	public String status;
	public ConsultingAgreementPage consultingAgreementPage;
	public String ComplianceSSO;
	String tOwner ="";
	String eventNumber = "";
	InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
	public static ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
	
	@Test(priority = 0,description = "Aggregate Spend Management")
	public void initialize() throws Exception
	{
		BaseClass.reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		BaseClass.reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "Doc1234567");
		BaseClass.reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "7");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			BaseClass.reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			BaseClass.reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			BaseClass.reportDetails.put("SSO ID of Automation Test Script Author", "Sreekanth A");
			BaseClass.reportDetails.put("Name of Automation Test Script Author", "503076057");
		}
		BaseClass.reportDetails.put("Test Script Type", "System Testing");
		BaseClass.reportDetails.put("Requirement Document ID of System", "Doc1234567");
		BaseClass.reportDetails.put("Requirement ID", "");
		

	
	}

	/**
	 *  Step No : 01 & 02
	 *  Login to the Application as Super User 
	 */
	
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{
			OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
			PDFResultReport.addStepDetails(
					"Login to the Appliaction as Super User entering the valid credentials and \n"
							+ "Click on login button present in the page\n"
							+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
							+ "username : <Super user 1>\n" + "password: <pswd 1>",
					"Login page with title 'Aggregate Spend Management' should get displayed.",
					"Login page with title 'Aggregate Spend Management' get displayed.", "PASS", "N");
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	
	
	/**
	 *  Step No : 3
	 *  Navigate to Workflow "New Event plus"
	 *   
	 * @throws Exception
	 */
	@Test(priority = 2)
	public void clickOnConsultingEventAndSelectNewEventPlus() throws Exception
	{
		try {
			/*OneASTHomePageUtils.selectItemFromMenuPanelInOneASTHomePage(BaseClass.driver,
					OneASTHomePage.AGREEMENT, OneASTHomePage.NEW_SHOWSITE_AGREEMENT, false, "");*/
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(500);
		
			eventNumber = OneASTUtil.getEventOrAgreementNumber();
			System.out.println("Agreement Number :: " + eventNumber);
						
			PDFResultReport.addStepDetails("Navigate to Workflow --> Agreement --> New ShowSite Agreement", 
					"1. A EventPlus with case id <E-xxx> should be created  "
					+"2. Save, Submit, Other Actions dropdown , Close buttons should display at the top right.", 
					
					"1. A EventPlus with case id "+eventNumber +" is created  "
					+"2. Save, Submit, Other Actions dropdown , Close buttons is display at the top right.", "PASS", "Y");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

				
	}
	
	/**
	 *  Step No : 04 , 05 & 06
	 *  Search or Add any Organization
	 *  
	 */
	
	@Test(priority = 3)
	public void searchforaOrganizationorAdd()
	{
		try {
			initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.switchToDefaultFrame();
			BaseClass.waitForObj(1000);
			BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
			BaseClass.waitForObj(1000);
			OneASTUtil.addNewOrganization();
			 PDFResultReport.addStepDetails("Add the CR to the agreement and Click on Submit button",
					 "1. The fields should be displayed after adding the CR: \n " +
							 "1) Organization Name \n" +
							 "2) Street Address \n" +
							 "3) City \n" + 
							 "4) Country/State  \n " +
							 "5) Unique HCP Identifier/NPI \n" +
					"2. Agreement should allow only one CR \n" +
					"3. Added CR should be replaced with newly added CR \n " +
					"4. After clicking on Submit button Workflow should be navigated to Legal Entity info page",
					 "1. The fields should be displayed after adding the CR: \n " +
							 "1) Organization Name \n" +
							 "2) Street Address \n" +
							 "3) City \n" + 
							 "4) Country/State  \n " +
							 "5) Unique HCP Identifier/NPI \n" +
					"2. Agreement should allow only one CR \n" +
					"3. Added CR should be replaced with newly added CR \n " +
					"4. After clicking on Submit button Workflow should be navigated to Legal Entity info page", "PASS", "Y");
			 BaseClass.waitForObj(2000);
			 BaseClass.click(initiationPage.nextButton);
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/**
	 *  Step No : 07 , 08 & 09
	 *  Search or Add any Organization
	 *  
	 */
	@Test(priority = 4)
	public void legalEntityInfo()
	{
		try {
			BaseClass.waitForObj(4000);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			tOwner = ExcelReport.testData.get("transactionsOwner");
			 
			 PDFResultReport.addStepDetails("Select the pole as AMERICAS and region as 'UNITED STATES'",
					 "User should be able to select the pole as AMERICAS and region as 'UNITED STATES'",
					 "User is able to select the pole as AMERICAS and region as 'UNITED STATES'", "PASS", "Y");
			 BaseClass.waitForObj(2000);
			OneASTUtil.enterTheValuesInBusinessInformationTab("Americas", "United States", "United States",
					"Detection & Guidance Solutions (DGS)", "Interventional",
					"020110-GE Medical Systems (F39000)", "Investigational", "Covered", "Yes", tOwner,"", "",
					"");
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			 BaseClass.waitForObj(2000);
			 BaseClass.click(initiationPage.nextButton);
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 *  Step No : 10 & 11
	 * Add Agreement Compensiation details
	 *  
	 */
	
	@Test(priority = 5)
	public void agreementAndCompensiationDetailsTab()
	{
		try {
			String businessjustification = ExcelReport.testData.get("businessjustificationText");
			String gehc = ExcelReport.testData.get("gehcText");
			String noofVisitors = ExcelReport.testData.get("noofVisitorsText");
			String fmvpaymentVisitors = ExcelReport.testData.get("fmvpaymentVisitorsText");
			String fmvjustification = ExcelReport.testData.get("fmvjustificationText");
			String name = ExcelReport.testData.get("nameText");
			String agreementTitle = ExcelReport.testData.get("agreementTitleText");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(4000);
			PDFResultReport.addStepDetails("Check all the fields in Agreement  Details section ",
					"The below fields should be displayed in Agreement details section : \n " +
							"1. Business Justification for Engagement (open field) mandatory \n"+ 
							"2. GEHC Products/Services Included (open field) with banner that says �**Note � for all regions outside of U.S.� � mandatory \n "+
							"3. Contract Effective Start/End Date � mandatory \n "+
							"a. Validations: \n "+
							  "i. Start date should be equal to or greater than created date \n "+
							  "ii. End date should be equal to or greater than start date \n " +
							  "iii. For US regions alone, the start date should be greater than one year. \n " +
							"4. CR information (name, address, GE ID) pre- populated based on the CR chosen in the CR info section. \n " +
							"5. Agreement Title (open field) \n " +
							"6. Payee Recipient - Add Payee button to be enable besides this label. \n" +
							" On clicking the add payee the vendor search pop up should be enabled .\n " + 
							"Vendor selected ok clicked. Based on the vendor selected the vendor name should be populated against this label \n" +
							"7. Showsite Contact information (Name) \n" +
							"8. Showsite Tax ID/NPI � only Pole = Americas & Region= United States is chosen in legal entity",
							
							"The below fields should be displayed in Agreement details section : \n " +
							"1. Business Justification for Engagement (open field) mandatory \n"+ 
							"2. GEHC Products/Services Included (open field) with banner that says �**Note � for all regions outside of U.S.� � mandatory \n "+
							"3. Contract Effective Start/End Date � mandatory \n "+
							"a. Validations: \n "+
							  "i. Start date should be equal to or greater than created date \n "+
							  "ii. End date should be equal to or greater than start date \n " +
							  "iii. For US regions alone, the start date should be greater than one year. \n " +
							"4. CR information (name, address, GE ID) pre- populated based on the CR chosen in the CR info section. \n " +
							"5. Agreement Title (open field) \n " +
							"6. Payee Recipient - Add Payee button to be enable besides this label. \n" +
							" On clicking the add payee the vendor search pop up should be enabled .\n " + 
							"Vendor selected ok clicked. Based on the vendor selected the vendor name should be populated against this label \n" +
							"7. Showsite Contact information (Name) \n" +
							"8. Showsite Tax ID/NPI � only Pole = Americas & Region= United States is chosen in legal entity", "PASS", "Y");

			OneASTUtil.agreementandCompensationdetails(businessjustification,gehc,noofVisitors,fmvpaymentVisitors,
					fmvjustification,name,agreementTitle);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			
			
			OneASTUtil.addPayee(2, ExcelReport.testData.get("searchOptionsDropDownValue"),
					ExcelReport.testData.get("cityValue"), ExcelReport.testData.get("gsl"),
					ExcelReport.testData.get("vendorName"),
					ExcelReport.testData.get("countryDropDownValue"));
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
					} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 *  Step No : 12 & 13
	 *  Search or Add any Organization
	 *  
	 */
	
	@Test(priority = 6)
	public void uploadTabandSummary() throws AWTException
	{
		try {
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			
			OneASTUtil.clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
			BaseClass.waitForObj(4000);
			PDFResultReport.addStepDetails("Verify the Uploads section and below fields after clicking any attachment \n"+
											"* Subject ,\n"  +
											"* File, \n"+
											"* Attachment Category",
											"Below uploads should be displayed : \n" +
											"* Agenda / Transaction Owner Checklist , \n" +
											"* FMV Calculation ,\n" +
											"* Needs Assessment Approval (required if new showsite) : Optional",
											"Below uploads are displayed : \n" +
													"* Agenda / Transaction Owner Checklist , \n" +
													"* FMV Calculation ,\n" +
													"* Needs Assessment Approval (required if new showsite) : Optional",
													"PASS", "Y");
			BaseClass.waitForObj(4000);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			click(initiationPage.nextButton);
			
			PDFResultReport
			.addStepDetails(
					"Verify the Summary section and click on submit",
					"All the details that were entered in the previous tabs should populate correctly in the Summary tab",
					"All the details that were entered in the previous tabs is populate correctly in the Summary tab",
					"PASS", "Y");
						waitForObj(2000);
						JavascriptExecutor js = (JavascriptExecutor) driver;
						js.executeScript("window.scrollBy(0,250)");
						waitForObj(1000);
						PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
						js.executeScript("window.scrollBy(0,500)");
						waitForObj(1000);
						PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
						waitForObj(2000);
						js.executeScript("window.scrollBy(0,750)");
						waitForObj(1000);
						PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
						js.executeScript("window.scrollBy(0,900)");
						waitForObj(1000);
						PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
						waitForObj(1000);
						BaseClass.waitForObj(4000);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						click(initiationPage.nextButton);
						
						CommonUtils.waitUntilAjaxRequestCompletes(driver);
						waitForObj(1000);
						OneASTUtil.logOutFromAppalication();
						
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	/**
	 *  Step No : 14 & 15
	 *  Approve with IPP COE  & Direct Manager
	 *  
	 */
	
	@Test(priority = 7)
	public void approvewithIPPCOEandDirectManager()
	{
		try {
			OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName");
			BaseClass.waitForObj(3000);
			PDFResultReport.addStepDetails("Log in with IPP COE and open the workflow and click on Approve button",
					"The workflow should be submitted for Direct manager approval",
					"The workflow is submitted for Direct manager approval", "PASS", "N");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.waitForObj(3000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);	
			OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.waitForObj(2000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			OneASTUtil.logOutFromAppalication();
			
			
			OneASTUtil.loginandclickonOneASTRadioButton("DirectManagerName");
			BaseClass.waitForObj(3000);
			PDFResultReport.addStepDetails("Log in as Direct manager and open the workflow and click on Approve button",
					"workflow should be navigated to IPPCOE for activation of the agreement",
					"workflow is navigated to IPPCOE for activation of the agreement", "PASS", "N");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.waitForObj(3000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);	
			OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.waitForObj(2000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			OneASTUtil.logOutFromAppalication();
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
	/**
	 *  Step No : 16
	 *  Login with IPPCOE and open the workflow and verify the status
	 *  
	 */
	
	@Test(priority = 8)
	public void uploadfileandApprovewithIPPCOE() throws AWTException
	{
		try {
			OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName");
			BaseClass.waitForObj(3000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			BaseClass.waitForObj(3000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(BaseClass.driver);
			String status = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if ( status.trim().equalsIgnoreCase("Pending-Activation"))
			{
				PDFResultReport
						.addStepDetails(
								"Login with IPPCOE and open the workflow and verify the status",
								"Workflow should be opened and the status should be Pending-Activation",
								"Workflow is opened and the status is " +status+ "", 
								"PASS", "Y");
			}
			BaseClass.waitForObj(3000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);	
			OneASTUtil.verifyIsApprovalLinkAvailable();
			BaseClass.waitForObj(2000);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.waitForObj(2000);
			OneASTUtil.singleUpload("TestData.xlsx");
			BaseClass.waitForObj(4000);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			click(initiationPage.nextButton);
			BaseClass.waitForObj(4000);
			OneASTUtil.logOutFromAppalication();
			
			
			OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName");
			BaseClass.waitForObj(3000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			BaseClass.waitForObj(3000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);	
			if ( status.trim().equalsIgnoreCase("Resolved-Completed"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on submit after entering mandatory fields",
								"The agreements should be activated and the status should be 'Resolved-Completed'",
								"The agreements is activated and the status is" +status+ "", 
								"PASS", "Y");
			}
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
