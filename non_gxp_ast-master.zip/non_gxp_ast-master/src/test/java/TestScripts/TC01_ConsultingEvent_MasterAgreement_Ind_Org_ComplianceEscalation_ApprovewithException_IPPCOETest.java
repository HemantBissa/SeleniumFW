package TestScripts;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.AggregateSpendManagementUtils;
import Components.CommonUtils;
import Components.OneASTHomePageUtils;
import Components.OneASTUtil;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.InitiationPage;
import ObjectRepository.OneASTHomePage;

public class TC01_ConsultingEvent_MasterAgreement_Ind_Org_ComplianceEscalation_ApprovewithException_IPPCOETest extends BaseClass
{
	public String eventNumber;
	public String status;
	public ConsultingAgreementPage consultingAgreementPage;
	public String ComplianceSSO;
	InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
	String[] agreements=null;
	String tOwner ="";
	@Test(priority = 0,description = "Aggregate Spend Management")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "Doc1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "7");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "Sindhu Vankadari");
			reportDetails.put("Name of Automation Test Script Author", "502616489");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "Doc1234567");
		reportDetails.put("Requirement ID", "");
		

	
	}
	
	/**
	 * Step No : 10
	 */
	
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{	
			OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
			PDFResultReport.addStepDetails(
					"Login to the Appliaction as Super User entering the valid credentials and \n"
							+ "Click on login button present in the page\n"
							+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
							+ "username : <Super user 1>\n" + "password: <pswd 1>",
					"Login page with title 'Aggregate Spend Management' should get displayed.",
					"Login page with title 'Aggregate Spend Management' get displayed.", "PASS", "N");
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	
	/**
	 * Step No : 20
	 * @throws Exception 
	 */
	@Test(priority = 2)
	public void clickOnConsultingEventAndSelectNewConsultingEvent() throws Exception
	{
		OneASTHomePageUtils.selectItemFromMenuPanelInOneASTHomePage(BaseClass.driver,
				OneASTHomePage.EVENT, OneASTHomePage.NEW_CONSULTING_EVENT, false, "");
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		
		BaseClass.waitForObj(2000);	
		eventNumber = OneASTUtil.getEventOrAgreementNumber();
		System.out.println("Agreement Number :: " + eventNumber);
		//System;
		PDFResultReport.addStepDetails("Navigate to Workflow --> Event --> New Consulting Event", 
				"1. A Consulting Event with case id <E-xxx> should be created and radio buttons with below labels should get displayed "
				+"a.'Master Agreement'\n"
				+"b. 'Single Event Agreement'\n"
				+"2. The status of the Agreement should be displayed as 'Pending-EventIntiation'.", 
				
				"'1. A Consulting Agreement with case id "+eventNumber +" is created and radio buttons with below labels should get displayed in 'Select CR' page. \n"
						+"1. 'Individual' \n"
						+"2. 'Organization' \n"
						+"2. The status of the Agreement should be displayed as 'New'.", "PASS", "Y");
		
	//	OneASTUtil.amendAgreementandSearchOptions(ExcelReport.testData.get("TC05_searchType_AmendAgreement"));
				
	}
	
	@Test(priority=3)
	public void selectEventType(){
		
		//BaseClass.waitForObj(30000);
		
		initiationPage = new InitiationPage(driver);
		switchToDefaultFrame();
		BaseClass.waitForObj(2000);
		BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
		OneASTUtil.selectConsultingEventType("Master");
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails("Select the 'Master Agreement' radio button and click on [Submit] button.", 
				
				"The screen should navigate to 'Search Agreement Options' page with below tabs. \n"
				+"1. Agreement ID \n"
				+"2. Covered Recepient - Individual \n"
				+"3. Covered Recepient - Organization", 
				
				"The screen is navigated to 'Search Agreement Options' page with below tabs. \n"
						+"1. Agreement ID \n"
						+"2. Covered Recepient - Individual \n"
						+"3. Covered Recepient - Organization", "PASS", "Y");
	}

	
	@Test(priority=4)
	public void verifyErrormessage() throws Exception{
		
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		
		click(initiationPage.nextButton);
		
		String errorMsg = text(initiationPage.errorMessage);
		
		if(errorMsg.contains("Please search and select master agreement to amend")){
			
			PDFResultReport.addStepDetails("Click on Next button", 
					"The screen should display error message : \n"
					+"Please search and select master agreement to amend", 
					"The screen display error message : \n"
							+"Please search and select master agreement to amend", "PASS", "Y");
		}
	}

	
	@Test(priority=5)
	public void selectAgreement() throws Exception
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.select(initiationPage.searchAgreementOptions, "Agreement ID");
		
		agreements = ExcelReport.testData.get("TC01_ConsultingEvent_Agreements").split(",");
		OneASTUtil.searchWithAgreementandClickonSearch(agreements[0]);
		BaseClass.waitForObj(4000);
		initiationPage.agreementID.clear();
		OneASTUtil.searchWithAgreementandClickonSearch(agreements[1]);
		BaseClass.waitForObj(2000);
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(4000);
		
		PDFResultReport.addStepDetails("Select the agreement as 1 - Ind Agreement , 1 Org Agreement and click on 'Next' button", 
						"The screen should be navigated to CR information page", 
						"The screen is navigated to CR information page", "PASS", "Y");
		
		Boolean CRIndividual = initiationPage.crIndividuals.get(1).isDisplayed();
		
		click(initiationPage.crOrganizationTab);
		PDFResultReport.addStepDetails("",	
				"", 
				"", "PASS", "Y");
		BaseClass.waitForObj(4000);
		Boolean CROrganization = initiationPage.crOrganization.get(1).isDisplayed();
		
		BaseClass.waitForObj(2000);
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(4000);
		PDFResultReport.addStepDetails("Verify the CRs and click on 'Next' button", 
				"The Workflow should be navigated to 'Event Information' tab", 
				"The Workflow is navigated to 'Event Information' tab", "PASS", "Y");
		BaseClass.waitForObj(2000);
		tOwner = ExcelReport.testData.get("transactionsOwner");
		System.out.println(tOwner);
		BaseClass.waitForObj(4000);
		OneASTUtil.enterTheValuesInBusinessInformationTab("EMEA", "EAGM", "Egypt",
				"Detection & Guidance Solutions (DGS)", "Interventional",
				"680210-GEMS EGYPT LTD", "", "", "Yes", tOwner,"", "Product Training",
				"Application Training");
			
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(8000);
		PDFResultReport
				.addStepDetails(
						"Enter below fields under Paying legal entity section:\n"
								+ "1.Pole:EMEA\n"
								+ "2.Region:EAGM\n"
								+ "3.Paying Country\n"
								+ "4.Business\n"
								+ "5.Modality\n"
								+ "6.Legal Entity\n"
								+ "7.Select yes for Are you submitting the request on behalf of others?\n"
								+ "8.Transaction Owner",
						"Should be able to enter all the mandatory fields",
						"User able to enter all the mandatory fields", "PASS", "N");
		
		PDFResultReport.addStepDetails("Enter below fields under Spend Details section:\n"
				+ "Spend Type:Consulting(default)\n" + "Spend Category:Product Training\n"
				+ "Spend Sub Category:Application Training",
				"Should be able to enter all the mandatory fields",
				"User able to enter all the mandatory fields", "PASS", "Y");
		
		OneASTUtil.enterEventInforamtionAndVenueInformation_MasterConsultingEvent("Consulting Event",
				 "GE Site", "venue Name Field",
				"Afghanistan", "venue City Field");
		PDFResultReport.addStepDetails(
				"Enter below fields under Event Info section and Venue Info\n"
						+ "1.Event Start Date\n" + "2.Event End Date\n" + "3.Event Title\n"
						+ "4.Business/Event Justification\n" + "Venue Info:\n"
						+ "1.Venue type\n" + "2.Venue Name\n" + "3.Country\n" + "4.City",
				"Should be able to enter all the mandatory fields",
				"User able to enter all the mandatory fields", "PASS", "Y");
		
		By agreement1 = By.xpath("//span[contains(text(),'"+agreements[0]+"')");
		By agreement2 = By.xpath("//span[contains(text(),'"+agreements[1]+"')");
		
		
		
		click(initiationPage.nextButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(2000);
		PDFResultReport.addStepDetails("",	
				"", 
				"", "PASS", "Y");
		click(initiationPage.nextButton);
		if(OneASTUtil.isElementPresent(initiationPage.masterAgreementDetails) && 
				OneASTUtil.isElementPresent(agreement1) && OneASTUtil.isElementPresent(agreement2)){
			
			PDFResultReport.addStepDetails("Verify the 'Agreement Details' values and click on 'Next' button", 
					"The details should be autopopulated from the master agreement and workflow should be moved to 'Fair Market Value(FMV)' tab", 
					"The details are autopopulated from the master agreement and workflow is moved to 'Fair Market Value(FMV)' tab", "PASS", "Y");
		}else{
			
			PDFResultReport.addStepDetails("Verify the 'Agreement Details' values and click on 'Next' button", 
					"The details should be autopopulated from the master agreement and workflow should be moved to 'Fair Market Value(FMV)' tab", 
					"The details are not autopopulated from the master agreement and workflow is moved to 'Fair Market Value(FMV)' tab", "PASS", "Y");
		}
	
		BaseClass.waitForObj(4000);
		PDFResultReport.addStepDetails("Verify the FMV values", 
				"The Hourly rates for 'Service', 'Preparation' and 'Travel' should get autopopulated from the agreement", 
				"The Hourly rates for 'Service', 'Preparation' and 'Travel' get autopopulated from the agreement", "PASS", "Y");
		
		if(OneASTUtil.isElementPresent(initiationPage.servBusinessJust))
		{
			click(initiationPage.serviceBusinessJustification.get(0));
		}
		BaseClass.waitForObj(2000);
			
		
		if(OneASTUtil.isElementPresent(initiationPage.servBusinessJust))
		{
			click(initiationPage.serviceBusinessJustification.get(4));
		}
		BaseClass.waitForObj(2000);
		
		
		PDFResultReport.addStepDetails("Change the FMV values", "User should be able to change the hours", 
				 "User is able to change the hours ", "PASS", "Y");
		click(initiationPage.nextButton);
			BaseClass.waitForObj(3000);
		PDFResultReport.addStepDetails("Click on submit button","Workflow should be navigated to 'Budget' section",
				"Workflow is navigated to 'Budget' section","PASS" ,"Y");
		
	/**
	 * Gather Budget Details Tab
	 */
		BaseClass.waitForObj(2000);
		
		OneASTUtil.paymentMethodsInTheBudget("In-Kind","2356","test","test",0);
		BaseClass.waitForObj(2000);
		OneASTUtil.paymentMethodsInTheBudget("Non-SSP PO","3456","test","test",1);
		BaseClass.waitForObj(2000);
		PDFResultReport.addStepDetails("","","","PASS" ,"Y");
		click(initiationPage.nextButton);
		BaseClass.waitForObj(6000);
		PDFResultReport.addStepDetails("Enter all the mandatory fields in the budget section and click on 'Next' button",
				"Workflow should be navigated to 'Uploads' section",
				"Workflow is navigated to 'Uploads' section","PASS" ,"Y");
		
		
		/**
		 *  Upload Tab   Step : 18 in TC   I19
		 */
		BaseClass.waitForObj(1000);
		
		System.out.println("Upload");
		
		if(OneASTUtil.isElementPresent(initiationPage.uploadButton)){
		OneASTUtil.clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
		}
		else
		{
			click(initiationPage.nextButton);
		}
		BaseClass.waitForObj(4000);
		
		if (initiationPage.summaryTab.getText().equalsIgnoreCase("Summary"))
		{
			PDFResultReport
					.addStepDetails("Upload the Required document and click on [Next] button",
							"Summary tab should get displayed", "Summary tab is displayed",
							"PASS", "Y");
		}
		
		click(initiationPage.submitButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(5000);
		if (initiationPage.confirmationMessageOnSubmission
				.getText().trim()
				.startsWith(
						"Event "
								+ eventNumber
								+ " has been submitted for Approval. Any change in status will be communicated via email."))
		{
			PDFResultReport
					.addStepDetails(
							"Click on [Submit] button",
							"Wf should be assigned for IPP COE Approval and below Confirmation message should get displayed\n"
									+ " Event E-XXXX has been submitted for Approval.\n"
									+ "Any change in status will be communicated via email.\n"
									+ "Thank you",
							"Wf is assigned for IPP COE Approval and below Confirmation message should get displayed\n"
									+ " "
									+ initiationPage.confirmationMessageOnSubmission.getText()
									+ "", "PASS", "Y");
		}
		
		System.out.println("Close Event");
		//OneASTUtil.pendingWith = OneASTUtil.getPendingUserNameBySearchEventOrAgreement(eventNumber);
		
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		
		
	/**
	 *   Login with IPPCOE 
	 */
		
	
		OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName"); 
		BaseClass.waitForObj(2000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);

		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		consultingAgreementPage = new ConsultingAgreementPage(driver); 
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		// COMMENTS STRT
		if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
		{
			PDFResultReport
					.addStepDetails(
							"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
							"1.The workflow should get open in review mode with a link.\n"
									+ "2.The link should be enabled for Super User.\n"
									+ "3.The Status of the Workflow should be Pending-Approval.",
							"1.The workflow is opened in review mode with a link.\n"
									+ "2.The link id enabled for the super user.\n"
									+ "3.The Status of the Workflow is " + statusOfEvent + ".",
							"PASS", "Y");
		}
		
		 /**
		  * Step NO : 250
		  */
		OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();
		if (initiationPage.confirmationMessageOnSubmission
				.getText()
				.trim()
				.startsWith(
						"Event "
								+ eventNumber
								+ " has been submitted for Approval. Any change in status will be communicated via email."))
		{
			PDFResultReport
					.addStepDetails(
							"Click on [Submit] button",
							"Wf should be assigned for Super user Approval and below Confirmation message should get displayed\n"
									+ " Event E-XXXX has been submitted for Approval.\n"
									+ "Any change in status will be communicated via email.\n"
									+ "Thank you",
							"Wf is assigned for Super User Approval and below Confirmation message should get displayed\n"
									+ " "
									+ initiationPage.confirmationMessageOnSubmission.getText()
									+ "", "PASS", "Y");
		}
	
		
		
		
		
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
	
		OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName"); 
		BaseClass.waitForObj(3000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		// COMMENT START 0001
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		consultingAgreementPage = new ConsultingAgreementPage(driver);
	
		statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		System.out.println(statusOfEvent);
		if (statusOfEvent.equalsIgnoreCase("Pending-Finalize/Reconcile"))
		{
			PDFResultReport
					.addStepDetails(
							"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
							"1.The workflow should get open in review mode with a link.\n"
									+ "2.The link should be enabled for the ippcoe .\n"
									+ "3.The Status of the Workflow should be Pending-Finalize/Reconcile.",
							"1.The workflow is opened in review mode with a link.\n"
									+ "2.The link id enabled for the ippcoe .\n"
									+ "3.The Status of the Workflow is " + statusOfEvent + ".",
									"PASS", "Y");
		}
		OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();
		
	
		/**
		 * Finalize/Reconcile
		 *//*
	
		*//**
		 * Finalize CR(S)
		 */
		
		OneASTUtil.finalizeCRs();
		PDFResultReport.addStepDetails("",	
				"", 
				"", "PASS", "Y");
		
	
		BaseClass.waitForObj(2000);
		/**
		 * Finalize/Reconcile Budget
		 */
		OneASTUtil.finalizeRecouncilBudgetSubmittion("All Attendees");
		
		
	
		/**
		 *   Uploads
		 */
		OneASTUtil.clickOnUploadsTabAndUploadTheFilesInFinalizeReconcile("TestData.xlsx");
		BaseClass.waitForObj(2000);
		PDFResultReport.addStepDetails("Verify the document types in the uploads section  upload the mandatory documents and click on [Next] ", 
				 "All the documents should be correctly displayed based on the Pole and region selected"	, 
				 				"All the documents are correctly displayed based on the Pole and region selected", "PASS", "Y");
		BaseClass.waitForObj(2000);
		
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(2000);
		
		PDFResultReport
					.addStepDetails("Verify the document types in the uploads section , upload the mandatory documents and click on [Next]",
							"Summary tab should get displayed", "Summary tab is displayed",
							"PASS", "Y");
		
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(5000);

		click(initiationPage.submitButton);
		PDFResultReport.addStepDetails("",	
				"", 
				"", "PASS", "Y");
		
	//	OneASTUtil.closeEventOrAgreement();
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		
		
		/**
		 *    Pending-ProofOfDelivery
		 */
		
		
		OneASTUtil.loginandclickonOneASTRadioButton("IPPCOEUserName"); 
		waitForObj(2000);
		
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		waitForObj(2000);
		PDFResultReport.addStepDetails("Verify all the details entered in the previous  screens are populated in the Summary tab and click on [Sumbit] ", 
				 "On clicking [Submit] workflow should be submitted for POD approval and should be pending with IPP COE"	, 
				 				"On clicking [Submit] workflow is  submitted for POD approval and should be pending with IPP COE", "PASS", "Y");
		
		waitForObj(2000);
		OneASTUtil.verifyIsApprovalLinkAvailable();
		waitForObj(2000);
		OneASTUtil.selectDateOfApprovalFromCalender(0);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(2000);
		OneASTUtil.selectDateOfApprovalFromCalender(1);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		PDFResultReport.addStepDetails("",	
				"", 
				"", "PASS", "Y");
		waitForObj(2000);
		click(initiationPage.submitButton);
		waitForObj(2000);
		PDFResultReport.addStepDetails("",	
				"", 
				"", "PASS", "Y");
		waitForObj(2000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		
		OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName"); 
		BaseClass.waitForObj(2000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		
		statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		if (statusOfEvent.equalsIgnoreCase("Pending-Closure"))
		{
			PDFResultReport
					.addStepDetails(
							"Login as IPP COE and verify the fields in POD screen .\n "
							+"1.Click on Reconcile button.\n"
									+ "2.Enter  DATE OF APPROVAL and [Submit] .\n" ,
									" Workflow should be submitted for closure. The status should be updated as  Pending-Closure.",
							"Workflow is submitted for closure. The status is updated as  Pending-Closure.",
									"PASS", "Y");
		}
		
	}
	
				
	


}

	
	
	
	



