package TestScripts;

import java.awt.AWTException;
import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.AggregateSpendManagementUtils;
import Components.CommonUtils;
import Components.OneASTHomePageUtils;
import Components.OneASTUtil;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.InitiationPage;
import ObjectRepository.OneASTHomePage;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class TC02_EventPlus_ProductTraining extends BaseClass{
	
	public String eventNumber;
	public String status;
	public ConsultingAgreementPage consultingAgreementPage;
	public String ComplianceSSO;
	String tOwner ="";
	InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
	
	@Test(priority = 0,description = "Aggregate Spend Management")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "Doc1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "7");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "Hemant Bissa");
			reportDetails.put("Name of Automation Test Script Author", "502654823");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "Doc1234567");
		reportDetails.put("Requirement ID", "");
	}
	
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{	
			OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
			PDFResultReport.addStepDetails(
					"Login to the Appliaction as Super User entering the valid credentials and \n"
							+ "Click on login button present in the page\n"
							+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
							+ "username : <Super user 1>\n" + "password: <pswd 1>",
					"Login page with title 'Aggregate Spend Management' should get displayed.",
					"Login page with title 'Aggregate Spend Management' get displayed.", "PASS", "N");
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**Step 30 :
	Navigate to Workflow --> Event --> EventsPlus
	Spend category- Product Training
	*/
	
	@Test(priority = 2)
	public void clickOnConsultingEventAndSelectNewEventPlus() throws Exception
	{
		OneASTHomePageUtils.selectItemFromMenuPanelInOneASTHomePage(BaseClass.driver,
				OneASTHomePage.EVENT, OneASTHomePage.NEW_EVENTPLUS_EVENT, false, "");
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(5000);
		
		eventNumber = OneASTUtil.getEventOrAgreementNumber();
		System.out.println("Event Number :: " + eventNumber);
		
		PDFResultReport.addStepDetails("Navigate to Workflow --> Event --> New EventPlus", 
				"1. A EventPlus with case id <E-xxx> should be created  "
				+"2. Save, Submit, Other Actions dropdown , Close buttons should display at the top right.", 
				
				"1. A EventPlus with case id "+eventNumber +" is created  "
				+"2. Save, Submit, Other Actions dropdown , Close buttons is display at the top right.", "PASS", "Y");			
	}
	
	@Test(priority=3)
	public void selectSpendCategoryEducationalItems(){
				
		initiationPage = new InitiationPage(driver);
		switchToDefaultFrame();
		BaseClass.waitForObj(1000);
		BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
		OneASTUtil.selectEventPlusSpendType("Product Training");
		BaseClass.waitForObj(2000);
		eventNumber = OneASTUtil.getEventOrAgreementNumber();
		System.out.println("Event Number :: " + eventNumber);
		PDFResultReport.addStepDetails("Select Spend category as 'Product Training' and click on [Submit] button", 
				
				"1. A new EventPlus - Product Training <E-xxxxx> should be created and the status should be 'Pending-EventInitiation' \n", 
				
				"1. A new EventPlus - Product Training "+eventNumber +" is created and the status is 'Pending-EventInitiation' \n"
				, "PASS", "Y");
	}
	
		/**Step 40 :
		A) Enter below fields should be mandatory under 'Paying legal entity' section:
		1.Pole:""Americas""
		2.Region:""United States""
		3.Paying Country
		4.Business
		5.Modality
		6.Legal Entity
		7.Products
		8.Product Indicator
		9.Select ""yes"" for Are you submitting the request on behalf of others? 
		10.Transaction Owner
		11.Selected Currency:autopopulate currency based on the paying country 
		12.Change to other currency: non-mandatory dropdown
		B) Enter below fields in Event info details :
		1.Start/End Dates ( mandatory)
		2.Event Title (mandatory text field)
		3.Event Justification (mandatory dropdown)
		4.Event Justification Additional Details(mandatory opentext field)
		C) Enter below fields in Venue information:
		1.Venue type (dropdown)
		2.Venue name
		3.Country
		4.City
		- Click [Next]
		*/
	
	@Test(priority=4)
	public void addBusinessInformation()
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		tOwner = ExcelReport.testData.get("transactionsOwner");
		System.out.println(tOwner);
		BaseClass.waitForObj(5000);
		OneASTUtil.enterTheValuesInBusinessInformationTab("Americas", "United States", "United States",
				"Detection & Guidance Solutions (DGS)", "Interventional",
				"020110-GE Medical Systems (F39000)", "Innova IGS 540", "Covered", "Yes", tOwner,"", "","");
		BaseClass.waitForObj(2000);
		
		PDFResultReport.addStepDetails(
				"Enter below fields under Paying legal entity section:\n"
						+ "1.Pole:Americas\n"
						+ "2.Region:EAGM\n"
						+ "3.Paying Country\n"
						+ "4.Business\n"
						+ "5.Modality\n"
						+ "6.Legal Entity\n"
						+ "7.Select yes for Are you submitting the request on behalf of others?\n"
						+ "8.Transaction Owner \n"
						+ "11.Selected Currency:autopopulate currency based on the paying country \n"
						+ "12.Change to other currency: non-mandatory dropdown\n"
						+ "B) Enter below fields in Event info details :\n"
						+ "1.Start/End Dates ( mandatory)\n"
						+ "2.Event Title (mandatory text field)\n"
						+ "3.Event Justification (mandatory dropdown)\n"
						+ "4.Event Justification Additional Details(mandatory opentext field)\n"
						+ "C) Enter below fields in Venue information:\n"
						+ "1.Venue type (dropdown)\n"
						+ "2.Venue name\n"
						+ "3.Country\n"
						+ "4.City\n"
						+ "- Click [Next]",
				"A) Should be able to enter all the mandatory  fields in Paying legal entity section \n"
						+ "B) Event Info Details: \n"
						+ "1.Start/End Dates ( mandatory)- Start date should be greater than Creation date and End date should always be greater than start date\n" 
						+ "2.Event Title (mandatory text field)\n"
						+ "3.Event Justification (mandatory dropdown) should have below values :\n"
							+ "a. Demonstration of a GEHC product/service (prior to sale) \n"
							+ "b. Education/Training of a GEHC product/service (prior to sale)\n"
							+ "c. General sales/promotion of GEHC product/services\n"
							+ "d. Support of Educational Program or Event \n"
							+ "e. Support of Third Party Event Invitation \n"
							+ "f. Other � Specify\n"
						+ "4.Event Justification Additional Details(mandatory opentext field)\n"
						+ "C) Venue Information : \n"
							+ "a. Venue type � drop down\n"
								+ "i. Conference Center\n"
								+ "ii. GE Site \n"
								+ "iii. Hospital/Clinic Setting \n"
								+ "iv. Research building (LS only) \n"
								+ "v. Other location \n"
							+ "b. Venue name - open text mandatory\n"
							+ "c. Country � open text mandatory \n"
							+ "d. City � drop down mandatory\n"
							+ "- Screen should be navigated to Additional Information tab",
				
							"A) Should be able to enter all the mandatory  fields in Paying legal entity section \n"
									+ "B) Event Info Details: \n"
									+ "1.Start/End Dates ( mandatory)- Start date should be greater than Creation date and End date should always be greater than start date\n" 
									+ "2.Event Title (mandatory text field)\n"
									+ "3.Event Justification (mandatory dropdown) should have below values :\n"
										+ "a. Demonstration of a GEHC product/service (prior to sale) \n"
										+ "b. Education/Training of a GEHC product/service (prior to sale)\n"
										+ "c. General sales/promotion of GEHC product/services\n"
										+ "d. Support of Educational Program or Event \n"
										+ "e. Support of Third Party Event Invitation \n"
										+ "f. Other � Specify\n"
									+ "4.Event Justification Additional Details(mandatory opentext field)\n"
									+ "C) Venue Information : \n"
										+ "a. Venue type � drop down\n"
											+ "i. Conference Center\n"
											+ "ii. GE Site \n"
											+ "iii. Hospital/Clinic Setting \n"
											+ "iv. Research building (LS only) \n"
											+ "v. Other location \n"
										+ "b. Venue name - open text mandatory\n"
										+ "c. Country � open text mandatory \n"
										+ "d. City � drop down mandatory\n"
										+ "- Screen should be navigated to Additional Information tab", "PASS", "Y");
		
		
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(8000);
	
		OneASTUtil.enterEventInforamtionAndVenueInformation_EventPlus_ProductTraining("1","EventPlus",
				"Demonstration of a GEHC product/service (prior to sale)","Additional Details","GE Site", "venue Name Field",
				"Afghanistan", "venue City Field");
		BaseClass.waitForObj(2000);
				
		PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
		BaseClass.waitForObj(2000);
		click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);	
	}
	
	/**Step 50
	  Select "No" for "Will a Speaker or Consultant be invited to this event" and click [Next]
	  */

	@Test(priority=5)
	public void selectSpeakerasNo(){
		
		//BaseClass.select(initiationPage.speakerOrConsultant, "No");
		BaseClass.waitForObj(5000);
		
		PDFResultReport.addStepDetails("Select 'No' for 'Will a Speaker or Consultant be invited to this event' and click [Next]",
				"Screen should be navigated to CR Information tab", 
				"Screen should be navigated to CR Information tab", "PASS", "Y");
		
		click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
	}
	
		/**
		 * Step 60
		Add 2 CRs -
		1)Search by Name
		2)Add a new CR Individual
		3)Try to add a duplicate CR and check the error message
		and click [Next]
		*/
				
	@Test(priority=6)
	public void addCR(){
		
		OneASTUtil.selectCRType("Individual");
		BaseClass.waitForObj(4000);
		OneASTUtil.addNewIndividual(initiationPage.addNewIndividualButton);
		//String name = BaseClass.text(initiationPage.getLastname);
		//OneASTUtil.addDuplicateIndividual(name);              //----> Modified the method
		BaseClass.waitForObj(5000);
		click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		
		PDFResultReport.addStepDetails("Add 2 CRs - \n"
				+ "1) Search by Name \n" 
				+ "2)Add a new CR Individual \n"
				+ "3)Try to add a duplicate CR and check the error message \n"
				+  "and click [Next]", 
				
				 "1)CR should be searched \n"
				+ "2)A new CR hsould be added to database \n"
				+ "3)Below error message should be displayed if there are duplicates for the CR:\n"
				+ "'Duplicates have been found with AST Covered Recipient Database. Do you wish to proceed with manual entered name?' \n"
				+ "- Fields of duplicate record to be displayed: In case it is an individual \n"
				+ "1) GE ID \n"
				+ "2) Last Name \n"
				+ "3) First Name \n"
				+ "4) Address \n"
				+ "5) City \n"
				+ "6) Country/State \n"
 
				+ "-Fields to be displayed in case of CR Individual \n"
				+ "1) Last Name \n"
				+ "2) First Name  \n"
				+ "3) Specialty  \n"
				+ "4) Employer Institution Name \n"
				+ "5) Street address  \n"
				+ "6) City  \n"
				+ "7) Country/State \n"
				+ "8) Unique HCP Identifier/NPI \n"

				+ "-Screen should be navigated to Gather Budget details tab", 
				
				 "1)CR is searched \n"
							+ "2)A new CR is added to database \n"
							+ "3)Below error message is displayed if there are duplicates for the CR:\n"
							+ "'Duplicates have been found with AST Covered Recipient Database. Do you wish to proceed with manual entered name?' \n"
							+ "- Fields of duplicate record to be displayed: In case it is an individual \n"
							+ "1) GE ID \n"
							+ "2) Last Name \n"
							+ "3) First Name \n"
							+ "4) Address \n"
							+ "5) City \n"
							+ "6) Country/State \n"
			 
							+ "-Fields to be displayed in case of CR Individual \n"
							+ "1) Last Name \n"
							+ "2) First Name  \n"
							+ "3) Specialty  \n"
							+ "4) Employer Institution Name \n"
							+ "5) Street address  \n"
							+ "6) City  \n"
							+ "7) Country/State \n"
							+ "8) Unique HCP Identifier/NPI \n"

							+ "-Screen is navigated to Gather Budget details tab", "PASS", "Y");
	}
	
	/**
	 * Step 70 :
	 * 1.Select "If SSP PO Payment Method involved ?*" as No and add 6 budget lines with all payment methods and click [Next]
	 */
				
	@Test(priority=7)
	public void addbudgetDetails()
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.waitForObj(5000);
		
		OneASTUtil.paymentMethodsInTheBudget_Updated("SSP PO","123","test",0);         //--- Modified the method
		BaseClass.waitForObj(2000);
		//OneASTUtil.vendorSearch("", "", "STAPLES INC100763", "", "", 0);       //--- Modified the method
		
		BaseClass.click(initiationPage.addItem);
		BaseClass.waitForObj(2000);
		OneASTUtil.paymentMethodsInTheBudget_Updated("Pcard","123","test",1);
		BaseClass.waitForObj(2000);
		
		BaseClass.click(initiationPage.addItem);
		BaseClass.waitForObj(2000);
		OneASTUtil.paymentMethodsInTheBudget_Updated("Non-SSP PO","123","test",2);
		BaseClass.waitForObj(2000);
		
		BaseClass.click(initiationPage.addItem);
		BaseClass.waitForObj(2000);
		OneASTUtil.paymentMethodsInTheBudget_Updated("Pcard","123","test",3);
		BaseClass.waitForObj(2000);
		
		BaseClass.click(initiationPage.addItem);
		BaseClass.waitForObj(2000);
		OneASTUtil.paymentMethodsInTheBudget_Updated("Payroll","123","test",4);
		BaseClass.waitForObj(2000);
		
		BaseClass.click(initiationPage.addItem);
		BaseClass.waitForObj(2000);
		OneASTUtil.paymentMethodsInTheBudget_Updated("Non-SSP PO","123","test",5);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.addExpenseDetails("Hotel","234");
		BaseClass.waitForObj(2000);
		click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		
		int[] allIndCostValues = {234,234,234,234,234,234}; 
		int overallCost = OneASTUtil.verifyTotalEstimatedEventCost(allIndCostValues);
		
		/*String eventCost = initiationPage.totalEventCost.getText();
		int finalEventCost = Integer.valueOf(eventCost);*/
		
		//Need to work on string to int conversion
		
		/*if(overallCost==finalEventCost) {
		
		PDFResultReport.
		addStepDetails(
				"1.Select 'If SSP PO Payment Method involved ?*' as No and add 6 budget lines with all payment methods and click [Next]",
				"1.When SSP PO is selected , question 'Is the vendor created in SSP?*' should be populated with Yes or No radiobuttons\n"
				+"2.Total Estimated Event Cost should be correctly calculated and screen should navigate to Uploads tab on clicking [Next]\n", 
				"Screen is able to navigate to Uploads tab", "PASS", "Y");
		}
		else {
			PDFResultReport.
			addStepDetails(
					"1.Select 'If SSP PO Payment Method involved ?*' as No and add 6 budget lines with all payment methods and click [Next]",
					"1.When SSP PO is selected , question 'Is the vendor created in SSP?*' should be populated with Yes or No radiobuttons\n"
					+"2.Total Estimated Event Cost should be correctly calculated and screen should navigate to Uploads tab on clicking [Next]\n", 
					"Screen is unable to navigate to Uploads tab", "FAIL", "Y");
		}*/
	}
	
	/**
	 * Step 80
	 * Verify the document types in the uploads section , upload the mandatory documents and click on [Next]
	 */

	@Test(priority=8)
	public void addUploadswithSummary() throws AWTException
	{
			System.out.println("Upload");
			OneASTUtil.clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
			BaseClass.waitForObj(4000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(4000);
			
			PDFResultReport.
			addStepDetails(
					"Verify the document types in the uploads section , upload the mandatory documents and click on [Next].",
					"All the documents should be correctly displayed based on the Pole and region selected- Screen should be navigated to Summary tab.",
					"All the documents displayed correctly based on the Pole and region selected- Screen should be navigated to Summary tab.", "PASS", "Y");
			
		/**
		 * Step 90
		 * Verify all the details entered in the previous  screens are populated in the Summary tab and click on [Sumbit]
		 */
		
		if (initiationPage.summaryTab.getText().equalsIgnoreCase("Summary"))
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,250)");
			waitForObj(1000);
			boolean searchButtonStatus = initiationPage.summarySearchButton.isEnabled();
			
			PDFResultReport.addStepDetails("","","","PASS", "Y");
			js.executeScript("window.scrollBy(0,500)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("","","","PASS", "Y");
			
			js.executeScript("window.scrollBy(0,750)");
			waitForObj(1000);
			boolean uploadButtonStatus = initiationPage.summaryUploadButton.isEnabled();
			PDFResultReport.addStepDetails("","","","PASS", "Y");
			
			js.executeScript("window.scrollBy(0,1000)");
			waitForObj(1000);
			PDFResultReport.addStepDetails("","","","PASS", "Y");
			
			if(!searchButtonStatus && !uploadButtonStatus) {
				System.out.println("Search and Upload buttons are disabled in summary tab.");
			}
		}
		
		click(initiationPage.submitButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(5000);
		if (initiationPage.confirmationMessageOnSubmission
				.getText().trim()
				.startsWith(
						"Event "
								+ eventNumber
								+ " has been submitted for Approval. Any change in status will be communicated via email."))
		{
			PDFResultReport
					.addStepDetails(
							"Verify the details entered in the previous  screens are populated in the Summary tab and click on [Sumbit]",
							" All the details entered in the previous tab should be displayed in the Summary tab correctly, "
							+ "PO Request section should display with SSPPO details and should be in read-only.\n"
							+ " Event E-XXXX has been submitted for Approval.\n"
							+ "Any change in status will be communicated via email.\n"
							+ "Thank you",
							"Wf is assigned for Direct Manager and below Confirmation message should get displayed\n"
							+ " "
							+ initiationPage.confirmationMessageOnSubmission.getText()
							+ "", "PASS", "Y");
		}
		
		/**
		 *  LOG OUT From Super User
		 */
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
	}
	
	/**
	 * Login as IPP COE and Delegate the workflow
	 */
	
	@Test(priority=9)
	public void IPPCOELoginAndDelegation()
	{
		OneASTUtil.loginandclickonOneASTRadioButton("IPPCOE"); //Need to add to Test Data sheet
		BaseClass.waitForObj(3000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		consultingAgreementPage = new ConsultingAgreementPage(driver); 
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		
		if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
		{
			PDFResultReport
					.addStepDetails(
							"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
							"1.The workflow should get open in review mode with a link.\n"
									+ "2.The link should be enabled for Super User.\n"
									+ "3.The Status of the Workflow should be Pending-Approval.",
							"1.The workflow is opened in review mode with a link.\n"
									+ "2.The link id enabled for the super user.\n"
									+ "3.The Status of the Workflow is " + statusOfEvent + ".",
							"PASS", "Y");
		}
		
		ApprovalPage approvalPage = new ApprovalPage(driver);
		click(approvalPage.approvalFlowLink);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(3000);
		
		OneASTUtil.clickOnOtherActionsAndSelectDelegateToAnAdditionalApprover(ExcelReport.testData.get("Delegate"), "Delegate to another user");
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(5000);
		
		//String additionalApproverSSO = OneASTUtil.clickOnOtherActionsAndSelectDelegated_IPPCOE_SSO("212435254", "Please approve.",eventNumber);
		BaseClass.waitForObj(5000);
		
			PDFResultReport.
			addStepDetails(
					"Login as IPP COE and Delegate the workflow",
					
					"Workflow should be assigned to Delegated IPP COE\n"
					+"Worksummary header section should be updated correctly",
					
					"Workflow is assigned to Delegated IPP COE\n"
					+"Worksummary header section is updated correctly", "PASS", "Y");
		
		
			/*OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();
		
		if (initiationPage.confirmationMessageOnSubmission
				.getText()
				.trim()
				.startsWith(
						"Event "
								+ eventNumber
								+ " Has Been Submitted For Further Process."))
		*/
		
		/**
		 *  LOG OUT From IPPCOE user
		 */
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
	}
	
	/**
	 * Login as Delegated IPP COE and select "Approve with Exception" from the Other actions dropdown and [Submit]
	 */
	
	@Test(priority=10)
	public void loginWithDelagatedIPPCOE()
	{	
		OneASTUtil.loginandclickonOneASTRadioButton("additionalApprover"); //212435254 ----> Need to update in Test Data sheet
		BaseClass.waitForObj(3000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		consultingAgreementPage = new ConsultingAgreementPage(driver); 
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		 statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		
			if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for Super User.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the super user.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
			
			ApprovalPage approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			OneASTUtil.clickOnOtherActionsAndSelectApprovewithException("Hotel outside of policy", "Approve");
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			PDFResultReport
			.addStepDetails(
					"Login as Delegated IPP COE and select 'Approve with Exception' from the Other actions dropdown and [Submit].",
					
					"Workflow should be assigned to Direct manager\n"
					+"Worksummary header section should be updated correctly.",
					
					"Workflow is assigned to Direct manager\n"
					+"Worksummary header section is updated correctly.",
					
					"PASS", "Y");
			
			/**
			 *LOG OUT From Delegated IPPCOE user
			 */
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
	}
	
	
	/**
	 * Login as Direct Manager and approve the workflow
	 */
	
	@Test(priority=11)
	public void directManagerApproval()
	{
		OneASTUtil.loginandclickonOneASTRadioButton("DirectManagerName");
		BaseClass.waitForObj(3000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		consultingAgreementPage = new ConsultingAgreementPage(driver); 
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		 statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		
			if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for Direct Manager.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the super user.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
		
			ApprovalPage approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
		
			set(approvalPage.additonalCommentesTextArea, "Test");
			click(approvalPage.approveButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
		
			if (initiationPage.confirmationMessageOnSubmission
					.getText().trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ " Has Been Submitted For Further Process."))
			{
				PDFResultReport
						.addStepDetails(
								"Verify the details entered in the previous  screens are populated in the Summary tab and click on [Sumbit]",
								
								"System should display the below message.\n"
								+ " Event E-XXXX Has Been Submitted For Further Process.\n"
								+ "Thank you",
								
								"Screen should be navigated PO-Requisition screen and work header should be updated correctly"
								+ initiationPage.confirmationMessageOnSubmission.getText(),
								
								"PASS", "Y");
			}
		
			/**
			 *LOG OUT From Direct Manager user
			 */
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		}
	
	/**
	 * Login as Requestor and Reassign the workflow
	 * @throws Exception 
	 */
	
	@Test(priority=12)
	public void reassigningWorkflow() throws Exception {
		
		OneASTUtil.loginandclickonOneASTRadioButton("superUserUserName");
		BaseClass.waitForObj(2000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		
		CommonUtils.waitUntilAjaxRequestCompletes(driver);		
		consultingAgreementPage = new ConsultingAgreementPage(driver); 
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		 statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		
			if (statusOfEvent.equalsIgnoreCase("Pending-Finalize/Reconcile"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for Super User.\n"
										+ "3.The Status of the Workflow should be Pending-Finalize/Reconcile.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the super user.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
			
			ApprovalPage approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			String reassignUserID = ExcelReport.testData.get("reassignedSuperUser"); //Need to add to Test Data sheet Bomishetty
					
			OneASTUtil.reassignTheWorkflow(reassignUserID);
			waitForObj(3000);
			
			PDFResultReport
			.addStepDetails(
					"Login as Requestor and Reassign the workflow.",
					
					"Workflow should be pending with reassigned user and the workdetails should updated correctly.",
					
					"Workflow is pending with reassigned user and the workdetails is updated correctly.",
					
					"PASS", "Y");
	}
	
	//Need to review after this with Pradeep
	
	/**
	 *1.Login to application as Reassigned user and select "Request more information" from other actions dropdown.
	  2.Change Pole to ASIA-APAC,Enter all the necessary fields and [Submit]
	 */
		
	@Test(priority=13)
	public void loginWithAssignedSuperUser() throws Exception {
		
		OneASTUtil.loginandclickonOneASTRadioButton("reassignedSuperUser");
		BaseClass.waitForObj(2000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		
		CommonUtils.waitUntilAjaxRequestCompletes(driver);		
		consultingAgreementPage = new ConsultingAgreementPage(driver); 
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		 statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		
			if (statusOfEvent.equalsIgnoreCase("Pending-Finalize/Reconcile"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for Super User.\n"
										+ "3.The Status of the Workflow should be Pending-Finalize/Reconcile.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the super user.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
			
			ApprovalPage approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			OneASTUtil.clickOnOtherActionsAndSendBackForUpdates(eventNumber);
			waitForObj(3000);
			
			/**
			 *LOG OUT and Re-login for reassigned superuser
			 */
			
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			
			OneASTUtil.loginandclickonOneASTRadioButton("reassignedSuperUser");
			BaseClass.waitForObj(2000);
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			BaseClass.waitForObj(2000);
			
			consultingAgreementPage = new ConsultingAgreementPage(driver); 
			statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			
				if (statusOfEvent.equalsIgnoreCase("Pending-EventInitiation"))
				{
					PDFResultReport
							.addStepDetails(
									"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
									"1.The workflow should get open in review mode with a link.\n"
											+ "2.The link should be enabled for Reassigned Super User.\n"
											+ "3.The Status of the Workflow should be Pending-EventInitiation.",
									"1.The workflow is opened in review mode with a link.\n"
											+ "2.The link id enabled for the Reassigned super user.\n"
											+ "3.The Status of the Workflow is " + statusOfEvent + ".",
									"PASS", "Y");
				}
				
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			OneASTUtil.enterTheValuesInBusinessInformationTab("ASIA-APAC", "ANZ", "Australia",
					"Detection & Guidance Solutions (DGS)", "Interventional",
					"740110-GE Healthcare Australia Pty Limited", "", "", "Yes", tOwner,"", "", "");
			BaseClass.waitForObj(2000);
			
			click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			OneASTUtil.clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
			BaseClass.waitForObj(4000);
			
			click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			click(initiationPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			
			PDFResultReport
			.addStepDetails(
					"1.Login to application as Reassigned user and select 'Request more information' from other actions dropdown.\n"
					+"2.Change Pole to ASIA-APAC,Enter all the necessary fields and [Submit].\n",
					
					"1.Workflow should be sent back to Initiation and should be pending with reassigned user\n"
					+"2. Workflow should be submitted for TO approval.\n",
					
					"1.Workflow sent back to Initiation and is pending with reassigned user\n"
					+"2. Workflow is submitted for TO approval.\n",
					
					"PASS", "Y");
			
			/**
			 *  LOG OUT From Super User
			 */
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
	}
		
	/**
	 *Login as Transaction Owner and approve the workflow
	 */
	
	@Test(priority=14)
	public void transactionOwnerLoginNApprove()
	{
		OneASTUtil.loginandclickonOneASTRadioButton("transactionsOwner"); //Need to add to Test Data sheet
		BaseClass.waitForObj(3000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		consultingAgreementPage = new ConsultingAgreementPage(driver); 
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		
		if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
		{
			PDFResultReport
					.addStepDetails(
							"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
							"1.The workflow should get open in review mode with a link.\n"
									+ "2.The link should be enabled for Super User.\n"
									+ "3.The Status of the Workflow should be Pending-Approval.",
							"1.The workflow is opened in review mode with a link.\n"
									+ "2.The link id enabled for the super user.\n"
									+ "3.The Status of the Workflow is " + statusOfEvent + ".",
							"PASS", "Y");
		}
		
		ApprovalPage approvalPage = new ApprovalPage(driver);
		click(approvalPage.approvalFlowLink);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(3000);
		
		click(approvalPage.approveButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(3000);
		
		if (initiationPage.confirmationMessageOnSubmission
				.getText().trim()
				.startsWith(
						"Event "
								+ eventNumber
								+ " has been submitted for Approval. Any change in status will be communicated via email."))
		{
			PDFResultReport
					.addStepDetails(
							"Login as Transaction Owner and approve the workflow.",
							
							"Workflow should be submitted for IPPCOE approval.",
							
							"Workflow is submitted for IPPCOE approval."
							+ initiationPage.confirmationMessageOnSubmission.getText(),
							
							"PASS", "Y");
		}
		
		/**
		 *  LOG OUT From Transaction owner
		 */
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
	}
	
	/**
	 * Login as IPP COE and approve the workflow
	 */
	
	@Test(priority=15)
	public void IPPCOELoginAndApprove()
	{
		OneASTUtil.loginandclickonOneASTRadioButton("additionalApprover"); //Need to add to delegated IPPCOE Test Data sheet
		BaseClass.waitForObj(3000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		consultingAgreementPage = new ConsultingAgreementPage(driver); 
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		
		if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
		{
			PDFResultReport
					.addStepDetails(
							"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
							"1.The workflow should get open in review mode with a link.\n"
									+ "2.The link should be enabled for Super User.\n"
									+ "3.The Status of the Workflow should be Pending-Approval.",
							"1.The workflow is opened in review mode with a link.\n"
									+ "2.The link id enabled for the super user.\n"
									+ "3.The Status of the Workflow is " + statusOfEvent + ".",
							"PASS", "Y");
		}
		
		ApprovalPage approvalPage = new ApprovalPage(driver);
		click(approvalPage.approvalFlowLink);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(3000);
		
		click(approvalPage.approveButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(3000);
		
		if (initiationPage.confirmationMessageOnSubmission
				.getText().trim()
				.startsWith(
						"Event "
								+ eventNumber
								+ " has been submitted for Approval. Any change in status will be communicated via email."))
		{
			PDFResultReport
					.addStepDetails(
							"Login as Transaction Owner and approve the workflow.",
							
							"Workflow should be submitted for IPPCOE approval.",
							
							"Workflow is submitted for IPPCOE approval."
							+ initiationPage.confirmationMessageOnSubmission.getText(),
							
							"PASS", "Y");
		}
		
		/**
		 *  LOG OUT From IPPCOE user
		 */
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
	}
	
	/**
	 * Login as Direct Manager and approve the workflow
	 */
	
	@Test(priority=16)
	public void directManagerApprovalForUpdatedEvent()
	{
		OneASTUtil.loginandclickonOneASTRadioButton("DirectManagerName");
		BaseClass.waitForObj(3000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		consultingAgreementPage = new ConsultingAgreementPage(driver); 
		String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		 statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
		
			if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for Direct Manager.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the super user.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
		
			ApprovalPage approvalPage = new ApprovalPage(driver);
			click(approvalPage.approvalFlowLink);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
		
			set(approvalPage.additonalCommentesTextArea, "Test");
			click(approvalPage.approveButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
		
			if (initiationPage.confirmationMessageOnSubmission
					.getText().trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ " Has Been Submitted For Further Process."))
			{
				PDFResultReport
						.addStepDetails(
								"Verify the details entered in the previous  screens are populated in the Summary tab and click on [Sumbit]",
								
								"System should display the below message.\n"
								+ " Event E-XXXX Has Been Submitted For Further Process.\n"
								+ "Thank you",
								
								"Screen should be navigated PO-Requisition screen and work header should be updated correctly"
								+ initiationPage.confirmationMessageOnSubmission.getText(),
								
								"PASS", "Y");
			}
		
			/**
			 *LOG OUT From Direct Manager
			 */
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		}

	/**
	 * Login as Requester and submit the work flow
	 */
	
	@Test(priority=17)
	public void loginWithRequestorAndVerifyMassUpload() throws Exception {
		
		OneASTUtil.loginandclickonOneASTRadioButton("reassignedSuperUser");
		BaseClass.waitForObj(2000);
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
		BaseClass.waitForObj(2000);
		
		click(initiationPage.nextButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		BaseClass.waitForObj(2000);
		
		//OneASTUtil.clickOnImportAndUploadFile("oa_massupload.xlsx");
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		BaseClass.waitForObj(2000);
		
		//As we are not adding agreements we will be able to add and delete the CRs
		
		//boolean status = initiationPage.checkStatusAfterMassUpload.isDisplayed();
		
		/*if (status) {
			
		PDFResultReport
		.addStepDetails(
				"Verify Finalize CR tab and Mass upload the CRs",
				
				"1.Banner should be available and should be in bold. Bullet points should be removed\n"
				+"2.User should not have access to delete the CR and add a new CR\n"
				+"3.User should be able to import the CRs and it should be updated as 'New' in last column in the CR table.",
				
				"1.Banner is available and is in bold. Bullet points are removed\n"
				+"2.User don't have access to delete the CR and add a new CR\n"
				+"3.User is able to import the CRs and it is updated as 'New' in last column in the CR table.",
				
				"PASS", "Y");
		}*/
		
		click(initiationPage.nextButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		BaseClass.waitForObj(2000);
		
		
		/*click(initiationPage.finalPaymentToBeMade);
		BaseClass.waitForObj(2000);
		click(initiationPage.nextButton);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		BaseClass.waitForObj(2000);
		
		OneASTUtil.selectPaymentMethodForReconcile(1);
		OneASTUtil.reconcileSelectedPaymentMethod(1);*/
	}
	
	/**
	 * Verify Finalize section in Finalize/Reconcile budget tab
	 */
	
	@Test(priority=18)
	public void verifyFinalizeSectionInFRBudgetTab() throws Exception {
		
		BaseClass.waitForObj(3000);
		//OneASTUtil.verifyAllFieldsInFinalizeSection(6);
		PDFResultReport.addStepDetails("","","","PASS", "Y");
	}
	
	/**
	 * 1.Perform zero re-concillation for Non SSP PO line (parent line)
	   2.Partially reconcile (partially paid reconcile line) the FMV line
	   3.Enter PO number for the SSP PO line (FMV line) in Finalize section ----> Need to add one SSP PO line then we can go forward
	 */
	
	@Test(priority=19)
	public void reconcileForPaymentMehods() throws Exception {
		
		BaseClass.waitForObj(3000);
		/*OneASTUtil.selectPaymentMethodForReconcile("1");
		OneASTUtil.reconcileSelectedPaymentMethod("1");*/
		
		/*boolean allocateAmtDropdown = initiationPage.allocateAmtTo.isDisplayed();
		
		if (allocateAmtDropdown) {
			
		PDFResultReport.
		addStepDetails(
				"1.Perform zero reconcillation for Non SSP PO line (parent line)\n"
				+"2. Partially reconcile (partially paid reconcile line) the FMV line\n"
				+"3. Enter PO number for the SSP PO line (FMV line) in Finalize section\n",
				
				"1.Line should be auto reconciled\n"
				+"2.User should be able to reconcile for lesser amount\n",
				
				"1.Line is auto reconciled\n"
				+"2.User is able to reconcile for lesser amount\n",
				
				"PASS", "Y");
		
		BaseClass.click(initiationPage.cancelButtonInModelPopUpWindow);
		BaseClass.waitForObj(5000);
		
		}*/
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
