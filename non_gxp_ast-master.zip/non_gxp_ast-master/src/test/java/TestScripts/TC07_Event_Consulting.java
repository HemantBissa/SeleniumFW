package TestScripts;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import Components.CommonUtils;
import Components.LoginUtils;
import Components.OneASTHomePageUtils;
import Components.OneASTUtil;
import Components.PeagDesignerStudioHomePageUtils;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.AggregateSpendManagementPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.HomePage;
import ObjectRepository.InitiationPage;
import ObjectRepository.LogInPage;
import ObjectRepository.OneASTHomePage;
import ObjectRepository.PeagDesignerStudioHomePage;
public class TC07_Event_Consulting extends BaseClass
{
	public String eventNumber,statusOfEvent;
	public HomePage homePage;
	public ArrayList<String> tabs;
	public ApprovalPage approvalPage;
	public LogInPage loginPage;
	public AggregateSpendManagementPage aggregateSpendManagementPage;
	public InitiationPage initiationPage;
	public AggregateSpendManagementNonUSPage aggregateSpendManagementNonUSPage;
	public PeagDesignerStudioHomePage peagDesignerStudioHomePage;
	public String additionalApprovar;
	public OneASTHomePage oneASTHomePage;
	public ConsultingAgreementPage consultingAgreementPage;
	public String ComplianceSSO;
	@Test(priority = 0,description = "")
	public void initialize() throws Exception
	{
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "DOC1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "1");
		if (ExcelReport.testData.get("ScriptExecution").trim()
				.equalsIgnoreCase("Post Execution Report"))
		{
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else
		{
			reportDetails.put("SSO ID of Automation Test Script Author", "502616490");
			reportDetails.put("Name of Automation Test Script Author", "Pavan Yarlagadda");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "DOC1234567");
		reportDetails.put("Requirement ID", "");
	}
	/**
	 * Step No : 10
	 */
	@Test(priority = 1)
	public void astHomePage()
	{
		try
		{
			loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "userName", "password");
			waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Login to the Appliaction as Super User entering the valid credentials and \n"
									+ "Click on login button present in the page\n"
									+ "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
									+ "username : 502618771\n" + "password: rules",
							"1.Login page with titleAggregate Spend Managementshould get displayed.\n"
									+ "2.The page should contain the text The Paying legal Entity of your interaction is based in with below two radio buttons:\n"
									+ " AST\n" + " Korea Tracking Code",
							"Aggregate Spend Management page is displayed.", "PASS", "N");
			homePage = new HomePage(driver);
			if (getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
			{
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						driver, PeagDesignerStudioHomePage.LAUNCH,
						PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
				tabs = new ArrayList<String>(driver.getWindowHandles());
				driver.switchTo().window(tabs.get(1));
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
			}
			aggregateSpendManagementPage = new AggregateSpendManagementPage(driver);
			click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			PDFResultReport.addStepDetails("Select OneAST User portal from launch icon\n",
					" AST page should get displayed.", " AST page is get displayed.", "PASS", "N");
			click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(15000);
			/**
			 * Step No : 20
			 */
			OneASTHomePageUtils.selectItemFromMenuPanelInOneASTHomePage(BaseClass.driver,
					OneASTHomePage.EVENT, OneASTHomePage.NEW_CONSULTING_EVENT, false, "");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.switchToDefaultFrame();
			eventNumber = OneASTUtil.getEventOrAgreementNumber();
			OneASTUtil.agreementNumber = eventNumber;
			System.out.println("Agreement Number :: " + eventNumber);
			initiationPage = new InitiationPage(driver);
			BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
			BaseClass.waitForObj(2000);
			PDFResultReport.addStepDetails("Navigate to Workflow > Event > New Consulting Event",
					"A new Agreement with Event case id <E-XXXX> should be created in a new Tab.",
					"A new Agreement with Event case id " + eventNumber
							+ " is created in a new Tab.", "PASS", "Y");
			/**
			 * Step No : 30
			 */
			initiationPage = new InitiationPage(driver);
			switchToDefaultFrame();
			BaseClass.waitForObj(2000);
			BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
			BaseClass.click(initiationPage.singleEventAgreementRadioButton);
			BaseClass.click(initiationPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			initiationPage = new InitiationPage(driver);
			if (text(initiationPage.crInformationTab).equalsIgnoreCase("CR Information"))
			{
				PDFResultReport
						.addStepDetails("Select Agreement Type as Single Event Agreement",
								"CR Info tab should get displayed", "CR Info tab is displayed",
								"PASS", "Y");
			}
			/**
			 * Step No : 40
			 */
			boolean value = OneASTUtil.verifyFieldsInCRIndividualTab();
			if (value)
			{
				PDFResultReport
						.addStepDetails(
								"click on [CR Individual] tab",
								"Below should get displayed\n"
										+ "Search options\n"
										+ "Individual Name\n"
										+ "Country/State and [Search] button and [Add New Organization] button",
								"Below are displayed\n"
										+ "Search options\n"
										+ "Individual Name\n"
										+ "Country/State and [Search] button and [Add New Organization] button",
								"PASS", "Y");
			}
			/**
			 * Step No : 50
			 */
			OneASTUtil.selectGEIdAndSearchForGEId();
			if (isElementPresent(initiationPage.radioButtonForSearchResult))
			{
				PDFResultReport
						.addStepDetails(
								"Select any Search Option as GE ID and enter GE ID and  click on [Submit] button",
								"Individual search results should get displayed",
								"Individual search results is displayed", "PASS", "Y");
			}
			/**
			 * Step No : 60
			 */
			OneASTUtil.clickOnRadioButtonForSearchResult();
			PDFResultReport.addStepDetails("Select any CR Individual and click on [Submit] button",
					"CR Individual should get added under CR Individual",
					"CR Individual is added under CR Individual", "PASS", "Y");
			/***
			 * Step No : 70 & 80
			 */
			OneASTUtil.addNewIndividual(initiationPage.addNewIndividualButtonInCRIndividual);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			PDFResultReport.addStepDetails("Enter below fields\n" + "1.Individual type\n"
					+ "2.Name of Individual\n" + "3.Department/Section\n" + "4.Country\n"
					+ "5.Address\n" + "6.City\n" + "7.Postal Code\n" + "8.Address line2\n"
					+ "9.Phone\n" + "10.E-mail and click on [Submit] button",
					"CR Individual should get added under CR Individual",
					"CR Individual is added under CR Individual", "PASS", "Y");
			/**
			 * Step No : 90
			 */	
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
					initiationPage.nextButton);
			BaseClass.waitForObj(5000);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",
					initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			if (initiationPage.eventInformationTab.getText().trim()
					.equalsIgnoreCase("Event Information"))
			{
				PDFResultReport.addStepDetails("Click on [Submit] button",
						"Event Info tab should get displayed", "Event Info tab is displayed",
						"PASS", "Y");
			}
			/**
			 * Step No : 100
			 */
			initiationPage = new InitiationPage(BaseClass.driver);
			OneASTUtil.enterValuesInBusinessInformationTab("EMEA", "EAGM", "Egypt",
					"Detection & Guidance Solutions (DGS)", "Interventional",
					"680210-GEMS EGYPT LTD", "", "", "Yes", "", "Product Training",
					"Application Training");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			PDFResultReport
					.addStepDetails(
							"Enter below fields under Paying legal entity section:\n"
									+ "1.Pole:EMEA\n"
									+ "2.Region:EAGM\n"
									+ "3.Paying Country\n"
									+ "4.Business\n"
									+ "5.Modality\n"
									+ "6.Legal Entity\n"
									+ "7.Select yes for Are you submitting the request on behalf of others?\n"
									+ "8.Transaction Owner",
							"Should be able to enter all the mandatory fields",
							"User able to enter all the mandatory fields", "PASS", "Y");
			/**
			 * Step No : 110
			 */
			PDFResultReport.addStepDetails("Enter below fields under Spend Details section:\n"
					+ "Spend Type:Consulting(default)\n" + "Spend Category:Product Training\n"
					+ "Spend Sub Category:Application Training",
					"Should be able to enter all the mandatory fields",
					"User able to enter all the mandatory fields", "PASS", "Y");
			/**
			 * Step No : 120
			 */
			OneASTUtil.enterEventInforamtionAndVenueInformation("Consulting Event",
					"Business Justification for EngagementRequired", "GE Site", "venue Name Field",
					"Afghanistan", "venue City Field");
			PDFResultReport.addStepDetails(
					"Enter below fields under Event Info section and Venue Info\n"
							+ "1.Event Start Date\n" + "2.Event End Date\n" + "3.Event Title\n"
							+ "4.Business/Event Justification\n" + "Venue Info:\n"
							+ "1.Venue type\n" + "2.Venue Name\n" + "3.Country\n" + "4.City",
					"Should be able to enter all the mandatory fields",
					"User able to enter all the mandatory fields", "PASS", "Y");
			/**
			 * Step No : 130
			 */
			((JavascriptExecutor) driver).executeScript("arguments[0].click();",
					initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			if (initiationPage.agreementDetailsTab.getText().trim()
					.equalsIgnoreCase("Agreement Details"))
			{
				PDFResultReport.addStepDetails("Click on [Submit] button",
						"Agreement Details tab should get displayed",
						"Agreement Details tab is displayed", "PASS", "Y");
			}
			/**
			 * Step No : 140
			 */
			click(initiationPage.willServiceCompensationBePaidNoRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			click(initiationPage.noTransferOfValueRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			PDFResultReport
					.addStepDetails(
							"Select service compensation as No for Will service compensation be paid?Required",
							"User should be able to select as No",
							"User is able to select as No", "PASS", "Y");
			/**
			 * Step No : 150
			 */
			/*OneASTUtil.enterValuesInAgreementDetailsTab(2,
					"Business Justification for EngagementRequired",
					"GEHC Products/Services Included", "Consultant Qualification Summary",
					"Payment Details", "SERVICE TO BE PROVIDED", true);*/
			PDFResultReport.addStepDetails("Enter the below fields\n"
					+ "Business Justification for Engagement\n"
					+ "GEHC Products/Services Included\n" + "Consultant Qualification Summary\n"
					+ "Payment Details\n" + "SERVICE TO BE PROVIDED and click on + button",
					"User should be able to enter mutiple SERVICE TO BE PROVIDED by clicking on + symbol.\n"
							+ "Screen must be navigated to Agreement details tab",
					"User is able to enter mutiple SERVICE TO BE PROVIDED by clicking on + symbol.\n"
							+ "Screen is navigated to Agreement details tab", "PASS", "Y");
			/**
			 * Step No : 160 && 170
			 */
			OneASTUtil.addPayee(2, ExcelReport.testData.get("searchOptionsDropDownValue"),
					ExcelReport.testData.get("cityValue"), ExcelReport.testData.get("gsl"),
					ExcelReport.testData.get("vendorName"),
					ExcelReport.testData.get("countryDropDownValue"));
			/**
			 * Step No : 180
			 */
			PDFResultReport.addStepDetails("Verify Covered Recipient and CR Address",
					"Covered Recipient and CR Address details should get displayed",
					"Covered Recipient and CR Address details are displayed", "PASS", "Y");
			/**
			 * Step No : 190
			 */
			click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(3000);
			if (initiationPage.gatherBudgetDetailsTab.getText().trim()
					.equalsIgnoreCase("Gather Budget Details"))
			{
				PDFResultReport.addStepDetails("Click on [Next] button",
						"WF should be navigated to Budget tab",
						"WF is navigated to Budget tab", "PASS", "Y");
			}
			/**
			 * Step No : 200
			 */
			OneASTUtil.enterValuesInBudgetDetailsTab(
					ExcelReport.testData.get("ifSSPPOPaymentMethodInvolvedDropDown"),
					ExcelReport.testData.get("paymentMethodDropDown"),
					ExcelReport.testData.get("expenseDropDown"), "",
					ExcelReport.testData.get("amount"), ExcelReport.testData.get("CurrencyValue"),
					ExcelReport.testData.get("costCenter"),
					ExcelReport.testData.get("description"),
					ExcelReport.testData.get("isThisVendoreCreatedInSSP"),
					ExcelReport.testData.get("cityValue"),
					ExcelReport.testData.get("gsl"),
					ExcelReport.testData.get("countryDropDownValue"),
					ExcelReport.testData.get("state"));
			PDFResultReport.addStepDetails(
					"Enter all the mandatory fields under Budget tab Select Yes for SSP Integration and \n"
							+ "Select Expense type and \n" + "Payment method,\n" + "Amount,\n"
							+ "CostCenter,\n" + "Vendor Name,\n"
							+ "Description/SSP Requisition Title",
					"Should be able to enter all the mandatory fields",
					"User is able to enter all the mandatory fields", "PASS", "Y");
			/**
			 * Step No : 210 && 220
			 */
			OneASTUtil.clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
			if (initiationPage.summaryTab.getText().equalsIgnoreCase("Summary"))
			{
				PDFResultReport
						.addStepDetails("Upload the Required document and click on [Next] button",
								"Summary tab should get displayed", "Summary tab is displayed",
								"PASS", "Y");
			}
			/**
			 * Step No : 230
			 */
			// TODO
			/**
			 * Step NO : 240
			 */
			click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);				
			click(initiationPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
			if (initiationPage.confirmationMessageOnSubmission
					.getText().trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ " has been submitted for Approval. Any change in status will be communicated via email."))
			{
				PDFResultReport
						.addStepDetails(
								"Click on [Submit] button",
								"Wf should be assigned for Transaction Owner Approval and below Confirmation message should get displayed\n"
										+ " Event E-XXXX has been submitted for Approval.\n"
										+ "Any change in status will be communicated via email.\n"
										+ "Thank you",
								"Wf is assigned for Transaction Owner Approval and below Confirmation message should get displayed\n"
										+ " "
										+ initiationPage.confirmationMessageOnSubmission.getText()
										+ "", "PASS", "Y");
			}
			/**
			 * Step NO : 240
			 */
			OneASTUtil.closeEventOrAgreement();
			OneASTUtil.logOutFromAppalication();
			OneASTUtil
					.logInToApplicationAndClickOnOneAstRadioButtonAndClickOnSubmitButton(ExcelReport.testData
							.get("transactionsOwner"));
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			String statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the transaction owner.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the transaction owner.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
			/**
			 * Step NO : 250
			 */
			OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();
			if (initiationPage.confirmationMessageOnSubmission
					.getText()
					.trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ " has been submitted for Approval. Any change in status will be communicated via email."))
			{
				PDFResultReport
						.addStepDetails(
								"Click on [Submit] button",
								"Wf should be assigned for Transaction Owner Approval and below Confirmation message should get displayed\n"
										+ " Event E-XXXX has been submitted for Approval.\n"
										+ "Any change in status will be communicated via email.\n"
										+ "Thank you",
								"Wf is assigned for Transaction Owner Approval and below Confirmation message should get displayed\n"
										+ " "
										+ initiationPage.confirmationMessageOnSubmission.getText()
										+ "", "PASS", "Y");
			}
			OneASTUtil.closeEventOrAgreement();
			OneASTUtil.pendingWith = OneASTUtil.getPendingUserNameBySearchEventOrAgreement(eventNumber);
			OneASTUtil.closeEventOrAgreement();
			OneASTUtil.logOutFromAppalication();
			//IPP COE approval
			OneASTUtil
					.logInToApplicationAndClickOnOneAstRadioButtonAndClickOnSubmitButton("IPPCOE");
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the ippcoe .\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the ippcoe .\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
			"PASS", "Y");
			}
			
			BaseClass.click(approvalPage.approvalFlowLink);	
			BaseClass.waitForObj(5000);
			ComplianceSSO=OneASTUtil.clickOnOtherActionsAndSelectComplianceEscalation("Fontas, Jacques-110003319","International Interaction",eventNumber);
			
			BaseClass.switchToDefaultFrame();
			BaseClass.click(approvalPage.close);
			BaseClass.waitForObj(3000);	
			OneASTUtil.logOutFromAppalication();
			
			LogInPage loginPage = new LogInPage(BaseClass.driver);
			BaseClass.launchApplication(ExcelReport.testData.get("url"));
			BaseClass.set(loginPage.userId, "110003319");
			BaseClass.set(loginPage.password,
						ExcelReport.testData.get("password"));
			loginPage.clickOnLogin();
			BaseClass.waitForObj(5000);
			AggregateSpendManagementPage aggregateSpendManagementPage = new AggregateSpendManagementPage(
					BaseClass.driver);
			BaseClass.click(aggregateSpendManagementPage.oneASTRadioButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(3000);
			BaseClass.click(aggregateSpendManagementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			
			BaseClass.click(approvalPage.approvalFlowLink);	
			BaseClass.waitForObj(2000);
		
			PDFResultReport.addStepDetails("'Login as Compliance Escalation Reviewer of the Agreement and open the Event.", 
					"Status should be Updated to Pending-Approval",
					"Status is Updated to Pending-Approval","PASS","Y");
						
			OneASTUtil.clickOnOtherActionsAndSendBackToIPPCOE("Clarification Required","Send back to IPP COE for more clarification",eventNumber);
			
			BaseClass.switchToDefaultFrame();
			BaseClass.click(approvalPage.close);
			BaseClass.waitForObj(5000);	
				
			OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();
			if (initiationPage.confirmationMessageOnSubmission
					.getText()
					.trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ " has been submitted for Approval. Any change in status will be communicated via email."))
			{
				PDFResultReport
						.addStepDetails(
								"Click on [Submit] button",
								"Wf should be assigned for Direct Manager Approval and below Confirmation message should get displayed\n"
										+ " Event E-XXXX has been submitted for Approval.\n"
										+ "Any change in status will be communicated via email.\n"
										+ "Thank you",
								"Wf is assigned for Transaction Owner Approval and below Confirmation message should get displayed\n"
										+ " "
										+ initiationPage.confirmationMessageOnSubmission.getText()
										+ "", "PASS", "Y");
			}
			OneASTUtil.closeEventOrAgreement();
			OneASTUtil.logOutFromAppalication();
			//Direct Manager apprpoval
			
			OneASTUtil
					.logInToApplicationAndClickOnOneAstRadioButtonAndClickOnSubmitButton("DirectManagerName");
			OneASTUtil.searchWithASTWorkflowandVerifyStatus(eventNumber);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			consultingAgreementPage = new ConsultingAgreementPage(driver);
			statusOfEvent = text(consultingAgreementPage.statusOfAgreementOrEvent);
			if (statusOfEvent.equalsIgnoreCase("Pending-Approval"))
			{
				PDFResultReport
						.addStepDetails(
								"Click on the workflow Id under My Action Items section (or) Search for the workflow by entering the Agreement case id <E-xxxxxx> .",
								"1.The workflow should get open in review mode with a link.\n"
										+ "2.The link should be enabled for the transaction owner.\n"
										+ "3.The Status of the Workflow should be Pending-Approval.",
								"1.The workflow is opened in review mode with a link.\n"
										+ "2.The link id enabled for the transaction owner.\n"
										+ "3.The Status of the Workflow is " + statusOfEvent + ".",
								"PASS", "Y");
			}
			OneASTUtil.verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove();		
			if (initiationPage.confirmationMessageOnSubmission
					.getText()
					.trim()
					.startsWith(
							"Event "
									+ eventNumber
									+ "has been assigned to a temporary workbasket as a request is sent to SSP and system will be waiting for the response."))
			{
				PDFResultReport
						.addStepDetails(
								"Click on [Submit] button",
								"Wf should be assigned for Transaction Owner Approval and below Confirmation message should get displayed\n"
										+ " Event E-XXXX has been submitted for Approval.\n"
										+ "Any change in status will be communicated via email.\n"
										+ "Thank you",
								"Wf is assigned for Transaction Owner Approval and below Confirmation message should get displayed\n"
										+ " "
										+ initiationPage.confirmationMessageOnSubmission.getText()
										+ "", "PASS", "Y");
			}
			OneASTUtil.closeEventOrAgreement();
			OneASTUtil.logOutFromAppalication();
			
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
