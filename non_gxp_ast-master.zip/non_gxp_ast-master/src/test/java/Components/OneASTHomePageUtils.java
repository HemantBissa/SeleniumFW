package Components;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import BaseClass.BaseClass;
import ObjectRepository.OneASTHomePage;

public class OneASTHomePageUtils
{
	/**
	 * @param driver
	 * @param mainLink
	 * @param subLink
	 * @param ifChildLinkIsAvailable
	 *            if child link available to "True" otherwise "False"
	 * @param childLink
	 *            if not available Use the following --> "StringUtils.EMPTY"
	 */
	public static void selectItemFromMenuPanelInOneASTHomePage(WebDriver driver,
			String mainLink, String subLink, boolean ifChildLinkIsAvailable, String childLink)
	{
		OneASTHomePage oneASTHomePage = new OneASTHomePage(
				driver);
		for(WebElement mainLinkWebelement : oneASTHomePage.globalMainLinks)
		{
			if(mainLinkWebelement.getText().equalsIgnoreCase(mainLink))
			{
				System.out.println("Main Link : "+mainLinkWebelement.getText());
				BaseClass.click(mainLinkWebelement);
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				break;
			}
		}
		for(WebElement subLinkWebelement : oneASTHomePage.globalMainLinks)
		{
			if(subLinkWebelement.getText().equalsIgnoreCase(subLink))
			{
				System.out.println("Sub Link : "+subLinkWebelement.getText());
				new Actions(driver).moveToElement(subLinkWebelement).build().perform();
				BaseClass.waitForObj(1000);
				if(ifChildLinkIsAvailable == true)
				{
					for(WebElement childLinkWebElement : oneASTHomePage.globalMainLinks)
					{
						if(childLinkWebElement.getText().equalsIgnoreCase(childLink))
						{
							System.out.println("Child Link : "+childLinkWebElement.getText());
							childLinkWebElement.click();
							CommonUtils.waitUntilAjaxRequestCompletes(driver);
							BaseClass.waitForObj(2000);
							break;
						}
					}
				}else
				{
					if(subLinkWebelement.getText().equalsIgnoreCase(subLink))
					{
						BaseClass.click(subLinkWebelement);
						CommonUtils.waitUntilAjaxRequestCompletes(driver);
						BaseClass.waitForObj(2000);
						break;
					}
				}
				break;
			}
		}
	}
}
