package Components;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import BaseClass.BaseClass;
import ObjectRepository.PeagDesignerStudioHomePage;

public class PeagDesignerStudioHomePageUtils
{
	/**
	 * @param driver
	 * @param mainLink
	 * @param subLink
	 * @param ifChildLinkIsAvailable
	 *            if child link available to "True" otherwise "False"
	 * @param childLink
	 *            if not available Use the following --> "StringUtils.EMPTY"
	 */
	public static void selectItemFromMenuPanelPeagDesignerStudioHomePage(WebDriver driver,
			String mainLink, String subLink, boolean ifChildLinkIsAvailable, String childLink)
	{
		PeagDesignerStudioHomePage peagDesignerStudioHomePage = new PeagDesignerStudioHomePage(
				driver);
		for(WebElement mainLinkWebelement : peagDesignerStudioHomePage.globalMainLinks)
		{
			if(mainLinkWebelement.getText().equalsIgnoreCase(mainLink))
			{
				System.out.println("Main Link : "+mainLinkWebelement.getText());
				BaseClass.click(mainLinkWebelement);
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				break;
			}
		}
		for(WebElement subLinkWebelement : peagDesignerStudioHomePage.subLinks)
		{
			if(subLinkWebelement.getText().equalsIgnoreCase(subLink))
			{
				System.out.println("Sub Link : "+subLinkWebelement.getText());
				new Actions(driver).moveToElement(subLinkWebelement).build().perform();
				BaseClass.waitForObj(1000);
				if(ifChildLinkIsAvailable == true)
				{
					for(WebElement childLinkWebElement : peagDesignerStudioHomePage.childLinks)
					{
						if(childLinkWebElement.getText().equalsIgnoreCase(childLink))
						{
							System.out.println("Child Link : "+childLinkWebElement.getText());
							childLinkWebElement.click();
							CommonUtils.waitUntilAjaxRequestCompletes(driver);
							BaseClass.waitForObj(2000);
							break;
						}
					}
				}else
				{
					if(subLinkWebelement.getText().equalsIgnoreCase(subLink))
					{
						BaseClass.click(subLinkWebelement);
						CommonUtils.waitUntilAjaxRequestCompletes(driver);
						BaseClass.waitForObj(2000);
						break;
					}
				}
				break;
			}
		}
	}
	
	public static void selectItemFromMenuPanelPeagDesignerStudioHomePage1(WebDriver driver,
			String mainLink, String subLink, boolean ifChildLinkIsAvailable, String childLink,String subChildLink)
	{
		PeagDesignerStudioHomePage peagDesignerStudioHomePage = new PeagDesignerStudioHomePage(
				driver);
		/*for(WebElement mainLinkWebelement : peagDesignerStudioHomePage.globalMainLinks)
		{
			if(mainLinkWebelement.getText().equalsIgnoreCase(mainLink))
			{
				System.out.println("Main Link : "+mainLinkWebelement.getText());
				
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				break;
			}
		}*/
		BaseClass.click(peagDesignerStudioHomePage.designerStuido);
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		for(WebElement subLinkWebelement : peagDesignerStudioHomePage.subLinks)
		{
			if(subLinkWebelement.getText().equalsIgnoreCase(subLink))
			{
				System.out.println("Sub Link : "+subLinkWebelement.getText());
				new Actions(driver).moveToElement(subLinkWebelement).build().perform();
				BaseClass.waitForObj(1000);
				if(ifChildLinkIsAvailable == true)
				{
					for(WebElement childLinkWebElement : peagDesignerStudioHomePage.childLinks)
					{
						if(childLinkWebElement.getText().equalsIgnoreCase(childLink))
						{
							System.out.println("Child Link : "+childLinkWebElement.getText());
						//	childLinkWebElement.click();
							
							new Actions(BaseClass.driver).moveToElement(childLinkWebElement)
							.build().perform();
							
							CommonUtils.waitUntilAjaxRequestCompletes(driver);
							BaseClass.waitForObj(2000);
							break;
						}
					}
					
					for(WebElement childLinkWebElement1 : peagDesignerStudioHomePage.childLinks)
					{
						if(childLinkWebElement1.getText().equalsIgnoreCase(subChildLink))
						{
							System.out.println("Sub Child Link : "+childLinkWebElement1.getText());
							childLinkWebElement1.click();
							CommonUtils.waitUntilAjaxRequestCompletes(driver);
							BaseClass.waitForObj(2000);
							break;
						}
					}
				}else
				{
					if(subLinkWebelement.getText().equalsIgnoreCase(subLink))
					{
						BaseClass.click(subLinkWebelement);
						CommonUtils.waitUntilAjaxRequestCompletes(driver);
						BaseClass.waitForObj(2000);
						break;
					}
				}
				break;
			}
		}
	}
	
	
	public static void clickOnLogFiles(WebDriver driver,String link){
		
		PeagDesignerStudioHomePage peagDesignerStudioHomePage = new PeagDesignerStudioHomePage(
				driver);
		BaseClass.switchFrame(peagDesignerStudioHomePage.pegaGadet0Ifr);
		
		for(WebElement LinkWebElement1 : peagDesignerStudioHomePage.logUtilityLinks)
		{
			if(LinkWebElement1.getText().equalsIgnoreCase(link))
			{
				System.out.println("Link : "+LinkWebElement1.getText());
				LinkWebElement1.click();
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				BaseClass.waitForObj(2000);
				break;
			}
		}
		
		BaseClass.switchToDefaultFrame();
		
	}
	
	public static void validateLogFile(WebDriver driver,String fileName){
		
		PeagDesignerStudioHomePage peagDesignerStudioHomePage = new PeagDesignerStudioHomePage(
				driver);
		
		BaseClass.switchWindow(1);
		
		for(WebElement logFile : peagDesignerStudioHomePage.logFiles){
			System.out.println("logFile link : " + logFile.getText());
			if(logFile.getText().contains(fileName))
			{
				
				logFile.click();
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				BaseClass.waitForObj(2000);
				break;
			}
			
			
		}
		
	}
	
	public static void searchEventandVerifyConfirmBOD(WebDriver driver,String eventID){
		
		PeagDesignerStudioHomePage peagDesignerStudioHomePage = new PeagDesignerStudioHomePage(
				driver);
		
		BaseClass.clear(peagDesignerStudioHomePage.linesPerPage);
		BaseClass.set(peagDesignerStudioHomePage.linesPerPage,"250000");
		BaseClass.clear(peagDesignerStudioHomePage.filterBy);
		
		BaseClass.waitForObj(2000);
		BaseClass.click(peagDesignerStudioHomePage.apply_Button);
		
		BaseClass.waitForObj(20000);
		
		
	}
}
