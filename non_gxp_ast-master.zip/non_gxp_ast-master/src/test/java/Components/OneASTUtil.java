package Components;

import java.awt.AWTException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import BaseClass.AutomationException;
import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import ObjectRepository.AggregateSpendManagementNonUSPage;
import ObjectRepository.AggregateSpendManagementPage;
import ObjectRepository.ApprovalPage;
import ObjectRepository.ConsultingAgreementPage;
import ObjectRepository.HomePage;
import ObjectRepository.InitiationPage;
import ObjectRepository.LogInPage;
import ObjectRepository.OneASTHomePage;
import ObjectRepository.PeagDesignerStudioHomePage;

import com.csvreader.CsvWriter;
public class OneASTUtil 
{
	public static String agreementNumber="A-15079";
	public static String amendServiceDetails, amendContractTerm, amendFMVDetails;
	public static String searchType, agreementID, lastName_Individual, lastName_Organization, GEID,
			UniqueHCPIdentifier;
	public static ArrayList<String> tabs;
	public static String FMV_Country, FMV_Role, FMV_Q1, FMV_Q2, FMV_Q3, FMV_Q4, overrideRate,
			lowHigh, overriderateValue, serviceHours, preparationHours, travelHours;
	public static InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
	public static ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
			BaseClass.driver);
	public static ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
	public static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("mmss");
	public static Calendar calendar = Calendar.getInstance();
	public static String time = simpleDateFormat.format(calendar.getTime());
	public static String pendingWith;
	public static String transactionOwner;
	public static String directManager;
	public static String complainceEscalation;
	public static HomePage homePage;
	public static AggregateSpendManagementPage aggregateSpendManagementPage;
	public static AggregateSpendManagementNonUSPage aggregateSpendManagementNonUSPage;
	/**
	 * @param driver
	 * @param mainLink
	 * @param subLink
	 * @param ifChildLinkIsAvailable
	 *            if child link available to "True" otherwise "False"
	 * @param childLink
	 *            if not available Use the following --> "StringUtils.EMPTY"
	 */
	public static void selectItemFromMenuPanelInOneASTHomePage(WebDriver driver,String mainLink,
			String subLink,boolean ifChildLinkIsAvailable,String childLink)
	{
		OneASTHomePage oneASTHomePage = new OneASTHomePage(driver);
		for(WebElement mainLinkWebelement:oneASTHomePage.globalMainLinks)
		{
			if (mainLinkWebelement.getText().equalsIgnoreCase(mainLink))
			{
				System.out.println("Main Link : " + mainLinkWebelement.getText());
				BaseClass.click(mainLinkWebelement);
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				break;
			}
		}
		for(WebElement subLinkWebelement:oneASTHomePage.globalMainLinks)
		{
			if (subLinkWebelement.getText().equalsIgnoreCase(subLink))
			{
				System.out.println("Sub Link : " + subLinkWebelement.getText());
				new Actions(driver).moveToElement(subLinkWebelement).build().perform();
				BaseClass.waitForObj(1000);
				if (ifChildLinkIsAvailable == true)
				{
					for(WebElement childLinkWebElement:oneASTHomePage.globalMainLinks)
					{
						if (childLinkWebElement.getText().equalsIgnoreCase(childLink))
						{
							System.out.println("Child Link : " + childLinkWebElement.getText());
							childLinkWebElement.click();
							CommonUtils.waitUntilAjaxRequestCompletes(driver);
							BaseClass.waitForObj(3000);
							break;
						}
					}
				} else
				{
					if (subLinkWebelement.getText().equalsIgnoreCase(subLink))
					{
						BaseClass.click(subLinkWebelement);
						CommonUtils.waitUntilAjaxRequestCompletes(driver);
						BaseClass.waitForObj(3000);
						break;
					}
				}
				break;
			}
		}
	}
	public static void createConsultingAgreement(String cRType)
	{
		try
		{
			OneASTHomePageUtils.selectItemFromMenuPanelInOneASTHomePage(BaseClass.driver,
					OneASTHomePage.AGREEMENT, OneASTHomePage.NEW_CONSULTING_AGREEMENT, false, "");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			agreementNumber = OneASTUtil.getEventOrAgreementNumber();
			System.out.println("Agreement Number :: " + agreementNumber);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);
			if (cRType.equalsIgnoreCase("Individual"))
			{
				BaseClass.click(consultingAgreementPage.individualRadioButton);
			} else
			{
				BaseClass.click(consultingAgreementPage.organizationRadioButton);
			}
			BaseClass.waitForObj(5000);
			BaseClass.click(consultingAgreementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(15000);
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	/**
	 * 
	 * @param expectedGEId
	 */
	public static void selectCRType(String cRType)
	{
		try
		{
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			if (ExcelReport.testData.get("addNewIndividual").equalsIgnoreCase("Yes"))
			{
				addNewIndividual(initiationPage.addNewIndividualButton);
				BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			} else if (ExcelReport.testData.get("addNewOrganization").equalsIgnoreCase("Yes"))
			{
				addNewOrganization();
				BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			} else
			{
				if (cRType.equalsIgnoreCase("Individual") || (cRType.equalsIgnoreCase("Country")))
				{
					if(cRType.equalsIgnoreCase("Individual")){
					BaseClass.set(consultingAgreementPage.lastNameTextField, "automation");
					BaseClass.click(consultingAgreementPage.searchButtonInCRIndividual);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					}
					else if(cRType.equalsIgnoreCase("Country"))
					{
						BaseClass.select(consultingAgreementPage.countryDropDown, "United States");
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.click(consultingAgreementPage.searchButtonInCRIndividual);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					}
				} else
				{
					BaseClass.set(consultingAgreementPage.organizationNameTextField, "hospital");
					BaseClass.click(consultingAgreementPage.searchButtonInCROrganization);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				}
				for(int i = 0;i <= consultingAgreementPage.searchResults.size();i++)
				{
					int sz = consultingAgreementPage.searchResults.size();
					
					BaseClass.waitForObj(5000);
					((JavascriptExecutor) BaseClass.driver).executeScript(
							"arguments[0].scrollIntoView(true);",
							consultingAgreementPage.searchResults.get(i));
					BaseClass.waitForObj(3000);
					((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
							consultingAgreementPage.searchResults.get(i));
					BaseClass.waitForObj(5000);
					/*((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
							consultingAgreementPage.searchResults.get(i));*/
					((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
							consultingAgreementPage.submitButtonInSearchResultPage);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
					//BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
					System.out.println();
					boolean error = isElementPresent(consultingAgreementPage.errorMessage);
					System.out.println("Error Message :: " + error);
					if (error == true)
					{
						BaseClass.click(consultingAgreementPage.cancelButtonForList);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(5000);
						BaseClass.click(consultingAgreementPage.searchButtonInCRIndividual);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(5000);
						continue;
					} else
					{
						break;
					}
				}
			}
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	/**
	 * This method is for to enter values in Business Information tab
	 * 
	 * @param poleDropDownValue
	 * @param regionDropDownValue
	 * @param payingCountryDropDownValue
	 * @param businessDropDownValue
	 * @param modalityDropDownValue
	 * @param legalEntityDropDownVallue
	 * @param areYouSubmittingTheRequestOnBehalfOthers
	 * @param changeToOthercountryDropDownValue
	 * @Optional
	 * @param spendCategoryDropDownValue
	 * @param spendSubTypeDropDownValue
	 */
	public static void enterTheValuesInBusinessInformationTab(String poleDropDownValue,
			String regionDropDownValue,String payingCountryDropDownValue,
			String businessDropDownValue,String modalityDropDownValue,
			String legalEntityDropDownVallue,String products,String productIndicatpor,
			String areYouSubmittingTheRequestOnBehalfOthers,String transactionOwnerName,
			String changeToOthercountryDropDownValue,String spendCategoryDropDownValue,
			String spendSubTypeDropDownValue)
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			if (!poleDropDownValue.equalsIgnoreCase("ASIA-APAC")
					&& !poleDropDownValue.equalsIgnoreCase("Americas"))
			{
				BaseClass.select(initiationPage.poleDropDown, "ASIA-APAC");
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.poleDropDown, "Americas");
				BaseClass.waitForObj(5000);
			}
			if (!poleDropDownValue.equalsIgnoreCase("ASIA-APAC")
					&& !poleDropDownValue.equalsIgnoreCase("EMEA"))
			{
				BaseClass.select(initiationPage.poleDropDown, "EMEA");
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.poleDropDown, "ASIA-APAC");
				BaseClass.waitForObj(5000);
			}
			if (!poleDropDownValue.equalsIgnoreCase("EMEA")
					&& !poleDropDownValue.equalsIgnoreCase("Americas"))
			{
				BaseClass.select(initiationPage.poleDropDown, "Americas");
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.poleDropDown, "EMEA");
				BaseClass.waitForObj(5000);
			}
			BaseClass.select(initiationPage.poleDropDown, poleDropDownValue);
			BaseClass.waitForObj(5000);
			if (poleDropDownValue.equalsIgnoreCase("Americas"))
			{
				if (!regionDropDownValue.equalsIgnoreCase("Canada")
						&& !regionDropDownValue.equalsIgnoreCase("LATAM"))
				{
					BaseClass.select(initiationPage.regionDropDown, "Canada");
					BaseClass.waitForObj(5000);
					BaseClass.select(initiationPage.regionDropDown, "LATAM");
					BaseClass.waitForObj(5000);
				}
				if (!regionDropDownValue.equalsIgnoreCase("Canada")
						&& !regionDropDownValue.equalsIgnoreCase("United States"))
				{
					BaseClass.select(initiationPage.regionDropDown, "United States");
					BaseClass.waitForObj(5000);
					BaseClass.select(initiationPage.regionDropDown, "Canada");
					BaseClass.waitForObj(5000);
				}
				if (!regionDropDownValue.equalsIgnoreCase("United States")
						&& !regionDropDownValue.equalsIgnoreCase("LATAM"))
				{
					BaseClass.select(initiationPage.regionDropDown, "LATAM");
					BaseClass.waitForObj(5000);
					BaseClass.select(initiationPage.regionDropDown, "United States");
					BaseClass.waitForObj(5000);
				}
			}
			if (poleDropDownValue.equalsIgnoreCase("EMEA"))
			{
				if (!regionDropDownValue.equalsIgnoreCase("Europe"))
				{
					BaseClass.select(initiationPage.regionDropDown, "EGM");
					BaseClass.waitForObj(5000);
					BaseClass.select(initiationPage.regionDropDown, "Europe");
					BaseClass.waitForObj(5000);
				}
				if (!regionDropDownValue.equalsIgnoreCase("EGM"))
				{
					BaseClass.select(initiationPage.regionDropDown, "EGM");
					BaseClass.waitForObj(5000);
					BaseClass.select(initiationPage.regionDropDown, "Europe");
					BaseClass.waitForObj(5000);
				}
			}
			if (poleDropDownValue.equalsIgnoreCase("ASIA-APAC"))
			{
				if (!regionDropDownValue.equalsIgnoreCase("Korea")
						&& !regionDropDownValue.equalsIgnoreCase("ASEAN"))
				{
					BaseClass.select(initiationPage.regionDropDown, "Korea");
					BaseClass.waitForObj(5000);
					BaseClass.select(initiationPage.regionDropDown, "ASEAN");
					BaseClass.waitForObj(5000);
				}
				if (!regionDropDownValue.equalsIgnoreCase("Japan")
						&& !regionDropDownValue.equalsIgnoreCase("ANZ"))
				{
					BaseClass.select(initiationPage.regionDropDown, "Japan");
					BaseClass.waitForObj(5000);
					BaseClass.select(initiationPage.regionDropDown, "ANZ");
					BaseClass.waitForObj(5000);
				}
				if (!regionDropDownValue.equalsIgnoreCase("ASEAN")
						&& !regionDropDownValue.equalsIgnoreCase("South Asia"))
				{
					BaseClass.select(initiationPage.regionDropDown, "ASEAN");
					BaseClass.waitForObj(5000);
					BaseClass.select(initiationPage.regionDropDown, "South Asia");
					BaseClass.waitForObj(5000);
				}
			}
			BaseClass.select(initiationPage.regionDropDown, regionDropDownValue);
			BaseClass.waitForObj(10000);
			BaseClass.select(initiationPage.payingCountryDropDown, payingCountryDropDownValue);
			BaseClass.waitForObj(5000);
			if (!BaseClass.getAttributeValue(initiationPage.payingCountryDropDown, "value")
					.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.payingCountryDropDown, payingCountryDropDownValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			}
			BaseClass.select(initiationPage.payingCountryDropDown, "Select...");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.payingCountryDropDown, payingCountryDropDownValue);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.businessDropDown, businessDropDownValue);
			BaseClass.waitForObj(5000);
			if (!BaseClass.getAttributeValue(initiationPage.businessDropDown, "value")
					.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.businessDropDown, businessDropDownValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			}
			System.out.println();
			BaseClass.select(initiationPage.businessDropDown, "Select...");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.businessDropDown, businessDropDownValue);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.modalityDropDown, modalityDropDownValue);
			BaseClass.waitForObj(5000);
			if (!BaseClass.getAttributeValue(initiationPage.modalityDropDown, "value")
					.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.modalityDropDown, modalityDropDownValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			}
			BaseClass.select(initiationPage.legalEntityDropDown, legalEntityDropDownVallue);
			BaseClass.waitForObj(5000);
			if (!BaseClass.getAttributeValue(initiationPage.legalEntityDropDown, "value")
					.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.legalEntityDropDown, legalEntityDropDownVallue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			}
			BaseClass.select(initiationPage.legalEntityDropDown, "Select...");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.legalEntityDropDown, legalEntityDropDownVallue);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			if (regionDropDownValue.equalsIgnoreCase("United States"))
			{
				BaseClass.select(initiationPage.productDropDown, products);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.productIndicatorDropDown, productIndicatpor);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
			}
			if (areYouSubmittingTheRequestOnBehalfOthers.equalsIgnoreCase("Yes"))
			{
				BaseClass.click(initiationPage.onBehalfOfOtherYesRadioButton);
				BaseClass.waitForObj(5000);
				 PDFResultReport.addStepDetails("","","", "PASS", "Y");
				BaseClass.set(initiationPage.transactionOwnerSerachBox, transactionOwnerName);
				BaseClass.waitForObj(3000);
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.searchButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.radioButtonForTransactionOwner);
				BaseClass.waitForObj(3000);
				((JavascriptExecutor) BaseClass.driver).executeScript(
						"arguments[0].scrollIntoView(true);",
						initiationPage.radioButtonForTransactionOwner);
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			} else
			{
				BaseClass.click(initiationPage.onBehalfOfOtherNoRadioButton);
				BaseClass.waitForObj(5000);
			}
			if (!changeToOthercountryDropDownValue.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.changeToOthercountryDropDown,
						changeToOthercountryDropDownValue);
				BaseClass.waitForObj(5000);
			}
			
			Boolean spendType = isElementPresent(initiationPage.spendCatAvailable);
			if(spendType){
			BaseClass.select(initiationPage.spendCategoryDropDown, spendCategoryDropDownValue);
			BaseClass.waitForObj(1000);
			if (!spendSubTypeDropDownValue.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.spendSubTypeDropDown, spendSubTypeDropDownValue);
				BaseClass.waitForObj(3000);
			}
			}
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	/**
	 * This method is for to enter values in Supporting Information tab
	 * 
	 * @param businessJustificationForEngagementTextFieldValue
	 * @param gehcProductOrServicesIncludedTextFieldValue
	 * @param consultantQualificationSummaryTextFieldValue
	 * @param serviceToBeProvidedTextAreaValue
	 * @param payMentDetailsTextFieldValue
	 */
	public static void enterValuesInSupportingInformationTab(
			String businessJustificationForEngagementTextFieldValue,
			String gehcProductOrServicesIncludedTextFieldValue,
			String consultantQualificationSummaryTextFieldValue,
			String serviceToBeProvidedTextAreaValue,String payMentDetailsTextFieldValue)
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.click(initiationPage.nextButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(5000);
		BaseClass.set(initiationPage.businessJustificationForEngagementTextField,
				businessJustificationForEngagementTextFieldValue);
		BaseClass.set(initiationPage.gehcProductOrServicesIncludedTextField,
				gehcProductOrServicesIncludedTextFieldValue);
		BaseClass.set(initiationPage.consultantQualificationSummaryTextField,
				consultantQualificationSummaryTextFieldValue);
		BaseClass.set(initiationPage.serviceToBeProvidedTextArea, serviceToBeProvidedTextAreaValue);
		BaseClass.set(initiationPage.payMentDetailsTextField, payMentDetailsTextFieldValue);
	}
	/**
	 * 
	 * @param agreementTitleTextFieldValue
	 * @param willServiceCompensationBePaid
	 *            if "Yes" below field is Optional, if "No" below radio button
	 *            Value should be provided
	 * @param noServiceComponentTAndLOnlyRadioButtonAttributeValue
	 */
	public static void enterValuesInAgreementDetailsTab(String agreementTitleTextFieldValue,
			String willServiceCompensationBePaid,
			String noServiceComponentTAndLOnlyRadioButtonAttributeValue,String cRType,
			String addNewServiceProvider) throws Exception
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.set(initiationPage.agreementTitleTextField, agreementTitleTextFieldValue);
			BaseClass.waitForObj(1000);
			selectBothEffectiveandExpirationDateFromCalender();
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(3000);
			if (!willServiceCompensationBePaid.equalsIgnoreCase("Yes"))
			{
				BaseClass.click(initiationPage.willServiceCompensationBePaidNoRadioButton);
				BaseClass.waitForObj(5000);
				if (initiationPage.noServiceComponentTAndLOnlyRadioButton.getAttribute("id")
						.equalsIgnoreCase(noServiceComponentTAndLOnlyRadioButtonAttributeValue))
				{
					BaseClass.click(initiationPage.noServiceComponentTAndLOnlyRadioButton);
				} else
				{
					BaseClass.click(initiationPage.noTransferOfValueRadioButton);
				}
				if (cRType.equals("Organization"))
				{
					if (addNewServiceProvider.equalsIgnoreCase("Yes"))
					{
						addNewIndividual(initiationPage.addNewServiceProviderButton);
					} else
					{
						((JavascriptExecutor) BaseClass.driver).executeScript(
								"arguments[0].click();", initiationPage.addServiceProviderButton);
						BaseClass.waitForObj(5000);
						BaseClass.set(initiationPage.lastNameSearchfieldinAddServiceProvider,
								"test");
						BaseClass.waitForObj(5000);
						BaseClass.click(initiationPage.searchButtoninAddServiceProvider);
						BaseClass.waitForObj(5000);
						BaseClass.click(initiationPage.selectRadioButtoninAddServiceProvider);
						BaseClass.waitForObj(5000);
						BaseClass.click(initiationPage.submitButtonForTransactionOwner);
						BaseClass.waitForObj(5000);
						isElementPresent(initiationPage.cRServiceProvideLabel);
						System.out.println(BaseClass.driver.findElement(
								initiationPage.cRServiceProvideLabel).getText());
					}
				}
			} else
			{
				BaseClass.click(initiationPage.willServiceCompensationBePaidYesRadioButton);
				BaseClass.waitForObj(5000);
				if (cRType.equals("Organization"))
				{
					if (addNewServiceProvider.equalsIgnoreCase("Yes"))
					{
						addNewIndividual(initiationPage.addNewServiceProviderButton);
					} else
					{
						BaseClass.waitForObj(5000);
						((JavascriptExecutor) BaseClass.driver).executeScript(
								"arguments[0].click();", initiationPage.addServiceProviderButton);
						BaseClass.waitForObj(5000);
						BaseClass.set(initiationPage.lastNameSearchfieldinAddServiceProvider,
								"test");
						BaseClass.waitForObj(5000);
						BaseClass.switchToDefaultFrame();
						BaseClass.waitForObj(5000);
						BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
						BaseClass.waitForObj(5000);
						clickOnImage("SearchButton");
						BaseClass.waitForObj(5000);
						BaseClass.click(initiationPage.serachResultsInSearchProvider.get(0));
						BaseClass.waitForObj(5000);
						BaseClass.click(initiationPage.submitButtonForTransactionOwner);
						BaseClass.waitForObj(5000);
						isElementPresent(initiationPage.cRServiceProvideLabel);
						System.out.println(BaseClass.driver.findElement(
								initiationPage.cRServiceProvideLabel).getText());
					}
				}
				enterDetailsInFMVTab(ExcelReport.testData.get("FMVDetails"));
			}
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * This method used to navigate to Uploads tab and upload files
	 * 
	 * @param fileName
	 */
	public static void clickOnUploadsTabAndUploadTheFiles(String fileName) throws AWTException
	{
		try
		{
			BaseClass.switchToDefaultFrame();
			BaseClass.waitForObj(1000);
			BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
			initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.waitForObj(1000);
			//BaseClass.click(initiationPage.nextButton);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
						
			int size=initiationPage.mandatoryUploadsList.size();
			System.out.println(size);
			for(int i = 0;i < size;i++)
			{
				String documentTitle = initiationPage.documentTitleInUploadsTab.get(i).getText();
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.uploadButtonList.get(i));
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.subject_Upload, documentTitle);
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.attachmentButton);
				BaseClass.waitForObj(3000);
				CommonUtils.uploadFileUsingRobot(fileName);
				BaseClass.click(initiationPage.okButtonInModalPopUp);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(3000);
			}
		} catch(AutomationException e)
		{
			e.printStackTrace();
		}
	}
	
	public static void singleUpload(String fileName) throws AWTException
	{
		BaseClass.waitForObj(3000);
		BaseClass.click(initiationPage.singleuploadButtonList);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(3000);
		BaseClass.set(initiationPage.subject_Upload, "Test");
		BaseClass.waitForObj(3000);
		BaseClass.click(initiationPage.attachmentButton);
		BaseClass.waitForObj(3000);
		CommonUtils.uploadFileUsingRobot(fileName);
		BaseClass.click(initiationPage.okButtonInModalPopUp);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
	
		
	}
	
	
	
	/**
	 * This method used to click on Summary tab
	 * 
	 * @param fileName
	 */
	public static void clickOnSummaryTab()
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.click(consultingAgreementPage.submitButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	/**
	 * This method used to get Event ID or Agreement Number
	 * 
	 * @param fileName
	 */
	public static String getEventOrAgreementNumber()
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.switchToDefaultFrame();
		return initiationPage.number.getText();
	}
	/**
	 * This method used to select Date from Calender
	 * 
	 * @param fileName
	 */
	@SuppressWarnings("unused")
	public static void selectDateFromCalender(WebElement calender,int monthValue,String monthName,
			int yearValue,String year,String dateValue)
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.click(calender);
		BaseClass.waitForObj(1000);
		for(int i = 0;i < monthValue;i++)
		{
			if (monthName.contains("Aug"))
			{
				monthName = "August";
			}
			if (monthName.contains("Sep"))
			{
				monthName = "September";
			}
			if (monthName.contains("Oct"))
			{
				monthName = "October";
			}
			if (monthName.contains("Nov"))
			{
				monthName = "November";
			}
			if (monthName.contains("Dec"))
			{
				monthName = "December";
			}
			if (monthName.contains("Jan"))
			{
				monthName = "January";
			}
			if (monthName.contains("Feb"))
			{
				monthName = "February";
			}
			if (monthName.contains("Mar"))
			{
				monthName = "March";
			}
			if (monthName.contains("Apr"))
			{
				monthName = "April";
			}
			if (monthName.contains("May"))
			{
				monthName = "May";
			}
			if (monthName.contains("June"))
			{
				monthName = "June";
			}
			if (monthName.contains("July"))
			{
				monthName = "July";
			}
			if (monthName.equalsIgnoreCase(initiationPage.currentMonthValue.getText()))
			{
				break;
			}
			if (!monthName.equalsIgnoreCase(initiationPage.currentMonthValue.getText()))
			{
				BaseClass.click(initiationPage.previousMonthLink);
				if (monthName.equalsIgnoreCase(initiationPage.currentMonthValue.getText()))
				{
					break;
				}
			}
		}
		for(int i = 0;i < yearValue;i++)
		{
			if (year.equalsIgnoreCase(initiationPage.currentYearValue.getText()))
			{
				break;
			}
			if (!year.equalsIgnoreCase(initiationPage.currentYearValue.getText()))
			{
				BaseClass.click(initiationPage.nextYearLink);
				if (year.equalsIgnoreCase(initiationPage.currentYearValue.getText()))
				{
					break;
				}
			}
		}
		for(int i = 0;i < initiationPage.datesInCalender.size();i++)
		{
			if (dateValue.equalsIgnoreCase("32") || dateValue.equalsIgnoreCase("31"))
			{
				String Date = PDFResultReport.systemDate();
				String[] date = Date.split("-");
				String currentDate = date[0];
				currentDate = String.valueOf(Integer.parseInt(dateValue) - 1);
				System.out.println("Current Date " + currentDate);
				BaseClass.click(initiationPage.nextMonthLink);
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.datesInCalender.get(i));
				break;
			} else
			{
				BaseClass.click(initiationPage.datesInCalender.get(Integer.parseInt(dateValue)));
				break;
			}
		}
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
	}
	/**
	 * This method used to navigate to FMV tab and calculate Rates
	 * 
	 * @param fileName
	 */
	@SuppressWarnings("unused")
	public static void enterDetailsInFMVTab(String FMVDetails)
	{
		try
		{/*
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			String currency = null;
			String hourlyRate = null;
			int i = 0;
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			String[] FMVdetails = FMVDetails.split(",");
			FMV_Country = FMVdetails[0];
			FMV_Role = FMVdetails[1];
			FMV_Q1 = FMVdetails[2];
			FMV_Q2 = FMVdetails[3];
			FMV_Q3 = FMVdetails[4];
			FMV_Q4 = FMVdetails[5];
			overrideRate = FMVdetails[6];
			lowHigh = FMVdetails[7];
			serviceHours = FMVdetails[8];
			preparationHours = FMVdetails[9];
			travelHours = FMVdetails[10];
			if (isElementPresent(initiationPage.serviceProviderSpecialtyRole)
					&& isElementPresent(initiationPage.numberOfYearsOfExperience)
					&& isElementPresent(initiationPage.defaultHourlyRate))
			{
				System.out.println("CR Service Provider has Default rate values");
				currency = BaseClass.text(initiationPage.defaultCurrency);
			} else
			{
				//for( i=1 ;i++){
				BaseClass.select(initiationPage.FMV_Country.get(i), FMV_Country);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.FMV_Role.get(i), FMV_Role);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.FMV_Q1.get(i), FMV_Q1);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.FMV_Q2.get(i), FMV_Q2);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.FMV_Q3.get(i), FMV_Q3);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.FMV_Q4.get(i), FMV_Q4);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				currency = BaseClass.getAttributeValue(initiationPage.FMV_Q4.get(i), "value");
				BaseClass.click(initiationPage.calculateFMVRate.get(i));
				BaseClass.waitForObj(10000);
			}
			hourlyRate = BaseClass.text(initiationPage.hourlyRate.get(i));
			System.out.println(hourlyRate);
			if (!hourlyRate.isEmpty())
			{
				if (overrideRate.equalsIgnoreCase("Yes"))
				{
					if (lowHigh.equalsIgnoreCase("Low"))
					{
						BaseClass.click(initiationPage.overrideRate.get(i));
						String[] hourlyRate1 = hourlyRate.split(Character.toString(currency
								.charAt(0)));
						double newRate = Double.parseDouble(hourlyRate1[0]) - 10.00;
						BaseClass.set(initiationPage.newRate.get(i), String.valueOf(newRate));
						BaseClass.set(initiationPage.overrideJustification.get(i),
								"Overriding the existing rate");
					} else
					{
						BaseClass.click(initiationPage.overrideRate.get(i));
						String[] hourlyRate1 = hourlyRate.split(Character.toString(currency
								.charAt(0)));
						double newRate = Double.parseDouble(hourlyRate1[0]) + 10.00;
						BaseClass.set(initiationPage.newRate.get(i), String.valueOf(newRate));
						BaseClass.set(initiationPage.overrideJustification.get(i),
								"Overriding the existing rate");
					}
				}
				BaseClass.set(initiationPage.serviceHours.get(i), serviceHours);
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.preparationHours.get(i), preparationHours);
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.travelHours.get(i)
						, travelHours);
				BaseClass.waitForObj(5000);
				new Actions(BaseClass.driver).moveToElement(initiationPage.preparationHours.get(i))
						.click().build().perform();
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				String serviceRate = BaseClass.text(initiationPage.serviceRate);
				String[] serviceRate1 = serviceRate.split(" ");
				String travelRate = BaseClass.text(initiationPage.travelRate);
				String[] travelRate1 = travelRate.split(" ");
				String preparationRate = BaseClass.text(initiationPage.preparationRate);
				String[] preparationRate1 = preparationRate.split(" ");
				String actualTotalServiceAmount = BaseClass.text(initiationPage.totalServiceAmount);
				String[] actualTotalServiceAmount1 = actualTotalServiceAmount.split(" ");
				String actualTotalServiceAmount2 = String.format("%.1f",
						Double.parseDouble(actualTotalServiceAmount1[0]));
				System.out.println("Actual Total Service Amount " + actualTotalServiceAmount2);
				String actualTotalPreparationAmount = BaseClass
						.text(initiationPage.totalPreparationAmount);
				String[] actualTotalPreparationAmount1 = actualTotalPreparationAmount.split(" ");
				String actualTotalPreparationAmount2 = String.format("%.1f",
						Double.parseDouble(actualTotalPreparationAmount1[0]));
				System.out.println("Actual Total Service Amount " + actualTotalPreparationAmount2);
				String actualTotalTravelAmount = BaseClass.text(initiationPage.totalTravelAmount);
				String[] actualTotalTravelAmount1 = actualTotalTravelAmount.split(" ");
				String actualTotalTravelAmount2 = String.format("%.1f",
						Double.parseDouble(actualTotalTravelAmount1[0]));
				System.out.println("Actual Total Service Amount " + actualTotalTravelAmount2);
				String actualTotalHours = String.format("%.1f",
						Double.parseDouble(BaseClass.text(initiationPage.totalNoOfHours)));
				System.out.println("Actual Total Hours " + actualTotalHours);
				double expectedTotalServiceAmount = Double.parseDouble(serviceRate1[0])
						* Double.parseDouble(serviceHours);
				double expectedTotalTravelAmount = Double.parseDouble(travelRate1[0])
						* Double.parseDouble(travelHours);
				double expectedTotalPreparationAmount = Double.parseDouble(preparationRate1[0])
						* Double.parseDouble(preparationHours);
				if (expectedTotalServiceAmount == Double.parseDouble(actualTotalServiceAmount2)
						&& expectedTotalPreparationAmount == Double
								.parseDouble(actualTotalPreparationAmount2)
						&& expectedTotalTravelAmount == Double
								.parseDouble(actualTotalTravelAmount2))
				{
					System.out.println("Amounts are displayed as Expected");
				}
				double expectedTotalCompensationAmount = Double
						.parseDouble(actualTotalServiceAmount2)
						+ Double.parseDouble(actualTotalPreparationAmount2)
						+ Double.parseDouble(actualTotalTravelAmount2);
				double expectedTotalHours = Double.parseDouble(serviceHours)
						+ Double.parseDouble(travelHours) + Double.parseDouble(preparationHours);
				if (expectedTotalHours == Double.parseDouble(actualTotalHours)
						&& expectedTotalCompensationAmount == Double
								.parseDouble(actualTotalCompensationAmount))
				{
					System.out.println(actualTotalCompensationAmount);
				}
			}
			
		*/} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	/**
	 * This method is used to verify the Element Present
	 * 
	 * @param fileName
	 */
	public static boolean isElementPresent(By byLocator)
	{
		try
		{
			BaseClass.driver.findElement(byLocator);
			return true;
		} catch(NoSuchElementException e)
		{
			return false;
		}
	}
	/**
	 * This method is used to get Current Date Value
	 * 
	 * @param fileName
	 */
	public static String getCurrentDateValue()
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		return BaseClass.getAttributeValue(initiationPage.currentDate, "data-day");
	}
	/**
	 * This method is used to perform all approvals and activate Agreement
	 * 
	 * @param fileName
	 */
	public static void approveAndActivateAgreement(String fileName,String transactionNum)
	{
		try
		{
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			String status;
			for(int i=0;i<6;i++){
				
				BaseClass.switchToDefaultFrame();
				BaseClass.click(approvalPage.close);
				BaseClass.waitForObj(5000);					
				status = OneASTUtil.searchWithASTWorkflowandVerifyStatus(transactionNum);
				if(status.equalsIgnoreCase("Pending-Approval")){
					
					BaseClass.click(approvalPage.approvalFlowLink);
					
					if(isElementPresent(approvalPage.uploadinIPPCOE)){
						
						uploadDocumentForIPPCOEApproval("TestData.xlsx");					
					}						
					BaseClass.set(approvalPage.additionalComments,"Approve");	
					
					BaseClass.click(approvalPage.approveButton);
					
					BaseClass.waitForObj(5000);
				}else if (status.equalsIgnoreCase("Pending-Activation"))
				{
				activateAgreement("TestData.xlsx", "Pending-Activation");
				
				}else if(status.equalsIgnoreCase("Resolved-Completed")){
					System.out.println(status);
					break;
				}
			}
			
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		} 
	}
	public static void clickOnSubmitandVerifyStatus()
	{
		ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
				BaseClass.driver);
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.waitForObj(5000);
		BaseClass.click(consultingAgreementPage.submitButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		String status = BaseClass.text(approvalPage.status);
		if (status.equalsIgnoreCase("Resolved-Completed"))
		{
			System.out.println("Status is dispalyed as " + status);
		}
	}
	
	public static void addEducationalItems()
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.waitForObj(2000);
		BaseClass.set(initiationPage.descriptonOfItem, "Description");
		BaseClass.set(initiationPage.purposeofTheItem, "Purpose");
	}
	
	public static void addNewIndividual(WebElement addButton)
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					addButton);
			System.out.println("Add Individual");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			String title = BaseClass.text(initiationPage.titleAddNewCRIndividual);
			if (title.equalsIgnoreCase("Add New CR Individual")
					|| title.equalsIgnoreCase("Add New Individual"))
			{
				BaseClass.set(initiationPage.lastNameSearchfieldinAddServiceProvider,
						"Adding New CR Individual"+" "+time);
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.firstNameAddNewIndividual, "Adding New CR Individual"+" "+time);
				BaseClass.waitForObj(3000);
				BaseClass.select(initiationPage.countryAddNewIndividual, "Australia");
				
				BaseClass.waitForObj(3000);
				BaseClass.select(initiationPage.practitionerTypeAddNewIndividual, "Pharmacist");
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.employerInstitutionNameAddNewIndividual,
						"Adding New CR Individual"+" "+time);
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.addressAddNewIndividual, "Sydney");
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.cityAddNewIndividual, "Sydney");
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.postalCodeAddNewIndividual, "02ES20");
				BaseClass.waitForObj(3000);
				BaseClass.select(initiationPage.primarySpecialtyAddNewIndividual, "Optometry");
				BaseClass.waitForObj(2000);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				BaseClass.waitForObj(5000);
				ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
						BaseClass.driver);
				boolean error = isElementPresent(consultingAgreementPage.errorMessage);
				System.out.println("Error Message :: " + error);
				if (error == true)
				{
					BaseClass.click(initiationPage.submitButtonForTransactionOwner);
					BaseClass.waitForObj(5000);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
				}
			}
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	public static void addNewOrganization()
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.click(initiationPage.addNewOrganizationButton);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.addNewOrganizationButton);
			BaseClass.waitForObj(5000);
			String title = BaseClass.text(initiationPage.titleAddNewCRIndividual);
			if (title.equalsIgnoreCase("Add New CR Organization"))
			{
				BaseClass.select(initiationPage.organizationType, "Pre-commitment");
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.organizationName, " AST CE Automation Test"+" "+time);
				BaseClass.waitForObj(3000);
				BaseClass.select(initiationPage.countryAddNewIndividual, "Australia");
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.addressAddNewIndividual, "Sydney");
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.cityAddNewIndividual, "Sydney");
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.postalCodeAddNewIndividual, "02ES20");
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				BaseClass.waitForObj(5000);
				ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
						BaseClass.driver);
				boolean error = isElementPresent(consultingAgreementPage.errorMessage);
				System.out.println("Error Message :: " + error);
				if (error == true)
				{
					BaseClass.click(initiationPage.submitButtonForTransactionOwner);
					BaseClass.waitForObj(5000);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
				}
			}
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	public static void amendAgreementandSearchOptions(String searchTypeAmend)
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			OneASTHomePageUtils.selectItemFromMenuPanelInOneASTHomePage(BaseClass.driver,
					OneASTHomePage.AGREEMENT, OneASTHomePage.AMEND_CONSULTING_AGREEMENT, false, "");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			String[] searchValues = searchTypeAmend.split(",");
			searchType = searchValues[0];
			agreementID = searchValues[1];
			lastName_Individual = searchValues[2];
			lastName_Organization = searchValues[3];
			GEID = searchValues[4];
			UniqueHCPIdentifier = searchValues[5];
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);
			agreementNumber = OneASTUtil.getEventOrAgreementNumber();
			System.out.println("Agreement Number :: " + agreementNumber);
			PDFResultReport
					.addStepDetails(
							"Navigate to Workflow > Agreement > Amend Existing Consulting Agreement",
							"A new Agreement with Agreement case id <A-XXXX> should be created in a new Tab.",
							"A new Agreement with Agreement case id <" + agreementNumber
									+ "> is created in a new Tab.", "PASS", "Y");
			BaseClass.switchToDefaultFrame();
			BaseClass.switchFrame(consultingAgreementPage.pegaGadgetFrame);
			if (searchType.equalsIgnoreCase("Agreement ID"))
			{
				BaseClass.select(initiationPage.searchAgreementOptions, "Agreement ID");
				BaseClass.waitForObj(4000);
				PDFResultReport.addStepDetails(
						"Select 'Agreement ID' from search Agreement options ",
						"'Agreement Number' text field should get displayed",
						"'Agreement Number' text field is displayed", "PASS", "Y");
				BaseClass.set(initiationPage.agreementID, agreementID);
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.searchInAmendAgreement);
				BaseClass.waitForObj(3000);
				PDFResultReport
						.addStepDetails(
								"Enter the valid 'Agreement Number' and Click on [Search] button",
								"The  Agreement with  mentioned Agreement ID should be displayed with below columns. \n"
										+ "a) Select  Radio button to enable the user to select the agreement to be amended \n"
										+ "b) Agreement Number  As defined in the agreement \n"
										+ "c) Spend Type  As defined in the agreement \n"
										+ "d) Spend Category  As defined in the agreement \n"
										+ "e) Business  As defined in the agreement \n"
										+ "f) Modality  As defined in the agreement \n"
										+ "g) Product - if US only \n"
										+ "h) Start  Start date defined in the agreement \n"
										+ "i) End  End date define in the agreement \n"
										+ "j) Agreement Amount  Agreement amount approved in the agreement \n",
								"The  Agreement with  mentioned Agreement ID should be displayed with below columns. \n"
										+ "a) Select  Radio button to enable the user to select the agreement to be amended \n"
										+ "b) Agreement Number  As defined in the agreement \n"
										+ "c) Spend Type  As defined in the agreement \n"
										+ "d) Spend Category  As defined in the agreement \n"
										+ "e) Business  As defined in the agreement \n"
										+ "f) Modality  As defined in the agreement \n"
										+ "g) Product - if US only \n"
										+ "h) Start  Start date defined in the agreement \n"
										+ "i) End  End date define in the agreement \n"
										+ "j) Agreement Amount  Agreement amount approved in the agreement \n",
								"PASS", "Y");
				BaseClass.waitForObj(4000);
				BaseClass.click(initiationPage.selectAgreementRadioButton);
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.okButtonInModalPopUp);
				BaseClass.waitForObj(4000);
			} else
			{
				if (searchType.equalsIgnoreCase("Covered Recipient â€“ Individual"))
				{
					BaseClass.select(initiationPage.searchAgreementOptions,
							"Covered Recipient â€“ Individual");
					BaseClass.waitForObj(4000);
					if (lastName_Individual.isEmpty())
					{
						PDFResultReport
								.addStepDetails(
										"'Select 'Covered Reciepient-Individual' from search Agreement options",
										"'Search Options should get displayed- \n"
												+ "1) Last Name  Open text user input \n"
												+ "2) First Name  Open text user input \n"
												+ "3)GE ID", "'Search Options get displayed- \n"
												+ "1) Last Name  Open text user input \n"
												+ "2) First Name  Open text user input \n"
												+ "3)GE ID", "PASS", "Y");
						BaseClass.set(consultingAgreementPage.lastNameTextField,
								lastName_Individual);
						BaseClass.click(initiationPage.searchForCRIndividualAmend);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(5000);
						PDFResultReport
								.addStepDetails(
										"Enter a valid First name/Last name and click on [Search] button.",
										"The popup should be displayed with the list of CRs based on the search criteria entered with below column names. \n"
												+ "1) Select \n"
												+ "2) GE ID\n"
												+ "3) Last Name \n"
												+ "4) First Name \n"
												+ "5) Employer Institution Name  This will not have any values in case of US covered recipients\n"
												+ "6) Street Address\n"
												+ "7) City \n"
												+ "8) Country/State  All values stored under the State field in the US for covered recipients should be merged under this column.\n"
												+ "9) Specialty\n"
												+ "10) Unique HCP Identifier/NPI - All values stored under the NPI field in the US for covered recipients should be merged under this column",
										"The popup is displayed with the list of CRs based on the search criteria entered with below column names. \n"
												+ "1) Select \n"
												+ "2) GE ID\n"
												+ "3) Last Name \n"
												+ "4) First Name \n"
												+ "5) Employer Institution Name  This will not have any values in case of US covered recipients\n"
												+ "6) Street Address\n"
												+ "7) City \n"
												+ "8) Country/State  All values stored under the State field in the US for covered recipients should be merged under this column.\n"
												+ "9) Specialty\n"
												+ "10) Unique HCP Identifier/NPI - All values stored under the NPI field in the US for covered recipients should be merged under this column",
										"PASS", "Y");
					} else if (!GEID.isEmpty() | !UniqueHCPIdentifier.isEmpty())
					{
						Select select = new Select(BaseClass.driver.findElement(By
								.id("SearchIndividualOptions")));
						WebElement option = select.getFirstSelectedOption();
						String lastName_textBox = BaseClass.driver.findElement(By.id("LastName"))
								.getTagName();
						String firstName_textBox = BaseClass.driver.findElement(By.id("FirstName"))
								.getTagName();
						String country_dropdown = BaseClass.driver.findElement(By.id("Country"))
								.getTagName();
						if (BaseClass.getAttributeValue(initiationPage.searchAmend_Header, "title")
								.startsWith("HOW TO SEARCH FOR YOUR COVERED RECIPIENT")
								&& option.getText().equalsIgnoreCase(
										"Last Name/ First Name/ Country")
								&& lastName_textBox.equalsIgnoreCase("input")
								&& firstName_textBox.equalsIgnoreCase("input")
								&& country_dropdown.equalsIgnoreCase("select"))
						{
							System.out.println("Banner displayed");
							PDFResultReport
									.addStepDetails(
											"Select 'Covered Recipient- Indivdual' from search Agreement options",
											"1. A banner with 'ENTER YOUR SEARCH CRITERIA TO ADD YOUR CR' should be displayed. \n"
													+ "2. The value 'Last Name/First name/Country' should be autopulated in 'Search Options' dropdown. \n"
													+ "3. Below fields should be populated under 'Search Options' dropdown.\n"
													+ "1) Last Name  Open text field\n"
													+ "2) First Name  Open text field\n"
													+ "3) Country/State  Dropdown field with List of countries.",
											"1. A banner with 'ENTER YOUR SEARCH CRITERIA TO ADD YOUR CR' is displayed. \n"
													+ "2. The value 'Last Name/First name/Country' is autopulated in 'Search Options' dropdown. \n"
													+ "3. Below fields are populated under 'Search Options' dropdown.\n"
													+ "1) Last Name  Open text field\n"
													+ "2) First Name  Open text field\n"
													+ "3) Country/State  Dropdown field with List of countries.",
											"PASS", "Y");
							if (isElementPresent(initiationPage.searchCriteriaBanner))
							{
								PDFResultReport
										.addStepDetails(
												"'Verify the banner when 'Covered Recipient - Individual' option in 'Search for Agreement Options' dropdown",
												"'Below banner should be displayed. \n"
														+ " A Covered Recipient (CR) is an HCP/GO Individual or an HCI/GI receiving the value/benefit of the request.\n"
														+ " Search for the CR(s) by entering the last/first name or the  primary organization name and clicking Ã¢â‚¬Å“search) \n"
														+ " For CR Individuals, search can also be completed by using the Unique HCP Identifier/NPI number or the GE AST ID \n"
														+ " Research search for all CR(s) included in request \n"
														+ " If CR is not included in search, please click 'Add New Individual' or 'Add New Organization' to add CR to AST database \n"
														+ " Looking for recently used CRs? Click on history tab below to view your recently used CR names",
												"'Below banner is displayed. \n"
														+ " A Covered Recipient (CR) is an HCP/GO Individual or an HCI/GI receiving the value/benefit of the request.\n"
														+ " Search for the CR(s) by entering the last/first name or the  primary organization name and clicking Ã¢â‚¬Å“search) \n"
														+ " For CR Individuals, search can also be completed by using the Unique HCP Identifier/NPI number or the GE AST ID \n"
														+ " Research search for all CR(s) included in request \n"
														+ " If CR is not included in search, please click 'Add New Individual' or 'Add New Organization' to add CR to AST database \n"
														+ " Looking for recently used CRs? Click on history tab below to view your recently used CR names",
												"PASS", "N");
							}
						}
						if (!GEID.equalsIgnoreCase(" "))
						{
							BaseClass.select(initiationPage.searchIndividualOptions, "GE ID");
							BaseClass.waitForObj(5000);
							BaseClass.set(initiationPage.GEID_textField, GEID);
							BaseClass.waitForObj(3000);
							BaseClass.click(initiationPage.searchForCRIndividualAmend);
							CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
							BaseClass.waitForObj(5000);
							PDFResultReport
									.addStepDetails(
											"1. Select 'GE ID' value from the 'Search Options' dropdown \n"
													+ "2. Enter a valid GE ID and click on [Search] button \n"
													+ "Pre Requisite : The selected Agreement should have FMV rate over ridden.",
											"1. An Open text box with 'GE ID' label should be displayed. \n"
													+ "2. A pop up witth label 'Indivudual Agreement search by CRID' should be displayed with below columns.\n"
													+ " SELECT\n" + " GE ID\n" + " LAST NAME\n"
													+ " FIRST NAME\n"
													+ " EMPLOYER INSTITUTION NAME\n"
													+ " ADDRESS \n" + " CITY\n"
													+ " COUNTRY/ STATE \n" + " SPECIALTY\n"
													+ " UNIQUE HCP IDENTIFIER/ NPI",
											"1. An Open text box with 'GE ID' label is displayed. \n"
													+ "2. A pop up witth label 'Indivudual Agreement search by CRID' is displayed with below columns.\n"
													+ " SELECT\n" + " GE ID\n" + " LAST NAME\n"
													+ " FIRST NAME\n"
													+ " EMPLOYER INSTITUTION NAME\n"
													+ " ADDRESS \n" + " CITY\n"
													+ " COUNTRY/ STATE \n" + " SPECIALTY\n"
													+ " UNIQUE HCP IDENTIFIER/ NPI", "PASS", "Y");
						} else
						{
							BaseClass.select(initiationPage.searchIndividualOptions,
									"Unique HCP Identifier/ NPI");
							BaseClass.waitForObj(5000);
							BaseClass.set(initiationPage.NPINumber_textField, UniqueHCPIdentifier);
							BaseClass.waitForObj(3000);
							BaseClass.click(initiationPage.searchForCRIndividualAmend);
							CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
							BaseClass.waitForObj(5000);
							PDFResultReport
									.addStepDetails(
											"1. Select 'Unique HCP Identifier/NPI' value from the 'Search Options' dropdown \n"
													+ "2. Enter a valid Unique HCP Identifier and click on [Search] button",
											"1. An Open text box with 'GE ID' label should be displayed. \n"
													+ "2. A pop up witth label 'Indivudual Agreement search by CRID' should be displayed with below columns.\n"
													+ " SELECT\n" + " GE ID\n" + " LAST NAME\n"
													+ " FIRST NAME\n"
													+ " EMPLOYER INSTITUTION NAME\n"
													+ " ADDRESS \n" + " CITY\n"
													+ " COUNTRY/ STATE \n" + " SPECIALTY\n"
													+ " UNIQUE HCP IDENTIFIER/ NPI",
											"1. An Open text box with 'GE ID' label should be displayed. \n"
													+ "2. A pop up witth label 'Indivudual Agreement search by CRID' should be displayed with below columns.\n"
													+ " SELECT\n" + " GE ID\n" + " LAST NAME\n"
													+ " FIRST NAME\n"
													+ " EMPLOYER INSTITUTION NAME\n"
													+ " ADDRESS \n" + " CITY\n"
													+ " COUNTRY/ STATE \n" + " SPECIALTY\n"
													+ " UNIQUE HCP IDENTIFIER/ NPI", "PASS", "Y");
						}
					}
				}
				if (searchType.equalsIgnoreCase("Covered Recipient  Organization"))
				{
					BaseClass.select(initiationPage.searchAgreementOptions,
							"Covered Recipient  Organization");
					BaseClass.set(consultingAgreementPage.organizationNameTextField,
							lastName_Organization);
					BaseClass.click(initiationPage.searchForCROrganizationAmend);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				}
				for(int i = 0;i <= consultingAgreementPage.searchResults.size();i++)
				{
					BaseClass.waitForObj(5000);
					((JavascriptExecutor) BaseClass.driver).executeScript(
							"arguments[0].scrollIntoView(true);",
							consultingAgreementPage.searchResults.get(i));
					BaseClass.waitForObj(3000);
					((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
							consultingAgreementPage.searchResults.get(i));
					BaseClass.waitForObj(3000);
					BaseClass.click(initiationPage.searchAgreementAmendButton);
					PDFResultReport
							.addStepDetails(
									"'Select the radio button in 'Select' column against the respective CR to be selected and click on [Search Agreement] button",
									"'1. All the Agreements in 'Resolved - Completed' status should be displayed. \n"
											+ "2. Agreements with selected CR which has 'No Service Compensation' should not be displayed.\n"
											+ "3. Amended Agreements with the selected CR should not be displayed.",
									"'1. All the Agreements in 'Resolved - Completed' status are displayed. \n"
											+ "2. Agreements with selected CR which has 'No Service Compensation' not be displayed.\n"
											+ "3. Amended Agreements with the selected CR not be displayed.",
									"PASS", "Y");
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(3000);
					boolean error = isElementPresent(initiationPage.verifyRadioButtonPresent);
					System.out.println("Error Message :: " + error);
					if (error == false)
					{
						continue;
					} else
					{
						PDFResultReport
								.addStepDetails(
										"Select the radio button under 'Select' column present against  the CR  to be selected and click on [Search Agreement]  button",
										"1. The List of Agreements in the system in 'Resolved - Completed' status created with the CR selected should be displayed with below columns \n"
												+ "a) Select  Radio button to enable the user to select the agreement to be amended \n"
												+ "b) Agreement Number  As defined in the agreement \n"
												+ "c) Spend Type  As defined in the agreement \n"
												+ "d) Spend Category  As defined in the agreement \n"
												+ "e) Business  As defined in the agreement \n"
												+ "f) Modality  As defined in the agreement \n"
												+ "g) Product - if US only \n"
												+ "h) Start  Start date defined in the agreement \n"
												+ "i) End  End date define in the agreement \n"
												+ "j) Agreement Amount  Agreement amount approved in the agreement \n",
										"1. The List of Agreements in the system in 'Resolved - Completed' status created with the CR selected should be displayed with below columns \n"
												+ "a) Select  Radio button to enable the user to select the agreement to be amended \n"
												+ "b) Agreement Number  As defined in the agreement \n"
												+ "c) Spend Type  As defined in the agreement \n"
												+ "d) Spend Category  As defined in the agreement \n"
												+ "e) Business  As defined in the agreement \n"
												+ "f) Modality  As defined in the agreement \n"
												+ "g) Product - if US only \n"
												+ "h) Start  Start date defined in the agreement \n"
												+ "i) End  End date define in the agreement \n"
												+ "j) Agreement Amount  Agreement amount approved in the agreement \n",
										"PASS", "Y");
						BaseClass.click(initiationPage.selectAgreementRadioButton);
						PDFResultReport
								.addStepDetails(
										"'Select the radio button against the required Agreement and click on [Submit] button.",
										"'The selected Agreement should be populated on the 'Search Agreement Options' page with all the details.",
										"'The selected Agreement is populated on the 'Search Agreement Options' page with all the details.",
										"PASS", "Y");
						break;
					}
				}
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						consultingAgreementPage.submitButtonInSearchResultPage);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			}
			BaseClass.waitForObj(4000);
			PDFResultReport
					.addStepDetails(
							"Verify the details of the Agreement present in the section where search results are displayed.",
							"The Agreement details should be verified.",
							"The Agreement details should be verified.", "PASS", "N");
			BaseClass.click(consultingAgreementPage.submitButton);
			BaseClass.waitForObj(4000);
			PDFResultReport
					.addStepDetails(
							"Select the radio button against the required Agreement and click on [Submit] button.",
							"The screen should be navigated to next screen with title  'SELECT AMENDMENT EDIT'",
							"The screen is navigated to next screen with title  'SELECT AMENDMENT EDIT'",
							"PASS", "Y");
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	public static void selectSectiontoAmend(String amendDetails) throws Exception
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			String[] details = amendDetails.split(",");
			amendServiceDetails = details[0];
			amendContractTerm = details[1];
			amendFMVDetails = details[2];
			isElementPresent(initiationPage.verifyAmendText);
			String parentAgreementID = BaseClass.text(initiationPage.amendedFrom_ParentAgreementID);
			if (parentAgreementID.equalsIgnoreCase(ExcelReport.testData.get("Agreement ID")))
			{
				System.out.println("Parent Agreement ID" + parentAgreementID);
			}
			PDFResultReport
					.addStepDetails(
							"Verify the 'SELECT AMENDMENT EDIT' page ",
							"The page should contain below elements \n"
									+ "1. 'Amended From:' text with the Parent Agreement ID. This should be present through out the Agreement.\n"
									+ "2. A field with label 'What do you wish to Amend?' with below values each with \"Yes\" and \"no\" radio buttons \n"
									+ "- Services/payment Details \n" + "- Contract Term \n"
									+ "	- FMV Rate and /or Agreement Hours.",
							"The page should contain below elements \n"
									+ "1. 'Amended From:' text with the Parent Agreement ID. This is present through out the Agreement.\n"
									+ "2. A field with label 'What do you wish to Amend?' with below values each with \"Yes\" and \"no\" radio buttons \n"
									+ "- Services/payment Details \n" + "- Contract Term \n"
									+ "	- FMV Rate and /or Agreement Hours.", "PASS", "Y");
			if (amendServiceDetails.equalsIgnoreCase("Yes"))
			{
				BaseClass.clickOnRadioButton(initiationPage.amendServiceDetailsYes);
				BaseClass.waitForObj(3000);
			}
			if (amendContractTerm.equalsIgnoreCase("Yes"))
			{
				BaseClass.clickOnRadioButton(initiationPage.amendContracttermYes);
				BaseClass.waitForObj(3000);
			}
			if (amendFMVDetails.equalsIgnoreCase("Yes"))
			{
				BaseClass.clickOnRadioButton(initiationPage.amendFMVDetailsYes);
				BaseClass.waitForObj(3000);
			}
			BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
			BaseClass.waitForObj(4000);
		} catch(Exception e)
		{
			
			e.printStackTrace();
		}
	}
	public static void amendServiceDetails()
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
			BaseClass.waitForObj(4000);
			PDFResultReport
					.addStepDetails(
							"Click on [Next] button",
							"1. The changes should be made in 'Business Information' section. \n"
									+ "2. The screen should be navigated to next tab 'Supporting Information'",
							"1. The changes are made in 'Business Information' section. \n"
									+ "2. The screen is navigated to next tab 'Supporting Information'",
							"PASS", "Y");
			BaseClass.set(initiationPage.businessJustificationForEngagementTextField, "Amend test");
			BaseClass.set(initiationPage.gehcProductOrServicesIncludedTextField, "Amend test");
			BaseClass.set(initiationPage.consultantQualificationSummaryTextField, "Amend test");
			if (isElementPresent(initiationPage.serviceToBeProvided_Readonly) == false
					&& isElementPresent(initiationPage.paymentDetails_Readonly) == false)
			{
				System.out
						.println("'SERVICE TO BE PROVIDED' and 'Payment Details' are Read only fields");
				PDFResultReport
						.addStepDetails(
								"'Verify the 'Supporting Information' section.",
								"'1. The 'Supporting Information' tab should contain the below fields autopulated from parent Agreement and should be in editable mode in 'Justification' section \n"
										+ "- Business Justification for Engagement \n"
										+ "- GEHC Products/Service Included \n"
										+ "- Consultant Qualification Summary \n"
										+ "2. 'Contract Information' section with 'Original Amendment language' sub section should contain below fields in Read-only mode \n"
										+ "- Service to be provided \n" + "- Payment Details",
								"'1. The 'Supporting Information' tab contain the below fields autopulated from parent Agreement and are in editable mode in 'Justification' section \n"
										+ "- Business Justification for Engagement \n"
										+ "- GEHC Products/Service Included \n"
										+ "- Consultant Qualification Summary \n"
										+ "2. 'Contract Information' section with 'Original Amendment language' sub section contain below fields in Read-only mode \n"
										+ "- Service to be provided \n" + "- Payment Details",
								"PASS", "N");
			}
			if (amendServiceDetails.equalsIgnoreCase("Yes"))
			{
				if (isElementPresent(initiationPage.amendServiceDetailsText))
				{
					BaseClass.set(initiationPage.proposedServiceToBeProvided, "Amended test");
					BaseClass.set(initiationPage.ProposedPaymentDetails, "Amended test");
				}
				BaseClass.waitForObj(4000);
				PDFResultReport
						.addStepDetails(
								"Modify the required fields under 'Supporting Info' tab \n"
										+ "'Below fields autopulated from parent Agreement and  should be in editable mode in 'Justification'  section \n"
										+ "- Business Justification for Engagement \n"
										+ "- GEHC Products/Service Included \n"
										+ "- Consultant Qualification Summary \n"
										+ "- Original Amendment language with \n"
										+ "'SERVICE TO BE PROVIDED' and 'Payment Details' should be autopopulated from the Parent Agreement in Read-only mode"
										+ "-Proposed Amendment language \n"
										+ "Service to be Provided and + icon to add more lines under service to be provided and payment details should get displayed with open text field in editable mod",
								"Should be able to modify all the required fields",
								"Able to modify all the required fields", "PASS", "Y");
			} else
			{
				PDFResultReport
						.addStepDetails(
								"Modify the required fields under 'Supporting Info' tab \n"
										+ "'Below fields autopulated from parent Agreement and  should be in editable mode in 'Justification'  section \n"
										+ "- Business Justification for Engagement \n"
										+ "- GEHC Products/Service Included \n"
										+ "- Consultant Qualification Summary \n"
										+ "- Original Amendment language with \n"
										+ "'SERVICE TO BE PROVIDED' and 'Payment Details' should be autopopulated from the Parent Agreement in Read-only mode",
								"Should be able to modify all the required fields",
								"Able to modify all the required fields", "PASS", "Y");
			}
			BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
			BaseClass.waitForObj(4000);
			PDFResultReport
					.addStepDetails(
							"Click on [Next] button",
							"1. The screen should be moved to 'Agreement details' tab. \n"
									+ "2. All the fields should be in read only mode populated from Parent Agreement.",
							"1. The screen is moved to 'Agreement details' tab. \n"
									+ "2. All the fields are in read only mode populated from Parent Agreement.",
							"PASS", "Y");
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unused")
	public static void amendContractTerm() throws Exception
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			if (isElementPresent(initiationPage.agreementTitle_Readonly)
					&& isElementPresent(initiationPage.originalEffectiveDate_Readonly)
					&& isElementPresent(initiationPage.originalExpirationDate_Readonly)
					&& isElementPresent(initiationPage.serviceCompensationToBePaid_Readonly))
			{
				System.out.println("All the fields are Read only in Agreement Details Pages");
				PDFResultReport
						.addStepDetails(
								"Veriy the below fields should get populated from the parent agreement in Read-only \n"
										+ "'CR Organization' should get added in read-only mode \n"
										+ "Below fields under covered Receipients should get displayed under read-only \n"
										+ "-'GE ID'\n"
										+ "-'Covered Receipient'\n"
										+ "-'Beneficiary Address'\n"
										+ "-'Payee Recipient'\n"
										+ "-'Payee Address'\n"
										+ "-'Agreement Title'\n"
										+ "Below fields under Service Provider should get displayed under read-only\n"
										+ "-'CR Service Provider'\n"
										+ "-'Original Effective Date' and 'Original Expiration Date (C)' should get displayed in read-only mode from Parent ID\n"
										+ "-Will service compensation be paid? should be selected as 'Yes' under SERVICE COMPENSATION Q&A'\n"
										+ "'ENTER THE ACTUAL EFFECTIVE DATE' section should be displayed with 'Effective Date' and 'Expiration Date' mandatoy fields and it should be editable for user to enter the dates.",
								"'Should be able to verify the details from the Parent agreement",
								"'Able to verify the details from the Parent agreement", "PASS",
								"Y");
			}
			if (amendContractTerm.equalsIgnoreCase("Yes"))
			{
				if (isElementPresent(initiationPage.amendContractTermText))
				{
					String expirationDate = BaseClass.getAttributeValue(
							initiationPage.expirationDate, "value");
					String effectiveDate = BaseClass.getAttributeValue(
							initiationPage.effectiveDate, "value");
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					Date effectiveDate1 = sdf.parse(effectiveDate);
					Date expirationDate1 = sdf.parse(expirationDate);
					System.out.println(sdf.format(effectiveDate1));
					System.out.println(sdf.format(expirationDate1));
					if (expirationDate1.compareTo(effectiveDate1) > 0)
					{
						System.out.println("expirationDate is greater than effectiveDate");
					} else if (expirationDate1.compareTo(effectiveDate1) < 0)
					{
						System.out.println("expirationDate is less than effectiveDate");
					} else if (effectiveDate1.compareTo(expirationDate1) == 0)
					{
						System.out.println("expirationDate is equal to effectiveDate");
					}
					String createdDate = BaseClass.text(approvalPage.workDetails
							.get(ApprovalPage.CREATED));
					/*  Date createdDate1= sdf.parse(createdDate);
					  
					  if(effectiveDate1.compareTo(createdDate1)>0){
						  
						  System.out.println("'Effective date' is greater than to the created date");
					  }else if(effectiveDate1.compareTo(createdDate1)<0){
						    System.out.println("'Effective date' is less than created date");
						  }else if(effectiveDate1.compareTo(createdDate1)==0){
						    System.out.println("'Effective date' is equal to the created date");
						  }*/
					PDFResultReport
							.addStepDetails(
									"'Validate the below conditions for 'Effective date' and 'Expiration date' \n"
											+ "1. 'Expiration date' should be greater than the effective date \n"
											+ "2. 'Effective date' should be greater than or equal to the created date \n"
											+ "3. If the Region is chosen as 'United States', there should be a validation that the 'Expiration date' should be more than one year that the 'Effective date'.",
									"'The mentioned validations should be verified.",
									"'The mentioned validations are verified.", "PASS", "Y");
					BaseClass.waitForObj(1000);
					BaseClass.click(initiationPage.effectiveDateCalender);
					BaseClass.waitForObj(1000);
					String Date = PDFResultReport.systemDate();
					String[] date = Date.split("-");
					String currentDate = date[0];
					currentDate = String.valueOf(Integer.parseInt(currentDate) + 1);
					System.out.println("Current Date " + currentDate);
					selectDateFromCalender(initiationPage.effectiveDateCalender, 12, date[1], 10,
							date[2], currentDate);
					String year = String.valueOf(Integer.parseInt(date[2]) + 1);
					selectDateFromCalender(initiationPage.expirationDateCalender, 12, date[1], 10,
							year, "25");
					BaseClass.waitForObj(3000);
					PDFResultReport
							.addStepDetails(
									"Modify the 'Effective Date' and 'Expiration Date'",
									"'Should be able to modify  the 'Effective Date' and 'Expiration Date'",
									"Able to modify  the 'Effective Date' and 'Expiration Date'",
									"PASS", "Y");
				}
			}
			BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
			BaseClass.waitForObj(5000);
			PDFResultReport.addStepDetails("Click on [Next] button",
					"Wf should be navigated to FMV tab", "Wf is navigated to FMV tab", "PASS", "Y");
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	public static void amendFMVDetails(String overrideRate,String highLow) throws Exception
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			if (isElementPresent(initiationPage.FMVCountry_Readonly)
					&& isElementPresent(initiationPage.FMVSpecialityRole_Readonly)
					&& isElementPresent(initiationPage.FMVhourlyRate_Readonly)
					&& isElementPresent(initiationPage.FMVTravelRate_Readonly)
					&& isElementPresent(initiationPage.FMVTotalAgreementAmount_Readonly))
			{
				System.out.println("All the details in FMV tab are Read only");
				PDFResultReport
						.addStepDetails(
								"Verify that below fields should be Auto-Populated from the FMV tab from Parent Agreement \n"
										+ " CONSULTANT COUNTRY & SPECIALTY Section:\n"
										+ "'Country'\n"
										+ "'Specialty/RoleRequired'\n"
										+ "-FMV QUESTIONS Section should be autopopulated from parent-agreement\n"
										+ "-FAIR MARKET VALUE (FMV) COMPENSATION section should get autopopulated from Read-only mode\n"
										+ "-Hourly/override Rate\n" + "-Service\n"
										+ "-Preparation\n" + "-Travel\n" + "-Total\n",
								"Should be able to verify the details from the Parent agreement",
								"Able to verify the details from the Parent agreement", "PASS", "Y");
			}
			if (amendFMVDetails.equalsIgnoreCase("Yes"))
			{
				String currency = null;
				String hourlyRate = null;
				// BaseClass.click(initiationPage.nextButton);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				//hourlyRate = BaseClass.text(initiationPage.hourlyRate);
				System.out.println(hourlyRate);
				currency = BaseClass.text(initiationPage.defaultCurrency);
				String[] hourlyRate1 = hourlyRate.split(" ");
				String hourlyRate3;
				if (hourlyRate1[0].length() > 5)
				{
					String hourlyRate2 = hourlyRate1[0].replace(",", "");
					hourlyRate3 = String.format("%.1f", Double.parseDouble(hourlyRate2));
					System.out.println("Actual Total Service Amount " + hourlyRate3);
				} else
				{
					hourlyRate3 = String.format("%.1f", Double.parseDouble(hourlyRate1[0]));
					System.out.println("Actual Total Service Amount " + hourlyRate3);
				}
				String serviceRate = BaseClass.text(initiationPage.serviceRate);
				String[] serviceRate1 = serviceRate.split(" ");
				String serviceRate3;
				if (serviceRate1[0].length() > 5)
				{
					String serviceRate2 = serviceRate1[0].replace(",", "");
					serviceRate3 = String.format("%.1f", Double.parseDouble(serviceRate2));
					System.out.println("Actual Total Service Amount " + serviceRate3);
				} else
				{
					serviceRate3 = String.format("%.1f", Double.parseDouble(serviceRate1[0]));
					System.out.println("Actual Total Service Amount " + serviceRate3);
				}
				String actualTotalServiceAmount = BaseClass.text(initiationPage.totalServiceAmount_1);
				String[] actualTotalServiceAmount1 = actualTotalServiceAmount.split(" ");
				String actualTotalServiceAmount3;
				if (actualTotalServiceAmount1[0].length() > 5)
				{
					String actualTotalServiceAmount2 = actualTotalServiceAmount1[0]
							.replace(",", "");
					actualTotalServiceAmount3 = String.format("%.1f",
							Double.parseDouble(actualTotalServiceAmount2));
					System.out.println("Actual Total Service Amount " + actualTotalServiceAmount3);
				} else
				{
					actualTotalServiceAmount3 = String.format("%.1f",
							Double.parseDouble(actualTotalServiceAmount1[0]));
					System.out.println("Actual Total Service Amount " + actualTotalServiceAmount3);
				}
				String serviceNoOfHours = BaseClass.getAttributeValue(initiationPage.serviceHours_1,
						"value");
				double expectedTotalServiceAmount = Double.parseDouble(serviceRate3)
						* Double.parseDouble(serviceNoOfHours);
				new Actions(BaseClass.driver).moveToElement(initiationPage.totalServiceAmount_1)
						.build().perform();
				if (hourlyRate.equalsIgnoreCase(serviceRate)
						&& BaseClass.getAttributeValue(initiationPage.serviceHours_1, "type")
								.equalsIgnoreCase("number")
						&& expectedTotalServiceAmount == Double
								.parseDouble(actualTotalServiceAmount3))
				{
					PDFResultReport
							.addStepDetails(
									"'Verify the 'Service' sections under 'Hourly rate' field.",
									"'1. Below fields should be present in 'Service ' section \n"
											+ "- 'Service Rate' field  should be same as Hourly rate or 'New rate'(when over ridden) and should be populated from the parent Agreement. \n"
											+ "- 'No of remaining hours' field should display the hours remaining in the parent Agreement after hours are finalized. \n"
											+ "- 'Amendment Hours' field should be an open text field \n"
											+ "- 'Total Service Amount' should be calculated as Amendment hours * Service Rate",
									"'1. Below fields are present in 'Service ' section \n"
											+ "- 'Service Rate' field  is same as Hourly rate or 'New rate'(when over ridden) and is populated from the parent Agreement. \n"
											+ "- 'No of remaining hours' field display the hours remaining in the parent Agreement after hours are finalized. \n"
											+ "- 'Amendment Hours' field is an open text field \n"
											+ "- 'Total Service Amount' is calculated as Amendment hours * Service Rate",
									"PASS", "Y");
				}
				// Preparation Amount
				String PreparationRate = BaseClass.text(initiationPage.preparationRate);
				String[] PreparationRate1 = PreparationRate.split(" ");
				String PreparationRate3;
				if (PreparationRate1[0].length() > 5)
				{
					String PreparationRate2 = PreparationRate1[0].replace(",", "");
					PreparationRate3 = String.format("%.1f", Double.parseDouble(PreparationRate2));
					System.out.println("Actual Total Preparation Amount " + PreparationRate3);
				} else
				{
					PreparationRate3 = String.format("%.1f",
							Double.parseDouble(PreparationRate1[0]));
					System.out.println("Actual Total Preparation Amount " + PreparationRate3);
				}
				String actualTotalPreparationAmount = BaseClass
						.text(initiationPage.totalPreparationAmount_1);
				String[] actualTotalPreparationAmount1 = actualTotalPreparationAmount.split(" ");
				String actualTotalPreparationAmount3;
				if (actualTotalPreparationAmount1[0].length() > 5)
				{
					String actualTotalPreparationAmount2 = actualTotalPreparationAmount1[0]
							.replace(",", "");
					actualTotalPreparationAmount3 = String.format("%.1f",
							Double.parseDouble(actualTotalPreparationAmount2));
					System.out.println("Actual Total Preparation Amount "
							+ actualTotalPreparationAmount3);
				} else
				{
					actualTotalPreparationAmount3 = String.format("%.1f",
							Double.parseDouble(actualTotalPreparationAmount1[0]));
					System.out.println("Actual Total Preparation Amount "
							+ actualTotalPreparationAmount3);
				}
				String PreparationNoOfHours = BaseClass.getAttributeValue(
						initiationPage.preparationHours_1, "value");
				double expectedTotalPreparationAmount = Double.parseDouble(String.format(
						"%.1f",
						Double.parseDouble(PreparationRate3)
								* Double.parseDouble(PreparationNoOfHours)));
				if (hourlyRate.equalsIgnoreCase(PreparationRate)
						&& BaseClass.getAttributeValue(initiationPage.preparationHours_1, "type")
								.equalsIgnoreCase("number")
						&& expectedTotalPreparationAmount == Double
								.parseDouble(actualTotalPreparationAmount3))
				{
					PDFResultReport
							.addStepDetails(
									"'Verify the 'Preparation' sections under 'Hourly rate' field.",
									"'1. Below fields should be present in 'Preparation ' section \n"
											+ "- 'Preparation Rate' field  should be same as Hourly rate or 'New rate'(when over ridden) and should be populated from the parent Agreement. \n"
											+ "- 'No of remaining hours' field should display the hours remaining in the parent Agreement after hours are finalized. \n"
											+ "- 'Amendment Hours' field should be an open text field \n"
											+ "- 'Total Preparation Amount' should be calculated as Amendment hours * Preparation Rate",
									"'1. Below fields are present in 'Preparation ' section \n"
											+ "- 'Preparation Rate' field  is same as Hourly rate or 'New rate'(when over ridden) and is populated from the parent Agreement. \n"
											+ "- 'No of remaining hours' field display the hours remaining in the parent Agreement after hours are finalized. \n"
											+ "- 'Amendment Hours' field is an open text field \n"
											+ "- 'Total Preparation Amount' is calculated as Amendment hours * Preparation Rate",
									"PASS", "Y");
				}
				// Travel rate
				String travelRate = BaseClass.text(initiationPage.travelRate);
				String[] travelRate1 = travelRate.split(" ");
				String travelRate3;
				if (travelRate1[0].length() > 5)
				{
					String travelRate2 = travelRate1[0].replace(",", "");
					travelRate3 = String.format("%.1f", Double.parseDouble(travelRate2));
					System.out.println("Actual Total Service Amount " + travelRate3);
				} else
				{
					travelRate3 = String.format("%.1f", Double.parseDouble(travelRate1[0]));
					System.out.println("Actual Total Service Amount " + travelRate3);
				}
				String actualTotalTravelAmount = BaseClass.text(initiationPage.totalTravelAmount);
				String[] actualTotalTravelAmount1 = actualTotalTravelAmount.split(" ");
				String actualTotalTravelAmount3;
				if (actualTotalTravelAmount1[0].length() > 5)
				{
					String actualTotalTravelAmount2 = actualTotalTravelAmount1[0].replace(",", "");
					actualTotalTravelAmount3 = String.format("%.1f",
							Double.parseDouble(actualTotalTravelAmount2));
					System.out.println("Actual Total Travel Amount " + actualTotalTravelAmount3);
				} else
				{
					actualTotalTravelAmount3 = String.format("%.1f",
							Double.parseDouble(actualTotalTravelAmount1[0]));
					System.out.println("Actual Total Travel Amount " + actualTotalTravelAmount3);
				}
				travelRate3 = String.valueOf(Double.parseDouble(hourlyRate3) / 2.0);
				System.out.println("Travel rate:" + travelRate3);
				String travelNoOfHours = BaseClass.getAttributeValue(initiationPage.travelHours_1,
						"value");
				double expectedTotalTravelAmount = Double.parseDouble(String.format("%.1f",
						Double.parseDouble(travelRate3) * Double.parseDouble(travelNoOfHours)));
				if (travelRate.replace(",", "").contains(travelRate3)
						&& BaseClass.getAttributeValue(initiationPage.travelHours_1, "type")
								.equalsIgnoreCase("number")
						&& expectedTotalTravelAmount == Double
								.parseDouble(actualTotalTravelAmount3))
				{
					PDFResultReport
							.addStepDetails(
									"'Verify the 'Travel' sections under 'Hourly rate' field.",
									"'1. Below fields should be present in 'Travel ' section \n"
											+ "- 'Travel Rate' field  should be half of actual hourly rate(New rate when over ridden) and should be populated from the parent Agreement."
											+ "- 'No of remaining hours' field should display the hours remaining in the parent Agreement after hours are finalized. \n"
											+ "- 'Amendment Hours' field should be an open text field \n"
											+ "- 'Total Travel Amount' should be calculated as Amendment hours * Service Rate",
									"'1. Below fields are present in 'Service ' section \n"
											+ "- 'Travel Rate' field  is same as half of actual hourly rate(New rate when over ridden) and should be populated from the parent Agreement. \n"
											+ "- 'No of remaining hours' field display the hours remaining in the parent Agreement after hours are finalized. \n"
											+ "- 'Amendment Hours' field is an open text field \n"
											+ "- 'Total Travel Amount' is calculated as Amendment hours * Service Rate",
									"PASS", "Y");
				}
				BaseClass.waitForObj(3000);
				if (BaseClass.text(initiationPage.banner_TravelSection).contains(
						"The travel section above is not for T&L payments"))
				{
					new Actions(BaseClass.driver)
							.moveToElement(initiationPage.banner_TravelSection).build().perform();
					BaseClass.waitForObj(3000);
					PDFResultReport
							.addStepDetails(
									"Verify the Banner under 'Travel' section.",
									"The below banner should be displayed under 'Travel' section \n"
											+ "Note: The travel section above is not for T&L payments but referring to the time the HCP/GO is getting compensation due to his/her travel.  For T&L payments, please add the expenses under the budget tab within the event workflow.",
									"The below banner is displayed under 'Travel' section \n"
											+ "Note: The travel section above is not for T&L payments but referring to the time the HCP/GO is getting compensation due to his/her travel.  For T&L payments, please add the expenses under the budget tab within the event workflow.",
									"PASS", "Y");
				}
				Double expectedTotalCompensationAmount = expectedTotalServiceAmount
						+ expectedTotalPreparationAmount + expectedTotalTravelAmount;
				String actualTotalCompensationAmount = BaseClass
						.text(initiationPage.totalCompensationAmount);
				String actualTotalHours = BaseClass.text(initiationPage.totalNoOfHours);
				double expectedTotalHours = Double.parseDouble(serviceNoOfHours)
						+ Double.parseDouble(PreparationNoOfHours)
						+ Double.parseDouble(travelNoOfHours);
				if (expectedTotalHours == Double.parseDouble(actualTotalHours)
						&& actualTotalCompensationAmount.contains(String
								.valueOf(expectedTotalCompensationAmount)))
				{
					System.out.println(actualTotalCompensationAmount);
					PDFResultReport
							.addStepDetails(
									"'Verify the 'Total' section",
									"'The 'Total' section should have below fields  which should be populated based on below conditions \n"
											+ "1. Total Number of hours remaining  From the original agreement (total service hours + total preparation hours + total travel time) \n"
											+ "2.  Total Amendment hours  Service Amendment hours + Preparation Amendment hours + Travel Time Amendment hours \n"
											+ "3. Total compensation amount   From the amended agreement (total service amount + total preparation amount + total travel time)",
									"'The 'Total' section have below fields  which should be populated based on below conditions \n"
											+ "1. Total Number of hours remaining  From the original agreement (total service hours + total preparation hours + total travel time) \n"
											+ "2.  Total Amendment hours  Service Amendment hours + Preparation Amendment hours + Travel Time Amendment hours \n"
											+ "3. Total compensation amount   From the amended agreement (total service amount + total preparation amount + total travel time)",
									"PASS", "Y");
				}
				String serviceHours = "2.00";
				String preparationHours = "2.00";
				String travelHours = "2.00";
				BaseClass.clear(initiationPage.serviceHours_1);
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.serviceHours_1, serviceHours);
				BaseClass.waitForObj(5000);
				BaseClass.clear(initiationPage.preparationHours_1);
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.preparationHours_1, preparationHours);
				BaseClass.waitForObj(5000);
				BaseClass.clear(initiationPage.travelHours_1);
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.travelHours_1, travelHours);
				BaseClass.waitForObj(5000);
				new Actions(BaseClass.driver).moveToElement(initiationPage.preparationHours_1)
						.click().build().perform();
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				PDFResultReport
						.addStepDetails(
								"Enter the 'Amend Hours'  under 'Service', 'Preparation' and 'Travel' sections",
								"The below sections should be changed accordingly. \n"
										+ "1. Total Service Amount \n"
										+ "2. Total Preparation Amount \n"
										+ "3. Total Travel Amount \n"
										+ "4. Total Amendment hours \n"
										+ "5. Total compensation amount",
								"The below sections are changed accordingly. \n"
										+ "1. Total Service Amount \n"
										+ "2. Total Preparation Amount \n"
										+ "3. Total Travel Amount \n"
										+ "4. Total Amendment hours \n"
										+ "5. Total compensation amount", "PASS", "Y");
				if (overrideRate.equalsIgnoreCase("Yes"))
				{
					if (BaseClass.driver.findElement(By.id("ServiceRateOverrideYes")).isSelected())
					{
						//BaseClass.click(initiationPage.overrideRate);
						BaseClass.waitForObj(5000);
					}
					//BaseClass.click(initiationPage.overrideRate);
					BaseClass.waitForObj(4000);
					PDFResultReport.addStepDetails("'Select the 'Over ride' checkbox",
							"'The below fields should be displayed."
									+ "1. New Rate  mandatory open text to enter Amount.\n"
									+ "2. Override Justification  mandatory open text",
							"'The below fields should be displayed."
									+ "1. New Rate  mandatory open text to enter Amount.\n"
									+ "2. Override Justification  mandatory open text", "PASS",
							"Y");
					String[] hourlyRate11 = hourlyRate
							.split(Character.toString(currency.charAt(0)));
					double newRate = 0;
					if (hourlyRate11[0].contains(","))
					{
						hourlyRate11[0] = hourlyRate11[0].replace(",", "");
					}
					if (highLow.contains("high"))
					{
						newRate = Double.parseDouble(hourlyRate11[0]) + 10.00;
					} else if (highLow.contains("low"))
					{
						newRate = Double.parseDouble(hourlyRate11[0]) - 10.00;
					}
					/*BaseClass.set(initiationPage.newRate, String.valueOf(newRate));
					BaseClass.set(initiationPage.overrideJustification,
							"Overriding the existing rate");*/
					BaseClass.waitForObj(4000);
					PDFResultReport
							.addStepDetails(
									"Enter the  Amount in 'New Rate' box higher than populated  FMV rate. (Actual FMV rate)",
									"1. The 'Hourly Rate'  should be populated with new value entered in 'New Rate' field. \n"
											+ "2. The fields under 'Service', 'Preparation' and 'Travel' should be changed accordingly.",
									"1. The 'Hourly Rate'  is populated with new value entered in 'New Rate' field. \n"
											+ "2. The fields under 'Service', 'Preparation' and 'Travel' should be changed accordingly.",
									"PASS", "Y");
				}
			}
			clickOnUploadsTabAndUploadTheFiles("TestData.xlsx");
			BaseClass.click(consultingAgreementPage.nextButtonOrSubmitButton);
			BaseClass.waitForObj(4000);
			PDFResultReport.addStepDetails(
					"Upload the Required document and click on [Next] button",
					"'Summary' tab should get displayed", "'Summary' tab should get displayed",
					"PASS", "Y");
			PDFResultReport
					.addStepDetails(
							"Verify the below section should get displayed under summary section \n"
									+ "-Amended From\n" + "-SELECT CR TYPE\n"
									+ "-PAYING LEGAL ENTITY\n" + "-SPEND DETAILS\n"
									+ "-ORIGINAL AGREEMENT LANGUAGE\n" + "-CR ORGANIZATION\n"
									+ "-COVERED RECEIPIENTS\n" + "-SERVICE PROVIDER\n"
									+ "-ENTER THE ACTUAL EFFECTIVE DATE\n"
									+ "-sERVICE COMPENSATION Q&A\n"
									+ "-CONSULTANT COUNTRY & SPECIALTY\n" + "-FMV QUESTIONS\n"
									+ "-FAIR MARKET VALUE (FMV) COMPENSATIOn\n" + "-Uploads\n"
									+ "-Certification\n", "'All sections should be Read-only",
							"'All sections are Read-only", "PASS", "Y");
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	/**
	 * This method is for to Select the Item from Other Actions button
	 * 
	 * @param expectedItemInOtherActions
	 */
	public static void clickOnOtherActionsAndSelectCoresspondingValue(
			String expectedItemInOtherActions)
	{
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.click(approvalPage.otherActionsButton);
		BaseClass.waitForObj(3000);
		for(WebElement itemInActions:approvalPage.itemsListInOtherActions)
		{
			if (itemInActions.getText().equalsIgnoreCase(expectedItemInOtherActions))
			{
				new Actions(BaseClass.driver).moveToElement(itemInActions).build().perform();
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				BaseClass.click(itemInActions);
				BaseClass.waitForObj(3000);
				break;
			}
		}
	}
	/**
	 * This is for to select the Delegate To Additional Approver
	 * 
	 * @param expectedItemInOtherActions
	 * @param delegateThisRequestToDropDownValue
	 * @param additonalCommentes
	 */
	public static void clickOnOtherActionsAndSelectDelegateToAnAdditionalApprover(
			String delegateSSO,String additonalComments)
	{
		try
		{
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.DELEGATE_TO_AN_ADDTIONAL_APPROVER);
			if (BaseClass.isElementPresent(approvalPage.delegateToAdditionalApprover)
					&& BaseClass.isElementPresent(approvalPage.additonalCommentesTextArea)
					&& isElementPresent(approvalPage.ceritification_OA_DelegateToAdditionalApprover))
			{
				PDFResultReport
						.addStepDetails(
								"Select the option ' Delegate to Additional Approver' from the 'Other Options' dropdown in the Work Header section.",
								"1. The [Approve] button should be changed to [Submit] button. \n"
										+ "2. Below fields should be displayed. \n"
										+ "- 'Delegate this request to' fields with [Search] button.\n"
										+ "- 'Additional Comments' sectio with 'Reason for delegating this request to another approver' mandatory open text field. \n"
										+ "-  Below certification language should be present. \n"
										+ " By submitting, I confirm that I have reviewed this interaction for complete documentation and consistency with relevant GEHC established guidance in the region(s) within my scope of responsibility.\n"
										+ " I delegate to  as an additional reviewer and certify that this individual is qualified to assess this transaction.",
								"1. The [Approve] button is changed to [Submit] button. \n"
										+ "2. Below fields are displayed. \n"
										+ "- 'Delegate this request to' fields with [Search] button.\n"
										+ "- 'Additional Comments' sectio with 'Reason for delegating this request to another approver' mandatory open text field. \n"
										+ "-  Below certification language is present. \n"
										+ " By submitting, I confirm that I have reviewed this interaction for complete documentation and consistency with relevant GEHC established guidance in the region(s) within my scope of responsibility.\n"
										+ " I delegate to  as an additional reviewer and certify that this individual is qualified to assess this transaction.",
								"PASS", "Y");
			}
			BaseClass.set(approvalPage.delegateToAdditionalApprover, delegateSSO);
			BaseClass.waitForObj(3000);
			BaseClass.click(approvalPage.searchDelegateSSO);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.radioButtonForTransactionOwner);
			BaseClass.waitForObj(3000);
			((JavascriptExecutor) BaseClass.driver).executeScript(
					"arguments[0].scrollIntoView(true);",
					initiationPage.radioButtonForTransactionOwner);
			BaseClass.waitForObj(3000);
			BaseClass.click(initiationPage.submitButtonForTransactionOwner);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"'Enter a valid SSO in 'Delegate this request to' field and click on [Search] button.",
							"'The user should be populated in 'Delegate this Request to' field.",
							"'The user should be populated in 'Delegate this Request to' field.",
							"PASS", "N");
			BaseClass.set(approvalPage.additonalCommentesTextArea, additonalComments);
			BaseClass.waitForObj(3000);
			BaseClass.click(approvalPage.submitButton);
			BaseClass.waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"Enter the Comments in the 'Additional Comments' section and click on [Submit] button.",
							"The Agreement should be submitted and confirmation message should be displayed.",
							"The Agreement should be submitted and confirmation message should be displayed.",
							"PASS", "Y");
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	/**
	 * This is for to select the Approve
	 * 
	 * @param expectedItemInOtherActions
	 * @param additonalCommentes
	 */
	public static void clickOnOtherActionsAndSelectApprove(String expectedItemInOtherActions,
			String additonalCommentes)
	{
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.APPROVE);
		BaseClass.set(approvalPage.additonalCommentesTextArea, additonalCommentes);
		BaseClass.click(approvalPage.approveButton);
		BaseClass.waitForObj(3000);
	}
	/**
	 * This is for to select the Reject from Other Actions
	 * 
	 * @param expectedItemInOtherActions
	 * @param rejectionDescriptionDropDownValue
	 * @param additonalCommentes
	 */
	public static void clickOnOtherActionsAndSelectReject(String rejectionDescriptionDropDownValue,
			String additonalCommentes)
	{
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.REJECT);
		PDFResultReport.addStepDetails("'Select 'Reject' from the Other Actions dropdown",
				"'Reject Description and 'Comments' should be Populated",
				"'Reject Description and 'Comments' are Populated", "PASS", "Y");
		BaseClass.select(approvalPage.rejectionDescriptionDropDown,
				rejectionDescriptionDropDownValue);
		BaseClass.waitForObj(3000);
		BaseClass.set(approvalPage.commentsTextFieldInReject, additonalCommentes);
		BaseClass.waitForObj(3000);
		BaseClass.click(approvalPage.submitButton);
		BaseClass.waitForObj(5000);
		PDFResultReport.addStepDetails(
				"Enter the 'Reject Description and 'Comments and click on [submit] button",
				"Workflow will be terminated with the status should be Resolved-Rejected.",
				"workflow will be terminated with the status is Resolved-Rejected.", "PASS", "Y");
	}
	/**
	 * This is for to select the Request For More Information from Other Actions
	 * 
	 * @param expectedItemInOtherActions
	 * @param rejectionDescriptionDropDownValue
	 * @param additonalCommentes
	 */
	public static void clickOnOtherActionsAndSelectRequestForMoreInformation(
			String reasonDropDownValue,String additonalCommentes)
	{
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.REQUEST_FOR_MORE_INFORMATION);
		BaseClass.waitForObj(3000);
		PDFResultReport.addStepDetails("Select 'Request more info'  from Other_Action dropdown",
				"Below fields should get populated: \n" + "'Reason' \n" + "'Requested Info'",
				"Below fields are populated: \n" + "'Reason' \n" + "'Requested Info'", "PASS", "Y");
		BaseClass.select(approvalPage.reasonDropDown, reasonDropDownValue);
		BaseClass.waitForObj(3000);
		BaseClass.set(approvalPage.requestedInfoTextField, additonalCommentes);
		BaseClass.waitForObj(3000);
		BaseClass.click(approvalPage.submitButton);
		BaseClass.waitForObj(5000);
	}
	/**
	 * This method is for to click On Other Actions And Select Cancel
	 * 
	 * @param yesOrNo
	 *            either "Yes" or "No"
	 */
	public static void clickOnOtherActionsAndSelectCancel(String yesOrNo)
	{
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.CANCEL);
		BaseClass.waitForObj(3000);
		if (yesOrNo.equalsIgnoreCase("Yes"))
		{
			BaseClass.click(approvalPage.yesRadioButtonForCancel);
		} else
		{
			BaseClass.click(approvalPage.noRadioButtonForCancel);
		}
		BaseClass.click(approvalPage.submitButtonInCancelPopUp);
		BaseClass.waitForObj(3000);
	}
	public static String searchWithASTWorkflowandVerifyStatus(String transactionNum)
	{
		OneASTHomePage oneASTHomePage = new OneASTHomePage(BaseClass.driver);
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.set(oneASTHomePage.searchTextField, transactionNum);
		BaseClass.waitForObj(3000);
		BaseClass.click(oneASTHomePage.searchButtonField);
		BaseClass.waitForObj(5000);
		BaseClass.switchFrame(approvalPage.pegaGadet0Ifr);
		String status = BaseClass.text(approvalPage.status);
		return status;
	}
	/**
	 * 
	 */
	public static void selectBothEffectiveandExpirationDateFromCalender()
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		String Date = PDFResultReport.systemDate();
		String[] date = Date.split("-");
		String currentDate = date[0];
		currentDate = String.valueOf(Integer.parseInt(currentDate) + 1);
		System.out.println("Current Date " + currentDate);
		OneASTUtil.selectDateFromCalender(initiationPage.effectiveDateCalender, 12, date[1], 10,
				date[2], currentDate);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		String year = String.valueOf(Integer.parseInt(date[2]) + 1);
		BaseClass.waitForObj(2000);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		OneASTUtil.selectDateFromCalender(initiationPage.expirationDateCalender, 12, date[1], 10,
				year, currentDate);
	}
	
	
	
	/**
	 * 
	 * @param searchOptionsDropDownValue
	 * @param serviceProviderValue
	 * @throws Exception
	 */
	public static void addServiceProvider(String searchOptionsDropDownValue,
			String serviceProviderValue) throws Exception
	{
		try {
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.searchServiceProvider);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.searchOptionsDropDown, searchOptionsDropDownValue);
			BaseClass.waitForObj(5000);
			if (initiationPage.searchOptionsDropDown.getAttribute("value").equalsIgnoreCase(
					"Last Name/ First Name/ Country"))
			{
				BaseClass.set(initiationPage.lastNameSearchfieldinAddServiceProvider,
						serviceProviderValue);
			}
			if (initiationPage.searchOptionsDropDown.getAttribute("value").equalsIgnoreCase(
					"Unique HCP Identifier/ NPI"))
			{
				BaseClass.set(initiationPage.npiNumberField, serviceProviderValue);
			}
			
			if (initiationPage.searchOptionsDropDown.getAttribute("value").equalsIgnoreCase("GE ID"))
			{
				BaseClass.waitForObj(8000);
				BaseClass.set(initiationPage.geIdTextField, serviceProviderValue);
			}
			BaseClass.waitForObj(5000);
			clickOnImage("SearchButton");
			BaseClass.waitForObj(5000);
			BaseClass.click(initiationPage.selectRadioButtoninAddServiceProvider);
			BaseClass.waitForObj(5000);
			BaseClass.click(initiationPage.submitButtonForTransactionOwner);
			BaseClass.waitForObj(5000);
			isElementPresent(initiationPage.cRServiceProvideLabel);
			System.out.println(BaseClass.driver.findElement(initiationPage.cRServiceProvideLabel)
					.getText());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void enterValuesInBusinessInformationTab(String poleDropDownValue,
			String regionDropDownValue,String payingCountryDropDownValue,
			String businessDropDownValue,String modalityDropDownValue,
			String legalEntityDropDownVallue,String products,String productIndicatpor,
			String areYouSubmittingTheRequestOnBehalfOthers,
			String changeToOthercountryDropDownValue,String spendCategoryDropDownValue,
			String spendSubTypeDropDownValue)
	{
		try
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.select(initiationPage.poleDropDown, poleDropDownValue);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.regionDropDown, regionDropDownValue);
			BaseClass.waitForObj(10000);
			BaseClass.select(initiationPage.payingCountryDropDown, payingCountryDropDownValue);
			BaseClass.waitForObj(5000);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.businessDropDown, businessDropDownValue);
			BaseClass.waitForObj(5000);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.modalityDropDown, modalityDropDownValue);
			BaseClass.waitForObj(5000);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.legalEntityDropDown, legalEntityDropDownVallue);
			BaseClass.waitForObj(5000);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			if (regionDropDownValue.equalsIgnoreCase("United States"))
			{
				BaseClass.select(initiationPage.productDropDown, products);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.productIndicatorDropDown, productIndicatpor);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			}
			if (areYouSubmittingTheRequestOnBehalfOthers.equalsIgnoreCase("Yes"))
			{
				BaseClass.click(initiationPage.onBehalfOfOtherYesRadioButton);
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.transactionOwnerSerachBox,
						ExcelReport.testData.get("transactionsOwner"));
				BaseClass.waitForObj(3000);
				((JavascriptExecutor) BaseClass.driver).executeScript(
						"arguments[0].scrollIntoView(true);",
						initiationPage.searchButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.searchButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.radioButtonForTransactionOwner);
				BaseClass.waitForObj(3000);
				((JavascriptExecutor) BaseClass.driver).executeScript(
						"arguments[0].scrollIntoView(true);",
						initiationPage.radioButtonForTransactionOwner);
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			} else
			{
				BaseClass.click(initiationPage.onBehalfOfOtherNoRadioButton);
				BaseClass.waitForObj(5000);
			}
			if (!changeToOthercountryDropDownValue.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.changeToOthercountryDropDown,
						changeToOthercountryDropDownValue);
				BaseClass.waitForObj(5000);
			}
			BaseClass.select(initiationPage.spendCategoryDropDown, spendCategoryDropDownValue);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			if (!spendSubTypeDropDownValue.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.spendSubTypeDropDown, spendSubTypeDropDownValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(3000);
			}
			new Actions(BaseClass.driver).moveToElement(initiationPage.spendSubTypeDropDown)
					.build().perform();
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	public static void clickOnImage(String imageName) throws Exception
	{
		try
		{
			Pattern fileName = new Pattern(System.getProperty("user.dir") + "\\Resources\\"
					+ imageName + ".PNG");
			Thread.sleep(1000);
			Screen screen = new Screen();
			Thread.sleep(1000);
			screen.click(fileName);
			Thread.sleep(1000);
		} catch(Exception e)
		{
			
			e.printStackTrace();
		}
	}
	public static void loginandclickonOneASTRadioButton(String userName)
    {
          LogInPage loginPage = new LogInPage(BaseClass.driver);
          BaseClass.launchApplication(ExcelReport.testData.get("url"));
          LoginUtils.loginIntoApplication(loginPage, userName, "password");
          BaseClass.waitForObj(5000);
          if (BaseClass.getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
          {
          PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
                              BaseClass.driver, PeagDesignerStudioHomePage.LAUNCH,
                              PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
                 tabs = new ArrayList<String>(BaseClass.driver.getWindowHandles());
                 BaseClass.driver.switchTo().window(tabs.get(1));
              CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
                 PDFResultReport
                              .addStepDetails(
                                           "Login to the Appliaction as Super User entering the valid credentials and \n"
                                                        + "Click on login button present in the page\n"
                                                        + "Login credentials:Url : https://stg-ast.gehealthcare.com/prweb/PRServlet/\n"
                                                        + "username : <Super user 1>\n" + "password: <pswd 1>",
                                           "Login page with title 'Aggregate Spend Management' should get displayed.",
                                           "Login page with title 'Aggregate Spend Management' get displayed.",
                                           "PASS", "N");
          }
          AggregateSpendManagementPage aggregateSpendManagementPage = new AggregateSpendManagementPage(
                       BaseClass.driver);
    if(isElementPresent(aggregateSpendManagementPage.oneAST_radioButton)){
                 
    BaseClass.click(aggregateSpendManagementPage.oneASTRadioButton);
        CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
          BaseClass.waitForObj(3000);
         BaseClass.click(aggregateSpendManagementPage.submitButton);
        CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
          BaseClass.waitForObj(5000);
          }
    }

	public static void activateAgreement(String fileName,String status)
	{
		try
		{
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.click(approvalPage.approvalFlowLink);
			BaseClass.waitForObj(3000);
			if (status.equalsIgnoreCase("Pending-Activation"))
			{
				System.out.println("Status is dispalyed as " + status);
				BaseClass.click(initiationPage.uploadButtonList.get(0));
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.subject_Upload, "test");
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.attachmentButton);
				BaseClass.waitForObj(3000);
				CommonUtils.uploadFileUsingRobot(fileName);
				BaseClass.click(initiationPage.okButtonInModalPopUp);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(3000);
				BaseClass.click(consultingAgreementPage.submitButton);
				BaseClass.waitForObj(5000);
				String msg = BaseClass.text(consultingAgreementPage.messageActivated);
				if (msg.contains("Activated"))
				{
					System.out.println(msg);
				}
			}
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		} catch(AWTException e)
		{
			
			e.printStackTrace();
		}
	}
	public static void requestOnBehalfofOthers(String areYouSubmittingTheRequestOnBehalfOthers)
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		if (areYouSubmittingTheRequestOnBehalfOthers.equalsIgnoreCase("Yes"))
		{
			BaseClass.click(initiationPage.onBehalfOfOtherYesRadioButton);
			BaseClass.waitForObj(5000);
			BaseClass.set(initiationPage.transactionOwnerSerachBox,
					ExcelReport.testData.get("superUserUserName"));
			BaseClass.waitForObj(3000);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click()",initiationPage.searchButtonForTransactionOwner);
					//BaseClass.click(initiationPage.searchButtonForTransactionOwner);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.radioButtonForTransactionOwner);
			BaseClass.waitForObj(3000);
			((JavascriptExecutor) BaseClass.driver).executeScript(
					"arguments[0].scrollIntoView(true);",
					initiationPage.radioButtonForTransactionOwner);
			BaseClass.waitForObj(3000);
			BaseClass.click(initiationPage.submitButtonForTransactionOwner);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
		} else
		{
			BaseClass.click(initiationPage.onBehalfOfOtherNoRadioButton);
			BaseClass.waitForObj(5000);
		}
	}
	@SuppressWarnings("unused")
	public static void uploadDocumentForIPPCOEApproval(String fileName)
	{
		try
		{
			ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
					BaseClass.driver);
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.click(approvalPage.uploadIPPCOEApproval);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(3000);
			BaseClass.set(initiationPage.subject_Upload, "test");
			BaseClass.waitForObj(3000);
			BaseClass.click(initiationPage.attachmentButton);
			BaseClass.waitForObj(3000);
			CommonUtils.uploadFileUsingRobot(fileName);
			BaseClass.click(initiationPage.okButtonInModalPopUp);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(3000);
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		} catch(AWTException e)
		{
			
			e.printStackTrace();
		}
	}
	/**
	 * This is for to select the Approve with Exception from Other Actions
	 * 
	 * @param expectedItemInOtherActions
	 * @param rejectionDescriptionDropDownValue
	 * @param additonalCommentes
	 */
	public static void clickOnOtherActionsAndSelectApprovewithException(
			String exceptionDescriptionDropDownValue,String additonalComments)
	{
		try {
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.APPROVE_WITH_AN_EXCEPTION);
			PDFResultReport
					.addStepDetails(
							"Select the option ' Approve with Exception' from the 'Other Options' dropdown in the Work Header section.",
							"1. The [Approve] button should be changed to [Submit] button. \n"
									+ "2. Below fields should be displayed. - 'Describe Exception Required' mandatory dropdown.- 'Is there Evidence of Pre-commitment?' mandatory field with 'Yes' or 'No' radio button. \n"
									+ "- 'Additional Comments' section with 'Additional Comments' mandatory open text field. \n"
									+ "- Below certification language should be present. \n"
									+ "By selecting the Ã¢â‚¬Å“Complete review button within this request, I confirm that I have reviewed this interaction for complete documentation and consistency with relevant GEHC established guidance.",
							"1. The [Approve] button is changed to [Submit] button. \n"
									+ "2. Below fields are displayed. - 'Describe Exception Required' mandatory dropdown.- 'Is there Evidence of Pre-commitment?' mandatory field with 'Yes' or 'No' radio button. \n"
									+ "- 'Additional Comments' section with 'Additional Comments' mandatory open text field. \n"
									+ "- Below certification language should be present. \n"
									+ "By selecting the Ã¢â‚¬Å“Complete review button within this request, I confirm that I have reviewed this interaction for complete documentation and consistency with relevant GEHC established guidance.",
							"PASS", "Y");
			BaseClass.select(approvalPage.rejectionDescriptionDropDown,
					exceptionDescriptionDropDownValue);
			BaseClass.waitForObj(3000);
			BaseClass.click(approvalPage.OA_EvidencePreCommitmentYes);
			BaseClass.waitForObj(3000);
			PDFResultReport
					.addStepDetails(
							"'Select an option in 'Describe Exception Required' dropdown and select 'Yes' for the field 'Is there Evidence of Pre-commitment?'",
							"'A mandatory dropdown 'What type of Evidence for Pre-Commitment?' should be populated.",
							"'A mandatory dropdown 'What type of Evidence for Pre-Commitment?' is populated.",
							"PASS", "Y");
			BaseClass.select(approvalPage.OA_TypeOfPreCommit, "Contract signed before approval");
			BaseClass.set(approvalPage.additonalCommentesTextArea, additonalComments);
			BaseClass.waitForObj(3000);
			BaseClass.click(approvalPage.submitButton);
			BaseClass.waitForObj(5000);
			PDFResultReport
					.addStepDetails(
							"1. Select an option from the ' What type of Evidence for Pre-Commitment?' dropdown \n"
									+ "2. Enter comments in 'Additional Comments' section and click on [Submit] button.",
							"The Agreement should be Approved by the IPPCOE and below message should be displayed. \n"
									+ "Agreement A-xxx has been sent for Approval. Any change in status will be communicated via email. \n"
									+ "Thank you",
							"The Agreement should be Approved by the IPPCOE and below message should be displayed. \n"
									+ "Agreement A-xxx has been sent for Approval. Any change in status will be communicated via email. \n"
									+ "Thank you", "PASS", "Y");
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * This is for to select the Compliance Escalation
	 * 
	 * @param expectedItemInOtherActions
	 * @param delegateThisRequestToDropDownValue
	 * @param additonalCommentes
	 */
	public static String clickOnOtherActionsAndSelectComplianceEscalation(String escalateRequestTo,
			String escalationReason,String transactionNum)
	{
		String[] escalationSSO = null;
		try
		{
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			clickOnOtherActionsAndSelectCoresspondingValue(approvalPage.COMPLIANCE_ESCALATION);
			if (BaseClass.isElementPresent(approvalPage.OA_EscalatorName)
					&& BaseClass.isElementPresent(approvalPage.OA_EscalateReason)
					&& BaseClass.isElementPresent(approvalPage.complianceEscalationCertification))
			{
				PDFResultReport
						.addStepDetails(
								"Select the option 'Compliance Escalation' from the 'Other Options' dropdown in the Work Header section.",
								"1. The [Approve] button should be changed to [Submit] button. \n"
										+ "2. Below fields should be displayed. \n"
										+ "-'Escalate Request To' mandatory dropdown.\n"
										+ "- 'Describe Escalation Reason' mandatory dropdown \n"
										+ "- 'Escalation Comments' non mandatory comments section \n"
										+ "-  Below certification language should be present. \n"
										+ "By selecting the Ã¢â‚¬Å“Submit button within this request, I confirm that I have reviewed this interaction for complete documentation and consistency with relevant GEHC established guidance, and highlighted area(s) that need(s) Compliance escalation review",
								"1. The [Approve] button is changed to [Submit] button. \n"
										+ "2. Below fields are displayed. \n"
										+ "-'Escalate Request To' mandatory dropdown.\n"
										+ "- 'Describe Escalation Reason' mandatory dropdown \n"
										+ "- 'Escalation Comments' non mandatory comments section \n"
										+ "-  Below certification language is present. \n"
										+ "By selecting the Ã¢â‚¬Å“Submit button within this request, I confirm that I have reviewed this interaction for complete documentation and consistency with relevant GEHC established guidance, and highlighted area(s) that need(s) Compliance escalation review",
								"PASS", "Y");
			}
			BaseClass.select(approvalPage.OA_EscalatorName, escalateRequestTo);
			BaseClass.waitForObj(3000);
			BaseClass.select(approvalPage.OA_EscalateReason, escalationReason);
			BaseClass.set(approvalPage.complianceEscalationComments, "Escalate this workflow");
			BaseClass.waitForObj(3000);
			String escalationName = new Select(BaseClass.driver.findElement(By
					.id("OA_EscalatorName"))).getFirstSelectedOption().getText();
			escalationSSO = escalationName.split("-");
			BaseClass.click(approvalPage.submitButton);
			BaseClass.waitForObj(5000);
			if(transactionNum.startsWith("A")){
			PDFResultReport
					.addStepDetails(
							"'1. Select a Compliance escalation reviewer from the 'Escalate Request To' dropdown. \n"
									+ "2. Select an option from 'Describe Escalation Reason' dropdown.\n"
									+ "3. Enter the comments in the 'Escalation Comments' section and click on [Submit] button.",
							"'The Agreement should be submitted successfully and below confirmation message should be displayed.\n"
									+ "Agreement A-xxx has been sent for Approval. Any change in status will be communicated via email.\n"
									+ "Thank you",
							"'The Agreement is submitted successfully and below confirmation message is displayed.\n"
									+ "Agreement A-xxx has been sent for Approval. Any change in status will be communicated via email.\n"
									+ "Thank you", "PASS", "Y");
			}else if(transactionNum.startsWith("E"))
			{
				
				PDFResultReport
				.addStepDetails(
						"'1. Select a Compliance escalation reviewer from the 'Escalate Request To' dropdown. \n"
								+ "2. Select an option from 'Describe Escalation Reason' dropdown.\n"
								+ "3. Enter the comments in the 'Escalation Comments' section and click on [Submit] button.",
						"'1. The Event should be submitted successfully and below message should be displayed.\n"
								+ "Event E-XXXX has been submitted for Approval. Any change in status will be communicated via email.\n"
								+ "Thank you"
								+ "2. The Agreement should be pending with Compliance Escalated of the Agreement.",
						"'The Agreement is submitted successfully and below confirmation message is displayed.\n"
								+ "Agreement A-xxx has been sent for Approval. Any change in status will be communicated via email.\n"
								+ "Thank you"
								+ "2. The Agreement is pending with Compliance Escalated of the Agreement.", "PASS", "Y");
			}
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
		return escalationSSO[1];
	}
	/**
	 * This is for to select the Compliance Escalation
	 * 
	 * @param expectedItemInOtherActions
	 * @param delegateThisRequestToDropDownValue
	 * @param additonalCommentes
	 */
	public static void clickOnOtherActionsAndSendBackToIPPCOE(String reason,String requestedInfo,String transactionNum)
	{
		try
		{
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.SEND_BACK_TO_IPPCOE);
			BaseClass.select(approvalPage.SendBackToIPPCOE_Reason, reason);
			BaseClass.waitForObj(3000);
			BaseClass.set(approvalPage.SendBackToIPPCOE_RequestedInfoTextArea, requestedInfo);
			BaseClass.waitForObj(3000);
			BaseClass.click(approvalPage.submitButton);
			BaseClass.waitForObj(5000);
			if(transactionNum.startsWith("A")){
			PDFResultReport
					.addStepDetails(
							"'1. Select an Option in 'Reason' dropdown and enter the required comments in 'Requested Info' field. \n"
									+ "2. Click on [Submit] button.",
							"'The Agreement should be submitted successfully and below confirmation message should be displayed. \n"
									+ "Agreement A-xxx has been sent for Approval. Any change in status will be communicated via email.\n"
									+ "Thank you",
							"'The Agreement is submitted successfully and below confirmation message is displayed.\n"
									+ "Agreement A-xxx has been sent for Approval. Any change in status will be communicated via email.\n"
									+ "Thank you", "PASS", "Y");
			}else if(transactionNum.startsWith("E")){
				
				PDFResultReport
				.addStepDetails(
						"'1. Select an Option in 'Reason' dropdown and enter the required comments in 'Requested Info' field. \n"
								+ "2. Click on [Submit] button.",
						"'The Event should be submitted successfully and below confirmation message should be displayed. \n"
								+ "Event E-xxx has been sent for Approval. Any change in status will be communicated via email.\n"
								+ "Thank you",
						"'The Event is submitted successfully and below confirmation message is displayed.\n"
								+ "Event E-xxx has been sent for Approval. Any change in status will be communicated via email.\n"
								+ "Thank you", "PASS", "Y");
				
				
			}
		} catch(AutomationException e)
		{
			
			e.printStackTrace();
		}
	}
	public static void loginIntoApplication(LogInPage loginPage,String username,String password)// 1
	{
		BaseClass.verifyElementIsEnabled(loginPage.userId, true);
		System.out.println(username);
		BaseClass.set(loginPage.userId, username);
		try
		{
			BaseClass.set(loginPage.password, ExcelReport.testData.get(password));
		} catch(Exception e)
		{
			e.printStackTrace();
		}
		loginPage.clickOnLogin();
		BaseClass.waitForObj(5000);
	}
	public static void selectConsultingEventType(String eventType)
	{
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		if (eventType.contains("Master"))
		{
			BaseClass.click(initiationPage.masterAgreement);
			BaseClass.waitForObj(3000);
		} else
		{
			BaseClass.click(initiationPage.singleEventAgreement);
		}
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
	}
	public static void reassignandSubmitAmendWorkflow() throws Exception
	{
		ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
				BaseClass.driver);
		InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		// BaseClass.switchToDefaultFrame();
		clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.REASSIGN);
		BaseClass.waitForObj(3000);
		PDFResultReport.addStepDetails(
				"Verify  Reassign option from the Other Actions dropdown and click on Reassign",
				"Reassign this request To should get displayed",
				"Reassign this request To get displayed", "PASS", "Y");
		BaseClass.set(approvalPage.reAssignSSO, "503031811");
		BaseClass.waitForObj(3000);
		BaseClass.click(approvalPage.searchButtonForReassign);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(8000);
		((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
				initiationPage.radioButtonForTransactionOwner);
		BaseClass.waitForObj(3000);
		PDFResultReport.addStepDetails(
				"Enter the SSO ID in Reassign To field and click on search button",
				"Search results should get displayed", "Search results should get displayed",
				"PASS", "Y");
		BaseClass.click(initiationPage.submitButtonForTransactionOwner);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(8000);
		BaseClass.set(approvalPage.reasonForReassigningthisItemtoanotherUser,
				"Assigning to some other user");
		BaseClass.click(initiationPage.nextButton);
		PDFResultReport.addStepDetails("Click on Ok button",
				"WF get transfer to selected  super user",
				"WF get transfer to selected  super user", "PASS", "Y");
		isElementPresent(approvalPage.confirmationMsg);
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(3000);
		AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
				BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
				AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
		BaseClass.waitForObj(3000);
		LogInPage loginPage = new LogInPage(BaseClass.driver);
		BaseClass.launchApplication(ExcelReport.testData.get("url"));
		LoginUtils.loginIntoApplication(loginPage, "TransactionOwnerUserName", "password");
		BaseClass.waitForObj(5000);
		AggregateSpendManagementPage aggregateSpendManagementPage = new AggregateSpendManagementPage(
				BaseClass.driver);
		BaseClass.click(aggregateSpendManagementPage.oneASTRadioButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(3000);
		BaseClass.click(aggregateSpendManagementPage.submitButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(15000);
		OneASTHomePage oneASTHomePage = new OneASTHomePage(BaseClass.driver);
		BaseClass.set(oneASTHomePage.searchTextField, agreementNumber);
		BaseClass.waitForObj(3000);
		BaseClass.click(oneASTHomePage.searchButtonField);
		BaseClass.waitForObj(8000);
		String status = null;
		BaseClass.switchFrame(approvalPage.pegaGadet0Ifr);
		BaseClass.waitForObj(3000);
		for(int i = 0;i < approvalPage.processFlowLinks.size();i++)
		{
			System.out.println(approvalPage.processFlowLinks.get(i).getText());
			if (approvalPage.processFlowLinks.get(i).getText().contains("OA"))
			{
				approvalPage.processFlowLinks.get(i).click();
				BaseClass.waitForObj(5000);
				status = BaseClass.text(approvalPage.status);
				break;
			}
		}
		if (status.equalsIgnoreCase("Pending-AgreementInitiation"))
		{
			PDFResultReport
					.addStepDetails(
							"Login with the Reassigned Transaction owner for application and open the workflow ",
							"Status should be Updated to Pending-AgreementIntiation",
							"Status is Updated to Pending-AgreementIntiation", "PASS", "Y");
		}
		BaseClass.click(consultingAgreementPage.submitButton);
		BaseClass.waitForObj(4000);
		isElementPresent(approvalPage.confirmationMsg);
		PDFResultReport
				.addStepDetails(
						"Click on [Submit] button",
						"'Wf should be assigned for Transaction Owner Approval and below Confirmation message should get displayed \n"
								+ "'Agreement A-XXXX has been sent for Approval. Any change in status will be communicated via email. \n"
								+ "Thank you' \n",
						"'Agreement"
								+ agreementNumber
								+ " has been sent for Approval. Any change in status will be communicated via email. \n"
								+ "Thank you' \n", "PASS", "Y");
		BaseClass.switchToDefaultFrame();
		BaseClass.click(approvalPage.close);
	}
	/**
	 * 
	 */
	public static void amendAgreement_requestForInfo()
	{
		agreementNumber = "A-13768";
		LogInPage loginPage = new LogInPage(BaseClass.driver);
		BaseClass.launchApplication(ExcelReport.testData.get("url"));
		LoginUtils.loginIntoApplication(loginPage, "TransactionOwnerUserName", "password");
		BaseClass.waitForObj(5000);
		AggregateSpendManagementPage aggregateSpendManagementPage = new AggregateSpendManagementPage(
				BaseClass.driver);
		BaseClass.click(aggregateSpendManagementPage.oneASTRadioButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(3000);
		BaseClass.click(aggregateSpendManagementPage.submitButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(15000);
		OneASTHomePage oneASTHomePage = new OneASTHomePage(BaseClass.driver);
		ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
		BaseClass.set(oneASTHomePage.searchTextField, agreementNumber);
		BaseClass.waitForObj(3000);
		BaseClass.click(oneASTHomePage.searchButtonField);
		BaseClass.waitForObj(8000);
		String status = null;
		BaseClass.switchFrame(approvalPage.pegaGadet0Ifr);
		BaseClass.waitForObj(3000);
		for(int i = 0;i < approvalPage.processFlowLinks.size();i++)
		{
			System.out.println(approvalPage.processFlowLinks.get(i).getText());
			if (approvalPage.processFlowLinks.get(i).getText().contains("OA"))
			{
				approvalPage.processFlowLinks.get(i).click();
				BaseClass.waitForObj(5000);
				status = BaseClass.text(approvalPage.status);
				break;
			}
		}
		if (status.equalsIgnoreCase("Pending-Approval"))
		{
			PDFResultReport.addStepDetails("Open the workflow ",
					"Status should be Updated to Pending-Approval ",
					"Status is Updated to Pending-Approval ", "PASS", "Y");
		}
		OneASTUtil.clickOnOtherActionsAndSelectRequestForMoreInformation("Clarification Required",
				"Test Request for Infor");
		PDFResultReport
				.addStepDetails(
						"Enter the below fields 'Reason' and 'Requested info'  and click on [Submit] button",
						"1. The Agreement should be submitted successfully and below message should be displayed. \n"
								+ "Agreement A-XXXX has been submitted for Approval. Any change in status will be communicated via email. \n"
								+ "Thank you" + "2. The Agreement should be sent to Intiation",
						"1. The Agreement should be submitted successfully and below message should be displayed. \n"
								+ "Agreement "
								+ agreementNumber
								+ " has been submitted for Approval. Any change in status will be communicated via email. \n"
								+ "Thank you" + "2. The Agreement should be sent to Intiation",
						"PASS", "Y");
		isElementPresent(approvalPage.confirmationMsg);
		BaseClass.switchToDefaultFrame();
		BaseClass.set(oneASTHomePage.searchTextField, agreementNumber);
		BaseClass.waitForObj(3000);
		BaseClass.click(oneASTHomePage.searchButtonField);
		BaseClass.waitForObj(8000);
		BaseClass.switchFrame(approvalPage.pegaGadet0Ifr);
		BaseClass.waitForObj(3000);
		for(int i = 0;i < approvalPage.processFlowLinks.size();i++)
		{
			System.out.println(approvalPage.processFlowLinks.get(i).getText());
			if (approvalPage.processFlowLinks.get(i).getText().contains("OA"))
			{
				approvalPage.processFlowLinks.get(i).click();
				BaseClass.waitForObj(5000);
				status = BaseClass.text(approvalPage.status);
				break;
			}
		}
		initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		BaseClass.select(initiationPage.spendCategoryDropDown, "Product Training");
		BaseClass.waitForObj(8000);
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
		BaseClass.click(initiationPage.nextButton);
		BaseClass.waitForObj(5000);
	}
	public static void selectGEIdAndSearchForGEId() throws Exception
	{
		initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.select(initiationPage.searchOptionsDropDown, "GE ID");
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(5000);
		setValueUsingSikuli("GEIDTextArea", ExcelReport.testData.get("geId"));
		/*new Actions(BaseClass.driver).moveToElement(initiationPage.geIdTextField).sendKeys(
				ExcelReport.testData.get("geId"));*/
		BaseClass.waitForObj(5000);
		OneASTUtil.clickOnImage("SearchButton");
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(5000);
	}
	public static void clickOnRadioButtonForSearchResult()
	{
		initiationPage = new InitiationPage(BaseClass.driver);
		boolean flag = isElementPresent(By.cssSelector("input[type='radio']"));
		System.out.println(flag);
		((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].scrollIntoView(true);",
				initiationPage.radioButtonForSearchResult);
		BaseClass.waitForObj(3000);
		((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
				initiationPage.radioButtonForSearchResult);
		BaseClass.waitForObj(5000);
		BaseClass.click(initiationPage.okButtonInModalPopUp);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(5000);
	}
	
	public static void clickOnRadioButtonForAddSelectedCR()
	{
		initiationPage = new InitiationPage(BaseClass.driver);
		boolean flag = isElementPresent(By.cssSelector("input[type='radio']"));
		System.out.println(flag);
		/*((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].scrollIntoView(true);",
				initiationPage.radioButtonForSearchResult);*/
		BaseClass.waitForObj(5000);
		((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
				consultingAgreementPage.buttonAddSelectedCR);
		BaseClass.waitForObj(5000);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(5000);
	}
	public static void enterEventInforamtionAndVenueInformation(String agreementTitle,
			String eventJustification,String venueTypeDropDownValue,String venueNameFieldValue,
			String venueCountryDropDownValue,String venueCityValue)
	{
		initiationPage = new InitiationPage(BaseClass.driver);
		BaseClass.set(initiationPage.agreementTitleTextField, agreementTitle);
		BaseClass.waitForObj(5000);
		OneASTUtil.selectBothEffectiveandExpirationDateFromCalender();
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.set(initiationPage.eventJustificationField, eventJustification);
		BaseClass.select(initiationPage.venueTypeDropDown, venueTypeDropDownValue);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.set(initiationPage.venueNameField, venueNameFieldValue);
		BaseClass.select(initiationPage.venueCountryDropDown, venueCountryDropDownValue);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.set(initiationPage.venueCityField, venueCityValue);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
	}
	public static void enterValuesInTheAgreementDetailsTab(int length,
			String businessJustificationForEngagement,String gehcProductsOrServicesIncluded,
			String consultantQualificationSummary,String paymentDetails,String serviceToBeProvided,
			boolean plusSymbolToAddServiceToBeProvided)
	{
		/*String servicesToBeProvided="$PpyWorkPage$pContractedIndivs$l%d$pOA_ContractInfo$l%d$pServiceProvided";
		System.out.println(String.format(String.format(servicesToBeProvided, 1,1)));*/
		
		try
		{
			
			
			initiationPage = new InitiationPage(BaseClass.driver);
			Boolean serviceCompensationYesradio = isElementPresent(initiationPage.validatewillServiceCompensationBePaidYesRadioButton);
				if(serviceCompensationYesradio)
				{
					BaseClass.click(initiationPage.willServiceCompensationBePaidYesRadioButton);
				}
				else
				{
					BaseClass.click(initiationPage.willServiceCompensationBePaidYesRadioButton_Org);
							
				}
			
			for(int i = 0;i < length;i++)
			{
				BaseClass.set(
						initiationPage.businessJustificationForEngagementTextAreasList.get(i),
						businessJustificationForEngagement);
				BaseClass.set(initiationPage.gehcProductsOrServicesIncludedTextAreasList.get(i),
						gehcProductsOrServicesIncluded);
				BaseClass.set(initiationPage.consultantQualificationSummaryTextAreasList.get(i),
						consultantQualificationSummary);
				BaseClass.set(initiationPage.paymentDetailsTextAreasList.get(i), paymentDetails);
				BaseClass.set(initiationPage.serviceToBeProvidedTextAreasList.get(i),
						serviceToBeProvided);
				BaseClass.waitForObj(8000);
				if (plusSymbolToAddServiceToBeProvided)
				{
					List<WebElement> serviceToBeProvidedTextArea = BaseClass.driver.findElements(By
							.xpath("//textarea[starts-with(@id,'ServiceProvided')]"));
					System.out.println(serviceToBeProvidedTextArea.size());
					if (serviceToBeProvidedTextArea.size() > 0)
					{
						BaseClass.set(serviceToBeProvidedTextArea.get(1), "SERVICE TO BE PROVIDED");
						BaseClass.waitForObj(3000);
						PDFResultReport
								.addStepDetails(
										"1)Fields that should display under Supporting Information tab\n"
												+ "	a) Business Justification for   Engagement *\n"
												+ "	b)GEHC Products/Services Included\n"
												+ "	c)Consultant Qualification Summary *\n"
												+ "	d) SERVICE TO BE PROVIDED *\n"
												+ "	e)Payment Details*\n"
												+ "2)Enter all the mandatory information in the supporting information tab and click [Next]",
										"User should be able to enter mutiple SERVICE TO BE PROVIDED by clicking on + symbol.\n"
												+ "Screen must be navigated to Agreement details tab",
										"User is able to enter mutiple SERVICE TO BE PROVIDED by clicking on + symbol.\n"
												+ "Screen is navigated to Agreement details tab", "PASS",
										"Y");
					}
				}
					
				
			}
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	public static void enterValuesInTheAgreementDetailsTabDoubt(int length,
			String businessJustificationForEngagement,String gehcProductsOrServicesIncluded,
			String consultantQualificationSummary,String paymentDetails,String serviceToBeProvided,
			boolean plusSymbolToAddServiceToBeProvided)
	{
		String servicesToBeProvided="$PpyWorkPage$pContractedIndivs$l%d$pOA_ContractInfo$l%d$pServiceProvided";
		System.out.println(String.format(String.format(servicesToBeProvided, 1,1)));
		try
		{
			
			
			initiationPage = new InitiationPage(BaseClass.driver);
			for(int i = 0;i < length;i++)
			{
				BaseClass.set(
						initiationPage.businessJustificationForEngagementTextAreasList.get(i),
						businessJustificationForEngagement);
				BaseClass.set(initiationPage.gehcProductsOrServicesIncludedTextAreasList.get(i),
						gehcProductsOrServicesIncluded);
				BaseClass.set(initiationPage.consultantQualificationSummaryTextAreasList.get(i),
						consultantQualificationSummary);
				BaseClass.set(initiationPage.paymentDetailsTextAreasList.get(i), paymentDetails);
				BaseClass.set(initiationPage.serviceToBeProvidedTextAreasList.get(i),
						serviceToBeProvided);
				BaseClass.waitForObj(8000);
				if (plusSymbolToAddServiceToBeProvided)
				{
					List<WebElement> serviceToBeProvidedTextArea = null;
					if (i == 0)
					{
						((JavascriptExecutor) BaseClass.driver).executeScript(
								"arguments[0].click();",
								initiationPage.plusSymbolToAddServiceToBeProvided.get(i));
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(8000);
						serviceToBeProvidedTextArea = BaseClass.driver.findElements(By
								.xpath("//textarea[starts-with(@id,'ServiceProvided')]"));
						System.out.println(serviceToBeProvidedTextArea.size());
						new Actions(BaseClass.driver)
								.moveToElement(
										initiationPage.businessJustificationForEngagementTextAreasList
												.get(0)).build().perform();
						BaseClass.set(BaseClass.getElement(BaseClass.driver,
								BaseClass.LOCATOR_NAME, String.format(servicesToBeProvided, 1,1)),
								serviceToBeProvided);
						BaseClass.waitForObj(3000);
						BaseClass.set(BaseClass.getElement(BaseClass.driver,
								BaseClass.LOCATOR_NAME, String.format(servicesToBeProvided, 1,2)),
								serviceToBeProvided);
						BaseClass.waitForObj(3000);
					}
					if (i == 1)
					{
						BaseClass.set(BaseClass.getElement(BaseClass.driver,
								BaseClass.LOCATOR_NAME, String.format(servicesToBeProvided, 2,1)),
								serviceToBeProvided);
						BaseClass.waitForObj(3000);
					}
				}
			}
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	
	
	
	public static boolean verifyFieldsInCRIndividualTab()
	{
		initiationPage = new InitiationPage(BaseClass.driver);
		boolean searchOptions = BaseClass.isElementPresent(initiationPage.searchOptionsDropDown);
		boolean firstNameAddNewIndividual = BaseClass
				.isElementPresent(initiationPage.firstNameAddNewIndividual);
		boolean countryAddNewIndividual = BaseClass
				.isElementPresent(initiationPage.payingCountryDropDown);
		boolean searchButtonField = BaseClass
				.isElementPresent(initiationPage.searchButtonInCRIndividualPage);
		boolean addNewIndividualButton = BaseClass
				.isElementPresent(initiationPage.addNewIndividualButtonInCRIndividual);
		boolean value = searchOptions && addNewIndividualButton && searchButtonField
				&& countryAddNewIndividual && firstNameAddNewIndividual;
		return value;
	}
	public static void enterValuesInBudgetDetailsTab(
			String ifSSPPOPaymentMethodInvolvedDropDownValue,String paymentMethodDropDownValue,
			String expenseDropDownValue,String vendorNameValue,String amountValue,
			String currencyCodeDropDownValue,String costCenterValue,String descriptionValue,
			String isThisVendoreCreatedInSSP,String city,String gslValue,
			String countryDropDownValue,String stateValue)
	{
		try
		{
			initiationPage = new InitiationPage(BaseClass.driver);
			if (ifSSPPOPaymentMethodInvolvedDropDownValue.equalsIgnoreCase("Yes"))
			{
				BaseClass.select(initiationPage.ifSSPPOPaymentMethodInvolvedDropDown,
						ifSSPPOPaymentMethodInvolvedDropDownValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
				if (!paymentMethodDropDownValue.equalsIgnoreCase("SSP PO"))
				{
					BaseClass.set(initiationPage.vendorName, vendorNameValue);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				}
				BaseClass.select(initiationPage.paymentMethodDropDown, paymentMethodDropDownValue);
				
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
				/*BaseClass.select(initiationPage.expenseDropDown, expenseDropDownValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
				BaseClass.set(initiationPage.amount, amountValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
				if (initiationPage.currencyCodeDropDown.getTagName().trim().contains("select"))
				{
					BaseClass
							.select(initiationPage.currencyCodeDropDown, currencyCodeDropDownValue);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				} else
				{
					BaseClass.set(initiationPage.currencyCodeDropDown, currencyCodeDropDownValue);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				}*/
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.set(initiationPage.expenseDropDown, costCenterValue);
				BaseClass.waitForObj(8000);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.set(initiationPage.description, descriptionValue);
				BaseClass.waitForObj(8000);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.select(initiationPage.ifSSPPOPaymentMethodInvolvedDropDown,
						"Select...");
				BaseClass.select(initiationPage.ifSSPPOPaymentMethodInvolvedDropDown,
						ifSSPPOPaymentMethodInvolvedDropDownValue);
				BaseClass.select(initiationPage.ifSSPPOPaymentMethodInvolvedDropDown,
						"Select...");
				BaseClass.select(initiationPage.ifSSPPOPaymentMethodInvolvedDropDown,
						ifSSPPOPaymentMethodInvolvedDropDownValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
				boolean isTheVendorCreatedInSSPYESRadioButton = isElementPresent(By
						.id("SSPCreatedYes"));
				if (isTheVendorCreatedInSSPYESRadioButton)
				{
					if (isThisVendoreCreatedInSSP.equalsIgnoreCase("Yes"))
					{
						BaseClass.click(initiationPage.isTheVendorCreatedInSSPYESRadioButton);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.click(initiationPage.vendoreSearchButton);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						vendorSearch(city, gslValue, vendorNameValue, countryDropDownValue,
								stateValue);
					} else
					{
						
					}
				}
			}			
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			enterValueInSSPDetailsPage();
			clickOnGetOUAndSelectGETOUDropDownValue();
			vendorSearch("", "", ExcelReport.testData.get("vendorName"), "", "");
			BaseClass.click(initiationPage.okButtonInModalPopUp);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(3000);
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void addPayee(int addPayeeValue,String searchOptionsDropDownValue,
			String cityValue,String gslValue,String verndorName,String countryValue)
	{
		try
		{
			initiationPage = new InitiationPage(BaseClass.driver);
			for(int i = 0;i < addPayeeValue;i++)
			{
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.addPayeeButtonsList.get(i));
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(3000);
				if (i == 0)
				{
					PDFResultReport.addStepDetails("Click on [AddPayee] button",
							"Vendor search Popup should get displayed",
							"Vendor search Popup is displayed", "PASS", "Y");
				}
				if (!initiationPage.serachOptionsDropDown.getAttribute("value").contains(
						"Vendor Name"))
				{
					BaseClass.select(initiationPage.searchOptionsDropDown,
							searchOptionsDropDownValue);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
				}
				if (initiationPage.serachOptionsDropDown.getAttribute("value").contains("City"))
				{
					BaseClass.set(initiationPage.cityAddNewIndividual, cityValue);
				}
				if (initiationPage.serachOptionsDropDown.getAttribute("value").contains("GSL"))
				{
					BaseClass.set(initiationPage.gslTextField, gslValue);
				}
				if (initiationPage.serachOptionsDropDown.getAttribute("value").contains(
						"Vendor Name"))
				{
					BaseClass.set(initiationPage.vendorNameTextFieled, verndorName);
				}
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				if (!countryValue.equalsIgnoreCase(""))
				{
					BaseClass.select(initiationPage.countryDropDown, countryValue);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
				}
				BaseClass.click(initiationPage.searchButtonInVendorSearch);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				if (i == 0)
				{
					BaseClass.click(initiationPage.searchListRadioButtonsInVendorSearchPage.get(i));
					BaseClass.waitForObj(5000);
				}
				if (i == 1)
				{
					BaseClass.click(initiationPage.searchListRadioButtonsInVendorSearchPage
							.get(i - 1));
					BaseClass.waitForObj(5000);
				}
				BaseClass.click(initiationPage.okButtonInModalPopUp);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				if (i == 0)
				{
					PDFResultReport.addStepDetails(
							"'Search with any valid criteria  and click on [Submit] button",
							"'Payee should get added under Payee Recipient",
							"'Payee is added under Payee Recipient", "PASS", "Y");
				}
			}
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void enterValueInSSPDetailsPage()
	{
		try
		{
			initiationPage = new InitiationPage(BaseClass.driver);
			for(int i = 0;i < 3;i++)
			{
				boolean sspLink = isElementPresent(By.xpath("//a[contains(text(),'SSP Details')]"));
				System.out.println("SSP Link "+sspLink);
				if (sspLink)
				{
					((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
							initiationPage.sspDetailsLink);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(3000);
					((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
							initiationPage.isTheVendorCreatedInSSPYESRadioButton);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(3000);
					BaseClass.select(initiationPage.uNSPSCCodeDropDown, ExcelReport.testData.get("uNSPSCCodeDropDownValue"));
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(3000);
					enterValuesAndSearchForPoRequestorAndPoPreparerInSSPDetailsPage(
							initiationPage.pORequesterOrOwner,
							ExcelReport.testData.get("PoRequester"), 4);
					BaseClass.waitForObj(3000);
					enterValuesAndSearchForPoRequestorAndPoPreparerInSSPDetailsPage(
							initiationPage.poPreparerSSO, ExcelReport.testData.get("PoPreparer"), 6);
					break;
				} else
				{
					((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
							initiationPage.nextButton);
					BaseClass.waitForObj(3000);
					boolean alert = BaseClass.isAlertPresent();
					if (alert)
					{
						BaseClass.handleAlert();
						BaseClass.waitForObj(3000);
					}
					continue;
				}
			}
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void enterValuesAndSearchForPoRequestorAndPoPreparerInSSPDetailsPage(
			WebElement inputWebElement,String poRequesterAndApproverValue,int indexOfSearchButton)
	{
		String SEARCH_BUTTON_XPATH_IN_SSP_DETAILS_PAGE = "//div[starts-with(@node_name,'OA_SSPDetails_Part')]/div/div/div/div[%d]//button//div[contains(text(),'Search')]";
		try
		{
			initiationPage = new InitiationPage(BaseClass.driver);
			((JavascriptExecutor) BaseClass.driver).executeScript(
					"arguments[0].setAttribute('value','" + poRequesterAndApproverValue + "')",
					inputWebElement);
			BaseClass.waitForObj(3000);
			WebElement ele = BaseClass.getElement(BaseClass.driver, BaseClass.LOCATOR_XPATH,
					String.format(SEARCH_BUTTON_XPATH_IN_SSP_DETAILS_PAGE, indexOfSearchButton));
			System.out.println(ele);
			BaseClass.click(ele);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			boolean radioButton = isElementPresent(By
					.xpath("//input[@name='$PldapResults$ppxResults$l1$ppyRowSelected' and @type='radio']"));
			if (radioButton)
			{
				WebElement radioButtonElement = BaseClass.driver
						.findElement(By
								.xpath("//input[@name='$PldapResults$ppxResults$l1$ppyRowSelected' and @type='radio']"));
				radioButtonElement.click();
				BaseClass.waitForObj(5000);
				BaseClass.click(initiationPage.submitButtonInPoRequestetAndPoApproverResult);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			} else
			{
				BaseClass.click(initiationPage.cancelButtonInPoRequestetAndPoApproverResult);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				initiationPage = new InitiationPage(BaseClass.driver);
				inputWebElement.clear();
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				((JavascriptExecutor) BaseClass.driver).executeScript(
						"arguments[0].setAttribute('value','" + poRequesterAndApproverValue + "')",
						inputWebElement);
				BaseClass.waitForObj(3000);
				ele = BaseClass
						.getElement(BaseClass.driver, BaseClass.LOCATOR_XPATH, String.format(
								SEARCH_BUTTON_XPATH_IN_SSP_DETAILS_PAGE, indexOfSearchButton));
				System.out.println(ele);
				BaseClass.click(ele);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				radioButton = isElementPresent(By
						.xpath("//input[@name='$PldapResults$ppxResults$l1$ppyRowSelected' and @type='radio']"));
				if (radioButton)
				{
					WebElement radioButtonElement = BaseClass.driver
							.findElement(By
									.xpath("//input[@name='$PldapResults$ppxResults$l1$ppyRowSelected' and @type='radio']"));
					radioButtonElement.click();
					BaseClass.waitForObj(5000);
					BaseClass.click(initiationPage.submitButtonInPoRequestetAndPoApproverResult);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
				} else
				{
					BaseClass.click(initiationPage.cancelButtonInPoRequestetAndPoApproverResult);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
				}
			}
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void vendorSearch(String cityValue,String gslValue,String verndorName,
			String countryValue,String stateValue)
	{
		try
		{
			initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.click(initiationPage.vendoreSearchButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			new Actions(BaseClass.driver).moveToElement(initiationPage.vendorNameTextFieled)
			.sendKeys(ExcelReport.testData.get("vendorName")).build().perform();
			BaseClass.waitForObj(3000);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.set(initiationPage.cityAddNewIndividual, cityValue);
			BaseClass.waitForObj(3000);
			boolean vendorName = initiationPage.vendorNameTextFieled.isDisplayed();
			if (!vendorName)
			{
				new Actions(BaseClass.driver).moveToElement(initiationPage.vendorNameTextFieled)
						.sendKeys(ExcelReport.testData.get("vendorName")).build().perform();
			} else
			{
				/*new Actions(BaseClass.driver).moveToElement(initiationPage.gslTextField)
						.sendKeys(ExcelReport.testData.get("gsl")).build().perform();*/
			}
			BaseClass.waitForObj(3000);
			if (!countryValue.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.countryDropDown, countryValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(3000);
			}
			if (!stateValue.equalsIgnoreCase(""))
			{
				BaseClass.select(initiationPage.stateDropDown, stateValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
			}
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.searchButtonInVendorSearch);
			
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.waitForObj(3000);
			((JavascriptExecutor) BaseClass.driver).executeScript(
					"arguments[0].scrollIntoView(true);",
					initiationPage.searchListRadioButtonsInVendorSearchPage.get(0));
			BaseClass.waitForObj(3000);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.searchListRadioButtonsInVendorSearchPage.get(0));
			BaseClass.waitForObj(5000);
			/*((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.submitButtonInVendoreSearchPage);*/
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.submitButtonForTransactionOwner);
			
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.waitForObj(5000);
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void clickOnGetOUAndSelectGETOUDropDownValue()
	{
		try
		{
			initiationPage = new InitiationPage(BaseClass.driver);
			((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
					initiationPage.getOUButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
			BaseClass.select(initiationPage.getOUDropDown,
					ExcelReport.testData.get("getOUDropDownValue"));
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void setValueUsingSikuli(String imageName,String value) throws Exception
	{
		try
		{
			Pattern fileName = new Pattern(System.getProperty("user.dir") + "\\Resources\\"
					+ imageName + ".PNG");
			Thread.sleep(1000);
			Screen screen = new Screen();
			Thread.sleep(1000);
			screen.type(fileName, value);			
			Thread.sleep(1000);
		} catch(Exception e)
		{
			
			e.printStackTrace();
		}
	}
	/**
	 * This method is for to get SSO of Pending user Using Jdbc 
	 * @param pendingWithWhom  (in summary tab we have pending)
	 * @return
	 * @throws IOException
	 * @throws SQLException
	 */
	public static String getSSOOfPendingWithUserUsingJdbc(String pendingWithWhom) throws IOException,SQLException
	{
		String[] pendingWithTheUser = null ;
		try
		{
			String pendingWithUser = JdbcConnection.swapTwoString(pendingWithWhom);
			String pendingUser = JdbcConnection.conversionOfAlphabets(pendingWithUser);
			pendingWithTheUser = JdbcConnection
					.connectToDataBaseAndGetRequiredData(pendingUser);
			System.out.println(pendingWithTheUser[0]);
			return pendingWithTheUser[0];
		} catch(Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pendingWithTheUser[0];
	}
	/**
	 * This method is for to logout from application
	 */
	public static void logOutFromAppalication()
	{
		try
		{
			BaseClass.switchToDefaultFrame();
			BaseClass.waitForObj(1000);
			AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
					BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
					AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
			BaseClass.waitForObj(3000);
			boolean status = isElementPresent(By
					.cssSelector("div[node_name='pzStudioHeader']>div>div>div>div>div>div>span>a"));
			if (status)
			{
				BaseClass.driver.switchTo().window(tabs.get(0));
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(2000);
				PeagDesignerStudioHomePage peagDesignerStudioHomePage = new PeagDesignerStudioHomePage(
						BaseClass.driver);
				System.out.println("Login User Name ::"
						+ BaseClass.text(peagDesignerStudioHomePage.globalMainLinks.get(5)));
				PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
						BaseClass.driver,
						BaseClass.text(peagDesignerStudioHomePage.globalMainLinks.get(5)),
						PeagDesignerStudioHomePage.LOG_OFF, false, StringUtils.EMPTY);
				BaseClass.waitForObj(2000);
			}
		} catch(AutomationException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * This method is for to login to   application and click on the 
	 * One AST Radio button And Click on the submit button
	 */
	public static void logInToApplicationAndClickOnOneAstRadioButtonAndClickOnSubmitButton(String userName)
	{
		LogInPage loginPage = new LogInPage(BaseClass.driver);
		BaseClass.launchApplication(ExcelReport.testData.get("url"));
		LoginUtils.loginIntoApplication(loginPage, userName, "password");
		BaseClass.waitForObj(5000);
		homePage = new HomePage(BaseClass.driver);
		if (BaseClass.getPageTitle().equalsIgnoreCase("Pega Designer Studio"))
		{
			PeagDesignerStudioHomePageUtils.selectItemFromMenuPanelPeagDesignerStudioHomePage(
					BaseClass.driver, PeagDesignerStudioHomePage.LAUNCH,
					PeagDesignerStudioHomePage.AST_USER_PORTAL, false, StringUtils.EMPTY);
			tabs = new ArrayList<String>(BaseClass.driver.getWindowHandles());
			BaseClass.driver.switchTo().window(tabs.get(1));
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		}
		AggregateSpendManagementPage aggregateSpendManagementPage = new AggregateSpendManagementPage(
				BaseClass.driver);
		BaseClass.click(aggregateSpendManagementPage.oneASTRadioButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(5000);
		BaseClass.click(aggregateSpendManagementPage.submitButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(8000);
	}
	/**
	 * This method is for to verify is Approval Link  Available And Click On Approval Link And Approve 
	 */
	public static void verifyIsApprovalLinkAvailableAndClickOnApprovalLinkAndApprove()
	{
		try {
			BaseClass.switchToDefaultFrame();
			BaseClass.waitForObj(3000);
			BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
			BaseClass.waitForObj(2000);
			approvalPage = new ApprovalPage(BaseClass.driver);
			boolean approvalLink = OneASTUtil.isElementPresent(By.xpath("//a[contains(@href,'OA')]"));
			if (approvalLink)
			{
				BaseClass.click(approvalPage.approvalFlowLink);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(500);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
			}
			if(isElementPresent(approvalPage.uploadinIPPCOE)){
				
				uploadDocumentForIPPCOEApproval("TestData.xlsx");					
			}
			boolean additionalCommentsTextArea = OneASTUtil.isElementPresent(By
					.name("$PpyWorkPage$pAdditionalCommentsCertApproval"));
			if (additionalCommentsTextArea)
			{
				BaseClass.set(approvalPage.additonalCommentesTextArea, "Please approve.");
				BaseClass.waitForObj(1000);			
			}
			BaseClass.click(approvalPage.approveButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(8000);
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
								
	}
	
	
	public static void verifyIsApprovalLinkAvailable()
	{
		try {
			BaseClass.switchToDefaultFrame();
			BaseClass.waitForObj(5000);
			BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
			BaseClass.waitForObj(5000);
			approvalPage = new ApprovalPage(BaseClass.driver);
			boolean approvalLink = OneASTUtil.isElementPresent(By.xpath("//a[contains(@href,'OA')]"));
			if (approvalLink)
			{
				BaseClass.click(approvalPage.approvalFlowLink);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
			}
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	public static void verifyAprrovalLinkAndClickOnApprovalLinkAndClickOnNextButton()
	{
		try {
			BaseClass.switchToDefaultFrame();
			BaseClass.waitForObj(5000);
			BaseClass.switchFrame(homePage.pegaGadgetFrame);
			BaseClass.waitForObj(5000);
			approvalPage = new ApprovalPage(BaseClass.driver);
			boolean approvalLink = OneASTUtil.isElementPresent(By.xpath("//a[contains(@href,'OA')]"));
			if (approvalLink)
			{
				BaseClass.click(approvalPage.approvalFlowLink);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
			}
			PDFResultReport.addStepDetails("",	
					"", 
					"", "PASS", "Y");
			BaseClass.waitForObj(2000);
			BaseClass.click(initiationPage.nextButton);
			BaseClass.waitForObj(2000);
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void closeEventOrAgreement()
	{
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(5000);
		aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(BaseClass.driver);
		((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].scrollInToView(true);",
				aggregateSpendManagementNonUSPage.closeTab);
		BaseClass.waitForObj(2000);
		((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
				aggregateSpendManagementNonUSPage.closeTab);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(8000);
	}
	public static String getPendingUserNameBySearchEventOrAgreement(String transactionNum) throws IOException, SQLException
	{
		OneASTUtil.searchWithASTWorkflowandVerifyStatus(transactionNum);
		BaseClass.switchToDefaultFrame();
		BaseClass.waitForObj(5000);
		HomePage homePage = new HomePage(BaseClass.driver);
		BaseClass.switchFrame(homePage.pegaGadgetFrame);
		BaseClass.waitForObj(5000);
		OneASTUtil.pendingWith = BaseClass.text(approvalPage.pendingWith);
		return OneASTUtil.pendingWith=OneASTUtil.getSSOOfPendingWithUserUsingJdbc(OneASTUtil.pendingWith);
	}	
	public static void scrollAndViewPendingWithInSummary()
	{
		approvalPage = new ApprovalPage(BaseClass.driver);
		int value = 250;
		for(int i = 0;i < 5;i++)
		{
			((JavascriptExecutor) BaseClass.driver).executeScript("window.scrollBy(0," + value
					+ ")");
			BaseClass.waitForObj(1000);
			boolean isDisplayed = isElementPresent(By
					.xpath("//div[@node_name='OA_WorkHeader']//div[label[@for='PendingWith']]//span"));
			if (isDisplayed)
			{
				System.out.println(isDisplayed);
				OneASTUtil.pendingWith = BaseClass.text(approvalPage.pendingWith);
				break;
			} else
			{
				value = value * i + 2;
				continue;
			}
		}
	}
	
	public static void searchWithAgreementandClickonSearch(String agreementNumber){
		
		BaseClass.set(initiationPage.agreementID, agreementNumber);
		BaseClass.waitForObj(2000);
		BaseClass.click(initiationPage.searchInAmendAgreement);
		BaseClass.waitForObj(2000);	
		BaseClass.click(initiationPage.selectAgreementRadioButton);
		BaseClass.waitForObj(2000);
		BaseClass.click(initiationPage.okButtonInModalPopUp);
		BaseClass.waitForObj(4000);
	
	}
	
	public static void paymentMethodsInTheBudget(String paymentMethod,String costCenter,String description,String vendorName, int index)
	{
		try{
			BaseClass.select(initiationPage.ifSSPPOPaymentMethodInvolvedDropDown, "No");
			BaseClass.waitForObj(5000);
			BaseClass.select(initiationPage.paymentMethods.get(index),paymentMethod);
            BaseClass.waitForObj(8000);     
            BaseClass.select(initiationPage.paymentMethods.get(index),paymentMethod);
            BaseClass.waitForObj(5000);     
            BaseClass.set(initiationPage.costCenterList.get(index), costCenter);
            BaseClass.waitForObj(2000);
            BaseClass.set(initiationPage.descriptionsList.get(index), description);
            BaseClass.waitForObj(2000);
            if(paymentMethod == "SSP PO"){
            		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
            		
            		BaseClass.waitForObj(8000);
                          BaseClass.click(initiationPage.sspCreateNo.get(index));
                          BaseClass.waitForObj(8000); 
                          CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
                          BaseClass.set(initiationPage.vendorNamesList.get(index), vendorName);
          }
            BaseClass.waitForObj(4000);
            BaseClass.set(initiationPage.vendorNamesList.get(index), vendorName);
           
                System.out.println();
            
            BaseClass.waitForObj(2000);
		}catch(AutomationException e){
			e.printStackTrace();
		}
	}
	
	public static void addExpenseDetails(String expenseType, String stramount)
	{
		int SizeExpense = initiationPage.expenseTypeDropdown.size();
		for(int i=0;i < SizeExpense;i++){
		BaseClass.select(initiationPage.expenseTypeDropdown.get(i),expenseType);
        BaseClass.waitForObj(5000);   
        BaseClass.set(initiationPage.expenseCost.get(i), stramount);
        BaseClass.waitForObj(2000); 
		}
	}
	
	
	public void updatePOThroughClipboard(String transactionNum){

		try {
			LogInPage loginPage = new LogInPage(BaseClass.driver);
			OneASTUtil.logOutFromAppalication();
			LoginUtils.loginIntoApplication(loginPage, "superUserUserName", "password");
			searchWithASTWorkflowandVerifyStatus(transactionNum);
			
			BaseClass.click(approvalPage.approvalFlowLink);	
			BaseClass.waitForObj(2000);
			BaseClass.click(approvalPage.clipboard_link);
			BaseClass.waitForObj(5000);
			BaseClass.switchWindow(1);
			BaseClass.waitForObj(2000);
			BaseClass.click(approvalPage.pyWorkPage_link);
			
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void updatePOthroughCSVfile() throws Exception{
		
				
		LogInPage loginPage = new LogInPage(BaseClass.driver);		
		List<String> POAmounts = new ArrayList<String> () ;
		BaseClass.launchApplication(ExcelReport.testData.get("url"));
		LoginUtils.loginIntoApplication(loginPage, "OldASTUsername", "password");
		BaseClass.waitForObj(5000);
		String eventID = ExcelReport.testData.get("PONumberUpdateEventID");
		HomePage homePage = new HomePage(BaseClass.driver);
		BaseClass.set(homePage.searchBox, eventID);
		BaseClass.click(homePage.searchButton);
		BaseClass.waitForObj(5000);
		
		String eventIDLink= "//div[@node_name='pzSearchResultName']//a[contains(text(),'"+eventID+"')]";
		
		BaseClass.driver.findElement(By.xpath(eventIDLink)).click();
		
		BaseClass.waitForObj(5000);
		
		BaseClass.switchFrame(homePage.frame1);
		
		for(int j=0;j<homePage.POStatus.size();j++){
			
		if(homePage.POStatus.get(j).getText().equalsIgnoreCase("Pending SSP PO Number")){
			
			//for(int i=0;i<homePage.POAmounts.size();i++){
				
				POAmounts.add(homePage.POAmounts.get(j).getText());
				System.out.println(POAmounts.get(0));
			//}
		}
		
		}
		
		BaseClass.switchToDefaultFrame();	
		BaseClass.click(homePage.close);
		
		
		List<String> POCreatedDate = new ArrayList<String> () ;
		List<String> PORevision = new ArrayList<String> () ;
		List<String> PORefID = new ArrayList<String> () ;		
		List<String> POReqNum = new ArrayList<String> () ;

	Class.forName("oracle.jdbc.driver.OracleDriver");  
	
	//step2 create  the connection object  
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.119.150.227:1521:prpc","CR","CR");  
	
	//step3 create the statement object  
	Statement stmt=con.createStatement();  
	
	//step4 execute query  
	ResultSet rs=stmt.executeQuery("select REQUISITIONNUMBER,REFERENCEID,PXCREATEDATETIME from PRPC.SSPRequisitions where referenceid like '"+eventID+"%'");  
	while(rs.next())  
	{
		//System.out.println(rs.getString(7)+"  "+rs.getString(2)+"  "+rs.getString(3));  
					
		POReqNum.add(rs.getString(1));
		PORefID.add(rs.getString(2));
		POCreatedDate.add(rs.getString(3));
		
		
	}
	
	String date1 = POCreatedDate.get(0);
	System.out.println(date1);
	//String newDate = new SimpleDateFormat("dd-MMM-yyyy").format(date);
    SimpleDateFormat sdfSource = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
    
    //parse the string into Date object
    Date date = sdfSource.parse(date1);
    
    //create SimpleDateFormat object with desired date format
    SimpleDateFormat sdfDestination = new SimpleDateFormat("dd-MMM-yy");
    
    //parse the date into another format
    date1 = sdfDestination.format(date);
    System.out.println(date1);
	
	String csvFile = System.getProperty("user.dir")
			+ "\\Resources\\AST_PO_FEED.csv";
	BufferedReader br = null;
	String line = "";
	String cvsSplitBy = "~";
	String[] country=null;
	
	try
	{
		br = new BufferedReader(new FileReader(csvFile));
		while ((line = br.readLine()) != null)
		{
			// use comma as separator
			country = line.split(cvsSplitBy);
			//System.out.println("Country [code= " + country[4] + " , name=" + country[5] + "]");
		}
	} catch(Exception e)
	{
		// TODO: handle exception
	}
	
	for (int i = 0; i < country.length; i++) {
		
		System.out.println(country[i]);
	}
	System.out.println(country[1]);
	
	String filePath = System.getProperty("user.dir")
			+ "\\Resources\\AST_PO_FEED.csv";
			
	File file = new File(filePath);
	CsvWriter csvWriter = new CsvWriter(filePath);
	boolean alreadyExists = new File(filePath).exists();

	try
	{
		//new CsvWriter(new FileWriter(filePath, true), '~');
		csvWriter.setDelimiter('~');
		if(alreadyExists)
		{
			csvWriter.write("PO_NUMBER");
			csvWriter.write("PO_REVISION");
			csvWriter.write("VENDOR_NUMBER");
			csvWriter.write("VENDOR_NAME");
			csvWriter.write("VENDOR_SITE");
			csvWriter.write("VENDOR_SITE_CODE");
			csvWriter.write("LINE_NUMBER");
			csvWriter.write("UNIT_PRICE");
			csvWriter.write("QUANTITY");
			csvWriter.write("QUANTITY_REMAINING");
			csvWriter.write("PO_AMOUNT");
			csvWriter.write("INVOICED_AMOUNT");
			csvWriter.write("REMAINING_PO_AMOUNT");
			csvWriter.write("CURRENCY");
			csvWriter.write("ORG_ID");
			csvWriter.write("PO_STATUS");
			csvWriter.write("CANCEL_FLAG");
			csvWriter.write("PO_AUTHORIZATION_STATUS");
			csvWriter.write("LAST_UPDATE_DATE");
			csvWriter.write("CREATION_DATE");
			csvWriter.write("REQUISITION_NUM");
			csvWriter.write("REQUISITION_LINE");
			csvWriter.write("REQ_DISTRIBUTION_NUM");
			csvWriter.write("REFERENCE_ID");
			csvWriter.write("REQUESTOR_EMP_NUM");
			csvWriter.write("PREPARER_EMP_NUM");
						
			csvWriter.endRecord();
		}
	//	System.out.println("PO " + PONumber.get(0));
		csvWriter.write("1231231232");
		csvWriter.write(country[1]);
		csvWriter.write(country[2]);
		csvWriter.write(country[3]);
		csvWriter.write(country[4]);
		csvWriter.write(country[5]);
		csvWriter.write(country[6]);
		csvWriter.write(country[7]);
		csvWriter.write(country[8]);
		csvWriter.write(country[9]);
		csvWriter.write(POAmounts.get(0));				
		csvWriter.write(country[11]);
		csvWriter.write(country[12]);
		csvWriter.write(country[13]);				
		csvWriter.write(country[14]);
		csvWriter.write(country[15]);
		csvWriter.write(country[16]);
		csvWriter.write(country[17]);
		csvWriter.write(country[18]);
		csvWriter.write(date1);
		csvWriter.write(POReqNum.get(0));
		csvWriter.write(country[21]);
		csvWriter.write(country[22]);
		csvWriter.write(PORefID.get(0));
		csvWriter.write(country[24]);
		csvWriter.write(country[25]);		
		//csvWriter.replace(arg0, arg1, arg2)
	
		csvWriter.endRecord();
		
		
		csvWriter.flush();
		csvWriter.close();
		
		BaseClass.set(homePage.searchBox,"ProcessPONumberRequest");
		BaseClass.click(homePage.searchButton);
		BaseClass.waitForObj(5000);
		String serviceLink= "//div[@node_name='pzSearchResultName']//a[contains(text(),'SSPRestService Services ProcessPONumberRequest')]";
		
		BaseClass.driver.findElement(By.xpath(serviceLink)).click();
		
		BaseClass.waitForObj(5000);
		
		BaseClass.switchFrame(homePage.frame1);
		
		new Actions(BaseClass.driver).moveToElement(homePage.ActionsDropdown).click().build().perform();
		BaseClass.waitForObj(2000);
		
		BaseClass.click(homePage.Run);
		
		BaseClass.switchToDefaultFrame();
		BaseClass.switchWindow(1);
		
		BaseClass.click(homePage.uploadFile_RadioButton);
		BaseClass.waitForObj(2000);
		
		BaseClass.click(homePage.fileUpload);
		CommonUtils.uploadFileUsingRobot("AST_PO_FEED.csv");
		BaseClass.click(homePage.executeButton);
		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		BaseClass.waitForObj(10000);
		BaseClass.driver.close();
		BaseClass.waitForObj(2000);
		
		BaseClass.switchWindow(0);
		BaseClass.waitForObj(1000);
		BaseClass.click(homePage.close);
		BaseClass.set(homePage.searchBox,"UpdateWOWithPONumberAtFinalize");
		BaseClass.click(homePage.searchButton);
		BaseClass.waitForObj(5000);
		String updatePOLink= "//div[@node_name='pzSearchResultName']//a[contains(text(),'UpdateWOWithPONumberAtFinalize')]";
		
		BaseClass.driver.findElement(By.xpath(updatePOLink)).click();
		
		BaseClass.waitForObj(5000);
		BaseClass.switchFrame(homePage.frame1);
		
		new Actions(BaseClass.driver).moveToElement(homePage.ActionsDropdown).click().build().perform();
		BaseClass.waitForObj(2000);		
		BaseClass.click(homePage.Run);
		BaseClass.waitForObj(10000);
		BaseClass.switchWindow(2);
		BaseClass.click(homePage.updateWO_Run);
		BaseClass.waitForObj(10000);
		BaseClass.switchWindow(3);
		BaseClass.waitForObj(5000);
		String status = BaseClass.text(homePage.status);
		
		if(status.equalsIgnoreCase("Pass")){
			
			System.out.println("PO Number Updated Successfully");
		}else{
			
			System.out.println("PO Updation failed");
		}
		BaseClass.driver.close();
		
		BaseClass.switchWindow(0);
		BaseClass.waitForObj(1000);
		
		BaseClass.click(homePage.close);

	}catch (Exception e)
	{
		System.out.println("Unable to find the WebElement " + e.getMessage());
		e.printStackTrace();
	}
 
	}
	
	public static void finalizeCRs()
	{
		try {
			/*BaseClass.click(initiationPage.nextButton);
			BaseClass.waitForObj(2000);*/
			ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
			
			for(WebElement radio:approvalPage.CR_radiobuttons){
				
				radio.click();
			}
		} catch (AutomationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
	
public static void finalizeRecouncilBudgetSubmittion(String allocationType ) throws Exception{
		
		try{
			initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.click(initiationPage.nextButton);
			BaseClass.click(initiationPage.nextButton);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(5000);
			System.out.println("Clicled on Next button");
			
			/*Boolean updatePONumber = isElementPresent(initiationPage.verifyUpdatePoNumber);
			if(updatePONumber)
			{
				BaseClass.click(initiationPage.updatePONumber);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(2000);
				BaseClass.set(initiationPage.sspPONumber, "12345ABCDE");
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				BaseClass.waitForObj(2000);
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(2000);
			}*/
			
			int sizeCheckbox = initiationPage.finalizeORReconcileBudgetCeckBox.size();
			System.out.println(sizeCheckbox);
			for(int i = 0;i < sizeCheckbox;i++)
			{
				BaseClass.click(initiationPage.finalizeORReconcileBudgetCeckBox.get(i));
				Boolean verifyServiceDate = isElementPresent(initiationPage.verifyServiceDateCalender);
				if(verifyServiceDate)
				{
					InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
					String Date = PDFResultReport.systemDate();
					String[] date = Date.split("-");
					String currentDate = date[0];
					currentDate = String.valueOf(Integer.parseInt(currentDate) + 1);
					System.out.println("Current Date " + currentDate);
					OneASTUtil.selectDateFromCalender(initiationPage.serviceDateCalender.get(i), 12, date[1], 10,
							date[2], currentDate);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				}
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.partialPaymentSelectedNo.get(i));
				BaseClass.waitForObj(2000);
				if(i==1){
				PDFResultReport.addStepDetails("Verify Finalize section in Finalize/Reconcile budget tab , "
						+ "1) Select \n"
						+"2) Payment Key Ö auto populated \n"
						+ "3) Create partial Ö flag yes or no \n", 
						"Above details should be displayed in the finalization section", 
						"Above details are  displayed in the finalization section", "PASS", "Y");
				}
				BaseClass.click(initiationPage.btnReconcile.get(i));
				
				BaseClass.waitForObj(4000);
				BaseClass.selectByValue(initiationPage.oA_AllocationType, allocationType);
				
				BaseClass.waitForObj(2000);
				
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				BaseClass.waitForObj(5000);
			}
			BaseClass.click(initiationPage.blanketPOFinalPaymentNo);
			BaseClass.waitForObj(2000);
			
		}catch(AutomationException e){
			// TODO Auto-generated catch block
            e.printStackTrace();
		}
		
	}
	
	public static void selectDateOfApprovalFromCalender(int i)
	{
		if(initiationPage.closureDateCalander.get(i).isDisplayed()){
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			String Date = PDFResultReport.systemDate();
			String[] date = Date.split("-");
			String currentDate = date[0];
			currentDate = String.valueOf(Integer.parseInt(currentDate) + 1);
			System.out.println("Current Date " + currentDate);
			OneASTUtil.selectDateFromCalender(initiationPage.closureDateCalander.get(i), 12, date[1], 10,
					date[2], currentDate);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		}
	}
	
	public static void clickOnUploadsTabAndUploadTheFilesInFinalizeReconcile(String fileName) throws AWTException
    {
          
          try
          {
                initiationPage = new InitiationPage(BaseClass.driver);
                BaseClass.click(initiationPage.nextButton);
                CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
                BaseClass.waitForObj(5000);
                PDFResultReport.addStepDetails("Click on [Next] button",
                            "'Uploads' tab should get displayed", "'Uploads' tab get displayed", "PASS",
                            "Y");
                BaseClass.switchToDefaultFrame();
                BaseClass.switchFrame(initiationPage.pegaGadet0Ifr);
                System.out.println("Mandatory Uploads List Size"
                            + initiationPage.mandatoryUploadsList.size());
                int size=initiationPage.mandatoryUploadsList.size();
                             
                for(int i = 0;i < size;i++)
                {     
                  System.out.println(initiationPage.documentTitleInUploadsTab_FinzalizeReconcile.size());
                      System.out.println(initiationPage.uploadButtonList_FinalizeReconcile.size());
                      
                      String documentTitle = initiationPage.documentTitleInUploadsTab_FinzalizeReconcile.get(i).getText();
                      BaseClass.waitForObj(2000);
                      BaseClass.click(initiationPage.uploadButtonList_FinalizeReconcile.get(i));
                      CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
                      BaseClass.waitForObj(3000);
                      BaseClass.set(initiationPage.subject_Upload, documentTitle);
                      BaseClass.waitForObj(3000);
                      BaseClass.click(initiationPage.attachmentButton);
                      BaseClass.waitForObj(3000);
                      CommonUtils.uploadFileUsingRobot(fileName);
                      BaseClass.click(initiationPage.okButtonInModalPopUp);
                      CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
                      BaseClass.waitForObj(3000);
                }
          } catch(AutomationException e)
          {
                e.printStackTrace();
          }
          }
	
		public static void enterEventInforamtionAndVenueInformation_MasterConsultingEvent(String agreementTitle,
				String venueTypeDropDownValue,String venueNameFieldValue,
				String venueCountryDropDownValue,String venueCityValue)
		{
			try {
				initiationPage = new InitiationPage(BaseClass.driver);
				BaseClass.set(initiationPage.agreementTitleTextField, agreementTitle);
				BaseClass.waitForObj(5000);
				OneASTUtil.selectBothEffectiveandExpirationDateFromCalender();
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.venueTypeDropDown, venueTypeDropDownValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.venueNameField, venueNameFieldValue);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.venueCountryDropDown, venueCountryDropDownValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.venueCityField, venueCityValue);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		public static void selectEventPlusSpendType(String spendType)
		{
			InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
			BaseClass.selectByValue(initiationPage.spendCategoryDropDown, spendType);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.click(initiationPage.nextButton);
			BaseClass.waitForObj(5000);
			
		}
		
		public static void enterEventInfoDetails(String attendes,String evenjJustificationdropdown,String multiEvent,String eventJustDetails)
		{
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(1000);
			BaseClass.set(initiationPage.eventAttendees, attendes);
			BaseClass.waitForObj(1000);
			BaseClass.selectByValue(initiationPage.eventJustification, evenjJustificationdropdown);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.selectByValue(initiationPage.event_multiRegional, multiEvent);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(1000);
			BaseClass.set(initiationPage.event_JustificationDetails, eventJustDetails);
		}
		
		public static void validateAdditionalSpendTypes()
		{
			try {
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				Boolean speakerlabel = initiationPage.lbl_speakers.isDisplayed();
				Boolean willSpeaker = initiationPage.lbl_willspeaker.isDisplayed();
				BaseClass.waitForObj(1000);
				Boolean meallabel = initiationPage.lbl_meals.isDisplayed();
				Boolean willMeal = initiationPage.lbl_willmeal.isDisplayed();
				BaseClass.waitForObj(1000);
				Boolean regfeelabel = initiationPage.lbl_regrestrationFee.isDisplayed();
				Boolean willregfee = initiationPage.lbl_willRegistrationFees.isDisplayed();
				BaseClass.waitForObj(1000);
				Boolean nonEducatioanllabel = initiationPage.lbl_nonEducationalgifts.isDisplayed();
				Boolean willNonEducational = initiationPage.lbl_willNonEducationalGifts.isDisplayed();
				BaseClass.waitForObj(1000);
				Boolean astWorkFlowlabel = initiationPage.lbl_additionalASTWorkFlows.isDisplayed();
				Boolean willASTWorkFlow = initiationPage.lbl_willASTWorkFlows.isDisplayed();
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
					
		}
		
		public static void selectSpeakerInAddititionalSpendType(String speaker, String agreementid,String masterAgreement)
		{
						
			try {
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				if(speaker == "Yes"){
				BaseClass.select(initiationPage.selectSpeaker, speaker);
				BaseClass.select(initiationPage.selectSpeaker, "Select..");
				BaseClass.select(initiationPage.selectSpeaker, speaker);
				BaseClass.select(initiationPage.selectSpeaker, "Select..");
				BaseClass.select(initiationPage.selectSpeaker, speaker);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				BaseClass.select(initiationPage.selectNumberofSpeaker, "3");
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				
				if(masterAgreement == "Yes")
				{	
				BaseClass.select(initiationPage.selectMasterAgreementSpeaker, masterAgreement);
				BaseClass.select(initiationPage.selectMasterAgreementSpeaker, "Select..");
				BaseClass.select(initiationPage.selectMasterAgreementSpeaker, masterAgreement);
				
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.agreementID,agreementid);
				BaseClass.waitForObj(5000);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				 PDFResultReport.addStepDetails("Select Yes for Will a Speaker or Consultant be invited to this event?",
						 "Should display the below field \n " +
						 "1.Select number of speakers - as dropdown with numbers \n" +
						 "2. Does Speaker have a Master Agreement in AST?",
						 "It displayed the below field \n " +
						 "1.Select number of speakers - as dropdown with numbers \n" +
						 "2. Does Speaker have a Master Agreement in AST?", "PASS", "Y");
				BaseClass.waitForObj(8000);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				 CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.searchButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.radioButtonForAgreementSearch);
				BaseClass.waitForObj(3000);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				JavascriptExecutor js = (JavascriptExecutor) BaseClass.driver;
				js.executeScript("window.scrollBy(0,150)");
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				BaseClass.waitForObj(5000);
				}
				else{
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(2000);
					BaseClass.select(initiationPage.selectMasterAgreementSpeaker, "No");
					BaseClass.waitForObj(5000);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					 PDFResultReport.addStepDetails("","","", "PASS", "Y");
				}
				
				
				}
				
				else
				{
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(2000);
					BaseClass.select(initiationPage.selectSpeaker, speaker);
					BaseClass.select(initiationPage.selectSpeaker, "Select..");
					BaseClass.select(initiationPage.selectSpeaker, speaker);
					BaseClass.select(initiationPage.selectSpeaker, "Select..");
					BaseClass.select(initiationPage.selectSpeaker, speaker);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
					PDFResultReport.addStepDetails("Select [No] for Will a Speaker or Consultant be invited to this event?",
							"No additional field should populate.","No additional field is populated.", "PASS", "Y");
				}
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		public static void selectMealsInAdditionalSpendType(String meals,String estimatedEmp , String estimatedAmt)
		{
			try {
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				if(meals == "Yes"){
				BaseClass.select(initiationPage.selectMeals, meals);
				BaseClass.select(initiationPage.selectMeals, "Select...");
				BaseClass.select(initiationPage.selectMeals, meals);
				BaseClass.select(initiationPage.selectMeals, "Select...");
				BaseClass.select(initiationPage.selectMeals, meals);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				JavascriptExecutor js = (JavascriptExecutor) BaseClass.driver;
				js.executeScript("window.scrollBy(0,50)");
				 PDFResultReport.addStepDetails(" Select 'Yes' for Will meals and beverages be provided to attendees?",
						 "Should display the below field:,"
						 +"1. Estimated number of attendees receiving meal (including GE Employees and Non-HCPs/GOs) (open field),"
						 +"2. Estimated amount per person (open field),"
						 +"3. Total amount = Estimated number of attendees * Estimated amount per person",
						 "It displayed the below field:,"
						 +"1. Estimated number of attendees receiving meal (including GE Employees and Non-HCPs/GOs) (open field),"
						 +"2. Estimated amount per person (open field),"
						 +"3. Total amount = "+estimatedEmp +" * "+ estimatedAmt+"",
						 "PASS", "Y");
				 BaseClass.waitForObj(1000);
				BaseClass.set(initiationPage.mealEstimatedNumberOfAttendees, estimatedEmp);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				BaseClass.set(initiationPage.mealEstimatedAmount, estimatedAmt);
				BaseClass.waitForObj(1000);
				 PDFResultReport.addStepDetails("","","", "PASS", "Y");
				}
				else
				{
					BaseClass.select(initiationPage.selectMeals, meals);
					BaseClass.select(initiationPage.selectMeals, "Select...");
					BaseClass.select(initiationPage.selectMeals, meals);
					BaseClass.select(initiationPage.selectMeals, "Select...");
					BaseClass.select(initiationPage.selectMeals, meals);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
					PDFResultReport.addStepDetails("Select 'No' for Will meals and beverages be provided to attendees?",
							" No - No additional field should populate."," No - No additional field is populated.", "PASS", "Y");
				}
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		public static void selectRegistartionFeeInAdditionalSpendType(String regfee, String noofattendees,
				String regFeeperson ,String isHCPfeePaid){
			try {
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				if(regfee == "Yes"){
				BaseClass.select(initiationPage.selectRegistrationFees, regfee);
				BaseClass.select(initiationPage.selectRegistrationFees, "Select...");
				BaseClass.select(initiationPage.selectRegistrationFees, regfee);
				BaseClass.select(initiationPage.selectRegistrationFees, "Select...");
				BaseClass.select(initiationPage.selectRegistrationFees, regfee);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				JavascriptExecutor js = (JavascriptExecutor) BaseClass.driver;
				js.executeScript("window.scrollBy(0,50)");
				 PDFResultReport.addStepDetails("Select Yes for Will GEHC Pay for HCP 3rd Party Conference Attendee Registration Fees?",
						 "Should display the below field \n"
						 +"1.Number of HCP/GO Attendees requiring registration fees (open field) \n"
						  +"2.Registration fee per person (open field) \n"
						 +"3.Is HCP Attendee’s Institution aware that fee is to be paid by GEHC? (Yes or No dropdown) \n "
						  +"4.Total amount = Registration Fee per person * number of HCP/GO Attendee \n",
						 "It displayed the below field \n"
						 +"1.Number of HCP/GO Attendees requiring registration fees (open field) \n"
						  +"2.Registration fee per person (open field) \n"
						 +"3.Is HCP Attendee’s Institution aware that fee is to be paid by GEHC? (Yes or No dropdown) \n "
						  +"4.Total amount = Registration Fee per person * number of HCP/GO Attendee \n", "PASS", "Y");
				BaseClass.set(initiationPage.numberofHCP_GoAttendes, noofattendees);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				BaseClass.set(initiationPage.registrationfeeperPerson, regFeeperson);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				BaseClass.select(initiationPage.isHCPAttendeesFeeisPaidbyGEHC, isHCPfeePaid);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				}
				else
				{
					BaseClass.select(initiationPage.selectRegistrationFees, regfee);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(1000);
					BaseClass.select(initiationPage.selectRegistrationFees, "Select...");
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(1000);
					BaseClass.select(initiationPage.selectRegistrationFees, regfee);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(1000);
					PDFResultReport.addStepDetails("Select No for Will GEHC Pay for HCP 3rd Party Conference Attendee Registration Fees?",
							"No - No additional field should populate","No - No additional field is populated", "PASS", "Y");
				}
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public static void selectNonEducationalgiftsInAdditionalSpendType(String nonEducaioanl,String desc,
				String NoofgiftsReceived,String estimatedAmountperpersonGift,String willidentifygifts,String doesithavelog){
			try {
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				if(nonEducaioanl == "Yes"){
					JavascriptExecutor js = (JavascriptExecutor) BaseClass.driver;
					js.executeScript("window.scrollBy(0,150)");
				BaseClass.select(initiationPage.selectNonEducationalGifts, nonEducaioanl);
				BaseClass.select(initiationPage.selectNonEducationalGifts, "Select...");
				BaseClass.select(initiationPage.selectNonEducationalGifts, nonEducaioanl);
				BaseClass.select(initiationPage.selectNonEducationalGifts, "Select...");
				BaseClass.select(initiationPage.selectNonEducationalGifts, nonEducaioanl);
				BaseClass.select(initiationPage.selectNonEducationalGifts, "Select...");
				BaseClass.select(initiationPage.selectNonEducationalGifts, nonEducaioanl);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				BaseClass.set(initiationPage.describeTheGift, desc);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				BaseClass.set(initiationPage.totalNoOfHCPGiftsReceived, NoofgiftsReceived);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				BaseClass.set(initiationPage.estimatedAmoutGiftperPerson, estimatedAmountperpersonGift);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				BaseClass.select(initiationPage.willGEHCidentifyGifts, willidentifygifts);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(1000);
				BaseClass.select(initiationPage.doesitHaveGElog, doesithavelog);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(4000);
				PDFResultReport.addStepDetails(" Select Yes for Will GEHC provided non-educational gifts to HCPs and/or GOs?",
						"Yes - Should display the below field:\n"+
						"1.Describe the gift, including context and purpose \n"+
						"2.Does it have a GE log (is it branded)?  \n"+
						"3.Total number of attendees receiving gift (including GE Employees and Non-HCPs/GOs) \n"+
						"4.Estimated amount of gift per person \n"+
						"5.Total amount = total number of attendees * Estimated amount per person",
						"Yes - will display the below field:\n"+
						"1.Describe the gift, including context and purpose \n"+
						"2.Does it have a GE log (is it branded)?  \n"+
						"3.Total number of attendees receiving gift (including GE Employees and Non-HCPs/GOs) \n"+
						"4.Estimated amount of gift per person \n"+
						"5.Total amount = total number of attendees * Estimated amount per person", "PASS", "Y");
				BaseClass.waitForObj(2000);
				}
				else
				{
					BaseClass.select(initiationPage.selectNonEducationalGifts, nonEducaioanl);
					BaseClass.select(initiationPage.selectNonEducationalGifts, "Select...");
					BaseClass.select(initiationPage.selectNonEducationalGifts, nonEducaioanl);
					BaseClass.select(initiationPage.selectNonEducationalGifts, "Select...");
					BaseClass.select(initiationPage.selectNonEducationalGifts, nonEducaioanl);
					BaseClass.select(initiationPage.selectNonEducationalGifts, "Select...");
					BaseClass.select(initiationPage.selectNonEducationalGifts, nonEducaioanl);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
					PDFResultReport.addStepDetails("Select No for Will GEHC provided non-educational gifts to HCPs and/or GOs?",
							" No - No additional field should populate."," No - No additional field should populate.", "PASS", "Y");
				}
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public static void selectAdditionalASTWorkFlowInAdditionalSpendType(String astWorkFlow , String astIDs){
			try {
				if(astWorkFlow =="Yes"){
					JavascriptExecutor js = (JavascriptExecutor) BaseClass.driver;
					js.executeScript("window.scrollBy(0,50)");
				BaseClass.select(initiationPage.selectASTWorkFlows, astWorkFlow);
				BaseClass.select(initiationPage.selectASTWorkFlows, "Select...");
				BaseClass.select(initiationPage.selectASTWorkFlows, astWorkFlow);
				BaseClass.select(initiationPage.selectASTWorkFlows, "Select...");
				BaseClass.select(initiationPage.selectASTWorkFlows, astWorkFlow);
				BaseClass.select(initiationPage.selectASTWorkFlows, "Select...");
				BaseClass.select(initiationPage.selectASTWorkFlows, astWorkFlow);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.enterASTids, astIDs);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				BaseClass.waitForObj(3000);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.clear(initiationPage.enterASTids);
				BaseClass.waitForObj(1000);
				}
				else
				{
					BaseClass.select(initiationPage.selectASTWorkFlows, astWorkFlow);
					BaseClass.select(initiationPage.selectASTWorkFlows, "Select...");
					BaseClass.select(initiationPage.selectASTWorkFlows, astWorkFlow);
					BaseClass.select(initiationPage.selectASTWorkFlows, "Select...");
					BaseClass.select(initiationPage.selectASTWorkFlows, "No");
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
					PDFResultReport.addStepDetails("","","", "PASS", "Y");
				}
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		public static void enterReassignSSOandSelect(String reassignSSOID)
		{
			try {
				BaseClass.waitForObj(3000);
				BaseClass.set(initiationPage.reassignTo,reassignSSOID);
				BaseClass.waitForObj(3000);
				PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.searchButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				PDFResultReport.addStepDetails("Enter the SSO ID or last name first name combination in Reassign To field and click on search button ",
						"Search results should get displayed",
						"Search results is displayed", "PASS", "Y");
				BaseClass.waitForObj(5000);
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.radioButtonForTransactionOwner);
				BaseClass.waitForObj(3000);
				((JavascriptExecutor) BaseClass.driver).executeScript(
						"arguments[0].scrollIntoView(true);",
						initiationPage.radioButtonForTransactionOwner);
				BaseClass.waitForObj(3000);
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(2000);
				PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public static void changeSSPOLineandAddVendor(int i ,String ChangeTo_PO)
		{
			try {
				BaseClass.switchToDefaultFrame();
				BaseClass.waitForObj(5000);
				BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
				BaseClass.waitForObj(5000);
				BaseClass.select(initiationPage.poDropdown.get(i), ChangeTo_PO);
				BaseClass.waitForObj(2000);
				Boolean alert = OneASTUtil.isAlertPresent();
				if(alert){
					BaseClass.driver.switchTo().alert().accept();
				}
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				Boolean isvendorSSPO = isElementPresent(initiationPage.vendorCreatedSSPO);
				System.out.println();
				if(isvendorSSPO){
					PDFResultReport.addStepDetails("","","", "PASS", "Y");
					BaseClass.waitForObj(8000);
				    BaseClass.click(initiationPage.sspCreateYes.get(i));
				    BaseClass.waitForObj(8000); 
				    BaseClass.click(initiationPage.vendoreSearchButton_sendback.get(i));
				    BaseClass.waitForObj(4000);
				    vendorSearch("", "", ExcelReport.testData.get("vendorName"), "", "");
				    CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				   // BaseClass.set(initiationPage.vendorNamesList.get(i), "test");
				}
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		public static boolean isAlertPresent(){
		    boolean foundAlert = false;
		    WebDriverWait wait = new WebDriverWait(BaseClass.driver, 10);
		    try {
		        wait.until(ExpectedConditions.alertIsPresent());
		        foundAlert = true;
		    } catch (AutomationException e) {
		        foundAlert = false;
		    }
		    return foundAlert;
		}
		public static void changePOLine(int i ,String ChangeTo_PO)
		{
			try {
				
				BaseClass.select(initiationPage.poDropdown.get(i), ChangeTo_PO);
				Boolean alert = OneASTUtil.isAlertPresent();
				if(alert){
					BaseClass.driver.switchTo().alert().accept();
				}
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				BaseClass.set(initiationPage.vendorNamesList.get(i), "test");
				
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		
		public static void errorCheckchangePOLine(int i ,String ChangeTo_PO)
		{
			try {
				BaseClass.select(initiationPage.poDropdown.get(i), ChangeTo_PO);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				Boolean isvendorSSPO = isElementPresent(initiationPage.vendorCreatedSSPO);
				if(isvendorSSPO){
					BaseClass.waitForObj(8000);
				    BaseClass.click(initiationPage.sspCreateNo.get(i));
				    BaseClass.waitForObj(8000); 
				    CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				    BaseClass.set(initiationPage.vendorNamesList.get(i), "test");
				}
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

		
		public static void setInitiationPage()
		{
			try {
				BaseClass.waitForObj(4000);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.click(initiationPage.nextButton);
				BaseClass.waitForObj(4000);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.click(initiationPage.nextButton);
				BaseClass.waitForObj(4000);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.click(initiationPage.nextButton);
				BaseClass.waitForObj(4000);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.click(initiationPage.nextButton);
				BaseClass.waitForObj(4000);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.click(initiationPage.nextButton);
				BaseClass.waitForObj(4000);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.click(initiationPage.nextButton);
				BaseClass.waitForObj(4000);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.click(initiationPage.nextButton);
				BaseClass.waitForObj(4000);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.click(initiationPage.submitButton);
				BaseClass.waitForObj(2000);
				PDFResultReport.addStepDetails("","","", "PASS", "Y");
			} catch (AutomationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		@SuppressWarnings("unused")
		public static void enterTheDetailsInFMVTab(String FMVDetails)
		{
			try
			{
				BaseClass.switchToDefaultFrame();
				BaseClass.waitForObj(1000);
				BaseClass.switchFrame(initiationPage.pegaGadgetFrame);
				InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
				String currency = null;
				String hourlyRate = null;
					
				BaseClass.click(initiationPage.nextButton);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(5000);
				String[] FMVdetails = FMVDetails.split(",");
				
				FMV_Country = FMVdetails[0];
				FMV_Role = FMVdetails[1];
				FMV_Q1 = FMVdetails[2];
				FMV_Q2 = FMVdetails[3];
				FMV_Q3 = FMVdetails[4];
				FMV_Q4 = FMVdetails[5];
				overrideRate = FMVdetails[6];
				lowHigh = FMVdetails[7];
				serviceHours = FMVdetails[8];
				preparationHours = FMVdetails[9];
				travelHours = FMVdetails[10];
				if (isElementPresent(initiationPage.serviceProviderSpecialtyRole)
						&& isElementPresent(initiationPage.numberOfYearsOfExperience)
						&& isElementPresent(initiationPage.defaultHourlyRate))
				{
					System.out.println("CR Service Provider has Default rate values");
					currency = BaseClass.text(initiationPage.defaultCurrency);
				} else
				{
					int sizeFVMValues = initiationPage.FMV_Country.size();
					System.out.println(sizeFVMValues);
					for( int i = 0;i < sizeFVMValues;i++)
					{
						
						BaseClass.select(initiationPage.FMV_Country.get(i), FMV_Country);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(5000);
						BaseClass.select(initiationPage.FMV_Role.get(i), FMV_Role);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(5000);
						BaseClass.select(initiationPage.FMV_Q1.get(i), FMV_Q1);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(5000);
						BaseClass.select(initiationPage.FMV_Q2.get(i), FMV_Q2);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(5000);
						BaseClass.select(initiationPage.FMV_Q3.get(i), FMV_Q3);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(5000);
						BaseClass.select(initiationPage.FMV_Q4.get(i), FMV_Q4);
						CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
						BaseClass.waitForObj(5000);
						currency = BaseClass.getAttributeValue(initiationPage.FMV_Q4.get(i), "value");
						((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
								initiationPage.calculateFMVRate.get(i));
						BaseClass.waitForObj(500);
						((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
								initiationPage.calculateFMVRate.get(i));
						BaseClass.click(initiationPage.calculateFMVRate.get(i));
						BaseClass.waitForObj(8000);
					hourlyRate = BaseClass.text(initiationPage.hourlyRate.get(i));
					if(hourlyRate.isEmpty())
					{
						((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
								initiationPage.calculateFMVRate.get(i));
						BaseClass.click(initiationPage.calculateFMVRate.get(i));
						BaseClass.waitForObj(8000);
						((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
								initiationPage.calculateFMVRate.get(i));
						BaseClass.click(initiationPage.calculateFMVRate.get(i));
						BaseClass.waitForObj(8000);
					}
					System.out.println(hourlyRate);
					if (!hourlyRate.isEmpty())
					{
						if (overrideRate.equalsIgnoreCase("Yes"))
						{
							if (lowHigh.equalsIgnoreCase("Low"))
							{
								BaseClass.click(initiationPage.overrideRate.get(i));
								String[] hourlyRate1 = hourlyRate.split(Character.toString(currency
										.charAt(0)));
								double newRate = Double.parseDouble(hourlyRate1[0]) - 10.00;
								BaseClass.set(initiationPage.newRate.get(i), String.valueOf(newRate));
								BaseClass.set(initiationPage.overrideJustification.get(i),
										"Overriding the existing rate");
							} else
							{
								BaseClass.click(initiationPage.overrideRate.get(i));
								String[] hourlyRate1 = hourlyRate.split(Character.toString(currency
										.charAt(0)));
								double newRate = Double.parseDouble(hourlyRate1[0]) + 10.00;
								BaseClass.set(initiationPage.newRate.get(i), String.valueOf(newRate));
								BaseClass.set(initiationPage.overrideJustification.get(i),
										"Overriding the existing rate");
							}
						}
						
						
						/*String Travel = "//p[contains(@name,'TravelRate')]";
						
						String Service = "(//p[@name='$PpyWorkPage$pContractedIndivs$l'"+i+"'+$pPreparationRate'])[1]";
						String Preparation = "(//p[@name='$PpyWorkPage$pContractedIndivs$l'"+i+"'+$pPreparationRate'])[2]";
						
						String serviceRate =  BaseClass.text(initiationPage.travelRate_1.get(i));
						String[] serviceRate1 = serviceRate.split(" ");
						
						String travelRate = BaseClass.text(initiationPage.travelRate_1.get(i));
						String[] travelRate1 = serviceRate.split(" ");
						
						String preparationRate = BaseClass.driver.findElement(By.xpath(Preparation)).getText();
						String[] preparationRate1 = serviceRate.split(" ");
						
						String actualTotalServiceAmount = BaseClass.text(initiationPage.totalServiceAmount.get(i));
						String[] actualTotalServiceAmount1 = actualTotalServiceAmount.split(" ");
						String actualTotalServiceAmount2 = String.format("%.1f",
								Double.parseDouble(actualTotalServiceAmount1[0]));
						System.out.println("Actual Total Service Amount " + actualTotalServiceAmount2);
						String actualTotalPreparationAmount = BaseClass
								.text(initiationPage.totalPreparationAmount.get(i));
						String[] actualTotalPreparationAmount1 = actualTotalPreparationAmount.split(" ");
						String actualTotalPreparationAmount2 = String.format("%.1f",
								Double.parseDouble(actualTotalPreparationAmount1[0]));
						System.out.println("Actual Total Service Amount " + actualTotalPreparationAmount2);
						String actualTotalTravelAmount = BaseClass.text(initiationPage.totalTravelAmount_1.get(i));
						String[] actualTotalTravelAmount1 = actualTotalTravelAmount.split(" ");
						String actualTotalTravelAmount2 = String.format("%.1f",
								Double.parseDouble(actualTotalTravelAmount1[0]));
						System.out.println("Actual Total Service Amount " + actualTotalTravelAmount2);
						String actualTotalHours = String.format("%.1f",
								Double.parseDouble(BaseClass.text(initiationPage.totalNoOfHours_1.get(i))));
						System.out.println("Actual Total Hours " + actualTotalHours);
						double expectedTotalServiceAmount = Double.parseDouble(serviceRate1[0])
								* Double.parseDouble(serviceHours);
						double expectedTotalTravelAmount = Double.parseDouble(travelRate1[0])
								* Double.parseDouble(travelHours);
						double expectedTotalPreparationAmount = Double.parseDouble(preparationRate1[0])
								* Double.parseDouble(preparationHours);
						if (expectedTotalServiceAmount == Double.parseDouble(actualTotalServiceAmount2)
								&& expectedTotalPreparationAmount == Double
										.parseDouble(actualTotalPreparationAmount2)
								&& expectedTotalTravelAmount == Double
										.parseDouble(actualTotalTravelAmount2))
						{
							System.out.println("Amounts are displayed as Expected");
						}
						double expectedTotalCompensationAmount = Double
								.parseDouble(actualTotalServiceAmount2)
								+ Double.parseDouble(actualTotalPreparationAmount2)
								+ Double.parseDouble(actualTotalTravelAmount2);
						double expectedTotalHours = Double.parseDouble(serviceHours)
								+ Double.parseDouble(travelHours) + Double.parseDouble(preparationHours);*/
						
					}
					BaseClass.set(initiationPage.serviceHours.get(i), serviceHours);
					BaseClass.waitForObj(8000);
					
					BaseClass.set(initiationPage.travelHours.get(i), travelHours);
					BaseClass.waitForObj(8000);
					
					BaseClass.set(initiationPage.preparationHours.get(i), preparationHours);
					BaseClass.waitForObj(8000);
					new Actions(BaseClass.driver).moveToElement(initiationPage.preparationHours.get(i))
							.click().build().perform();
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.set(initiationPage.travelHours.get(i), travelHours);
					BaseClass.waitForObj(8000);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
					}
					//for( i=1 ;i++){
					
					/*if (expectedTotalHours == Double.parseDouble(actualTotalHours)
							&& expectedTotalCompensationAmount == Double
									.parseDouble(actualTotalCompensationAmount))
					{
						System.out.println(actualTotalCompensationAmount);
					}*/
				}
			
			} catch(AutomationException e)
			{
				
				e.printStackTrace();
			}
		}
		
		public static void agreementandCompensationdetails(String BusinessuJustification , String GEHCProducts,String noofVisitors,
				String fmvpaymentpervisitor,
				String fmvJustification, String name , String agreementTitle)
		{
			int sizeValues = initiationPage.businessJustificationForEngagementTextAreasList.size();
			for( int i = 0;i < sizeValues;i++)
			{
						
			BaseClass.set(initiationPage.businessJustificationForEngagementTextAreasList.get(i),BusinessuJustification);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.set(initiationPage.gehcProductsOrServicesIncludedTextAreasList.get(i),GEHCProducts);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.set(initiationPage.numberofTotalVisitors.get(i),noofVisitors);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.set(initiationPage.fmvPaymentperVisit.get(i),fmvpaymentpervisitor);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.text(initiationPage.totalFMVCompensation_label.get(i)).trim();
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.set(initiationPage.fmvJustification.get(i),fmvJustification);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.set(initiationPage.name.get(i),name);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.set(initiationPage.agreementTitleTextField, agreementTitle);
			BaseClass.waitForObj(5000);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			OneASTUtil.selectBothEffectiveandExpirationDateFromCalender();
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			PDFResultReport.addStepDetails("","","", "PASS", "Y");
			BaseClass.waitForObj(2000);
			
			}
		}
		
		
		
		public static void enterEventInforamtionAndVenueInformation_EventPlus_ProductTraining(String attendees,String agreementTitle,
                String eventJustification,String additionalEventJustificationDetails,String venueTypeDropDownValue,String venueNameFieldValue,
                String venueCountryDropDownValue,String venueCityValue)
   {/*
          try {
                initiationPage = new InitiationPage(BaseClass.driver);                          
                OneASTUtil.selectBothEffectiveandExpirationDateFromCalender();
                BaseClass.waitForObj(5000);
                BaseClass.set(initiationPage.eventAttendees, attendees);
                BaseClass.set(initiationPage.agreementTitleTextField, agreementTitle);
                BaseClass.waitForObj(2000);                          
                CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
                BaseClass.select(initiationPage.eventJustificationField, eventJustification);
                BaseClass.set(initiationPage.additionalEventJustificationDetails, additionalEventJustificationDetails);
                BaseClass.select(initiationPage.venueTypeDropDown, venueTypeDropDownValue);
                CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
                BaseClass.set(initiationPage.venueNameField, venueNameFieldValue);
                BaseClass.select(initiationPage.venueCountryDropDown, venueCountryDropDownValue);
                CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
                BaseClass.set(initiationPage.venueCityField, venueCityValue);
                CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
          } catch (AutomationException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
          }
   */}
		
		
		public static void addDuplicateIndividual(String name)
		   {
		          try
		          {/*
		                InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
		                ((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
		                              initiationPage.addNewIndividualButton);
		                System.out.println();
		                //BaseClass.click(addButton);
		              CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		                BaseClass.waitForObj(5000);
		                String title = BaseClass.text(initiationPage.titleAddNewCRIndividual);
		                if (title.equalsIgnoreCase("Add New CR Individual")
		                             || title.equalsIgnoreCase("Add New Individual"))
		                {
		                BaseClass.set(initiationPage.lastNameSearchfieldinAddServiceProvider,
		                                    name);
		                       BaseClass.waitForObj(3000);
		                       BaseClass.set(initiationPage.firstNameAddNewIndividual, name);
		                       BaseClass.waitForObj(3000);
		                       BaseClass.select(initiationPage.countryAddNewIndividual, "Australia");
		                       
		                       BaseClass.waitForObj(3000);
		                BaseClass.select(initiationPage.practitionerTypeAddNewIndividual, "Pharmacist");
		                       BaseClass.waitForObj(3000);
		                BaseClass.set(initiationPage.employerInstitutionNameAddNewIndividual,
		                                    "Adding New CR Individual"+" "+time);
		                       BaseClass.waitForObj(3000);
		                       BaseClass.set(initiationPage.addressAddNewIndividual, "Sydney");
		                       BaseClass.waitForObj(3000);
		                       BaseClass.set(initiationPage.cityAddNewIndividual, "Sydney");
		                       BaseClass.waitForObj(3000);
		                       BaseClass.set(initiationPage.postalCodeAddNewIndividual, "02ES20");
		                       BaseClass.waitForObj(3000);
		                BaseClass.select(initiationPage.primarySpecialtyAddNewIndividual, "Optometry");
		                BaseClass.click(initiationPage.submitButtonForTransactionOwner);
		                       BaseClass.waitForObj(5000);
		                       ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
		                                    BaseClass.driver);
		                       boolean error = isElementPresent(consultingAgreementPage.errorMessage);
		                       String errorMessage = BaseClass.text(initiationPage.duplicateErrorMessage);
		                       System.out.println("Error Message :: " + error);
		                       if (error == true && errorMessage.contains("Duplicates have been found"))
		                       {
		                              System.out.println(errorMessage);
		                              BaseClass.waitForObj(5000);
		                              CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		                              BaseClass.waitForObj(5000);
		                              PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
		                              click(initiationPage.cancelButtonInModelPopUpWindow);
		                              BaseClass.waitForObj(5000);
		                       }
		                }
		          */} catch(AutomationException e)
		          {
		                
		                e.printStackTrace();
		          }
		   }
		
		
		
		 public static int verifyTotalEstimatedEventCost (int[] IndCostValues )
		   {
			   int i,j;
		 	   int[] individualCost = new int[20];
		 	   int sumOfCost = 0;
		       try
		          {  
		        	  for(i=0; i <= IndCostValues.length; i++) {
		   
		              individualCost[i] = IndCostValues[i];
		              
		        	  }
		        	  
		        	  for(j=0; j<=individualCost.length; j++){
		        		  
		        		  sumOfCost += individualCost[j] ;
		        	  }
		        	  
		          } catch(AutomationException e)
		          {
		                
		                e.printStackTrace();
		          }
		          return sumOfCost;
		   }
		
		
		 public static void reassignTheWorkflow(String reassignID) throws Exception
			{
				ConsultingAgreementPage consultingAgreementPage = new ConsultingAgreementPage(
						BaseClass.driver);
				InitiationPage initiationPage = new InitiationPage(BaseClass.driver);
				ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
				// BaseClass.switchToDefaultFrame();
				clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.REASSIGN);
				BaseClass.waitForObj(3000);
				PDFResultReport.addStepDetails(
						"Verify  Reassign option from the Other Actions dropdown and click on Reassign",
						"Reassign this request To should get displayed",
						"Reassign this request To get displayed", "PASS", "Y");
				BaseClass.set(approvalPage.reAssignSSO, reassignID);
				BaseClass.waitForObj(3000);
				BaseClass.click(approvalPage.searchButtonForReassign);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
				((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
						initiationPage.radioButtonForTransactionOwner);
				BaseClass.waitForObj(3000);
				PDFResultReport.addStepDetails(
						"Enter the SSO ID in Reassign To field and click on search button",
						"Search results should get displayed", "Search results should get displayed",
						"PASS", "Y");
				BaseClass.click(initiationPage.submitButtonForTransactionOwner);
				CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
				BaseClass.waitForObj(8000);
				BaseClass.set(approvalPage.reasonForReassigningthisItemtoanotherUser,
						"Assigning to some other user");
				BaseClass.click(initiationPage.submitButton);
				PDFResultReport.addStepDetails("Click on Ok button",
						"WF get transfer to selected  super user",
						"WF get transfer to selected  super user", "PASS", "Y");
				isElementPresent(approvalPage.confirmationMsg);
				BaseClass.switchToDefaultFrame();
				BaseClass.waitForObj(3000);
				AggregateSpendManagementUtils.selectItemFromMenuPanelInAggregateSpendManagementPage(
						BaseClass.driver, AggregateSpendManagementNonUSPage.SWITCH_APPLICATION,
						AggregateSpendManagementNonUSPage.LOG_OUT, false, StringUtils.EMPTY);
				BaseClass.waitForObj(3000);
			}
		 
		 
		 public static void clickOnOtherActionsAndSendBackForUpdates(String transactionNum)
			{
				try
				{/*
					ApprovalPage approvalPage = new ApprovalPage(BaseClass.driver);
					clickOnOtherActionsAndSelectCoresspondingValue(ApprovalPage.SEND_BACK_FOR_UPDATES);
					BaseClass.waitForObj(3000);
					
					BaseClass.click(approvalPage.submitButton);
					BaseClass.waitForObj(5000);
					
					String requiredMessage = approvalPage.sentBackForUpdatesMessage.getText();
					
					if (requiredMessage.equalsIgnoreCase("Please click on submit to send back the workflow for updates and make the relevant changes."))
					{
						PDFResultReport
								.addStepDetails(
										"Select 'Request more information' from other actions dropdown.",
										"System should show message after selecting 'Request more information' from other actions dropdown.",
										"System has shown message after selecting 'Request more information' from other actions dropdown.",
										"PASS", "Y");
					}
					
					BaseClass.click(approvalPage.submitButton);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
					
					if(transactionNum.startsWith("A")){
					PDFResultReport
							.addStepDetails(
									"'1. Select an Option in 'Reason' dropdown and enter the required comments in 'Requested Info' field. \n"
											+ "2. Click on [Submit] button.",
									"'The Agreement should be submitted successfully and below confirmation message should be displayed. \n"
											+ "Agreement A-xxx has been sent for Approval. Any change in status will be communicated via email.\n"
											+ "Thank you",
									"'The Agreement is submitted successfully and below confirmation message is displayed.\n"
											+ "Agreement A-xxx has been sent for Approval. Any change in status will be communicated via email.\n"
											+ "Thank you", "PASS", "Y");
					} else if(transactionNum.startsWith("E")){
						
						PDFResultReport
						.addStepDetails(
								"Click on [Submit] button to submit the event for requesting more information..",
								"'The Event should be submitted successfully and below confirmation message should be displayed. \n"
										+ "An action in the approval process has been selected for Event E-XXXXX.\n"
										+ "Thank you",
								"'The Event is submitted successfully and below confirmation message is displayed.\n"
										+ "An action in the approval process has been selected for Event E-XXXXX.\n"
										+ "Thank you", "PASS", "Y");
					}
				*/} catch(AutomationException e)
				{
					
					e.printStackTrace();
				}
			}
		 
		 
		 
		 public static void paymentMethodsInTheBudget_Updated(String paymentMethod,String costCenter,String description,int index)
			{
				try {
					BaseClass.select(initiationPage.ifSSPPOPaymentMethodInvolvedDropDown, "No");
					BaseClass.waitForObj(5000);
					BaseClass.select(initiationPage.paymentMethods.get(index),paymentMethod);
		            BaseClass.waitForObj(8000);     
		            BaseClass.select(initiationPage.paymentMethods.get(index),paymentMethod);
		            BaseClass.waitForObj(5000);     
		            BaseClass.set(initiationPage.costCenterList.get(index), costCenter);
		            BaseClass.waitForObj(2000);
		            BaseClass.set(initiationPage.descriptionsList.get(index), description);
		            BaseClass.waitForObj(2000);
		            if(paymentMethod == "SSP PO"){
		            		CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
		            		BaseClass.waitForObj(8000);
		                    BaseClass.click(initiationPage.sspCreateYes.get(index));
		                    BaseClass.waitForObj(8000);
		                    BaseClass.set(initiationPage.costCenterList.get(index), costCenter);
		                    BaseClass.waitForObj(2000);
		                    BaseClass.set(initiationPage.descriptionsList.get(index), description);
		                    BaseClass.waitForObj(2000);
		          }
		            /*BaseClass.waitForObj(4000);
		            BaseClass.set(initiationPage.vendorSearchList.get(index), vendorName);
		            System.out.println();*/
		            
				}catch(AutomationException e){
					e.printStackTrace();
				}
			}
		 
		 
		 public static void paymentMethodsInTheBudget_1(String paymentMethod,String costCenter,String description,String vendorName, int index)
			{
				try{
					BaseClass.select(initiationPage.ifSSPPOPaymentMethodInvolvedDropDown, "No");
					BaseClass.waitForObj(2000);
					BaseClass.select(initiationPage.paymentMethods.get(index),paymentMethod);
		            BaseClass.waitForObj(5000);     
		            BaseClass.select(initiationPage.paymentMethods.get(index),paymentMethod);
		            BaseClass.waitForObj(5000);     
		            BaseClass.set(initiationPage.costCenterList.get(index), costCenter);
		            BaseClass.waitForObj(2000);
		            BaseClass.set(initiationPage.descriptionsList.get(index), description);
		            BaseClass.waitForObj(2000);
		            if(initiationPage.vendorNamesList.get(index).isDisplayed()){
		            	  BaseClass.set(initiationPage.vendorNamesList.get(index), vendorName);
		            }
		            else
		            {
		            	BaseClass.select(initiationPage.paymentMethods.get(index),paymentMethod);
		                BaseClass.waitForObj(5000);   
		                BaseClass.set(initiationPage.vendorNamesList.get(index), vendorName);
		                BaseClass.waitForObj(2000);
		            }
		          
		            BaseClass.waitForObj(2000);
				}catch(AutomationException e){
					e.printStackTrace();
				}
			} 
		 
		 
		 public static void vendorSearch(String vendorCountry, int index) {
				
				try {/*
						
					BaseClass.click(initiationPage.vendorSearchList.get(index));
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(8000);
					
					BaseClass.select(initiationPage.vendorCountryInVendorSearch, vendorCountry);
					BaseClass.waitForObj(3000);
					BaseClass.click(initiationPage.searchButtonInVendorSearch);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(3000);
					
					((JavascriptExecutor) BaseClass.driver).executeScript("arguments[0].click();",
							initiationPage.radioButtonForVendor);
					BaseClass.waitForObj(3000);
					((JavascriptExecutor) BaseClass.driver).executeScript(
							"arguments[0].scrollIntoView(true);",
							initiationPage.radioButtonForVendor);
					BaseClass.waitForObj(3000);
					BaseClass.click(initiationPage.submitButtonForTransactionOwner);
					CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
					BaseClass.waitForObj(5000);
					
					*/}catch(AutomationException e){
						e.printStackTrace();
					}
				}
		 
		 
}
