package Components;
import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import ObjectRepository.LogInPage;

public class LoginUtils
{
	/**
	 * To Login into application with valid user credentials and application
	 * will
	 * take the user to Home page.
	 * 
	 * @param loginPage
	 *            the Login page
	 * @param username
	 *            the user name as string
	 * @param password
	 *            the password as string
	 */
	public static void loginIntoApplication(LogInPage loginPage, String username, String password)// 1
	{
		BaseClass.verifyElementIsEnabled(loginPage.userId, true);
		System.out.println(ExcelReport.testData.get(username));
		BaseClass.set(loginPage.userId, ExcelReport.testData.get(username));
		try
		{
			BaseClass.set(loginPage.password,
					ExcelReport.testData.get(password));
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		loginPage.clickOnLogin();
		BaseClass.waitForObj(5000);
	}
}
