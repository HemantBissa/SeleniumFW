package Components;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class JdbcConnection
{
	static Connection connection = null;
	static PreparedStatement preparedStatement = null;
	public static String[] connectToDataBaseAndGetRequiredData(String pendingWithUserName)
			throws SQLException
	{
		String[] dataBaseValues = new String[3];
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.119.150.227:1521:prpc",
					"CR", "CR");
			System.out.println("Connected to PQM DB!!!");
			preparedStatement = connection
					.prepareStatement("select IPPCOE_SSO from PRPC.IPPCOEApprovers where IPPCOE_NAME like '"
							+ pendingWithUserName + "%'");
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next())
			{
				dataBaseValues[0] = resultSet.getString(1);
				break;
			}
			// conn.close();
		} catch(Exception e)
		{
			System.out.println(e);
		} finally
		{
			connection.close();
			preparedStatement.close();
			System.out.println("Disconnected to PQM DB!!!");
		}
		return dataBaseValues;
	}
	public static String swapTwoString(String desiredString)
	{
		String[] array = desiredString.split(" ");
		String a = array[0];
		String b = array[1];
		String temp = null;
		temp = a;
		a = b;
		b = temp;
		return desiredString = a + ", " + b;
	}
	public static String conversionOfAlphabets(String desiredString) throws IOException
	{
		String[] characters = desiredString.split(", ");
		String sentence = "";
		String sentence1 = "";
		char ch2 = (char) (characters[0].charAt(0));
		sentence = sentence + ch2;
		for(int i = 1;i < characters[0].length();i++)
		{
			if (Character.isUpperCase(characters[0].charAt(i)) == true)
			{
				ch2 = (char) (characters[0].charAt(i) + 32);
				sentence = sentence + ch2;
			} else if (Character.isLowerCase(characters[0].charAt(i)) == true)
			{
				ch2 = (char) (characters[0].charAt(i) - 32);
				sentence = sentence + ch2;
			} else
				sentence = sentence + characters[0].charAt(i);
		}
		char ch3 = (char) (characters[1].charAt(0));
		sentence1 = sentence1 + ch3;
		for(int i = 1;i < characters[1].length();i++)
		{
			if (Character.isUpperCase(characters[1].charAt(i)) == true)
			{
				ch3 = (char) (characters[1].charAt(i) + 32);
				sentence1 = sentence1 + ch3;
			} else if (Character.isLowerCase(characters[1].charAt(i)) == true)
			{
				ch3 = (char) (characters[1].charAt(i) - 32);
				sentence1 = sentence1 + ch3;
			} else
				sentence1 = sentence1 + characters[1].charAt(i);
		}
		System.out.println(sentence + ", " + sentence1);
		return desiredString = sentence + ", " + sentence1;
	}
}
