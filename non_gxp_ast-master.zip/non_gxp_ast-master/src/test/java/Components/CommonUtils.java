package Components;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.sikuli.script.SikuliException;
import BaseClass.AutomationException;
import BaseClass.BaseClass;
import BaseClass.PDFResultReport;

public class CommonUtils
{
	private static final String JS_JQUERY_DEFINED = "return typeof jQuery != 'undefined';";
	private static final String JS_PRIMEFACES_DEFINED = "return typeof PrimeFaces != 'undefined';";
	private static final String JS_JQUERY_ACTIVE = "return jQuery.active != 0;";
	private static final String JS_PRIMEFACES_QUEUE_NOT_EMPTY = "return !PrimeFaces.ajax.Queue.isEmpty();";
	public static void deleteFile(String filePathInMachine,String fileName)
	{
		File file = new File(filePathInMachine);
		String[] myFiles;
		if (file.isDirectory())
		{
			myFiles = file.list();
			for(int i = 0;i < myFiles.length;i++)
			{
				File myFile = new File(file, myFiles[i]);
				if (!myFile.isDirectory() && myFile.getName().trim().startsWith(fileName))
				{
					myFile.delete();
				}
			}
		}
	}
	
	public static boolean isFileDownloaded(String filePathInMachine,String fileName,String extension)
	{
		File file = new File(filePathInMachine);
		String[] myFiles;
		if (file.isDirectory())
		{
			myFiles = file.list();
			for(int i = 0;i < myFiles.length;i++)
			{
				File myFile = new File(file, myFiles[i]);
				if (!myFile.isDirectory() && myFile.getName().trim().startsWith(fileName)
						&& myFile.getName().trim().endsWith(extension))
				{
					return true;
				}
			}
		}
		return false;
	}
	/**
	 * To wait until element text are loaded
	 * 
	 * @param driver
	 *            the WebDriver
	 * @param webElements
	 *            the list of WebElements
	 */
	public static void waitUntilElementTextLoaded(final WebDriver driver,
			final List<WebElement> webElements)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver d)
					{
						boolean textStatus = true;
						for(WebElement webElement:webElements)
						{
							if (webElement.getText().isEmpty())
							{
								textStatus = false;
								break;
							}
						}
						System.out.println(textStatus);
						return textStatus;
					}
				});
	}
	/**
	 * To execute Java script query.
	 * 
	 * @param driver
	 *            the WebDriver
	 * @param javascript
	 *            the java script query
	 * @return java script status as boolean value.
	 */
	private static boolean executeBooleanJavascript(WebDriver driver,String javascript)
	{
		return (Boolean) ((JavascriptExecutor) driver).executeScript(javascript);
	}
	/**
	 * Wait till Ajax Request completes
	 * 
	 * @param driver
	 *            the WebDriver
	 */
	public static void waitUntilAjaxRequestCompletes(WebDriver driver)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver input)
					{
						boolean ajax = false;
						boolean jQueryDefined = executeBooleanJavascript(input, JS_JQUERY_DEFINED);
						boolean primeFacesDefined = executeBooleanJavascript(input,
								JS_PRIMEFACES_DEFINED);
						if (jQueryDefined)
						{
							ajax |= executeBooleanJavascript(input, JS_JQUERY_ACTIVE);
						}
						if (primeFacesDefined)
						{
							ajax |= executeBooleanJavascript(input, JS_PRIMEFACES_QUEUE_NOT_EMPTY);
						}
						return !ajax;
					}
				});
	}
	public static String checkDropdownDefaultValue(WebElement ele)
	{
		Select archiveList = new Select(ele);
		String selectedValue = archiveList.getFirstSelectedOption().getText();
		if (selectedValue.isEmpty())
		{
			System.out.println("The default value is blank");
		}
		return selectedValue;
	}
	/**
	 * This method is for to wait until webelement displays
	 * 
	 * @param driver
	 * @param locatorType
	 * @param locatorValue
	 */
	public static void waitUntilElementDispalyed(WebDriver driver,final String locatorType,
			final String locatorValue)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver driver)
					{
						boolean isDisplayed = driver.findElement(
								BaseClass.getLocators(locatorType, locatorValue)).isDisplayed();
						System.out.println(isDisplayed);
						return isDisplayed;
					}
				});
	}
	/**
	 * This method is for to wait until webelement displays
	 * 
	 * @param driver
	 * @param element
	 */
	public static void waitUntilElementDispalyed(WebDriver driver,final WebElement element)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class, StaleElementReferenceException.class)
				.until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver driver)
					{
						boolean isDisplayed = element.isDisplayed();
						return isDisplayed;
					}
				});
	}
	// ********************New BaseClass Method***********
	public static void waitUnitllPageLoads()
	{
		BaseClass.waitForPageLoad();
		waitUntilAjaxRequestCompletes(BaseClass.driver);
	}
	public static String[] getSplittedValue(String data,String spliter)
	{
		String splittedValue[];
		splittedValue = data.split(spliter);
		return splittedValue;
	}
	public static List<String> listoftext(List<WebElement> elem) throws AutomationException
	{
		try
		{
			List<String> textArray = new ArrayList<String>();
			for(WebElement element:elem)
			{
				textArray.add(element.getText().trim());
			}
			return textArray;
		} catch(RuntimeException localRuntimeException)
		{
			PDFResultReport.addStepDetails("Verify Element text",
					"Element text should be captured",
					"Error while getting the text from the Element: " + elem
							+ " and the Error message ---> " + localRuntimeException.getMessage(),
					"FAIL", "N");
			throw new AutomationException("Error in getting the text: ");// +
			// localRuntimeException.getMessage());
		}
	}
	public static List<WebElement> getListOfElements(WebDriver driver,String locatorType,
			String locator)
	{
		List<WebElement> element = null;
		try
		{
			switch (locatorType)
			{
			case "cssselector":
				element = driver.findElements(By.cssSelector(locator));
				break;
			case "id":
				element = driver.findElements(By.id(locator));
				break;
			case "name":
				element = driver.findElements(By.name(locator));
				break;
			case "class":
				element = driver.findElements(By.className(locator));
				break;
			case "linktext":
				element = driver.findElements(By.linkText(locator));
				break;
			case "partialLinktext":
				element = driver.findElements(By.partialLinkText(locator));
				break;
			case "xpath":
				element = driver.findElements(By.xpath(locator));
				break;
			case "tagname":
				element = driver.findElements(By.tagName(locator));
				break;
			default:
				return null;
			}
			return element;
		} catch(RuntimeException localRuntimeException)
		{
			PDFResultReport.addStepDetails(
					"Get Element",
					"Element should be displayed with the locator",
					"Error is displayed while creating web element"
							+ localRuntimeException.getMessage(), "FAIL", "N");
			throw new AutomationException("Error in creating element: "
					+ localRuntimeException.getMessage());
		}
	}
	@SuppressWarnings("unused")
	public static boolean verifyValuesInDropdown(WebElement elem,String value)
			throws AutomationException
	{
		try
		{
			int n = 0;
			boolean status = true;
			String optionValue = "";
			String[] dropDownvalues = value.toString().split("\\|");
			List<String> optionList = new ArrayList<String>();
			Select sel = new Select(elem);
			List<WebElement> localWebElement = sel.getOptions();
			for(WebElement option:localWebElement)
			{
				optionValue = option.getText();
				optionList.add(optionValue);
			}
			List<String> items = Arrays.asList(dropDownvalues);
			for(int i = 0;i < items.size();i++)
			{
				if (items.get(i).trim().equalsIgnoreCase(optionList.get(i).trim()))
				{
					System.out.println(items.get(i));
				} else
				{
					n++;
					status = false;
				}
			}
			return status;
		} catch(RuntimeException localRuntimeException)
		{
			PDFResultReport.addStepDetails("Verify the items in Listbox",
					"Item should be present in : " + elem.getText(),
					"Error while finding the listbox " + elem.getText()
							+ " and the error message ---> " + localRuntimeException.getMessage(),
					"FAIL", "N");
			throw new AutomationException("Listbox not found : "
					+ localRuntimeException.getMessage());
		}
	}
	public static boolean verifyFieldHighlighted(WebElement ele)
	{
		if (BaseClass.getAttributeValue(ele, "Class").contains("Highlight"))
		{
			return true;
		} else
		{
			return false;
		}
	}
	/**
	 * This method is for to wait until text matches with the given webelement
	 * text
	 * 
	 * @param driver
	 * @param element
	 * @param text
	 */
	public static void waitUntillTextMatches(WebDriver driver,final WebElement element,
			final String text)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class)
				.until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver driver)
					{
						System.out.println(BaseClass.text(element));
						return BaseClass.text(element).equals(text);
					}
				});
	}
	@SuppressWarnings({})
	public static void waitUntilNewWindowDispalyed(final WebDriver driver,final int windowCount)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver input)
					{
						return driver.getWindowHandles().size() == windowCount;
					}
				});
	}
	/**
	 * This method is for to wait until the text is displayed for a webelement
	 * 
	 * @param driver
	 * @param element
	 */
	public static void waitUntilTextDispalyed(WebDriver driver,final WebElement element)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver input)
					{
						return !BaseClass.text(element).equals(StringUtils.EMPTY);
					}
				});
	}
	public static void clickUntillSelected(WebDriver driver,final WebElement element)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver driver)
					{
						element.click();
						waitUntilAjaxRequestCompletes(driver);
						return element.isSelected();
					}
				});
	}
	/**
	 * This method is for to wait until text displayes, that contains the
	 * expected element text
	 * 
	 * @param driver
	 * @param element
	 * @param text
	 */
	public static void waitUntillTextContains(WebDriver driver,final WebElement element,
			final String text)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class)
				.until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver driver)
					{
						return BaseClass.text(element).contains(text);
					}
				});
	}
	/**
	 * This method is for to wait until the count is greater than or eqaul to
	 * the given number
	 * 
	 * @param driver
	 * @param locator
	 * @param count
	 */
	public static void waitUntillListCountGreaterThanEqualGivenNumber(WebDriver driver,
			final By locator,final int count)
	{
		new FluentWait<WebDriver>(driver).withTimeout(100, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class, StaleElementReferenceException.class)
				.until(new ExpectedCondition<Boolean>()
				{
					@Override
					public Boolean apply(WebDriver driver)
					{
						int listsize = driver.findElements(locator).size();
						boolean status = listsize >= count;
						System.out.println(listsize);
						System.out.println(status);
						return status;
					}
				});
	}
	public static String getBrowserInformation()
	{
		String browserName = "";
		String browserVersion = "";
		String browserInfo = "";
		try
		{
			Capabilities caps = ((RemoteWebDriver) BaseClass.driver).getCapabilities();
			browserName = caps.getBrowserName();
			browserVersion = caps.getVersion();
			browserInfo = browserName + " ver " + browserVersion;
		} catch(Exception e)
		{
			System.out.println("Unable to get Broser info: " + e.getMessage());
		}
		return browserInfo;
	}
	public static void uploadFileUsingSikuli(String fileNameWithExtension)
			throws InterruptedException,SikuliException
	{
		BaseClass.waitForObj(2000);
		Pattern fileNamePath = new Pattern(System.getProperty("user.dir").toString()
				+ "\\Resources\\filename.PNG");
		BaseClass.waitForObj(2000);
		Pattern openFile = new Pattern(System.getProperty("user.dir").toString()
				+ "\\Resources\\Open.PNG");
		BaseClass.waitForObj(2000);
		Screen screen = new Screen();
		BaseClass.waitForObj(2000);
		screen.type(fileNamePath, System.getProperty("user.dir").toString() + "\\Resources\\"
				+ fileNameWithExtension);
		BaseClass.waitForObj(2000);
		screen.wait(openFile);
		BaseClass.waitForObj(2000);
		screen.click(openFile);
		BaseClass.waitForObj(2000);
	}
	
	public static void uploadFileUsingRobot(String fileNameWithExtension) throws AWTException
	{
		String FilePath = System.getProperty("user.dir") + "\\Resources\\" + fileNameWithExtension
				+ "";
		System.out.println("FilePath ::" + FilePath);
		Robot robot = new Robot();
		StringSelection stringSelection = new StringSelection(FilePath);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
		robot.delay(1000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.delay(1000);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.delay(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.delay(1000);
	}
}
