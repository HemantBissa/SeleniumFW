package Components;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import BaseClass.BaseClass;
import ObjectRepository.AggregateSpendManagementNonUSPage;
/**
 * @author yarkumar
 */
public class AggregateSpendManagementUtils
{
	public static JavascriptExecutor js = (JavascriptExecutor) BaseClass.driver;
	/**
	 * @param driver
	 * @param mainLink
	 * @param subLink
	 * @param ifChildLinkIsAvailable
	 *            if child link available to "True" otherwise "False"
	 * @param childLink
	 *            if not available Use the following --> "StringUtils.EMPTY"
	 */
	public static void selectItemFromMenuPanelInAggregateSpendManagementPage(WebDriver driver,
			String mainLink,String subLink,boolean ifChildLinkIsAvailable,String childLink)
	{
		AggregateSpendManagementNonUSPage aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(
				driver);
		for(WebElement mainLinkWebelement:aggregateSpendManagementNonUSPage.menuLinks)
		{
			if (mainLinkWebelement.getText().equalsIgnoreCase(mainLink))
			{
				System.out.println("Main Link : " + mainLinkWebelement.getText());
				mainLinkWebelement.click();
				CommonUtils.waitUntilAjaxRequestCompletes(driver);
				BaseClass.waitForObj(2000);
				break;
			}
		}
		for(WebElement subLinkWebElement:aggregateSpendManagementNonUSPage.subLinks)
		{
			if (subLinkWebElement.getText().equalsIgnoreCase(subLink))
			{
				System.out.println("Sub Link : " + subLinkWebElement.getText());
				new Actions(driver).moveToElement(subLinkWebElement).build().perform();
				BaseClass.waitForObj(1000);
				if (ifChildLinkIsAvailable == true)
				{
					for(WebElement childLinkWebElement:aggregateSpendManagementNonUSPage.childLinks)
					{
						if (childLinkWebElement.getText().equalsIgnoreCase(childLink))
						{
							System.out.println("Child Link : " + childLinkWebElement.getText());
							childLinkWebElement.click();
							CommonUtils.waitUntilAjaxRequestCompletes(driver);
							BaseClass.waitForObj(2000);
							break;
						}
					}
				} else
				{
					if (subLinkWebElement.getText().equalsIgnoreCase(subLink))
					{
						BaseClass.click(subLinkWebElement);
						BaseClass.waitForObj(5000);
						break;
					}
				}
				break;
			}
		}
	}
	/**
	 * This method is for to click on the Radio button from the Search Result
	 * Table in the Covered Recipient
	 * 
	 * @param id
	 *            from the search Result table
	 * @param status
	 *            ='true', when the "uniqueHcpIdentifier" known , otherwise
	 *            'false'
	 * @param uniqueHcpIdentifier
	 *            from the search Result table (if status = 'false' then
	 *            uniqueHcpIdentifier="StringUtils.EMPTY")
	 * @return
	 */
	public static WebElement selectRadioButtonFromSearchResultTable(String id,boolean status,
			String uniqueHcpIdentifier)
	{
		WebElement element = null;
		element = BaseClass
				.getElement(
						BaseClass.driver,
						BaseClass.LOCATOR_XPATH,
						String.format(
								AggregateSpendManagementNonUSPage.INDIVIDUAL_SEARCH_RESULT_TABLE_RADIO_BUTTON_XPATH)
								.concat(id)
								+ "']]/td[2]/input");
		if (status == true)
		{
			element = BaseClass.getElement(
					BaseClass.driver,
					BaseClass.LOCATOR_XPATH,
					String.format("//table[@id='ViewTable']/tbody/tr[td[2]/input[@title='" + id
							+ "'] or td[text()=' " + uniqueHcpIdentifier + " ']]/td[2]/input"));
		}
		if (!element.isDisplayed())
		{
			new Actions(BaseClass.driver).moveToElement(element).perform();
		}
		return element;
	}
	/**
	 * This method is for to upload the file in the Budget Tab
	 * 
	 * @param uploadValue
	 *            {2,4,6,8}
	 * @param filePath
	 *            which file user wants to upload, that file Path
	 */
	public static void uplaodFileInEventPlusPage(int uploadValue,String filePath)
	{
		AggregateSpendManagementNonUSPage aggregateSpendManagementNonUSPage = new AggregateSpendManagementNonUSPage(
				BaseClass.driver);
		BaseClass.click(BaseClass.getElement(BaseClass.driver, BaseClass.LOCATOR_CSS,
				String.format(AggregateSpendManagementNonUSPage.UPLAOD_BUTTON_CSS, uploadValue)));
		BaseClass.click(aggregateSpendManagementNonUSPage.attachmentButton);
		BaseClass.waitForObj(3000);
		System.out.println("FilePath ::" + filePath);
		try
		{
			Robot robot = new Robot();
			StringSelection stringSelection = new StringSelection(filePath);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
			robot.delay(1000);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.delay(1000);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.delay(1000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.delay(3000);
			BaseClass.click(aggregateSpendManagementNonUSPage.okButtonInModalPopUp);
			CommonUtils.waitUntilAjaxRequestCompletes(BaseClass.driver);
			BaseClass.waitForObj(3000);
		} catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * This method is for to click on the Check from the Work Flow Table
	 * 
	 * @param eventId
	 * @return Webelement
	 */
	public static WebElement clickOnCheckBoxFromWorkFlowTable(String eventId)
	{
		WebElement element = null;
		element = BaseClass.getElement(BaseClass.driver, BaseClass.LOCATOR_XPATH,
				"//table[@id='ViewTable']/tbody/tr[td[2][text()='                     " + eventId
						+ "            ']]/td[1]/input[2]");
		return element;
	}
	/**
	 * This method is for to select the Date From the Calender
	 * 
	 * @param dateValue
	 * @return Webelement
	 */
	public static WebElement selectDateFromCalender(String dateValue)
	{
		WebElement element = null;
		element = BaseClass.getElement(BaseClass.driver, BaseClass.LOCATOR_XPATH,
				"//table[@id='Pega_Cal_Cont']/tbody/tr/td/a[@data-day='" + dateValue + "']");
		return element;
	}
}
