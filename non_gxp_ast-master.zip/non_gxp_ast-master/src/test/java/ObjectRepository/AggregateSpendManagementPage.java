package ObjectRepository;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import BaseClass.ClassInitilizer;

public class AggregateSpendManagementPage extends ClassInitilizer
{
	public AggregateSpendManagementPage(WebDriver driver)
	{
		super(driver);
		// isLoaded();
	}
	
	// Currently used
	
	/**
	 * To load Login and to verify page title
	 *//*
	@Override
	public void isLoaded()
	{
		verifyPageTitle("Aggregate Spend Management");
	}
	
	@FindBy(id = "IdentifyCountryNon-USHCP")
	public WebElement nonUsRadioButton;
	
	@FindBy(id="IdentifyCountryUSHCP")
	public WebElement usRadioButton;
	
	@FindBy(css = "div[data-node-id='IdentifyRegionAndLanguage']>table>tbody>tr>td>nobr>span>button")
	public WebElement submitButton;*/

	@FindBy(id="pyNoteOneAST")
	public WebElement oneASTRadioButton;
	
	public By oneAST_radioButton = By.id("pyNoteOneAST"); 
	
	//Newly added for OLD AST Autoamtion
	
	/**
	 * To load Login and to verify page title
	 */
	@Override
	public void isLoaded()
	{
		verifyPageTitle("Aggregate Spend Management");
	}
	
	@FindBy(id = "pyNoteNon-USHCP")
	public WebElement nonUsRadioButton;
	
	@FindBy(id="pyNoteUSHCP")
	public WebElement usRadioButton;
	
	@FindBy(css = "div[data-node-id='IdentifyRegionAndLanguage']>table>tbody>tr>td>nobr>span>button")
	public WebElement submitButton;
}
