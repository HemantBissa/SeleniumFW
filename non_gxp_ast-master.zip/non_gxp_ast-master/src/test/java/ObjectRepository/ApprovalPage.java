package ObjectRepository;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ApprovalPage extends PeagDesignerStudioHomePage
{
	public ApprovalPage(WebDriver driver)
	{
		super(driver);
	}
	@Override
	public void isLoaded()
	{
		//verifyPageTitle("Pega Designer Studio");
	}
	
	public static final String DELEGATE_TO_AN_ADDTIONAL_APPROVER="Delegate to an Additional Approver";
	public static final String REJECT="Reject";	
	public static final String APPROVE_WITH_AN_EXCEPTION="Approve with exception";
	public static final String REQUEST_FOR_MORE_INFORMATION="Request for more Information";
	public static final String COMPLIANCE_ESCALATION="Compliance Escalation";
	public static final String SEND_BACK_TO_IPPCOE="Send back to IPP COE";
	public static final String SEND_BACK_FOR_UPDATES="Send Back for Updates";
	public static final String CANCEL="Cancel";
	public static final String HISTORY="History";
	public static final String ATTACHMENTS="Attachments";	
	public static final String PRINT="Print";
	public static final String SPELL_CHECKER="Spell Checker";
	public static final String APPROVE="Approve";
	public static final String REASSIGN="ReAssign";
	
	@FindBy(id="EXPAND")
	public WebElement additionalComments;
	
	@FindBy(xpath="//button[@title='Complete this assignment']//div[contains(text(),'Approve')]")
	public WebElement approveButton;
	
	//@FindBy(xpath="//td[@class='titleBarDataValueStyleExpanded']//span")
	@FindBy(xpath="(//span[@class='ellipsis'])[1]")	
	public WebElement status;
	
	@FindBy(css="div[class='sectionBodyContainerSubHead'] a")
	public List<WebElement> processFlowLinks;
	
	public By verifyStatus = By.xpath("(//span[@class='ellipsis'])[1]");
	
	@FindBy(xpath="//button//div[contains(text(),'Other actions ')]")
	public WebElement otherActionsButton;
	
	@FindBy(css="span[class='menu-item-title']")
	public List<WebElement> itemsListInOtherActions;
	
	@FindBy(id="DelegateIPPCOESearch")
	public WebElement delegateThisRequestToDropDown;
	
	@FindBy(name="$PpyWorkPage$pAdditionalCommentsCertApproval")
	public WebElement additonalCommentesTextArea; 	
	
	@FindBy(id="RejectionDesc")
	public WebElement rejectionDescriptionDropDown;
	
	@FindBy(id="Comment")
	public WebElement commentsTextFieldInReject;
	
	@FindBy(xpath="//button[@title='Complete this assignment']//div[contains(text(),'Submit')]")
	public WebElement submitButton;
	
	@FindBy(id="RequestInfoReason")
	public WebElement reasonDropDown;
	
	@FindBy(id="pyNote")
	public WebElement requestedInfoTextField;
	
	@FindBy(id="CancelEventYes")
	public WebElement yesRadioButtonForCancel;
	
	@FindBy(id="CancelEventNo")
	public WebElement noRadioButtonForCancel;
	
	@FindBy(id="ModalButtonSubmit")
	public WebElement submitButtonInCancelPopUp;
	
	@FindBy(id="ModalButtonCancel")
	public WebElement cancelButtonInCancelPopUp;
	
	@FindBy(id="OA_ReassignName_SSO")
	public WebElement reAssignSSO;
	
	@FindBy(xpath="//button[starts-with(@name,'OA_ReassignFASec_')]")
	public WebElement searchButtonForReassign;
	
	@FindBy(id="EXPAND")
	public WebElement reasonForReassigningthisItemtoanotherUser; 
	
	@FindBy(id="close")
	public WebElement close;
			
	@FindBy(name="PegaGadget0Ifr")
	public WebElement pegaGadet0Ifr;
	
	public By confirmationMsg = By.xpath("//span[contains(text(),'Confirmation')]");
	
	public By confirmationMessage=By.cssSelector("div[node_name='OA_ConfirmMessages'] b");
	
	@FindBy(css="span[aria-label='Close this document']")
	public WebElement closeTab;
	
	@FindBy(css="div[node_name='OA_WorkHeader'] span")
	public List<WebElement> workDetails;
	
	public static final int CASE_ID=0;
	public static final int CREATED=1;
	public static final int START_DATE=2;
	public static final int STATUS=4;
	public static final int CREATED_BY=5;
	public static final int PENDING_WITH=6;
	public static final int TRANSACTION_OWNER=7;
	public static final int COMPLIANCE_ESCALATION1=8;
	public static final int IPP_COE=9;	
	public static final int DIRECT_MANAGER=10;
	
	@FindBy(xpath="//a[contains(@href,'OA')]")
	public WebElement approvalFlowLink;
	
	@FindBy(id="DelegateToAdditionalApprover")
	public WebElement delegateToAdditionalApprover;
	
	@FindBy(xpath="//div[@aria-label='Process Work Area']//button//div[contains(text(),'Search')]")
	public WebElement searchButton;
	
	@FindBy(id="RequestInfoReason")
	public WebElement requestInfoReasonDropDown;
	
	@FindBy(id="pyNote")
	public WebElement requestedInfo;	
	
	@FindBy(xpath="//label[@for='AmendServiceDetails']/following-sibling::div")
	public WebElement AmendServiceDetails_IPPDCOE_ReadOnly;
	
	@FindBy(xpath="//label[@for='AmendContractterm']/following-sibling::div")
	public WebElement AmendContractterm_IPPDCOE_ReadOnly;
	
	@FindBy(xpath="//label[@for='AmendFMVDetails']/following-sibling::div")
	public WebElement AmendFMVDetails_IPPDCOE_ReadOnly;
	
	public By originalAmendmentLanguage = By.xpath("//span[contains(text(),'No Changes made to Original Contract language')]");
	
	public By hoursFromAgreementalreadyFinalized = By.xpath("//label[contains(text(),'Hours from agreement already finalized')]");
	
	public By ceritification_IPPCOE = By.xpath("//div[@node_name='OA_IPPCOEApproveSec']//span[contains(text(),'Certification')]");
		
	public By ceritification_OA_DelegateToAdditionalApprover = By.xpath("//div[@node_name='OA_DelegateToAdditionalApproverSec']//span[contains(text(),'Certification')]");
	
	@FindBy(xpath="//a[@tabtitle='Comments']")
	public WebElement commentsTab;	
	
	@FindBy(xpath="//button[starts-with(@name,'OA_IPPCOEApproveSec')]//div[contains(text(),'Upload')]")
	public WebElement uploadIPPCOEApproval;
	
	@FindBy(xpath="//button[starts-with(@name,'OA_DelegateToAdditionalApproverSec')]")
	public WebElement searchDelegateSSO;
	
	@FindBy(xpath="//span[contains(text(),'Dashboard')]")
	public WebElement dashboardLink;
	
	@FindBy(id="OA_ExceptionReason")
	public WebElement exceptionDescriptionDropDown;
	
	@FindBy(id="OA_EvidencePreCommitmentYes")
	public WebElement OA_EvidencePreCommitmentYes;
	
	@FindBy(id="OA_TypeOfPreCommit")
	public WebElement OA_TypeOfPreCommit;
	
	@FindBy(id="OA_EscalateReason")
	public WebElement OA_EscalateReason;
	
	@FindBy(id="OA_EscalatorName")
	public WebElement OA_EscalatorName;
	
	@FindBy(name="$PpyWorkPage$pOtherReason")
	public WebElement complianceEscalationComments;
	
	@FindBy(xpath="//div[@node_name='OA_ComplianceEscalationReviewSec']//span[contains(text(),'Certification')]")
	public WebElement complianceEscalationCertification;
	
	@FindBy(id="RequestInfoReason")
	public WebElement SendBackToIPPCOE_Reason;
	
	@FindBy(name="$PpyWorkPage$ppyNote")
	public WebElement SendBackToIPPCOE_RequestedInfoTextArea;
	
	@FindBy(xpath="//div[@node_name='OA_IPPCOEApproveSec']//*[text()='Edit']")
	public WebElement edit_Button;
	
	public By actualAmendmentLanguageText = By.xpath("//span[contains(text(),'Actual Amendment Language')]");	
	
	@FindBy(xpath="//div[@node_name='OA_WorkHeader']//div[label[@for='PendingWith']]//span")
	public WebElement pendingWith;
	
	@FindBy(xpath="//div[@node_name='OA_RejectConf']//span/span")
	public WebElement rejectMsg;
	
	public By uploadinIPPCOE=By.xpath("//button[starts-with(@name,'OA_IPPCOEApproveSec')]//div[contains(text(),'Upload')]");
	
	//Updating PO number through clipboard
	@FindBy(xpath="//i[@class='pi pi-clipboard']")
	public WebElement clipboard_link;
	
	@FindBy(xpath="//span[starts-with(@title,'pyWorkPage')]//parent::div//parent::li/preceding-sibling::li//a")
	public WebElement pyWorkPage_link;
	
	@FindBy(xpath="//span[@title='BudgetBreakdown']//parent::div//parent::li/preceding-sibling::li//a")
	public WebElement budgetBreakdown_link;
	
	@FindBy(xpath="//div[@node_name='OA_BudgetPOForIntegration']//div//span[text()='SSP PO Number Received']")
	public WebElement sspPONumberReceived_Status;
	
	@FindBy(xpath="//div[@node_name='OA_BudgetPOForIntegration']//div/label[text()='SSP PO Number']/parent::div//span")
	public WebElement sspPONumber;
	
	@FindBy(xpath="//div[@class='radioTable']//input[@value='Yes']")
	public List<WebElement> CR_radiobuttons;
	
	@FindBy(xpath="//font[@color='#000000']")
	public WebElement sentBackForUpdatesMessage;
	
	
 }
