package ObjectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import BaseClass.BaseClass;
import BaseClass.ClassInitilizer;

/**
 * This is Login Class which defines Login page elements and methods.
 * @author yarkumar
 */
public class LogInPage extends ClassInitilizer
{
	public LogInPage(WebDriver driver)
	{
		super(driver);
	}
   
   @FindBy(xpath="//input[@id='txtUserID']")
	public WebElement userId;
 
   @FindBy(xpath="//input[@id='txtPassword']")
	public WebElement password;
	
	@FindBy(id="sub")
	public WebElement logInButton;

   @FindBy(id = "sub")
   private WebElement loginButton;
   /**
    * To load Login and to verify page title
    */
   @Override
   public void isLoaded() {
      verifyPageTitle("Pega 7");
   }

   /**
    * To click on Login button in Login Page.
    * @return the HomePage object
    */
   public void clickOnLogin() {
      BaseClass.click(loginButton);
      // BaseClass.waitUntilAjaxRequestCompletes(driver);
   }

}
