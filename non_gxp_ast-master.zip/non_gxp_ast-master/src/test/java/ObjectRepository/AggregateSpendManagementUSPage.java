package ObjectRepository;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import BaseClass.ClassInitilizer;

public class AggregateSpendManagementUSPage extends ClassInitilizer
{

	public AggregateSpendManagementUSPage(WebDriver driver)
	{
		super(driver);
		//isLoaded();
	}
	/**
	 * To load Login and to verify page title
	 */
	@Override
	public void isLoaded()
	{
		verifyPageTitle("Aggregate Spend Management");
	}
	
	public static final String WORK_FLOW="Workflow";	
	public static final String AGREEMENT="Agreement";
	public static final String EVENT="Event";
	public static final String EXPENSES="Expenses";
	public static final String NEW_CONSULTING="New Consulting";
	public static final String NEW_GRANT="New Grant";
	public static final String NEW_EVALUTION="New Evaluation";
	public static final String NEW_EVENTS_PLUS="New EventsPlus";
	public static final String NEW_RESEARCH_EVENT="New Research Event";
	public static final String NEW_OTHER_EVENT="New Other Event";
	
	public static final String RECIPIENTS="Recipients";
	public static final String VIEW_INDIVIDUAL="View Individual";
	
	public static final String SWITCH_APPLICATION="Switch Application";
	public static final String MANAGE_MY_ABSENCE="Manage My Absence";
	public static final String LOG_OUT="Log Out";
	
	/**
	 * CASEID_CSS_COLOMN_INDEX AND
	 * EVENT_START_DATE_CSS_COLOMN_INDEX ROW INDEX IS 1,
	 * CREATED_CSS_COLOMN_INDEX AND LAST_UPDATE_CSS_COLOMN_INDEX ROW INDEX IS 2,
	 * CREATED_BY_CSS_COLOMN_INDEX AND LAST_UPDATE_BY_CSS_COLOMN_INDEX ROW INDEX
	 * IS 4
	 */
	public static String EVENT_PLUS_TABLE_CSS="div[node_name='pyWorkSummary_DynamicEU']>table>tbody>tr:nth-of-type(%d)>td:nth-of-type(%d)>span";
	public static final int CASEID_EVENT_START_DATE_CSS_ROW_INDEX=1;
	public static final int CASEID_CSS_COLOMN_INDEX=3;
	public static final int EVENT_START_DATE_CSS_COLOMN_INDEX=11;
	public static final int CREATED_LAST_UPDATE_CSS_ROW_INDEX=2;
	public static final int CREATED_CSS_COLOMN_INDEX=3;
	public static final int LAST_UPDATE_CSS_COLOMN_INDEX=7;
	public static final int CREATED_BY_LAST_UPDATE_BY_CSS_ROW_INDEX=4;
	public static final int CREATED_BY_CSS_COLOMN_INDEX=3;
	public static final int LAST_UPDATE_BY_CSS_COLOMN_INDEX=7;
	
	public static String INDIVIDUAL_SEARCH_RESULT_TABLE_RADIO_BUTTON_XPATH="//table[@id='ViewTable']/tbody/tr[td[2]/input[@title='";
	public static String UPLAOD_BUTTON_CSS="div[node_name='UploadCustomerEventList_EU']>fieldset>table>tbody>tr>td>table>tbody>tr:nth-of-type(%d)>td>nobr>span>button";
	
	@FindBy(css = "a[role='link']")
	public List<WebElement> menuLinks;
	
	@FindBy(css = "td[id='ItemMiddle']")
	public List<WebElement> subLinks;
	
	@FindBy(css = "td[id='ItemMiddle']")
	public List<WebElement> childLinks;
	
	@FindBy(name="$PpyDisplayHarness$ppyTemplateInputBox")
	public WebElement searchBox;
	
	@FindBy(name="searchMenuButton")
	public WebElement searchButton;	

	@FindBy(css="span[role='heading']")
	public List<WebElement> linksInDashboard;
	
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement pegaGadgetFrame0;
	
	@FindBy(css = "li[role='tab']>a>span>table>tbody>tr>td>span>label")
	public WebElement eventId;
	
	@FindBy(css="span[class='ellipsis']")
	public WebElement statusOfObject;	
	
	@FindBy(css="li[role='presentation']>a>span")
	public List<WebElement> tabsUnderWorkFlows;
	
	@FindBy(name = "$PpyWorkPage$pSpendCategory")
	public WebElement eventPlusTypeDropDown;
	
	@FindBy(id = "submitButton")
	public WebElement submitButton;
	
	@FindBy(id="Business")
	public WebElement businessDropDown;
	
	@FindBy(xpath="(//img[@src='webwb/pxhelp_small_13406577422.png!!.png'])[1]")
	public WebElement questionMarkImg;
			
	@FindBy(id="Modality")
	public WebElement modalityDropDown;
	
	@FindBy(id="SubModality")
	public WebElement subModalityDropDown;
	
	@FindBy(id="Product")
	public WebElement productDropDown;
	
	@FindBy(id="RLAdd")
	public WebElement plusIconToAdd;
	
	@FindBy(name="$PpyWorkPage$pGiftDetails$l1$pTransactionDate")
	public WebElement transactionDate;
	
	@FindBy(id="cal$PpyWorkPage$pGiftDetails$l1$pTransactionDateIcon")
	public WebElement transactionCalender;
	
	@FindBy(id="Category")
	public WebElement categoryDropDown;
	
	@FindBy(name="$PpyWorkPage$pGiftDetails$l1$pFMV")
	public WebElement valuePerItem;
	
	@FindBy(name="$PpyWorkPage$pGiftDetails$l1$pQuantity")
	public WebElement 	quantity;
	
	@FindBy(name="$PpyWorkPage$pGiftDetails$l1$pCurrencyCode")
	public WebElement currency;
	
	@FindBy(id="SubmittingRequestOnBehalfOfYes")
	public WebElement submittingRequestOnBehalfOfOtherYesRadioButton;
	
	@FindBy(id="BehalfOfSearch")
	public WebElement behalfOfSearch;
	
	@FindBy(id="SubmittingRequestOnBehalfOfNo")
	public WebElement submittingRequestOnBehalfOfOtherNoRadioButton;
	
	@FindBy(css="table[param_name='EXPANDEDSubSectionSelectBusinessProduct_EUB']>tbody>tr>td>table>tbody>tr>td>span>button")
	public WebElement behalfOfSearchButton;
	
	@FindBy(name="$PldapResultsListView$ppySingleSelection")
	public WebElement radioButtonForBehalfInSearchResult;
	
	@FindBy(name="$PpyWorkPage$pSearchLECurrency")
	public WebElement changeToOtherCurrency;
	
	@FindBy(css="span[id='$PpyWorkPage$pRequestStartDateSpan']>img")
	public WebElement praposedStartDatecalender;
	
	@FindBy(css="span[id='$PpyWorkPage$pRequestEndDateSpan']>img")
	public WebElement praposedEndDatecalender;
	
	/*@FindBy(id="todayLink")*/
	@FindBy(id="cal$PpyWorkPage$pGiftDetails$l1$pTransactionDate_cell17")
	public WebElement todayLink;
	
	@FindBy(name="$PpyWorkPage$pEventTitle")
	public WebElement eventTitle;
	
	@FindBy(name="$PpyWorkPage$pEvent$pEventJustification")
	public WebElement eventJustification;
	
	@FindBy(css="button[title='Complete this assignment']")
	public WebElement nextButton;
	
	@FindBy(css="div[name='.ApprovalCertification']>button")
	public WebElement approveButton;
	
	@FindBy(name="$PpyWorkPage$pEvent$pBehalfOfSearch")
	public WebElement transactionOwner;	
	
	@FindBy(name="$PpyWorkPage$pAddEventJustification")
	public WebElement additionalEventJustificationDetails;
	
	@FindBy(id="CountOfPlannedAttendees")
	public WebElement estimatedAttendees;
	
	@FindBy(name="$PpyWorkPage$pOfferMealsToHCP")
	public WebElement doYouPlanToOfferMealsToHCPsAndOrGOsDuringThisEventDropDown;
	
	@FindBy(name="$PpyWorkPage$pEventInteractionPlace")
	public WebElement whereWillInteractionTakePlaceDropDown;
	
	@FindBy(id="HCPGOAttendMeal")
	public WebElement howManyHCPsAndOrGOsWillAttendThisMeal;
	
	@FindBy(id="AmountOfMeal")
	public WebElement amountOfMealPerPerson;
	
	@FindBy(name="$PpyWorkPage$pEventInvitation")
	public WebElement willASpeakerOrConsultantBeInvitedToThisEventDropDown;
	
	@FindBy(name="$PpyWorkPage$pNumberOfSpeakers")
	public WebElement howManySpeakersOrConsultantsDropDown;
	
	@FindBy(name="$PpyWorkPage$pTravelExpenses")
	public WebElement isGEPayingForAnyTravelRelatedExpensesForHCPAndOrGoParticipantsDropDown;
	
	@FindBy(name="$PpyWorkPage$pNonEducationalGiftsToHCPs")
	public WebElement isGEGoingToOfferNonEducationalGiftsToHCPsAndOrGOsDropDown;
	
	@FindBy(id="MultiRegionalEventtrue")
	public WebElement multiRegionalEvenYesRadioButton;
	
	@FindBy(id="MultiRegionalEventfalse")
	public WebElement multiRegionalEvenNoRadioButton;
		
	@FindBy(name="$PpyWorkPage$pTravelExpenses")
	public WebElement travelExpensesDropDown;
	
	@FindBy(name="$PpyWorkPage$pNonEducationalGiftsToHCPs")
	public WebElement nonEducationalGiftsToHCPsDropDown;
	
	@FindBy(id="MultiRegionalEventtrue")
	public WebElement multiRegionalEventYesRadionButton;
	
	@FindBy(id="MultiRegionalEventfalse")
	public WebElement multiRegionalEventNoRadionButton;
	
	@FindBy(id="UseSSPIntegration")
	public WebElement astSSPIntegrationDropDown;
	
	@FindBy(name="$PpyWorkPage$pVenue$pVenueType")
	public WebElement venueTypeDropDown;
	
	@FindBy(name="$PpyWorkPage$pVenue$pVenueName")
	public WebElement venueName;
	
	@FindBy(name="$PpyWorkPage$pVenue$pVenueCountry")
	public WebElement venueCountryDropDown;
	
	@FindBy(id="VenueCity")
	public WebElement venuCity;
	
	@FindBy(css="a[tabtitle='CR Individual']>span>span>label")
	public WebElement crIndividualTabUnderCoveredRecipientTab;
	
	@FindBy(css="a[tabtitle='CR Organizations']>span>span>label")
	public WebElement crOrganizationsTabUnderCoveredRecipientTab;
	
	@FindBy(css="a[tabtitle='History']>span>span>label")
	public WebElement historyTabUnderCoveredRecipientTab;
	
	@FindBy(name="$PpyWorkPage$pCRIndividualSearchCriteria$pLastName")
	public WebElement lastName;
	
	@FindBy(name="$PpyWorkPage$pCRIndividualSearchCriteria$pFirstName")
	public WebElement firstName;
	
	@FindBy(id="NPINumber")
	public WebElement uniqueHCPIdentifier;
	
	@FindBy(id="GEID_UI")
	public WebElement geId;
	
	@FindBy(css="div[node_name='CRIndividualSearchCriteriaName_EU']>table>tbody>tr>td>nobr>span>button")
	public WebElement clickHereForNationalRegulationsforCRs;
	
	@FindBy(css="table>tbody>tr>td>nobr>span>button")
	public List<WebElement> buttons;
	
	@FindBy(name="$PpyWorkPage$pCRIndividualSearchCriteria$pCountry")
	public WebElement coveredRecipientCountryDropDown;
	
	@FindBy(id="modaldialog_hd")
	public WebElement modalDialog;
	
	@FindBy(name="$PLSCRIndividualPage$ppySingleSelection")
	public List<WebElement> individualSearchresultsTableRadioButton;
	
	@FindBy(id="ModalButtonSubmit")
	public WebElement okButtonInModalPopUp;
	
	@FindBy(css="input[value='No']")
	public WebElement separationPrincipleConcernNoRadioButton;
	
	@FindBy(css="input[value='Yes']")
	public WebElement separationPrincipleConcernYesRadioButton;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pExpenseType")
	public WebElement expenseDropDown;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pExpenseCost")
	public WebElement amount;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pCurrencyCode")
	public WebElement currencyCode;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pCostCentre")
	public WebElement costCenter;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pVendorName")
	public WebElement vendorName;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pDescription")
	public WebElement description;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pPaymentMethod")
	public WebElement paymentMethodDropDown;
	
	@FindBy(name="$PpyAttachmentPage$ppxAttachName")
	public WebElement attachmentButton;
	
	@FindBy(name="$PpyAttachmentPage$ppyCategory")
	public WebElement attachmentCategoryDropDown;
	
	@FindBy(css="span[class='iconCloseSmall']")
	public WebElement closeTab;
	
	@FindBy(css="input[name='$PpyWorkPage$pSearchManagerApprover']")
	public WebElement ssoOrLastName;
	
	@FindBy(name="$PpyWorkPage$pEvent$pBehalfOfSearch")
	public WebElement ssoOrLastNameSearchBox;
	
	@FindBy(css="div[node_name='SearchTargetUser']>table>tbody>tr>td>nobr>span>button")				  
	public WebElement searchButtonForSsoOrLastName;
	
	@FindBy(css="table[id='ViewTable']>tbody>tr>td>input")
	public WebElement ssoOrLastNameRadioButton;
	
	public static String SSO_OR_LAST_NAME_TABLE_RECORD_CSS_VALUES="table[id='ViewTable']>tbody>tr>td:nth-of-type(%d)";
	
	@FindBy(xpath="//table[@id='ViewTable']/tbody/tr/td[2]")
	public List<WebElement> workIdValuesOfWorkFlowTable;	
	
	@FindBy(css="span[id='$PpyWorkPage$pStartDateSpan']>img")
	public WebElement roleAssignmentStartDateCalender;
	
	@FindBy(css="span[id='$PpyWorkPage$pEndDateSpan']>img")
	public WebElement roleAssignmentEndDateCalender;
	
	@FindBy(xpath="//table[@id='Pega_Cal_Cont']/tbody/tr/td[@class='calcell today selected']/a")
	public WebElement currentDateValue;
	
	@FindBy(name="$PpyWorkPage$pExceptionJustification")
	public WebElement specifyJustification;
	
	@FindBy(css="div[node_name='ConfirmManageAbsence']>table>tbody>tr>td>nobr>p")
	public WebElement confirmationManageAbsenceMessage;
	
	@FindBy(css="table[pl_prop_class='System-User-Recents']>tbody>tr>td>div>span>a")
	public List<WebElement> recentsItems;
	
	@FindBy(css="td[nowrap='nowrap']>a")
	public List<WebElement> processLinks;

}
