package ObjectRepository;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends PeagDesignerStudioHomePage
{
	
	@FindBy(id="pySearchText")
	public WebElement searchBox;
	
	@FindBy(css="div[class='layout layout-none float-right set-width-auto'] div i[role='link']")
	public WebElement searchButton;
	
	@FindBy(css="div[class='field-item dataLabelWrite']")
	public List<WebElement> searchResult;
	
	@FindBy(css="table[pl_prop_class='Data-Find-Results']>tbody>tr>td:nth-of-type(2) div span a")
	public WebElement operatorId;
	
	@FindBy(id="PegaGadget0Ifr")
	public WebElement frame1;
	
	@FindBy(xpath="//div[@pyclassname='GE-FW-AggregateSpendFW-Data-POReq']//td[5]/nobr/span")
	public List<WebElement> requistionNumber;
	
	@FindBy(xpath="//div[@pyclassname='GE-FW-AggregateSpendFW-Data-POReq']//td[2]/nobr/span")
	public List<WebElement> POAmounts;
	
	@FindBy(xpath="//div[@pyclassname='GE-FW-AggregateSpendFW-Data-POReq']//td[6]/nobr/span")
	public List<WebElement> POStatus;
	
	@FindBy(xpath="//span[@id='close']")
	public WebElement close;
	
	@FindBy(xpath="//div[contains(text(),'Actions')]")
	public WebElement ActionsDropdown;
	
	@FindBy(xpath="//td[contains(text(),'Run')]")
	public WebElement Run;
	
	@FindBy(xpath="//input[@value='UploadFile']")
	public WebElement uploadFile_RadioButton;
	
	@FindBy(name="fileUpload")
	public WebElement fileUpload;
	
	@FindBy(xpath="//span[text()='Execute']")
	public WebElement executeButton;
	
	@FindBy(xpath="//div[@node_name='pzRunRecordButton']//*[contains(text(),'Run')]")
	public WebElement updateWO_Run;
	
	@FindBy(xpath="(//tr[//td//label[contains(text(),'Status')]]//td/nobr)[1]")
	public WebElement status;
	
	@FindBy(xpath="//span[text()='Dashboard']")
	public WebElement dashBoardLink;
	
	@FindBy(css="div[node_name='OA_DashboardSection'] table[class='gridTable '] tr>td:nth-of-type(1)>div")
	public List<WebElement> workIdInMyActionsItems;
	
	@FindBy(id="PegaGadget0Ifr")
	public WebElement pegaGadgetFrame;
	
	@FindBy(id="PegaGadget1Ifr")
	public WebElement pegaGadgetFrame1;
	
	public HomePage(WebDriver driver)
	{
		super(driver);
	}
	@Override
	public void isLoaded()
	{
		//verifyPageTitle("Pega Designer Studio");
	}
}
