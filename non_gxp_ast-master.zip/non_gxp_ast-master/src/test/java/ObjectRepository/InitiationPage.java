package ObjectRepository;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class InitiationPage extends PeagDesignerStudioHomePage
{
	public InitiationPage(WebDriver driver)
	{
		super(driver);
	}
	@Override
	public void isLoaded()
	{
		//verifyPageTitle("Pega Designer Studio");
	}
	
	@FindBy(id="POLE")
	public WebElement poleDropDown;
	
	@FindBy(id="REGION")
	public WebElement regionDropDown;
	
	@FindBy(id="Country")
	public WebElement payingCountryDropDown;
	
	@FindBy(id="Business")
	public WebElement businessDropDown;
	
	@FindBy(id="MODALITYBUSINESS")
	public WebElement modalityDropDown;	
	
	@FindBy(id="LegalEntity")
	public WebElement legalEntityDropDown;
	
	@FindBy(id="Product")
	public WebElement productDropDown;

	@FindBy(id="ProductIndicator")
	public WebElement productIndicatorDropDown;
	
	@FindBy(id="SearchLECurrency")
	public WebElement changeToOthercountryDropDown;
	
	@FindBy(id="SubmittingRequestOnBehalfOfYes")
	public WebElement onBehalfOfOtherYesRadioButton;
	
	@FindBy(id="SubmittingRequestOnBehalfOfNo")
	public WebElement onBehalfOfOtherNoRadioButton;
	
	@FindBy(xpath="//select[@id='SpendCategory']")
	public WebElement spendCategoryDropDown;	
	
	public By spendCatAvailable = By.xpath("//select[@id='SpendCategory']");
	
	@FindBy(id="SpendSubType")
	public WebElement spendSubTypeDropDown;
	
	@FindBy(xpath="//textarea[@id='AgreementJustification']")
	public WebElement businessJustificationForEngagementTextField;
	
	@FindBy(id="AdditionalAgreementJustification")
	public WebElement gehcProductOrServicesIncludedTextField;
	
	@FindBy(id="Rationale")
	public WebElement consultantQualificationSummaryTextField;
	
	@FindBy(id="BehalfOfSearch")
	public WebElement transactionOwnerSerachBox;
	
	//@FindBy(xpath="//button[starts-with(@name,'OA_BusinessInformation_pyWorkPage_')]")
	@FindBy(xpath="//div[contains(text(),'Search')]")
	public WebElement searchButtonForTransactionOwner;
	
	@FindBy(name="$PldapResultsListView$ppySingleSelection")
	public WebElement radioButtonForTransactionOwner;
	
	@FindBy(xpath="//input[@name='$PpyWorkPage$pAgreementList$l1$ppyRowSelected'][@type='radio']")
	public WebElement radioButtonForAgreementSearch;
	
	@FindBy(xpath="//button[@id='ModalButtonSubmit']")
	public WebElement submitButtonForTransactionOwner;
	
	@FindBy(id="SearchLECurrency")
	public WebElement changeToTheCurrenyDorpDown;
	
	@FindBy(css="li[aria-label='Business Information'] span")
	public WebElement businessInformationTab;
	
	@FindBy(css="li[aria-label='Supporting Information'] span")
	public WebElement supportingInformationTab;
	
	@FindBy(css="li[aria-label='Agreement Details'] span")
	public WebElement agreementDetailsTab;
	
	@FindBy(css="li[aria-label='Uploads'] span")
	public WebElement uploadsTab;
	
	@FindBy(css="li[aria-label='Summary'] span")
	public WebElement summaryTab;
	
	@FindBy(xpath="//textarea[starts-with(@id,'ServiceProvided')]")
	public WebElement serviceToBeProvidedTextArea;
	
	@FindBy(id="PaymentDetails")
	public WebElement payMentDetailsTextField; 
	
	@FindBy(id="CRPayeeAddress")
	public WebElement payeeAddressTextField;
	
	@FindBy(id="EventTitle")
	public WebElement agreementTitleTextField;
	
	@FindAll({ @FindBy(css = "span[id='$PpyWorkPage$pRequestStartDateSpan'] img"),
			@FindBy(css = "span[id='$PpyWorkPage$pEffectiveDateSpan'] img") })
	public WebElement effectiveDateCalender;
	
	@FindAll({ @FindBy(css = "span[id='$PpyWorkPage$pRequestEndDateSpan'] img"),
			@FindBy(css = "span[id='$PpyWorkPage$pExpirationDateSpan'] img") })
	public WebElement expirationDateCalender;
	
	@FindBy(css="span[id='$PpyWorkPage$pBudgetBreakdown$l1$pServiceDateSpan'] img")
	public List<WebElement> serviceDateCalender;
	
	public By verifyServiceDateCalender = By.cssSelector("span[id='$PpyWorkPage$pBudgetBreakdown$l1$pServiceDateSpan'] img");
	
	@FindBy(id="todayLink")
	public WebElement todayLink;
	
	@FindBy(xpath="//input[@id='CheckServiceCompYes']")
	public WebElement willServiceCompensationBePaidYesRadioButton;
	
	@FindBy(xpath="//input[@id='OA_ServiceCompOrgYes']")
	public WebElement willServiceCompensationBePaidYesRadioButton_Org;
	
	public By validatewillServiceCompensationBePaidYesRadioButton = By.xpath("//input[@id='CheckServiceCompYes']");
	
	@FindBy(id="CheckServiceCompNo")
	public WebElement willServiceCompensationBePaidNoRadioButton;
	
	@FindBy(id="ServiceComponentNo Service Comp- T&L Only")
	public WebElement noServiceComponentTAndLOnlyRadioButton;
	
	@FindBy(id="ServiceComponentNo Transfer of Value")
	public WebElement noTransferOfValueRadioButton;
	
	@FindBy(id="previousYear")
	public WebElement previousYearLink;
	
	@FindBy(id="nextYear")
	public WebElement nextYearLink;
	
	@FindBy(id="previousMonth")
	public WebElement previousMonthLink;
	
	@FindBy(id="nextMonth")
	public WebElement nextMonthLink;
	
	@FindBy(css="tbody[id='controlCalBody'] td a")
	public List<WebElement> datesInCalender;
	
	@FindBy(id="calMonthCell")
	public WebElement currentMonthValue;
	
	@FindBy(id="calYearCell")
	public WebElement currentYearValue;
	
	@FindAll({ @FindBy(css = "div[node_name='OA_UploadDoc'] img[data-ctl='Icon']"),
        @FindBy(css = "div[data-node-id='OA_UploadForInitiation'] img[data-ctl='Icon']"),
        @FindBy(xpath = "//div[@id='PEGA_GRID1']//img[@data-ctl='Icon']")})
	public List<WebElement> mandatoryUploadsList;
	
	@FindBy(xpath="//button//div[contains(text(),'Upload')]")
	public List<WebElement> uploadButtonList;
	
	@FindBy(xpath="(//button//div[contains(text(),'Upload')])[1]")
	public WebElement singleuploadButtonList;
	
	@FindBy(name="$PpyAttachmentPage$ppxAttachName")
	public WebElement attachmentButton;	
	
	@FindBy(id="OA_Subject")
	public WebElement subject_Upload;
	
	@FindBy(id="ModalButtonSubmit")
	public WebElement okButtonInModalPopUp;
	
	@FindBy(css="div[id='dummyDiv']>div>div>ul[role='tablist'] label")
	public WebElement number;
	
    @FindBy(css="a[tabtitle='Fair Market Value']")
    public WebElement FMVTab;
    
    @FindBy(xpath="//select[@id='FMVPractType']")
    public List<WebElement> FMV_Country;
    
    @FindBy(xpath="//select[@id='FMVSpecialty']")
    public List<WebElement> FMV_Role;
    
    @FindBy(xpath="//select[@id='FMVQ1']")
    public List<WebElement> FMV_Q1;
    
    @FindBy(xpath="//select[@id='FMVQ2']")
    public List<WebElement> FMV_Q2;
    
    @FindBy(xpath="//select[@id='FMVQ3']")
    public List<WebElement> FMV_Q3;
    
    @FindBy(xpath="//select[@id='CurrencyCode']")
    public List<WebElement> FMV_Q4;
    
    @FindBy(xpath="//div[contains(text(),'Calculate')]")
    public List<WebElement> calculateFMVRate;
    
    @FindBy(xpath="(//div[contains(text(),'Save')])[2]")
    public WebElement saveButton;
    
    @FindBy(xpath="//span[@class='leftJustifyStyle']")
    public List<WebElement> hourlyRate;
    
    @FindBy(xpath="//input[contains(@id,'ServiceRateOverrideYes')]")
    public List<WebElement> overrideRate;
    
    @FindBy(xpath="//input[@id='ServiceRateOverrideValue']")
    public List<WebElement> newRate;
    
    @FindBy(xpath="//*[*/*[text()='Override Justification']]//textarea")
    public List<WebElement> overrideJustification;
    
    @FindBy(css="div[node_name='OA_ServiceRate'] p[name='$PpyWorkPage$pCRIndividual$pPreparationRate']")
    public WebElement serviceRate;
    
    @FindBy(css="div[node_name='OA_PreparationRate'] p[name='$PpyWorkPage$pCRIndividual$pPreparationRate']")
    public WebElement preparationRate;
    
    @FindBy(name="$PpyWorkPage$pCRIndividual$pTravelRate")
    public WebElement travelRate;
    
    @FindBy(xpath="//p[contains(@name,'TravelRate')]")
    public List<WebElement> travelRate_1;
    
    
    @FindBy(id="ServiceHours")
    public List<WebElement> serviceHours;
    
    @FindBy(id="ServiceHours")
    public WebElement serviceHours_1;
    
    @FindBy(id="TravelHours")
    public List<WebElement> travelHours;
    
    @FindBy(id="TravelHours")
    public WebElement travelHours_1;
    
    @FindBy(id="PreparationHours")
    public List<WebElement> preparationHours;
    
    @FindBy(id="PreparationHours")
    public WebElement preparationHours_1;
    
    @FindBy(xpath="//p[contains(@name,'ServiceAgreementAmount')]")
    public List<WebElement> totalServiceAmount;
    
    
    
    @FindBy(xpath="//p[contains(@name,'ServiceAgreementAmount')]")
    public WebElement totalServiceAmount_1;
    
    @FindBy(name="$PpyWorkPage$pCRIndividual$pPreparationAgreementAmount")
    public WebElement totalPreparationAount;   
    
    @FindBy(xpath="//p[contains(@name,'PreparationAgreementAmount')]")
    public List<WebElement> totalPreparationAmount;
    
    @FindBy(xpath="//p[contains(@name,'PreparationAgreementAmount')]")
    public WebElement totalPreparationAmount_1;
    
    @FindBy(name="$PpyWorkPage$pCRIndividual$pTravelAgreementAmount")
    public WebElement totalTravelAmount;
    
    @FindBy(xpath="//p[contains(@name,'TravelAgreementAmount')]")
    public List<WebElement> totalTravelAmount_1;

    @FindBy(name="$PpyWorkPage$pCRIndividual$pOA_TotalNoOfHours")
    public WebElement totalNoOfHours;
  
    @FindBy(xpath="//div[text()='Back']")
    public WebElement backbutton;
    
    @FindBy(xpath="//p[contains(@name,'TotalNoOfHours')]")
    public List<WebElement> totalNoOfHours_1;
    
    @FindBy(xpath="//div[label[@for='TotalAgreementAmount']] //p")
    public WebElement totalCompensationAmount;
    
    @FindBy(xpath="//button//div[contains(text(),'Add Service Provider')]")
    public WebElement addServiceProviderButton;
    
    @FindBy(xpath="//button//div[contains(text(),'Add new Service Provider')]")
    public WebElement addNewServiceProviderButton;
    
    @FindBy(xpath="//button//div[contains(text(),'Search Service Provider')]")
    public WebElement searchServiceProvider;
    
    @FindBy(xpath="//div[@node_name='OA_CRIndividualName']//input[@id='LastName']")
    public WebElement lastNameSearchfieldinAddServiceProvider;
    
    @FindBy(css="button[title='Click to search for HCPs']")
    public WebElement searchButtoninAddServiceProvider;
    
    @FindBy(xpath="//input[@id='$PServiceProvider$ppxResults$l$ppyRowSelected']")
    public WebElement selectRadioButtoninAddServiceProvider;

	public By cRServiceProvideLabel = By.xpath("//div[label[@for='CRServiceProvider']]//span");
	
	public By serviceProviderSpecialtyRole = By.xpath("//div[label[@for='FMVSpecialty']]//span");
	
	public By numberOfYearsOfExperience = By.xpath("//tr[td[label/span[contains(text(),'Number of Years of Experience (Post-Residency for Physicians')]]]/td[3]//span");
	
	public By defaultHourlyRate = By.xpath("//div[label[@for='ServiceRate']]//span/span");
    
	@FindBy(xpath = "//tr[td[nobr[label/span[contains(text(),'Currency in which the Speaker/Consultant is to be paid')]]]]//td[3]//span")
	public WebElement defaultCurrency;
	
	@FindBy(css="button[title='Complete this assignment']")
	public WebElement nextButton;
	
	@FindBy(css="td[class='calcell today selected'] a")
	public WebElement currentDate;
	
	@FindBy(css="td[class='calcell'] a")
	public List<WebElement > datesList;
	
	@FindBy(xpath="//button[starts-with(@name,'OA_ActivateAgreement')]")
	public WebElement uploadActivateAgreement;
	
	@FindBy(css="table[id='EXPAND-OUTERFRAME'] nobr a")
	public WebElement plusSymbolForServiceToBeProvided;
	
	@FindBy(id="SearchIndividualOptions")
	public WebElement searchOptionsDropDown;
	
	@FindBy(id="NPINumber")
	public WebElement npiNumberField;
	
	@FindBy(id="GEID_UI")
	public WebElement geIdTextField;
	
	@FindBy(css="div[data-node-id='OA_FMVQuestionList'] td span")
	public List<WebElement> fmvQuestionsList;
	
	@FindBy(css="//button//div[contains(text(),'Search')]")
	public WebElement searchButtonInAddServiceProvider;
	
	@FindBy(name="PegaGadget0Ifr")
	public WebElement pegaGadgetFrame;
	
	@FindBy(css="table[id='gridLayoutTable'] table[prim_page='pyWorkPage'] td[data-attribute-name='Select'] input:nth-of-type(2)")
	public List<WebElement> serachResultsInSearchProvider;
	
	//Add New Individual
	//@FindBy(xpath="//button[@title='If contracted individual is not in AST CR Database']")
	@FindBy(xpath="//div[contains(text(),'Add New Individual')]")
	public WebElement addNewIndividualButton;
	
	@FindBy(xpath="//span[@id='modaldialog_hd_title']")
	public WebElement titleAddNewCRIndividual;
	
	@FindBy(xpath="//div[@node_name='OA_CRIndividualName']//input[@id='FirstName']")
	public WebElement firstNameAddNewIndividual;
	
	@FindBy(id="CountryCode")
	public WebElement countryAddNewIndividual;	

	@FindBy(id="PrimarySpecialtyCode")
	public WebElement primarySpecialtyAddNewIndividual;
	
	@FindBy(id="PractitionerTypeCode")
	public WebElement practitionerTypeAddNewIndividual;
	
	@FindBy(id="EmployerInstitutionName")
	public WebElement employerInstitutionNameAddNewIndividual;
	
	@FindBy(id="StreetAddress1")
	public WebElement addressAddNewIndividual;
	
	@FindBy(id="City")
	public WebElement cityAddNewIndividual;
	
	@FindBy(id="PostalCode")
	public WebElement postalCodeAddNewIndividual;
	
	//Add New Organization
	//@FindBy(xpath="//button[@title='Click to add a new Covered Recipient Organization to the Event']")
	@FindBy(xpath="//div[contains(text(),'Add New Organization')]")
	public WebElement addNewOrganizationButton;
	
	@FindBy(id="Organizationtype")
	public WebElement organizationType;
	
	@FindBy(id="OrganizationName")
	public WebElement organizationName;
	
	//Amend Agreement
	@FindBy(id="SearchAgreementOptions")
	public WebElement searchAgreementOptions;
	
	@FindBy(id="AgreementID")
	public WebElement agreementID;
	
	@FindBy(xpath="(//div[contains(text(),'Search')])[1]")
	public WebElement searchInAmendAgreement;
	
	@FindBy(xpath="(//input[@id='$PpyWorkPage$pAgreementList$l$ppyRowSelected'])[1]")
	public WebElement selectAgreementRadioButton;
	
	public By verifyRadioButtonPresent = By
			.xpath("//table[@pl_prop=\".AgreementList\"]//tr[2]//input[2]");
	
	public By verifyAmendText = By.xpath("//strong[contains(text(),'What do you wish to amend')]");
	
	@FindBy(xpath="//label[@for='ParentAgreementID']")
	public WebElement amendedFrom_ParentAgreementID;
	
	@FindBy(id="AmendServiceDetailsNo")
	public WebElement amendServiceDetailsNo;
	
	@FindBy(id="AmendServiceDetailsYes")
	public WebElement amendServiceDetailsYes;
	
	@FindBy(id="AmendContracttermYes")
	public WebElement amendContracttermYes;
		
	@FindBy(id="AmendContracttermNo")
	public WebElement amendContracttermNo;
	
	@FindBy(id="AmendFMVDetailsYes")
	public WebElement amendFMVDetailsYes;
	
	@FindBy(id="AmendFMVDetailsNo")
	public WebElement amendFMVDetailsNo;

	public By amendServiceDetailsText = By.xpath("//span[contains(text(),'Proposed Amendment Language')]");
	
	@FindBy(id="ServiceProvided1")
	public WebElement proposedServiceToBeProvided;
	
	@FindBy(id="ProposedPaymentDetails")
	public WebElement ProposedPaymentDetails;
	
	public By amendContractTermText = By.xpath("//span[contains(text(),'Enter the Actual Effective Date')]");
	
	@FindBy(xpath="//div[@show_when=\".SearchAgreementOptions = 'Covered Recipient â€“ Individual'\"]//button")
	public WebElement searchForCRIndividualAmend;
	
	@FindBy(xpath="//div[@show_when=\".SearchAgreementOptions = 'Covered Recipient â€“ Organization'\"]//button")
	public WebElement searchForCROrganizationAmend;
	
	@FindBy(xpath="//button//div[contains(text(),'Search Agreement')]")
	public WebElement searchAgreementAmendButton;
	
	public By noCasesMessage = By.xpath("(//div[contains(text(),'No cases')])[1]");
	
	public By serviceToBeProvided_Readonly = By
			.xpath("//textarea[starts-with(@id,'ServiceProvided')]");
	
	public By paymentDetails_Readonly = By.xpath("//textarea[starts-with(@id,'PaymentDetails')]");
	
	public By agreementTitle_Readonly = By
			.xpath("//label[@for='EventTitle']//following-sibling::div[@class='field-item dataValueRead']");
	
	public By originalEffectiveDate_Readonly = By
			.xpath("//label[contains(text(),'Original Effective Date')]//following-sibling::div[@class='field-item dataValueRead']");
	
	public By originalExpirationDate_Readonly = By
			.xpath("//label[contains(text(),'Original Expiration Date')]//following-sibling::div[@class='field-item dataValueRead']");
	
	public By serviceCompensationToBePaid_Readonly = By
			.xpath("//label[@for='CheckServiceComp']//following-sibling::div[@class='field-item dataValueRead']");
	
	public By FMVCountry_Readonly = By
			.xpath("//label[@for='FMVPractType']//following-sibling::div[@class='field-item dataValueRead']");
	
	public By FMVSpecialityRole_Readonly = By
			.xpath("//label[@for='FMVSpecialty']//following-sibling::div[@class='field-item dataValueRead']");
	
	public By FMVhourlyRate_Readonly = By
			.xpath("//label[@for='ServiceRate']//following-sibling::div[@class='field-item dataValueRead']");
	
	public By FMVTravelRate_Readonly = By
			.xpath("//label[@for='TravelRate']//following-sibling::div[@class='field-item dataValueRead']");
	
	public By FMVTotalAgreementAmount_Readonly = By
			.xpath("//label[@for='TotalAgreementAmount']//following-sibling::div[@class='field-item dataValueRead']");
	
	@FindBy(id="ModalButtonCancel")
	public WebElement cancelButtonInModelPopUpWindow;
	
	@FindBy(xpath="//div[@node_name='OA_AgreementSearch']//i/img")
	public WebElement searchAmend_Header;
	
	public By searchCriteriaBanner = By.xpath("//div[@class='content-inner ']/ul");
	
	@FindBy(id="SearchIndividualOptions")
	public WebElement searchIndividualOptions;
	
	@FindBy(id="GEID_UI")
	public WebElement GEID_textField;
	
	@FindBy(id="NPINumber")
	public WebElement NPINumber_textField;
	
	@FindBy(xpath="//label[contains(text(),'Original Effective Date')]/following-sibling::div/span")
	public WebElement originalEffectiveDate;
	
	@FindBy(xpath="//label[contains(text(),'Original Expiration Date')]/following-sibling::div/span")
	public WebElement originalExpirationDate;
	
	@FindBy(id="EffectiveDate")
	public WebElement effectiveDate;
	
	@FindBy(id="ExpirationDate")
	public WebElement expirationDate;
	
	@FindBy(xpath="(//div[@string_type='paragraph']//span)[4]")
	public WebElement banner_TravelSection;
	
	@FindBy(xpath="//span[contains(text(),'Certification')]")
	public WebElement certification_Section;
	
	@FindBy(xpath="//div[@string_type='paragraph']//i")
	public WebElement certification_Language;
	
	//Consulting Event
	@FindBy(xpath="//input[@id='OA_AgreementTypeMaster Agreement'][@type='radio']")
	public WebElement masterAgreement;
	
	@FindBy(id="OA_AgreementTypeSingle Event Agreement")
	public WebElement singleEventAgreement;
	
	@FindBy(xpath="//ul[@class='pageErrorList layout-noheader-errors']/li")
	public WebElement errorMessage;
	
	@FindBy(xpath="//button[starts-with(@name,'OA_IPPCOEApproveSec_D_UploadDocument_pa')]")
	public List<WebElement> uploadButtonInIPPCOEApproveSection;	
	
	@FindBy(css="li[aria-label='CR Information'] span")
	public WebElement crInformationTab;
	
	@FindBy(xpath="//button[contains(@name,'OA_CRIndividualSearch_pyWorkPage')]//div[contains(text(),'Search')]")
	public WebElement searchButtonInCRIndividualPage;
	
	@FindBy(xpath="//button//div[contains(text(),'Add New Individual')]")
	public WebElement addNewIndividualButtonInCRIndividual;
	
	@FindBy(css="input[type='radio']")
	public WebElement radioButtonForSearchResult;
	
	@FindBy(css="div[node_name='OA_ContractedIndivs'] tr>td p")
	public List<WebElement> crTablesValues;
	
	@FindBy(css="li[aria-label='Event Information'] span")
	public WebElement eventInformationTab;
	
	@FindBy(id="EventJustification")
	public WebElement eventJustificationField;
	
	@FindBy(id="VenueType")
	public WebElement venueTypeDropDown;
	
	@FindBy(id="VenueName")
	public WebElement venueNameField;
	
	@FindBy(id="VenueCountry")
	public WebElement venueCountryDropDown;
	
	@FindBy(id="VenueCity")
	public WebElement venueCityField;	
	
	@FindBy(xpath="//textarea[starts-with(@id,'AgreementJustification')]")
	public List<WebElement> businessJustificationForEngagementTextAreasList;
	
	@FindBy(xpath="//textarea[starts-with(@id,'AdditionalAgreementJustification')]")
	public List<WebElement> gehcProductsOrServicesIncludedTextAreasList;
	
	@FindBy(xpath="//textarea[starts-with(@id,'Rationale')]")
	public List<WebElement> consultantQualificationSummaryTextAreasList;
	
	@FindBy(xpath="//textarea[starts-with(@id,'ServiceProvided')]")
	public List<WebElement> serviceToBeProvidedTextAreasList;
	
	@FindBy(xpath="//textarea[starts-with(@id,'PaymentDetails')]")
	public List<WebElement> paymentDetailsTextAreasList;
	
	@FindBy(css="table[id='EXPAND-OUTERFRAME'] nobr a")
	public List<WebElement> plusSymbolToAddServiceToBeProvided;
	
	@FindBy(xpath="//button//div[contains(text(),'Add Payee')]")
	public List<WebElement> addPayeeButtonsList;
	
	@FindBy(id="UseSSPIntegration")
	public WebElement ifSSPPOPaymentMethodInvolvedDropDown;
	
	@FindBy(xpath="//input[contains(@name,'CostCentre')]")
	public WebElement expenseDropDown;
	
	@FindBy(xpath="//input[@name='$PpyWorkPage$pBudgetBreakdown$l1$pExpenseCost']")
	public WebElement amount;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pCurrencyCode")
	public WebElement currencyCodeDropDown;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pCostCentre")
	public WebElement costCenter;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pDescription")
	public WebElement description;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pPaymentMethod")
	public WebElement paymentMethodDropDown;
	
	@FindBy(name="$PpyWorkPage$pBudgetBreakdown$l1$pVendorName")
	public WebElement vendorName;
	
	@FindBy(id="OA_AgreementTypeSingle Event Agreement")
	public WebElement singleEventAgreementRadioButton;	
	
	@FindBy(xpath="//button[@title='Complete this assignment']")
	public WebElement submitButton;
	
	@FindBy(xpath="//button//div[contains(text(),'Vendor Search')]")
	public WebElement vendorSearchButton;
	
	@FindBy(id="VendorName")
	public WebElement vendorNameTextFieled;
	
	@FindBy(id="GSL")
	public WebElement gslTextField;
	
	@FindBy(id="Country")
	public WebElement countryDropDown;
	
	@FindBy(xpath="//div[@pyclassname='PegaLS-Data-CR-CRVendorSearch']//button//div[contains(text(),'Search')]")
	public WebElement searchButtonInVendorSearch;
	
	@FindBy(css="input[name='$PpyListViewContentPage$ppySingleSelection']")
	public List<WebElement> searchListRadioButtonsInVendorSearchPage;
	
	@FindBy(name="$PCRDVendor$pCountry")
	public WebElement countryDropDownInVendorSearch;
	
	@FindBy(css="li[aria-label='Gather Budget Details'] span")
	public WebElement gatherBudgetDetailsTab;
	
	@FindBy(xpath="//a[contains(text(),'SSP Details')]")
	public WebElement sspDetailsLink;
	
	@FindBy(id="SSPCreatedNo")
	public WebElement isTheVendorCreatedInSSPNORadioButton;
	
	@FindBy(id="SSPCreatedYes")
	public WebElement isTheVendorCreatedInSSPYESRadioButton;
	
	@FindBy(id="UNSPSCCode")
	public WebElement uNSPSCCodeDropDown;
	
	@FindBy(id="RequestorSSO")
	public WebElement pORequesterOrOwner;
	
	@FindBy(id="PreparerSSO")
	public WebElement poPreparerSSO;
	
	@FindBy(xpath="//button[starts-with(@name,'OA_SSPDetails_Part')]")
	public List<WebElement> searchButtonListInSSPDetailsWindow;
	
	@FindBy(name="$PldapResults$ppxResults$l1$ppyRowSelected")
	public WebElement radioButtonForPoRequesterAndPoApprover;
	
	@FindBy(xpath="//div[@node_name='pyOverlayTemplate']//button[contains(text(),'Submit')]")
	public WebElement submitButtonInPoRequestetAndPoApproverResult;
	
	@FindBy(xpath="//div[@node_name='pyOverlayTemplate']//button[contains(text(),'Cancel')]")
	public WebElement cancelButtonInPoRequestetAndPoApproverResult;
	
	@FindBy(id="SearchVendorOptions")
	public WebElement serachOptionsDropDown;
	
	@FindBy(xpath="//button//div[contains(text(),'Vendor Search')]")
	public WebElement vendoreSearchButton;
	
	@FindBy(xpath="//button//div[contains(text(),'Vendor Search')]")
	public List<WebElement> vendoreSearchButton_sendback;
	
	@FindBy(id="State")
	public WebElement stateDropDown;
	
	@FindBy(xpath="//button//div[contains(text(),'Add Vendor')]")
	public WebElement addVendorButton;
	
	@FindBy(xpath="//button//div[contains(text(),'Get OU')]")
	public WebElement getOUButton;
	
	@FindBy(id="Org_ID")
	public WebElement getOUDropDown;
	
	@FindBy(css="table[param_name='EXPANDEDSubSectionOA_ConfirmMessagesB'] nobr>p:nth-of-type(2)")
	public WebElement confirmationMessageOnSubmission;
	
	@FindBy(xpath="//div[@node_name='pyOverlayTemplate']/div//button[contains(text(),'Submit')]")
	public WebElement submitButtonInVendoreSearchPage;
	
	@FindBy(xpath="//table//tr[starts-with(@id,'$PD_Upload')]/td[1]//span")
	public List<WebElement> documentTitleInUploadsTab;
	
	@FindBy(xpath="//input[@id='ServiceHours']")
	public List<WebElement> serviceHours_MasterAgreement;
	
	@FindBy(xpath="//input[@id='PreparationHours']")
	public List<WebElement> preparationHours_MasterAgreement;
	
	@FindBy(xpath="//input[@id='TravelHours']")
	public List<WebElement> travelHours_MasterAgreement;
	
	@FindBy(xpath="//input[@id='OA_ServiceBusiness Justification for EngagementRequired']")
	public List<WebElement> serviceBusinessJustification;	

	@FindBy(id="OA_Servicetest")
	public WebElement serviceTest;
	
	@FindBy(xpath="//div[@node_name='OA_CRIndividual']//table[@class='gridTable ']//tr//td/div")
	public List<WebElement> crIndividuals;
	
	@FindBy(xpath="//div[@node_name='OA_CROrganization']//table[@class='gridTable ']//tr//td/div")
	public List<WebElement> crOrganization;
	
	@FindBy(xpath="//label[contains(text(),'CR Organization')]")
	public WebElement crOrganizationTab;
	
	public By masterAgreementDetails = By.xpath("//label[contains(text(),'Master Agreement Details')]");
	
	@FindBy(xpath="//select[@id='PaymentMethod']")
	public List<WebElement> paymentMethods;
	
	@FindBy(xpath="//input[@id='CostCentre']")
	public List<WebElement> costCenterList;
	
	@FindBy(xpath="//textarea[starts-with(@id,'Description')]")
	public List<WebElement> descriptionsList;
	
	@FindBy(xpath="//textarea[starts-with(@id,'VendorName')]")
	public List<WebElement> vendorNamesList;
	
	 @FindBy(xpath="//input[contains(@id,'pySelected')]")
	    public List<WebElement> finalizeORReconcileBudgetCeckBox;
	    
	    @FindBy(xpath="//div/div[contains(text(),'Reconcile')]")
	    public List<WebElement> btnReconcile;
	    
	    @FindBy(xpath="//input[@value='No'][contains(@id,'PartialPaymentSelectedNo_ri_')]")
	    public List<WebElement> partialPaymentSelectedNo;
	    
	    @FindBy(xpath="//input[@id='BlanketPOFinalPaymentNo']")
	    public WebElement blanketPOFinalPaymentNo;
	    
	    @FindBy(xpath="//span/input[@id='OA_IsNoShowCRsNo']")
	    public WebElement oA_IsNoShowCRsNo;
	    
	    @FindBy(xpath="//select[@id='OA_AllocationType']")
	    public WebElement oA_AllocationType;
	    
	    @FindBy(xpath="//img[@class='inactvIcon']")
	    public List<WebElement> closureDateCalander;
	    
	    @FindBy(xpath="//div[@id='PEGA_GRID1']//table//tr[starts-with(@id,'$PD_Upload')]/td[1]//span")
	    public List<WebElement> documentTitleInUploadsTab_FinzalizeReconcile;	    	      

	    @FindBy(xpath="//div[@id='PEGA_GRID1']//*[starts-with(@id,'$PD_Upload')]/td[3]/div/span/button")
	      public List<WebElement> uploadButtonList_FinalizeReconcile;
		
	    public By servBusinessJust = By.xpath("//div[@node_name='OA_FMV_Master_Rate']//input");
	    
	    public By uploadButton = By.xpath("//button//div[contains(text(),'Upload')]");
	    
	    @FindBy(xpath="//a[contains(@title,'Delete')]")
	    public WebElement deleteIcon;
	    
	    @FindBy(xpath="(//a[contains(@title,'Delete')])[4]")
	    public WebElement deleteCR;
	    
	    public By verifyUpdatePoNumber = By.xpath("//div[text()='Update PO Number']");
	  
	    @FindBy(xpath="//div[text()='Update PO Number']")
	    public WebElement updatePONumber;
	    
	    @FindBy(xpath="//div[text()='Update PO Number']")
	    public WebElement sspPONumber;
	    
	    @FindBy(xpath="//div/span[text()='New']")
	    public WebElement verifyNew;
	    
	    @FindBy(xpath="//i/img[contains(@title,'HOW')]")
	    public List<WebElement> crInformationBanner;
	    
	    @FindBy(xpath="//input[@id='DescriptionofItem']")
	    public WebElement descriptonOfItem;
	    
	    @FindBy(xpath="//input[@id='PurposeofTheItem']")
	    public WebElement purposeofTheItem;
	    
	    @FindBy(xpath="//select[@id='ExpenseType']")
	    public List<WebElement> expenseTypeDropdown;
	    
	    @FindBy(xpath="//input[@id='ExpenseCost']")
	    public List<WebElement> expenseCost;
	    
	    @FindBy(xpath="//a[@title='Add Item ']")
	    public WebElement addItem;
	    
	    @FindBy(xpath="//input[@id='SSPCreatedNo']")
	    public List<WebElement> sspCreateNo;
	  //input[@id='SSPCreatedYes']
	    @FindBy(xpath="//input[@id='SSPCreatedYes']")
	    public List<WebElement> sspCreateYes;
	    	    
	    @FindBy(xpath="(//select[@id='PaymentMethod'])[4]")
	    public WebElement sspoDropdown;
	    
	    @FindBy(xpath="//select[@id='PaymentMethod']")
	    public List<WebElement> poDropdown;
	    
	    public By vendorCreatedSSPO = By.xpath("//span[(text()='Is the vendor created in SSP?')]");
	   	    
	    @FindBy(xpath="//input[@id='CountOfPlannedAttendees']")
	    public WebElement eventAttendees;
	    	 	    
	    @FindBy(xpath="//select[@id='EventJustification']")
	    public WebElement eventJustification;
	    
	    @FindBy(xpath="//select[@id='OA_MultiRegionalEvent']")
	    public WebElement event_multiRegional;
	    
	    @FindBy(xpath="//textarea[@id='AdditionalEventJustificationDetails']")
	    public WebElement event_JustificationDetails;
	    
	    @FindBy(xpath="//*[*/text()='Business Information']")
	    public WebElement tab_businessinformation;
	    
	    @FindBy(xpath="//*[*/*[text()='Meals']]")
	    public WebElement lbl_meals;
	    
	    @FindBy(xpath="//*[*/*[text()='Speakers']]")
	    public WebElement lbl_speakers;
	    
	    @FindBy(xpath="//*[*/*[text()='Registration Fee']]")
	    public WebElement lbl_regrestrationFee;
	    
	    @FindBy(xpath="//*[*/*[text()='Non-educational gifts']]")
	    public WebElement lbl_nonEducationalgifts;
	    
	    @FindBy(xpath="//*[*/*[text()='Additional AST Workflows']]")
	    public WebElement lbl_additionalASTWorkFlows;
	    
	    @FindBy(xpath="//*[*/*[text()='Will a Speaker or Consultant be invited to this event?']]//span")
	    public WebElement lbl_willspeaker;
	    
	    @FindBy(xpath="//*[*/*[text()='Will meals and beverages be provided to attendees?']]//span")
	    public WebElement lbl_willmeal;
	    
	    @FindBy(xpath="//*[*/*[text()='Will GEHC Pay for HCP 3rd Party Conference Attendee Registration Fees?']]//span")
	    public WebElement lbl_willRegistrationFees;
	    
	    @FindBy(xpath="//*[*/*[text()='Will GEHC provided non-educational gifts to HCPs and/or GOs?']]//span")
	    public WebElement lbl_willNonEducationalGifts;
	    
	    @FindBy(xpath="//*[*/*[text()='Is there an AST Sponsorship/Tradeshow or other AST event workflow associated with this request?']]//span")
	    public WebElement lbl_willASTWorkFlows;
	    
	    
	    @FindBy(xpath="//*[*/*[text()='Will a Speaker or Consultant be invited to this event?']]//select")
	    public WebElement selectSpeaker;
	    
	    @FindBy(xpath="//*[*/*[text()='Will meals and beverages be provided to attendees?']]//select")
	    public WebElement selectMeals;
	    
	    @FindBy(xpath="//*[*/*[text()='Will GEHC Pay for HCP 3rd Party Conference Attendee Registration Fees?']]//select")
	    public WebElement selectRegistrationFees;
	    
	    @FindBy(xpath="//*[*/*[text()='Will GEHC provided non-educational gifts to HCPs and/or GOs?']]//select")
	    public WebElement selectNonEducationalGifts;
	    
	    @FindBy(xpath="//*[*/*[text()='Is there an AST Sponsorship/Tradeshow or other AST event workflow associated with this request?']]//select")
	    public WebElement selectASTWorkFlows;
	    
	    @FindBy(xpath=" //*[*/*[text()='Select number of speakers']]//select")
	    public WebElement selectNumberofSpeaker;
	    
	    @FindBy(xpath=" //*[*/*[text()='Does Speaker have a Master Agreement in AST?']]//select")
	    public WebElement selectMasterAgreementSpeaker;
	    
	    @FindBy(xpath="//*[*/*[text()='Estimated number of attendees receiving meal (including GE Employees and Non-HCPs/GOs)?']]//input")
	    public WebElement mealEstimatedNumberOfAttendees;
	    
	    @FindBy(xpath="//*[*/*[text()='Estimated amount per person?']]//input")
	    public WebElement mealEstimatedAmount;
	    
	    @FindBy(xpath="//*[*/*[text()='Number of HCP/GO Attendees requiring registration fees?']]//input")
	    public WebElement numberofHCP_GoAttendes;
	    
	    @FindBy(xpath="//*[*/*[text()='Registration fee per Person?']]//input")
	    public WebElement registrationfeeperPerson;
	    
	    @FindBy(xpath="//*[*/*[text()='Is HCP Attendee’s Institution aware that fee is to be paid by GEHC?']]//select")
	    public WebElement isHCPAttendeesFeeisPaidbyGEHC;
	    
	    @FindBy(xpath="//*[*/*[text()='Describe the gift, including context and purpose']]//textarea")
	    public WebElement describeTheGift;
	    
	    @FindBy(xpath="//*[*/*[text()='Total number of HCPs/GOs receiving gift?']]//input")
	    public WebElement totalNoOfHCPGiftsReceived;
	    
	    @FindBy(xpath="//*[*/*[text()='Estimated amount of gift per person?']]//input")
	    public WebElement estimatedAmoutGiftperPerson;
	    
	    @FindBy(xpath="//*[*/*[text()='Will GEHC know the identities of the gift recipients?']]//select")
	    public WebElement willGEHCidentifyGifts;
	    
	    @FindBy(xpath="//*[*/*[text()='Does it have a GE log (is it branded)?']]//select")
	    public WebElement doesitHaveGElog;
	    
	    @FindBy(xpath="//textarea[@id='WorkFlowNumber']")
	    public WebElement enterASTids;
	    
		public By travelFee = By.xpath("//span[contains(text(),'Travel Fee')]");
		
		 @FindBy(xpath="//input[@id='OA_ReassignName_SSO']")
		 public WebElement reassignTo;
		    
		
		 @FindBy(xpath="//input[@id='SSPPONumber']")
		 public WebElement ssPONumber;
		 
		 
		 @FindBy(xpath="//*[*/*[text()='Number of total visits']]//input")
		 public List<WebElement> numberofTotalVisitors;
		 
		 @FindBy(xpath="//*[*/*[text()='Fair Market Value(FMV) payment per visit']]//input")
		 public List<WebElement> fmvPaymentperVisit;
		 
		 @FindBy(xpath="//*[*/*[text()='Total FMV Compensation']]//p")
		 public List<WebElement> totalFMVCompensation_label;
		 
		 @FindBy(xpath="//*[*/*[text()='FMV Justification']]//input")
		 public List<WebElement> fmvJustification;
		 

		 @FindBy(xpath="//*[*/*[text()='Name']]//input")
		 public List<WebElement> name;
		 
		 @FindBy(xpath="//input[@title='ETRODE SUPPLY']")	
		 public WebElement radioButtonForVendor;


		 @FindBy(xpath="(//div[contains(text(),'Search')])[1]")
		 	
		 public WebElement summarySearchButton;
		 	
		 	

		 @FindBy(xpath="(//div[contains(text(),'Upload')])[2]")
		 	
		 public WebElement summaryUploadButton;


		 @FindBy(xpath="//select[@id='ExpenseType']")

		 public List<WebElement> expenseType;


		 @FindBy(xpath="//div[contains(text(),'Vendor Search')]")
		 	
		 public List<WebElement> vendorSearchList;	
	    
}
