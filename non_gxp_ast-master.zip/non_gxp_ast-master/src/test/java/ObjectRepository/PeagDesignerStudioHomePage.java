package ObjectRepository;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import BaseClass.ClassInitilizer;


public class PeagDesignerStudioHomePage extends ClassInitilizer
{
	public PeagDesignerStudioHomePage(WebDriver driver)
	{
		super(driver);
	}
	
	// Currently used
	
	/*public static final String AST_DEV_2="AST @ DEV2 [ RS 01-08 ]";
	public static final String LAUNCH="Launch";
	public static final String CREATE="Create";
	public static final String RESOURCES="Resources";
	public static final String OPERATER_NAME="Pooja Dharmapal";
	public static final String DESIGNERSTUDIO="DesignerStudio";
	public static final String SYSTEM="System";
	public static final String OPERATIONS="Operations";
	public static final String LOGS="Logs";
	
	public static final String OPEN_OVERVIEW="Open Overview";
	public static final String OPEN_APPLICATION="Open Application";
	public static final String OPEN_APPLICATION_SKIN="Open Application Skin";
	public static final String NEW_APPLICATION="New Application";
	public static final String SWITCH_APPLICATION="Switch Application";
	public static final String SWITCH_WORK_POOL="Switch Work Pool";
	
	public static final String MANAGER="Manager";
	public static final String AST_USER_PORTAL="AST User Portal";
	
	public static final String LOG_OFF="Log off";*/
	public static final String ONE_AST_USER_PORTAL="One AST User Portal";
	
	 /**//**
	    * To load Login and to verify page title
	    *//*
	   @Override
	   public void isLoaded() {
	      verifyPageTitle("Pega Designer Studio");
	   }*/
	
	/*@FindBy(css = "div[node_name='pzStudioHeader']>div>div>div>div>div>div>span>a")
	public List<WebElement> globalMainLinks;
	
	@FindBy(id = "pySearchText")
	public WebElement searchTextField;
	
	@FindBy(css = "div[node_name='pzStudioHeaderTools']>div>div>div>div>div>div>span>i")
	public WebElement searchButtonField;
	
	@FindBy(css="span[class='menu-item-title']")
	public List<WebElement> subLinks;
	
	@FindBy(css="td[id='ItemMiddle']")
	public List<WebElement> childLinks;*/
	
	@FindBy(css="div[node_name='pzDesignerStudioMenu']>div>div>div>div>div>div>span>i")
	public WebElement designerStuido;
	
	@FindBy(css="div[node_name='pxLogsTools'] a")
	public List<WebElement> logUtilityLinks;
	
	@FindBy(xpath="//table//tr//a")
	public List<WebElement> logFiles;
	
	@FindBy(id="PegaGadget0Ifr")
	public WebElement pegaGadet0Ifr;
	
	@FindBy(name="linesPerPage")
	public WebElement linesPerPage;
	
	@FindBy(name="filterString")
	public WebElement filterBy;
	
	@FindBy(xpath="//input[@value='Apply']")
	public WebElement apply_Button;
	
	@FindBy(xpath="//div[label[@for='IPPCOEName']]/div/span")
	public WebElement IPPCOEName;
	
	@FindBy(xpath="//div[label[@for='DirectManagerName']]//span")
	public WebElement directManagerName;
	
	//Newly added for OLD AST Automation
	
	public static final String AST_DEV_2="AST @ DEV2 [ RS 01-08 ]";
	public static final String LAUNCH="Launch";
	public static final String CREATE="Create";
	public static final String RESOURCES="Resources";
	public static final String OPERATER_NAME="Pooja Dharmapal";
	
	public static final String OPEN_OVERVIEW="Open Overview";
	public static final String OPEN_APPLICATION="Open Application";
	public static final String OPEN_APPLICATION_SKIN="Open Application Skin";
	public static final String NEW_APPLICATION="New Application";
	public static final String SWITCH_APPLICATION="Switch Application";
	public static final String SWITCH_WORK_POOL="Switch Work Pool";
	
	public static final String MANAGER="Manager";
	public static final String AST_USER_PORTAL="AST User Portal";
	
	public static final String LOG_OFF="Log off";
	
	 /**
	    * To load Login and to verify page title
	    */
	   @Override
	   public void isLoaded() {
	      verifyPageTitle("Pega Designer Studio");
	   }
	
	@FindBy(css = "div[node_name='pzStudioHeader']>div>div>div>div>div>div>span>a")
	public List<WebElement> globalMainLinks;
	
	@FindBy(id = "pySearchText")
	public WebElement searchTextField;
	
	@FindBy(css = "div[node_name='pzStudioHeaderTools']>div>div>div>div>div>div>span>i")
	public WebElement searchButtonField;
	
	@FindBy(css="td[id='ItemMiddle']")
	public List<WebElement> subLinks;
	
	@FindBy(css="td[id='ItemMiddle']")
	public List<WebElement> childLinks;
	
	@FindBy(id="previousYear")
	public WebElement previousYearLink;
	
	@FindBy(id="nextYear")
	public WebElement nextYearLink;
	
	@FindBy(id="previousMonth")
	public WebElement previousMonthLink;
	
	@FindBy(id="nextMonth")
	public WebElement nextMonthLink;
	
	@FindBy(css="tbody[id='controlCalBody'] td a")
	public List<WebElement> datesInCalender;
	
	@FindBy(id="calMonthCell")
	public WebElement currentMonthValue;
	
	@FindBy(id="calYearCell")
	public WebElement currentYearValue;
	
	@FindBy(css="span[id='$PpyWorkPage$pRequestStartDateSpan'] img")
	public WebElement effectiveDateCalender;	
	
	@FindBy(css="span[id='$PpyWorkPage$pRequestEndDateSpan'] img")
	public WebElement expirationDateCalender;
}
