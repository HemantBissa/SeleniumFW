package ObjectRepository;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import BaseClass.ClassInitilizer;
public class ConsultingAgreementPage extends ClassInitilizer
{
	public ConsultingAgreementPage(WebDriver driver)
	{
		super(driver);
	}
	/**
	 * To load Login and to verify page title
	 */
	@Override
	public void isLoaded()
	{
		verifyPageTitle("Aggregate Spend Management For One AST");
	}
	
	@FindBy(name="PegaGadget0Ifr")
	public WebElement pegaGadgetFrame;
	
	@FindBy(id="CRTypeIndividual")
	public WebElement individualRadioButton;
	
	@FindBy(id="CRTypeOrganization")
	public WebElement organizationRadioButton;
	
	//@FindBy(css="button[title='Complete this assignment']")
	@FindBy(xpath="//button[@title='Complete this assignment']//div[contains(text(),'Submit')]")
	public WebElement submitButton;
	
	@FindBy(css="button[title='Complete this assignment']")
	public WebElement nextButtonOrSubmitButton;
	
	@FindBy(id="SearchIndividualOptions")
	public WebElement searchOptionsDropDown;
	
	@FindBy(id="LastName")
	public WebElement lastNameTextField;
	
	@FindBy(id="PrimaryOrgName")
	public WebElement organizationNameTextField;
	
	@FindBy(id="FirstName")
	public WebElement firstNameTextField;
	
	@FindBy(id="Country")
	public WebElement countryDropDown;
	
	@FindBy(css="button[title='List Individuals matching the criteria entered']")
	public WebElement searchButtonInCRIndividual;
	
	@FindBy(css="button[title='List Organizations matching the criteria entered']")
	public WebElement searchButtonInCROrganization;

	@FindBy(css="button[title='Click to add a new Covered Recipient Individual to the Event']")
	public WebElement addNewIndividualButton;
	
	@FindBy(css="table[class='ViewTableStyle']>tbody>tr>td>input")
	public List<WebElement> searchResults;
	
	@FindBy(id="ModalButtonSubmit")
	public WebElement submitButtonInSearchResultPage;
	
	@FindBy(css="(//span[@id='ERRORMESSAGES_ALL']/ul/li)[1]")
	public WebElement errorMessageList;
	
	@FindBy(css="button[id='RLDel']")
	public WebElement cancelButtonForList;
	
	public By errorMessage=By.xpath("(//span[@id='ERRORMESSAGES_ALL']/ul/li)[1]");
	
	@FindBy(xpath="//div[@node_name='Confirm']//p[contains(text(),'Activated')]")
	public WebElement messageActivated;
	
	@FindBy(xpath="(//span[@class='ellipsis'])[1]")
	public WebElement statusOfAgreementOrEvent;
	
	@FindBy(css="li[title='CR Organization']")
	public WebElement crOrganizationTab;
	
	@FindBy(css="li[title='History']")
	public WebElement historyTab;
	
	@FindBy(xpath="//div[contains(text(),'Add Selected CR')]")
	public WebElement buttonAddSelectedCR;
	
	@FindBy(xpath="//div[contains(text(),'Next')]")
	public WebElement buttonNext;
	
	public static String CR_TABLE_CELL_VALUES="//table[@summary='Contracted Covered Individuals']//tr[2]/td[%d]/div";
	
	
}
