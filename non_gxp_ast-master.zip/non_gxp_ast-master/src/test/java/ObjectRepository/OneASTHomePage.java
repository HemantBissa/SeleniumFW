package ObjectRepository;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import BaseClass.ClassInitilizer;


public class OneASTHomePage extends ClassInitilizer
{
	public OneASTHomePage(WebDriver driver)
	{
		super(driver);
	}
	
	public static final String AST_DEV_2="AST @ DEV2 [ RS 01-08 ]";
	public static final String LAUNCH="Launch";
	public static final String CREATE="Create";
	public static final String RESOURCES="Resources";
	public static final String OPERATER_NAME="Pooja Dharmapal";
	
	public static final String OPEN_OVERVIEW="Open Overview";
	public static final String OPEN_APPLICATION="Open Application";
	public static final String OPEN_APPLICATION_SKIN="Open Application Skin";
	public static final String NEW_APPLICATION="New Application";
	public static final String SWITCH_APPLICATION="Switch Application";
	public static final String SWITCH_WORK_POOL="Switch Work Pool";
	
	public static final String MANAGER="Manager";
	public static final String AST_USER_PORTAL="AST User Portal";
	
	public static final String LOG_OFF="Log off";
	
	public static final String AGREEMENT="Agreement";
	public static final String EVENT="Event";
	public static final String NEW_CONSULTING_AGREEMENT="New Consulting Agreement";
	public static final String AMEND_CONSULTING_AGREEMENT="Amend Existing Consulting Agreement";
	public static final String NEW_CONSULTING_EVENT="New Consulting";
	public static final String NEW_EVENTPLUS_EVENT="New EventsPlus";
	
	 /**
	    * To load Login and to verify page title
	    */
	   @Override
	   public void isLoaded() {
	      verifyPageTitle("Aggregate Spend Management For One AST");
	   }
	
	@FindBy(css = "span[class='menu-item-title']")
	public List<WebElement> globalMainLinks;
	
/*	@FindBy(name = "$PpyDisplayHarness$ppyTemplateInputBox")
	public WebElement searchTextField;*/
	
	@FindBy(xpath = "//div[@node_name='pzSearchFieldWorkResponsive']//button[@id='searchMenuButton']")
	public WebElement searchButtonField;
	
	@FindBy(css="td[id='ItemMiddle']")
	public List<WebElement> subLinks;
	
	@FindBy(css="td[id='ItemMiddle']")
	public List<WebElement> childLinks;
	
	@FindBy(xpath="//div[@node_name='pzSearchFieldWorkResponsive']//input[@title='Enter text to search']")
	public WebElement searchTextField;
	
	
}
