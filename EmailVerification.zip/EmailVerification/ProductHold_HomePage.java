package ObjectRepository;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.ClassInitilizer;
import Components.ParentHold_Methods;


public class ProductHold_HomePage
{
	public ProductHold_HomePage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public static final String AST_DEV_2="AST @ DEV2 [ RS 01-08 ]";
	public static final String LAUNCH="Launch";
	public static final String CREATE="CreateButton";
	public static final String RESOURCES="Resources";
	public static final String OPERATER_NAME="Pooja Dharmapal";
	
	public static final String OPEN_OVERVIEW="Open Overview";
	public static final String OPEN_APPLICATION="Open Application";
	public static final String OPEN_APPLICATION_SKIN="Open Application Skin";
	public static final String NEW_APPLICATION="New Application";
	public static final String SWITCH_APPLICATION="Switch Application";
	public static final String SWITCH_WORK_POOL="Switch Work Pool";
	
	public static final String MANAGER="Manager";
	public static final String AST_USER_PORTAL="AST User Portal";
	
	public static final String LOG_OFF="Log off";
	
	public static final String AGREEMENT="Agreement";
	public static final String EVENT="Event";
	public static final String NEW_CONSULTING_AGREEMENT="New Consulting Agreement";
	public static final String AMEND_CONSULTING_AGREEMENT="Amend Existing Consulting Agreement";
	public static final String NEW_CONSULTING_EVENT="New Consulting";
	public static final String NEW_EVENTPLUS_EVENT="New EventsPlus";
	public static final String NEW_SHOWSITE_AGREEMENT="New ShowSite Agreement"; 
	
	 /**
	    * To load Login and to verify page title
	    */
	  /* @Override
	   public void isLoaded() {
	      verifyPageTitle("Aggregate Spend Management For One AST");
	   }*/
	
	/*@FindBy(css = "span[class='menu-item-title']")
	public List<WebElement> globalMainLinks;
	*/
/*	@FindBy(name = "$PpyDisplayHarness$ppyTemplateInputBox")
	public WebElement searchTextField;*/
	
	@FindBy(xpath = "//a[contains(text(),'Create')]")
	public WebElement CreateButtonField;
	
	/*@FindBy(css="td[id='ItemMiddle']")
	public List<WebElement> subLinks;
	
	@FindBy(css="td[id='ItemMiddle']")
	public List<WebElement> childLinks;
	
	@FindBy(xpath="//div[@node_name='pzSearchFieldWorkResponsive']//input[@title='Enter text to search']")
	public WebElement searchTextField;*/
	
	@FindBy(id="PegaGadget0Ifr")
	public WebElement frame1;
	
	@FindBy(xpath="//span[@id='TABSPAN']/table/tbody/tr/td[2]/span/label")
	public WebElement PH_ID;
	
	
	@FindBy(xpath="//td[contains(text(),'Non-Conforming Product Hold')]")
	public WebElement Non_Confirming_product;
	
	@FindBy(xpath="//div[@id='RULE_KEY']//table/tbody/tr[2]/td[7]/nobr/span")
	public WebElement PH_Status;
	
	@FindBy(id="Title")
	public WebElement PH_Title_TxtField;
	
	@FindBy(id="ExpectedClosureDate")
	public WebElement PH_ExpClosureDate_TxtField;
	
	@FindBy(id="TrackwiseReference")
	public WebElement PH_TrackwiseReference_TxtField;
	
	@FindBy(id="HoldPartNumbers1")
	public WebElement PH_PartNumber_TxtField;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[1]/div/div/span")
	public WebElement PH_Initiator_LabelField;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[2]/div/div/span")
	public WebElement PH_Category_LabelField;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[3]/div/div/span")
	public WebElement PH_Title_LabelField;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[4]/div/div/span")
	public WebElement PH_ExpClosure_Date_LabelField;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[5]/div/div/span")
	public WebElement PH_Modalitied_Affected_LabelField;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[6]/div/div/span")
	public WebElement PH_TrackWise_Inv_LabelField;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[7]/div/div/span")
	public WebElement PH_QA_Owner_LabelField;
	
	@FindBy(xpath="//div[@class='layout layout-noheader layout-noheader-default']/div/div/div/div/div/div/div/div/div/div/span")
	public WebElement PH_Change_Summary_LabelField;
		
	@FindBy(xpath="//div[@class='content layout-content-inline content-inline centered ']/div[1]/div//span/button")
	public WebElement PH_BtnNext;
	
	@FindBy(xpath="//div[@class='content layout-content-inline content-inline centered ']/div[2]/div//span/button")
	public WebElement PH_BtnCancelRecord;
	
	@FindBy(xpath = "//div[@class='content-item content-field item-4   operator-menu with-icon']/div/div/span/a")
	public WebElement userNameOfLoginMember;
	
	@FindBy(css = "a[role=link]")
	public List<WebElement> homePageMenuItemLinks;
	
	@FindBy(css = "td[id='ItemMiddle']")
	public List<WebElement> homePageMenuItemSubLinks;
	
	@FindBy(xpath = "//td[text()='Log off']")
	public WebElement logOff;
	
	/*@FindBy(css = "table[role='presentation']>tbody>tr:nth-of-type(2)>td:nth-of-type(3)>nobr>span>button")
	public WebElement yesButtonAfterLogOff;*/
	
	/*@FindBy(css = "div.field-item.dataLabelWrite.label_red_dataLabelWrite")
	public WebElement loggOffText;*/
	
	@FindBy(id = "CouldTheNonconformanceLeadToAPotentiallyHazardous")
	public WebElement potentiallyHazarous;
	
	@FindBy(id = "RiskLevel")
	public WebElement riskLevel;
	
	
	@FindBy(xpath = "//div[@class='field-item dataLabelWrite labelforbold_dataLabelWrite']")
	public WebElement riskLevelStatusMsg;
	
	@FindBy(id = "ActionDescription1")
	public WebElement actionDescription_TxtField;
	
	@FindBy(name = "$PpyWorkPage$pHoldActionsDataSource$l1$pServicePartHoldActions")
	public WebElement holdAction_TxtField;
	
	@FindBy(id = "DueDate1")
	public WebElement dueDate_TxtField;
	
	@FindBy(xpath = "//div[@class='field-item dataLabelRead labelforbold_dataLabelRead']")
	public WebElement NotALARPriskLevelStatusMsg;
	
	@FindBy(xpath="//div[@class='content set-width-auto layout-content-inline content-inline centered ']/div[2]/div//span/button")
	public WebElement BtnNext;
	
	@FindBy(xpath = "//table[@prim_page='pyWorkPage']/tbody/tr[2]/td")
	public List<WebElement> verifyTableHeader;
	
	@FindBy(id = "QA_Approver")
	public WebElement qa_Approver_Dropdown;
	
	@FindBy(xpath = "//table[@pl_prop='pgRepPgSubSectionApproval3.pxResults']//tbody//tr/td//div/span")
	public List<WebElement> valuesInAutoPopulatedFields;
	
	@FindBy(id = "ChangesMade")
	public WebElement changeSummary_TxtField;
	
	@FindBy(xpath="//div[@class='content layout-content-inline content-inline centered ']/div[2]/div//span/button")
	public WebElement BtnReview;
	
	@FindBy(xpath="//div[@class='content set-width-auto layout-content-inline content-inline centered ']/div[2]/div//span/button")
	public WebElement BtnSubmitForApproval;
	
	
	@FindBy(xpath = "(//div[@class='content-item content-label item-2   standard_dataLabelWrite'])[1]/div/div")
	public WebElement pageHeader;
	
	@FindBy(xpath="//a[@title='Add Row']")
	public WebElement BtnAddRow;
	
	
	@FindBy(xpath="//table[@pl_prop='.ImpactedPartsPageList']/tbody/tr[%d]/td/div/span/input")
	public WebElement impactedPart;
	
	@FindBy(xpath="//li[@id='current']/a/span")
	public WebElement currentScreenLabel;
	
	@FindBy(xpath="//table[@prim_page='pyWorkPage']/tbody/tr[2]/td/div/input[2]")
	public WebElement partNumberCheckBox;
	
	@FindBy(xpath="//div[@node_name='pyConfirmMessage']/div/div/div/div/div/div")
	public WebElement parentHoldConfirmMsg;
	
	@FindBy(xpath="//span[@class='ellipsis']")
	public WebElement parentHoldStatus;
	
	
	@FindBy(xpath="//div[text()='Hold ID']/../following-sibling::span/a[@title='Click to filter']")
	public WebElement holdIDFilter;
	
	@FindBy(xpath="//input[@id='pySearchText']")
	public WebElement holdIDFilterSearchTxtBox;
	
	@FindBy(xpath="//div[@aria-labelledby='filterCriteria']//button[1]")
	public WebElement holdIDFilterApplyButton;
	
	@FindBy(xpath="//div[@aria-labelledby='filterCriteria']//button[2]")
	public WebElement holdIDFilterCancelButton;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_middle content-inline_middle chevron active ']/div/div/div/span/a")
	public WebElement currentLayout;
		
	@FindBy(xpath="//textarea[@id='Comments']")
	public WebElement commentsTextBox;
	
	@FindBy(xpath="//div[@rwp='.Comments']/div[1]/div/div/span/button")
	public WebElement QARejectButton;
	
	@FindBy(xpath="//div[@rwp='.Comments']/div[2]/div/div/span/button")
	public WebElement QAApproveButton;
	
	@FindBy(xpath="//input[@aria-label='SearchPanel']")
	public WebElement PHIDTopSearchTxtBox;
	
	@FindBy(xpath="//button[@id='searchMenuButton']")
	public WebElement PHIDTopSearchButton;
	
	@FindBy(xpath="(//*[@id='$PCaseContentsPage$ppxResults$l1'])/ul/li[2]/div/a[1]")
	public WebElement PHIDLink;
	
	@FindBy(xpath="//span[@class='case_title']")
	public WebElement screenTitle;
	
	
	@FindBy(xpath="//div[@id='modaldialog_hd']/span")
	public WebElement electronicSignaturePopupTitle;
	
	@FindBy(id = "username")
	public WebElement Login_User;
	
	@FindBy(id = "password")
	public WebElement Login_Pwd;
	
	@FindBy(id = "submitFrm")
	public WebElement Login_Button;
	

	@FindBy(name = "loginfmt")
	public WebElement mailId_TxtBox;
	
	@FindBy(xpath = "//input[@value='Next']")
	public WebElement next_Button;
	
	@FindBy(xpath="//button[contains(@aria-label,'sign out')]")
	public WebElement accountLink;
	
	/*@FindBy(css="div[role='listbox'] span>span")
	public List<WebElement> inboxList;*/
	
	//@FindBy(xpath="//*[*/*[text()='Inbox']]//span[@class='lvHighlightAllClass lvHighlightSubjectClass']")
	//public List<WebElement> inboxList;*/
	
	/*@FindBy(xpath="//span[@class='lvHighlightAllClass lvHighlightSubjectClass']")
	public List<WebElement> inboxList;*/
			
	@FindBy(css="span[class='rpHighlightAllClass rpHighlightSubjectClass']")
	public WebElement mailSubject;
	
	@FindBy(xpath="//span[contains(text(),'Sign out')]")
	public WebElement signOut;
	
	@FindBy(css="table[id='tblMain'] td[id='tdLng'] a")
	public WebElement followingLink;
	
	@FindBy(xpath="//input[@type='submit']")
	public WebElement yesButton;
	
	@FindBy(css="span[class='bidi allowTextSelection']")
	public WebElement senderInformation;
	
	@FindBy(css="span[class='allowTextSelection']")
	public WebElement dateAndTimeReceived;
	
	@FindBy(css="span[autoid='_pe_b']")
	public WebElement toInformation;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[2]/div/div/span")
	public WebElement QAUserName;
	
	@FindBy(xpath="//*[*/*/*[@class='rpHighlightAllClass rpHighlightSubjectClass']]//div[@class='PlainText']")
	public WebElement mailContent;
	
	@FindBy(id="OTPEntered")
	public WebElement otpTxtBox;
	
	@FindBy(xpath="//div[@class='content layout-content-inline_grid_triple content-inline_grid_triple  ']//div[3]/div/div/span/button")
	public WebElement verifyButton;
	
	
	@FindBy(xpath="//div[@class='content layout-content-inline content-inline  ']//div[2]/div/div/span/button")
	public WebElement electronicSignSubmitButton;
	
	@FindBy(xpath="//table[@pl_prop_class='GE-FW-ProductHoldsFW-Data-ModalityData']/tbody/tr/th/div/div/div/input[2]")
	public WebElement modalitiesAffectedSelectAll;
	
	@FindBy(xpath="//a[@title='Add Row']")
	public WebElement addRowPartNumber;
	
	
	/*@FindBy(xpath="//*[contains(text(), '"+ ParentHold_Methods.ParentHoldId +"')]")
	public List<WebElement> inboxList;*/
	//[contains(text(), '"+eventName+"')]"))
	//*[(text())='"+Variable+"']/a"
}
