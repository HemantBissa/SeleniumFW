package TestScripts;

import org.testng.annotations.Test;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import Components.ParentHold_Methods;
import Components.Product_Hold_Reusable;

public class ParentHold_Flow extends BaseClass {
	// public static ProductHold_HomePage productHoldHomePage = new
	// ProductHold_HomePage(driver);
	@Test(priority = 0, description = "Verify that Super Rules Initiator is able to create the new Parent Hold.")
	public void initialize() throws Exception {
		reportDetails.put("Automation Test Script Name", this.getClass().getSimpleName());
		reportDetails.put("Automation Test Script ID (Document ID from MyWorkshop)", "DOC1234567");
		reportDetails.put("Automation Test Script Revision No(Latest Revision in MyWorkshop)", "1");
		if (ExcelReport.testData.get("ScriptExecution").trim().equalsIgnoreCase("Post Execution Report")) {
			reportDetails.put("SSO ID of Automation Test Executor",
					ExcelReport.testData.get("SSO ID of Automation Test Script Executor"));
			reportDetails.put("Name of Automation Test Executor",
					ExcelReport.testData.get("Name of Automation Test Script Executor"));
		} else {
			reportDetails.put("SSO ID of Automation Test Script Author", "503040675");
			reportDetails.put("Name of Automation Test Script Author", "Arpita Mohanty");
		}
		reportDetails.put("Test Script Type", "System Testing");
		reportDetails.put("Requirement Document ID of System", "DOC1234567");
		reportDetails.put("Requirement ID", "");
	}

	@Test(priority = 1)
	public void loginToApplication_productHoldUser() throws Exception {
		ParentHold_Methods.addPreRequisite();
		ParentHold_Methods.productHoldLogin();
	}

	@Test(priority = 2)
	public void create_PH_ID() throws Exception {
		ParentHold_Methods.create_PH_ID();

	}

	@Test(priority = 3)
	public void verify_ParentHold_Id() throws Exception {
		ParentHold_Methods.verifyPH_ID();

	}

	@Test(priority = 4)
	public void enterMandatoryFields() throws Exception {

		ParentHold_Methods.enterMandatoryFields();

	}

	@Test(priority = 5)
	public void verify_Initiator_catagoryField() throws Exception {

		ParentHold_Methods.verifyInitiatorAndCategoryFields();

	}

	@Test(priority = 6)
	public void click_Next_ButtonOnInitiatorScreen() throws Exception {
		ParentHold_Methods.clickNextButtonOnInitiatorScreen();

	}

	@Test(priority = 7)
	public void select_Potentially_HazardousFieldsValue() throws Exception {
		ParentHold_Methods.select_Potentially_Hazardous();

	}

	@Test(priority = 8)
	public void parentHold_click_Next_Button() throws Exception {
		ParentHold_Methods.click_Next();

	}

	@Test(priority = 9)
	public void select_QA_Approver() throws Exception {
		ParentHold_Methods.select_QA_Approver();

	}

	@Test(priority = 10)
	public void click_Review_Button() throws Exception {
		ParentHold_Methods.click_Review_Button();

	}

	@Test(priority = 11)
	public void verifyFieldsValueAnd_Click_SubmitForApproval_Button() throws Exception {
		ParentHold_Methods.verifyFieldsValue();

	}

	@Test(priority = 12)
	public void logOut() throws Exception {
		Product_Hold_Reusable.logOffFromApplication();
	}

	@Test(priority = 13)
	public void loginToApplication_QAApprover() throws Exception {

		Product_Hold_Reusable.productHoldQAMemberLogin();
	}
	
	@Test(priority = 14)
	public void verifyMyCasesTabColumns() throws Exception {

		ParentHold_Methods.verify_ColumnsIn_MyCasesScreen();
	}
	
	@Test(priority = 15)
	public void clickHoldIdFilterIcon() throws Exception {

		ParentHold_Methods.click_HoldId_FilterIcon();
	}
	
	@Test(priority = 16)
	public void verifyFieldsValueInParentHold() throws Exception {

		ParentHold_Methods.verifyFieldsValueInParentProductHoldScreen();
	}
	
	@Test(priority = 17)
	public void clickRejectButton() throws Exception {

		ParentHold_Methods.click_Reject_Button();
	}
	
	@Test(priority = 18)
	public void logOutFrom_QAApprover() throws Exception {
		Product_Hold_Reusable.logOffFromApplication();
	}
	
	@Test(priority = 19)
	public void loginToWith_productHoldUser() throws Exception {
		ParentHold_Methods.productHoldLoginWithHoldInitiator();
	}
	
	@Test(priority = 20)
	public void search_ParentHoldId() throws Exception {
		ParentHold_Methods.SearchParentHoldId();
	}
	
	@Test(priority = 21)
	public void clickOn_SubmitFor_ApprovalButton() throws Exception {
		ParentHold_Methods.clickOnSubmitForApprovalButton();
	}
	
	@Test(priority = 22)
	public void logOffFrom_HoldInitiatorRole() throws Exception {
		Product_Hold_Reusable.logOffFromApplication();
	}
	
	@Test(priority = 23)
	public void loginWith_QAApprover() throws Exception {

		Product_Hold_Reusable.productHoldQAMemberLogin();
	}
	
	@Test(priority = 24)
	public void search_ParentHoldId_InQAApproverScreen() throws Exception {

		ParentHold_Methods.SearchParentHoldIdInQAApproverScreen();
	}
	
	@Test(priority = 25)
	public void click_Process_link_InQAApproverScreen() throws Exception {

		ParentHold_Methods.click_Process_Link();
	}
	
	@Test(priority = 26)
	public void enterComment_ClickApprove_InQAApproverScreen() throws Exception {

		ParentHold_Methods.enterCommentAndClickOnApprove();
	}
	
	@Test(priority = 27)
	public void verifyOTPFromWabmail() throws Exception {

		ParentHold_Methods.verifyEmail();
	}
	
	@Test(priority = 28)
	public void enterOTPInElectronicSignature() throws Exception {

		ParentHold_Methods.enterOTPInElectronicSignature();
	}
	
	@Test(priority = 29)
	public void clickOnVerifyButton() throws Exception {

		ParentHold_Methods.clickOnVerifyButton();
	}
	
	@Test(priority = 30)
	public void verifyFieldsValueAfterApproval() throws Exception {

		ParentHold_Methods.verifyFieldsValueAfterApproval();
	}
	
	@Test(priority = 31)
	public void logOffFromApplicationAfterApproval() throws Exception {

		Product_Hold_Reusable.logOffFromApplication();
	}
	
	
	
}
