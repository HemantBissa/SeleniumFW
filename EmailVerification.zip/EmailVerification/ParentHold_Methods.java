package Components;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.meta.When;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import ObjectRepository.LogInPage;
import ObjectRepository.ProductHold_HomePage;

public class ParentHold_Methods extends BaseClass {

	public static ProductHold_HomePage productHoldHomePage = new ProductHold_HomePage(driver);
	public static Product_Hold_Reusable productHoldReusable = new Product_Hold_Reusable();
	public static String userNameOfLoginMember;
	public static String pageHeader;
	public static String ParentHoldId;
	public static String ParentHoldStatus;
	public static String futureDate;
	public static String title;
	public static String trackwiseReference;
	public static String partNumber;
	public static String initiatorName;
	public static String catagory;
	public static String modality;
	public static String nameOfQAMember = ExcelReport.testData.get("QAUserName");
	public static String ssoIdOfQAMember = ExcelReport.testData.get("QAuserId");
	public static String expectedCloserDate;
	public static String currentDate = Product_Hold_Reusable.getCurrentDate("dd/MM/YYYY");
	public static String actionDescr = ExcelReport.testData.get("actionDescr");
	public static String holdAction = ExcelReport.testData.get("holdAction");
	public static String affectedOrgUnitFutureDate;
	public static String actionDescrActual;
	public static String holdActionActual;
	public static String changeSummary;
	public static String holdInitiatorName = ExcelReport.testData.get("HoldInitiatorName");
	public static String userNameOfQALoginMember;
	public static WebDriver childDriver;
	public static String qaApproverName;
	public static String otp;
	public static String changeSummaryText = ExcelReport.testData.get("changeSummary");

	// catagory=ExcelReport.testData.get("url");

	public static void initializeRepository() throws Exception {

		productHoldHomePage = new ProductHold_HomePage(driver);
	}

	/**
	 * This method is for PreRequisite validation
	 * 
	 * @throws Exception
	 */
	public static void addPreRequisite() throws Exception {
		try {
			LogInPage loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "userId", "password");
			waitForObj(5000);
			userNameOfLoginMember = text(productHoldHomePage.userNameOfLoginMember);

			PDFResultReport.addPrerequisiteDetails("A",
					"1. Tester must be provided with the SSO enabled URL for accessing the 'Product Holds' application.\n"
							+ "Record the SSO enabled URL as <URL>\n"
							+ "2. Tester must be provided with the login credentials of 'Product Hold User' user role for accessing the 'Product Holds' application.\n"
							+ "Record the 'User ID': <User1>\n" + "Record the 'User Role Name1': <UserRoleName1>\n"
							+ "3.Tester must be provided with the login credentials of 'QA Approver' user role for accessing the 'Product Holds' application.\n"
							+ "Record the 'User ID: <User2>\n" + "Record the 'User Role Name2' : <UserRoleName2>\n"
							+ "4. Tester must be provided with the following data for 'Impacted Site' records \n"
							+ "Record sample Inputs as\n" + "Part number : <Part number #1>\n"
							+ "Record sample Outputs as,\n" + "Hold site:<Hold site#1>\n"
							+ "Site Hold contact: <Site Hold contact#1>\n" + "Site DL:<Site DL#1>\n"
							+ "Part Description:<Part Description#1>\n"
							+ "5. Tester must be provided with the SSO ID of 'Product Hold User' user role for accessing the 'Product Holds' application.  \n"
							+ "Record the 'User ID': <SSO ID>\n"
							+ "6. Ensure that 'QA Approver' : < User2> has access to GE mail box \n"
							+ "7.Tester must be provided with the SSO enabled URL for accessing the 'GE Mail Box' application. \n"
							+ "Record the SSO enabled URL as <URL>\n"
							+ "8. Tester must be provided with the login credentials of 'GE Mail ID Account' user role for accessing the 'GE Mail ID ' application. \n"
							+ "Record the 'User ID': <User1>\n" + "Record the 'User Role Name1': <UserRoleName1>",
					"1. Tester is provided with the SSO enabled URL for accessing the 'Product Holds' application.\n"
							+ "Recorded the SSO enabled URL as <URL>\n"
							+ "2. Tester is provided with the login credentials of 'Product Hold User' user role for accessing the 'Product Holds' Application.\n"
							+ "'User ID' is recorded as <User1>\n"
							+ "'User Role Name1' is recorded as: <UserRoleName1> \n"
							+ "3.Tester is provided with the login credentials of 'QA Approver'  user role for accessing the 'Product Holds ' application.\n"
							+ "User ID' is recorded as <User2>\n"
							+ "User Role Name2' is recorded as: <UserRoleName2> \n"
							+ "4.Tester is provided with the following data for 'Impacted Site' records \n"
							+ "Sample inputs are recorded as \n" + "Part number : <Part number #1> \n"
							+ "Sample outputs recorded as: \n" + "Hold site:<Hold site#1>\n"
							+ "Site Hold contact: <Site Hold contact#1>\n" + "Site DL:<Site DL#1>\n"
							+ "Part Description:<Part Description#1>\n"
							+ "5. Tester must be provided with the SSO ID of 'Product Hold User' user role for accessing the 'Product Holds' application.  \n"
							+ "Record the 'User ID': <SSO ID>\n" + "6.QA Approver has  <User2> access to GE mail box \n"
							+ "7. Tester is provided with the login credentials of 'GE Mail ID Account' user role for accessing the 'GE Mail ID ' application.  \n"
							+ "Record the 'User ID': <User3>",
					"1. Tester is provided with the SSO enabled URL for accessing the 'Product Holds' application.\n"
							+ "Recorded the SSO enabled URL : " + ExcelReport.testData.get("url") + " is recorded\n"
							+ "2. Tester is provided with the login credentials of 'Product Hold User' user role for accessing the 'Product Holds' Application.\n"
							+ "User ID : " + userNameOfLoginMember + "is recorded\n" + "'User Role Name1 :"
							+ "Hold Initiator" + "is recorded \n"
							+ "3.Tester is provided with the login credentials of 'QA Approver'  user role for accessing the 'Product Holds ' application.\n"
							+ "User ID : " + nameOfQAMember + "is recorded\n" + "User Role Name2 : " + "QA Approver"
							+ "is recorded \n"
							+ "4.Tester is provided with the following data for 'Impacted Site' records \n"
							+ "Sample inputs are recorded as \n" + "Part number : "
							+ ExcelReport.testData.get("partNumber") + "is recorded \n"
							+ "Sample outputs recorded as: \n" + "Hold site : " + "DISTRIBUTION" + "is recorded\n"
							+ "Site Hold contact: " + " HCS WSO " + "is recorded\n" + " Site DL: "
							+ " Purnima.Nizambad@ge.com " + "is recorded\n" + " Part Description: "
							+ " Cable, STCB to Top Sensors " + "is recorded\n"
							+ "5. Tester must be provided with the SSO ID of 'Product Hold User' user role for accessing the 'Product Holds' application.  \n"
							+ "Record the 'User ID': " + ExcelReport.testData.get("userId") + " is recorded\n"
							+ "6.QA Approver has  " + ExcelReport.testData.get("QAuserId") + " access to GE mail box \n"
							+ "7. Tester is provided with the login credentials of 'GE Mail ID Account' user role for accessing the 'GE Mail ID ' application.  \n"
							+ "Record the 'User ID': " + ExcelReport.testData.get("QAuserId") + " ",
					"PASS", "N");

			PDFResultReport.addPrerequisiteDetails("B",
					"Testing must be conducted on a GEHC issued/authorized PC/Laptop.\n"
							+ "Testing on 'Google Chrome' Browser is  preferred.",
					"Testing is conducted on a GEHC issued/authorized PC/Laptop. \n"
							+ " Testing is conducted on 'Google Chrome' Browser. ",
					"Testing is conducted on a GEHC issued/authorized PC/Laptop.\n" + "Testing is conducted on : "
							+ ExcelReport.testData.get("Browser(Version)") + " is recorded\n",
					"PASS", "N");
			System.out.println("Name Of QA Member" + nameOfQAMember);
			System.out.println("SSO Id Of QA Member" + ssoIdOfQAMember);

		} catch (Exception e) {
		}
	}

	/**
	 * Step No : 10 this method is for to Login to the Application.
	 */
	public static void productHoldLogin() {

		try {
			pageHeader = text(productHoldHomePage.pageHeader);
			userNameOfLoginMember = text(productHoldHomePage.userNameOfLoginMember);
			if (pageHeader.equalsIgnoreCase("PRODUCT HOLDS")) {
				PDFResultReport.addStepDetails(
						"Open the 'Product Holds' application with the <URL>  as recorded in prerequisite  A(1). \n"
								+ "Enter the login credentials of 'Product Hold User' role as recorded in prerequisite A(2).\n"
								+ "Click on the [Log In] button\n" + "Record Login Date and Time",
						"Home page of 'Product Holds' application is displayed \n"
								+ "My Cases' screen and the <UserRoleName#1>  is displayed on the top Right corner.\n"
								+ "Login date and time is recorded.",
						"The SSO LOGIN page is displayed.\n" + "The " + pageHeader
								+ " page is displayed with My Cases tab.\n"
								+ "My Cases' screen and the <UserRoleName#1>: " + userNameOfLoginMember
								+ "  is displayed on the top Right corner.\n" + "Login date and time: "
								+ Product_Hold_Reusable.store_current_date_and_time() + " is recorded.",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Open the 'Product Holds' application with the <URL>  as recorded in prerequisite  A(1). \n"
								+ "Enter the login credentials of 'Product Hold User' role as recorded in prerequisite A(2).\n"
								+ "Click on the [Log In] button\n" + "Record Login Date and Time",
						"Home page of 'Product Holds' application is displayed\n"
								+ "My Cases' screen and the <UserRoleName#1>  is displayed on the top Right corner.\n"
								+ "Login date and time is recorded.",
						"The SSO LOGIN page is displayed.\n"
								+ "The <UserRoleName#1> page is not displayed with My Cases tab."
								+ "My Cases' screen and the <UserRoleName#1>  is not displayed on the top Right corner.\n"
								+ "Login date and time is recorded."
								+ Product_Hold_Reusable.store_current_date_and_time() + "",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Step No : 20 this method is for click on Create button and verify the
	 * Parent Hold ID.
	 */
	public static void create_PH_ID() {

		try {

			click(productHoldHomePage.CreateButtonField);
			waitForObj(5000);
			click(productHoldHomePage.Non_Confirming_product);
			waitForObj(6000);
			boolean parentHold = isElementPresent(productHoldHomePage.PH_ID);
			ParentHoldId = text(productHoldHomePage.PH_ID);
			System.out.println("Parent Hold Id is:" + ParentHoldId);
			if (parentHold == true) {
				PDFResultReport.addStepDetails(
						"Click on [Create] button.\n" + "Click on 'Non Conforming Product Hold \n"
								+ "Record the 'Parent Hold ID' as  < Parent Hold ID #1 > \n",
						"Initiate Product Holds' screen is displayed \n" + "'Parent Hold ID' is generated \n"
								+ "Record the 'Parent Hold ID' as  < Parent Hold ID #1 > \n"
								+ "Screenshot is attached to the step",
						"Initiate Product Holds' screen is displayed \n" + "'Parent Hold ID' is generated \n"
								+ "Record the 'Parent Hold ID' as :" + ParentHoldId + " \n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Click on [Create] button.\n" + "Click on 'Non Conforming Product Hold \n"
								+ "Record the 'Parent Hold ID' as  < Parent Hold ID #1 > \n",
						"Initiate Product Holds' screen is displayed \n" + "'Parent Hold ID' is generated \n"
								+ "Record the 'Parent Hold ID' as  < Parent Hold ID #1 > \n"
								+ "Screenshot is attached to the step",
						"Initiate Product Holds' screen is displayed \n" + "'Parent Hold ID' is generated \n"
								+ "Record the 'Parent Hold ID' as :" + ParentHoldId + " \n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Step No : 30 this method is for verifying Parent Hold Status.
	 */
	public static void verifyPH_ID() {

		try {
			waitForObj(6000);
			String split = ParentHoldId.replaceAll("-", " ");
			String[] splitStr = split.split("\\s+");
			String split_one = splitStr[0];
			String split_second = splitStr[1];
			int split_second_size = split_second.length();
			System.out.println("Splited String " + split_one + "\n" + split_second);

			Assert.assertEquals(split_one, "PHLD");

			if (split_second_size > 7) {

				System.out.println("Parent Hold numeric length Matched");

			} else {
				System.out.println("Parent Hold numeric length didn't Match");
			}

			switchFrame(productHoldHomePage.frame1);
			waitForObj(5000);
			ParentHoldStatus = text(productHoldHomePage.PH_Status);
			System.out.println("Parent Hold Status is:" + ParentHoldStatus);
			Assert.assertEquals(ParentHoldStatus, "Open");

			if (ParentHoldStatus.equalsIgnoreCase("Open") && split_second_size > 7) {
				PDFResultReport.addStepDetails("Verify that < Parent Hold ID #1 >  is alpha-numeric \n"
						+ "Prefixed with  PHLD- followed by minimum of 7 digits \n" + "formatted as PHLD-XXXXXXX \n"
						+ "where XXXXXXX is the numeric portion with Status as 'Open' \n"
						+ "Capture the screenshot and attach to the step \n",
						"'Parent Hold ID#1' is displayed as PHLD-XXXXXXX(minimum 7 digits) and the status is displayed as 'Open' \n"
								+ "Screenshot is attached to the step \n",
						"'Parent Hold ID#1' " + ParentHoldId + " is displayed as : " + ParentHoldId + " is recorded. \n"
								+ "Status is displayed as :" + ParentHoldStatus
								+ "\n Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails("Verify that < Parent Hold ID #1 >  is alpha-numeric \n"
						+ "Prefixed with  PHLD- followed by minimum of 7 digits \n" + "formatted as PHLD-XXXXXXX \n"
						+ "where XXXXXXX is the numeric portion with Status as 'Open' \n"
						+ "Capture the screenshot and attach to the step \n",
						"'Parent Hold ID#1' is displayed as PHLD-XXXXXXX(minimum 7 digits) and the status is displayed as 'Open' \n"
								+ "Screenshot is attached to the step \n",
						"'Parent Hold ID#1' " + ParentHoldId + " is displayed as :" + ParentHoldId + " is recorded. \n"
								+ "Status is displayed as :" + ParentHoldStatus + "\n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Step No : 40 this method is for entering all the attribute values under
	 * 'Initiate Product Holds' screen
	 */
	public static void enterMandatoryFields() {

		try {
			partNumber = ExcelReport.testData.get("partNumbers");
			//partNumber = ExcelReport.testData.get("partNumber");
			title = ExcelReport.testData.get("title");
			trackwiseReference = ExcelReport.testData.get("trackwiseReference");
			modality = ExcelReport.testData.get("modality");
			List<WebElement> modalities = driver.findElements(
					By.xpath("//div[@id='PEGA_GRID0']//div//table[@class='gridTable repeatReadWrite']//tbody/tr"));

			int rowcount = modalities.size();
			System.out.println("Row Count is:" + rowcount);

			for (int i = 2; i <= rowcount - 1; i++) {

				WebElement row = driver.findElement(
						By.xpath("//div[@id='PEGA_GRID0']//div//table[@class='gridTable repeatReadWrite']//tbody/tr["
								+ i + "]"));
				String rowVal = row.getText();
				System.out.println("Row Value is:" + rowVal);
				System.out.println("Row Number is:" + i);
				if (rowVal.equalsIgnoreCase(modality)) {

					WebElement col = driver.findElement(By
							.xpath("//div[@id='PEGA_GRID0']//div//table[@class='gridTable repeatReadWrite']//tbody/tr["
									+ i + "]/td[1]/div"));
					col.click();
					WebElement colVal = driver.findElement(By
							.xpath("//div[@id='PEGA_GRID0']//div//table[@class='gridTable repeatReadWrite']//tbody/tr["
									+ i + "]/td[1]/div/input[2]"));
					colVal.click();
					break;

				} else {
					System.out.println("No such column found");
					continue;
				}

			}
			
			//click(productHoldHomePage.modalitiesAffectedSelectAll);

			futureDate = Product_Hold_Reusable.getFutureDate("MM/dd/YYYY", 5);
			// String
			// currentDate=Product_Hold_Reusable.getCurrentDate("dd/MM/yyyy");
			set(productHoldHomePage.PH_Title_TxtField, title);
			set(productHoldHomePage.PH_ExpClosureDate_TxtField, futureDate);
			set(productHoldHomePage.PH_TrackwiseReference_TxtField, trackwiseReference);
			// set(productHoldHomePage.PH_PartNumber_TxtField, partNumber);
			Product_Hold_Reusable.enterMultiplePartNumbers(partNumber);
			waitForObj(5000);
			WebElement closureDate = driver.findElement(By.xpath("//*[@id='ExpectedClosureDate']"));
			expectedCloserDate = closureDate.getAttribute("value");

			if (productHoldHomePage.PH_PartNumber_TxtField.isDisplayed() == true) {
				PDFResultReport.addStepDetails("Enter the attribute values under 'Initiate Product Holds' screen as \n"
						+ "'Title'- <Title#1> \n"
						+ "'Expected Closure date ':  <DD-MMM-YYYY> - Select any future date \n"
						+ "'Modalities Affected':<Modalities Affected#1> - Check Box with multi select \n"
						+ "'TrackWise Investigation Number ': <TrackWise Investigation Number#1> (Only Number with PR as prefix.) \n"
						+ "IMPACTED PARTS: \n" + "'PART NUMBER':'<PART NUMBER#1>' as recorded in prerequisite A(4) \n"
						+ "Capture the screenshot and attach to the step ",
						"Under 'Initiate Product Holds' screen below attribute values are entered \n"
								+ "'Title'- <Title#1> \n" + "'Expected Closure date' -  <DD-MMM-YYYY> \n"
								+ "'Modalities Affected' - <Modalities Affected#1> \n"
								+ "'TrackWise Investigation Number ': <TrackWise Investigation Number#1> \n"
								+ "IMPACTED PARTS: \n" + "'PART NUMBER':'<PART NUMBER#1>' \n"
								+ "Screenshot is attached to the step",
						"Under 'Initiate Product Holds' screen below attribute values are entered \n"
								+ "'Title'- is recorded as: " + title + "\n"
								+ "'Expected Closure date' is recorded as: " + expectedCloserDate + " \n"
								+ "'Modalities Affected' is recorded as: " + modality + " \n"
								+ "'TrackWise Investigation Number 'is recorded as: " + "PR" + trackwiseReference + "\n"
								+ "IMPACTED PARTS: \n" + "'PART NUMBER':is recorded as: " + partNumber + " \n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails("Enter the attribute values under 'Initiate Product Holds' screen as \n"
						+ "'Title'- <Title#1> \n"
						+ "'Expected Closure date ':  <DD-MMM-YYYY> - Select any future date \n"
						+ "'Modalities Affected':<Modalities Affected#1> - Check Box with multi select \n"
						+ "'TrackWise Investigation Number ': <TrackWise Investigation Number#1> (Only Number with PR as prefix.) \n"
						+ "IMPACTED PARTS: \n" + "'PART NUMBER':'<PART NUMBER#1>' as recorded in prerequisite A(4) \n"
						+ "Capture the screenshot and attach to the step ",
						"Under 'Initiate Product Holds' screen below attribute values are entered \n"
								+ "'Title'- <Title#1> \n" + "'Expected Closure date' -  <DD-MMM-YYYY> \n"
								+ "'Modalities Affected' - <Modalities Affected#1> \n"
								+ "'TrackWise Investigation Number ': <TrackWise Investigation Number#1> \n"
								+ "IMPACTED PARTS: \n" + "'PART NUMBER':'<PART NUMBER#1>' \n"
								+ "Screenshot is attached to the step",
						"Under 'Initiate Product Holds' screen below attribute values are entered \n"
								+ "'Title'- is recorded as: " + title + "\n"
								+ "'Expected Closure date' is recorded as: " + expectedCloserDate + " \n"
								+ "'Modalities Affected' is recorded as: " + modality + " \n"
								+ "'TrackWise Investigation Number 'is recorded as: " + "PR" + trackwiseReference + "\n"
								+ "IMPACTED PARTS: \n" + "'PART NUMBER':is recorded as: " + partNumber + " \n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Step No : 50 this method is for verifying Initiator and Category Fields
	 */
	public static void verifyInitiatorAndCategoryFields() {

		try {

			initiatorName = text(productHoldHomePage.PH_Initiator_LabelField);
			System.out.println("Initiator Name is:" + initiatorName);

			catagory = text(productHoldHomePage.PH_Category_LabelField);
			System.out.println("Catagory is:" + catagory);

			switchToDefaultFrame();
			waitForObj(5000);
			userNameOfLoginMember = text(productHoldHomePage.userNameOfLoginMember);
			switchFrame(productHoldHomePage.frame1);
			waitForObj(5000);
			if (initiatorName.equalsIgnoreCase(userNameOfLoginMember)) {
				PDFResultReport.addStepDetails("'Verify that  following fields are auto populated with below values: \n"
						+ "'Initiator':'<First Name Last Name>' \n" + "'Category':'<Non-Conforming Product Hold>' \n"
						+ "Capture the screenshot and attach to the step \n",
						"'Following fields are auto populated with below values: \n"
								+ "'Initiator':'<First Name Last Name>' \n"
								+ "'Category':'<Non-Conforming Product Hold>' \n"
								+ "Screenshot is attached to the step",
						"'Following fields are auto populated with below values:\n" + "'Initiator' is recorded as:"
								+ initiatorName + "\n" + "'Category':is recorded as :" + catagory + "\n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails("'Verify that  following fields are auto populated with below values: \n"
						+ "'Initiator':'<First Name Last Name>' \n" + "'Category':'<Non-Conforming Product Hold>' \n"
						+ "Capture the screenshot and attach to the step \n",
						"'Following fields are auto populated with below values: \n"
								+ "'Initiator':'<First Name Last Name>' \n"
								+ "'Category':'<Non-Conforming Product Hold>' \n"
								+ "Screenshot is attached to the step",
						"'Following fields are auto populated with below values:\n" + "'Initiator' is recorded as:"
								+ initiatorName + "\n" + "'Category':is recorded as :" + catagory + "\n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Step No : 60 this method is for clicking on Next Button
	 */
	public static void clickNextButtonOnInitiatorScreen() {

		try {

			click(productHoldHomePage.PH_BtnNext);
			waitForObj(15000);
			boolean affectedOrgUnit = isElementPresent(productHoldHomePage.currentScreenLabel);

			if (affectedOrgUnit == true) {
				PDFResultReport.addStepDetails(
						"Click on [Next] Button \n" + "Capture the screenshot and attach to the step \n",
						"'Affected Org Unit' screen is displayed \n" + "Screenshot is attached to the step",
						"'Affected Org Unit' screen is displayed : " + affectedOrgUnit + "\n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Click on [Next] Button \n" + "Capture the screenshot and attach to the step \n",
						"'Affected Org Unit' screen is displayed \n" + "Screenshot is attached to the step",
						"'Affected Org Unit' screen is displayed : " + affectedOrgUnit + "\n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Step No : 70 Verify that the 'Part details:' <Part number #1> section
	 * field values in 'Affected Org Unit' screen are reflected with the values
	 * as recorded in prerequisite <A4>
	 */
	public static void select_Potentially_Hazardous() {

		try {

			waitForObj(2000);
			// List<String>
			// expectedHeaderText=ExcelReport.testData.get(ExpectedTableheaders);
			partNumber = ExcelReport.testData.get("partNumber");
			WebElement selectCheckBox = driver
					.findElement(By.xpath("//table[@prim_page='pyWorkPage']/tbody/tr[2]/td/div/input[2]"));
			String selectCheckBoxField = selectCheckBox.getAttribute("type");
			assertEquals(selectCheckBoxField, "checkbox");

			/*
			 * List<WebElement> tableCols = driver .findElements(By.xpath(
			 * "//table[@prim_page='pyWorkPage']/tbody/tr[2]/td")); int colSize
			 * = tableCols.size(); System.out.println("Column Size is:" +
			 * colSize);
			 * 
			 * for (int i = 2; i <= colSize - 1; i++) {
			 * 
			 * WebElement col = driver .findElement(By.xpath(
			 * "//table[@prim_page='pyWorkPage']/tbody/tr[2]/td[" + i + "]"));
			 * 
			 * String colVal = col.getText(); System.out.println("Col Value is:"
			 * + colVal); System.out.println("Col Number is:" + i); if
			 * (colVal.equalsIgnoreCase(partNumber)) {
			 * 
			 * System.out.println("Part Number Matched");
			 * 
			 * 
			 * } else { System.out.println("Part Number didn't Match");
			 * 
			 * }
			 * 
			 * 
			 * }
			 */

			ArrayList<String> ActualSubtabs = new ArrayList<String>();
			String ExpTabs = ExcelReport.testData.get("headers");

			ArrayList<String> ExpectedSubtas = new ArrayList<String>();
			String AffetedOrgUnit_Subtab = null;

			waitForObj(2000);

			List<WebElement> Ele = driver.findElements(By.xpath("//table[@pl_prop='.OrgSiteMapping']/tbody/tr[1]/th"));
			waitForObj(2000);
			System.out.println("Subtabs size is " + Ele.size());
			for (WebElement Subtabs : Ele) {
				AffetedOrgUnit_Subtab = Subtabs.getText().trim();
				ActualSubtabs.add(AffetedOrgUnit_Subtab);
				System.out.println("Affeted Org Unit Sub tabs are " + ActualSubtabs);
			}

			String[] Expectedvalues = ExpTabs.split(",");
			for (int i = 0; i < Expectedvalues.length; i++) {
				ExpectedSubtas.add(Expectedvalues[i].trim());
				System.out.println("Expected Subtabs are " + ExpectedSubtas);
			}
			Assert.assertEquals(ActualSubtabs, ExpectedSubtas);

			select(productHoldHomePage.potentiallyHazarous, "Yes");
			waitForObj(2000);
			boolean riskLevelField = isElementPresent(productHoldHomePage.riskLevel);
			System.out.println("Risk Level Field Displayed : " + riskLevelField);

			select(productHoldHomePage.riskLevel, "At ALARP");
			waitForObj(7000);

			String riskLblMsg = text(productHoldHomePage.riskLevelStatusMsg);
			System.out.println("Risk Level Label Message is Displaying as : " + riskLblMsg);

			Assert.assertEquals(riskLblMsg, "PSRB Review is not Required");

			select(productHoldHomePage.riskLevel, "Not At ALARP");
			waitForObj(7000);

			String riskLblMsg1 = text(productHoldHomePage.NotALARPriskLevelStatusMsg);
			System.out.println("Risk Level Label Message is Displaying as : " + riskLblMsg1);

			Assert.assertEquals(riskLblMsg1, "PSRB Review is Required");

			select(productHoldHomePage.potentiallyHazarous, "No");
			waitForObj(4000);

			String futureDate = Product_Hold_Reusable.getFutureDate("MM/dd/YYYY", 1);
			waitForObj(2000);
			set(productHoldHomePage.actionDescription_TxtField, actionDescr);
			set(productHoldHomePage.dueDate_TxtField, futureDate);
			select(productHoldHomePage.holdAction_TxtField, holdAction);

			actionDescrActual = text(productHoldHomePage.actionDescription_TxtField);
			holdActionActual = text(productHoldHomePage.holdAction_TxtField);
			WebElement dueDate = driver.findElement(By.xpath("//*[@id='DueDate1']"));
			affectedOrgUnitFutureDate = dueDate.getAttribute("value");
			// affectedOrgUnitFutureDate =
			// text(productHoldHomePage.dueDate_TxtField);

			waitForObj(5000);
			if (productHoldHomePage.BtnNext.isDisplayed() == true) {
				PDFResultReport.addStepDetails(
						"Verify that the 'Part details:' <Part number #1> section field values in 'Affected Org Unit' screen are reflected with the values as recorded in prerequisite <A4> \n"
								+ "SELECT: <Check box#1>\n" + "PART NUMBER:<PART NUMBER#1>\n"
								+ "HOLD SITE:<HOLD SITE#1>\n" + "SITE HOLD CONTACT: <SITE HOLD CONTACT#1>\n"
								+ "SITE DL:<SITE DL#1>\n" + "PART DESCRIPTION:<PART DESCRIPTION#1>\n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1>\n"
								+ "Under 'POTENTIALLY HAZARDOUS' section:\n"
								+ "Select 'Yes' for 'Could the nonconformance lead to a potentially hazardous situation'\n"
								+ "Verify the 'What is the Risk Level?*' field is displayed.\n"
								+ "Select 'At ALARP' for 'PSRB Review is Required� field.\n"
								+ "Verify following message is displayed 'PSRB Review is not Required'\n"
								+ "Select 'Not At ALARP' for 'PSRB Review is Required� field.'\n"
								+ "Verify following message is displayed 'PSRB Review is Required''\n"
								+ "Select 'No' for 'Could the nonconformance lead to a potentially hazardous situation'\n"
								+ "Under 'SITE ACTIONS' section, enter/select the following fields as:\n"
								+ "HOLD ACTIONS': < HOLD ACTIONS#1> : Select any value from the dropdown\n"
								+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> : Enter only alpha characters\n"
								+ "'DUE DATE':<DD-MM-YYYY> : Select any future date\n"
								+ "Capture the screenshot and attach to the step",
						"Field values under 'Affected org unit' screen are auto populated with below values.\n"
								+ "SELECT: <Check box#1> \n" + "PART NUMBER:<PART NUMBER#1> \n"
								+ "SITE HOLD CONTACTt: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION is recorded as: \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
								+ "Under 'POTENTIALLY HAZARDOUS' section, below value is selected: \n"
								+ "'Could the nonconformance lead to a potentially hazardous situation' : Yes \n"
								+ "What is the Risk Level?*' field is displayed \n"
								+ "Following message is displayed 'PSRB Review is not Required' \n"
								+ "Following message is displayed 'PSRB Review is Required' \n"
								+ "'Could the nonconformance lead to a potentially hazardous situation' : No \n"
								+ "'What is the Risk Level?*' field is not displayed.  \n"
								+ "Below fields under 'SITE ACTIONS' section are entered/selected as: \n"
								+ "HOLD ACTIONS': < HOLD ACTIONS#1>  \n"
								+ "ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "DUE DATE':<DD-MM-YYYY> \n"
								+ "Screenshot is attached to the step",
						"Field values under 'Affected org unit' screen are auto populated with below values.\n"
								+ "SELECT is displaying as : " + selectCheckBoxField + " \n"
								+ "PART NUMBER is recorded as : " + partNumber + " \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACTt: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION is recorded as: \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
								+ "Under 'POTENTIALLY HAZARDOUS' section, below value is selected: \n"
								+ "'Could the nonconformance lead to a potentially hazardous situation' : Yes \n"
								+ "What is the Risk Level?*' field is displayed \n"
								+ "Following message is displayed as:" + riskLblMsg + " \n"
								+ "Following message is displayed as:" + riskLblMsg1 + " \n"
								+ "Could the nonconformance lead to a potentially hazardous situation' : No \n"
								+ "What is the Risk Level?*' field is not displayed.  \n"
								+ "Below fields under 'SITE ACTIONS' section are entered/selected as: \n"
								+ "HOLD ACTIONS is recorded as: " + holdAction + "  \n"
								+ "ACTION DESCRIPTION is recorded as: " + actionDescr + " \n"
								+ "DUE DATE is recorded as: " + affectedOrgUnitFutureDate + "\n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Verify that the 'Part details:' <Part number #1> section field values in 'Affected Org Unit' screen are reflected with the values as recorded in prerequisite <A4> \n"
								+ "SELECT: <Check box#1>\n" + "PART NUMBER:<PART NUMBER#1>\n"
								+ "HOLD SITE:<HOLD SITE#1>\n" + "SITE HOLD CONTACT: <SITE HOLD CONTACT#1>\n"
								+ "SITE DL:<SITE DL#1>\n" + "PART DESCRIPTION:<PART DESCRIPTION#1>\n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1>\n"
								+ "Under 'POTENTIALLY HAZARDOUS' section:\n"
								+ "Select 'Yes' for 'Could the nonconformance lead to a potentially hazardous situation'\n"
								+ "Verify the 'What is the Risk Level?*' field is displayed.\n"
								+ "Select 'At ALARP' for 'PSRB Review is Required� field.\n"
								+ "Verify following message is displayed 'PSRB Review is not Required'\n"
								+ "Select 'Not At ALARP' for 'PSRB Review is Required� field.'\n"
								+ "Verify following message is displayed 'PSRB Review is Required''\n"
								+ "Select 'No' for 'Could the nonconformance lead to a potentially hazardous situation'\n"
								+ "Under 'SITE ACTIONS' section, enter/select the following fields as:\n"
								+ "HOLD ACTIONS': < HOLD ACTIONS#1> : Select any value from the dropdown\n"
								+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> : Enter only alpha characters\n"
								+ "'DUE DATE':<DD-MM-YYYY> : Select any future date\n"
								+ "Capture the screenshot and attach to the step",
						"Field values under 'Affected org unit' screen are auto populated with below values.\n"
								+ "SELECT: <Check box#1> \n" + "PART NUMBER:<PART NUMBER#1> \n"
								+ "SITE HOLD CONTACTt: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION is recorded as: \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
								+ "Under 'POTENTIALLY HAZARDOUS' section, below value is selected: \n"
								+ "'Could the nonconformance lead to a potentially hazardous situation' : Yes \n"
								+ "What is the Risk Level?*' field is displayed \n"
								+ "Following message is displayed 'PSRB Review is not Required' \n"
								+ "Following message is displayed 'PSRB Review is Required' \n"
								+ "'Could the nonconformance lead to a potentially hazardous situation' : No \n"
								+ "'What is the Risk Level?*' field is not displayed.  \n"
								+ "Below fields under 'SITE ACTIONS' section are entered/selected as: \n"
								+ "HOLD ACTIONS': < HOLD ACTIONS#1>  \n"
								+ "ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "DUE DATE':<DD-MM-YYYY> \n"
								+ "Screenshot is attached to the step",
						"Field values under 'Affected org unit' screen are auto populated with below values.\n"
								+ "SELECT is displaying as : " + selectCheckBoxField + " \n"
								+ "PART NUMBER is recorded as : " + partNumber + " \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACTt: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION is recorded as: \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
								+ "Under 'POTENTIALLY HAZARDOUS' section, below value is selected: \n"
								+ "'Could the nonconformance lead to a potentially hazardous situation' : Yes \n"
								+ "What is the Risk Level?*' field is displayed \n"
								+ "Following message is displayed as:" + riskLblMsg + " \n"
								+ "Following message is displayed as:" + riskLblMsg1 + " \n"
								+ "Could the nonconformance lead to a potentially hazardous situation' : No \n"
								+ "What is the Risk Level?*' field is not displayed.  \n"
								+ "Below fields under 'SITE ACTIONS' section are entered/selected as: \n"
								+ "HOLD ACTIONS is recorded as: " + holdActionActual + "  \n"
								+ "ACTION DESCRIPTION is recorded as: " + actionDescrActual + " \n"
								+ "DUE DATE is recorded as: " + affectedOrgUnitFutureDate + "\n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 80 click on Next Button in 'Affected Org Unit' screen
	 */
	public static void click_Next() {

		try {
			waitForObj(2000);
			click(productHoldHomePage.BtnNext);
			waitForObj(9000);

			String currentScreenName = text(productHoldHomePage.currentScreenLabel);
			if (currentScreenName.equalsIgnoreCase("Send for QA Approval")) {
				PDFResultReport.addStepDetails(
						"Click on [Next] Button \n" + "Capture the screenshot and attach to the step \n",
						"'Send for QA Approval' screen is displayed \n" + "Screenshot is attached to the step \n",
						"'Send for QA Approval' screen is displayed \n" + "Screenshot is attached to the step \n",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Click on [Next] Button \n" + "Capture the screenshot and attach to the step \n",
						"'Send for QA Approval' screen is displayed \n" + "Screenshot is attached to the step \n",
						"'Send for QA Approval' screen is displayed \n" + "Screenshot is attached to the step \n",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 90 click on Next Button in 'Affected Org Unit' screen
	 */
	public static void select_QA_Approver() {

		try {
			waitForObj(2000);
			// ProductHold_HomePage productHoldHomePage = new
			// ProductHold_HomePage(driver);

			String qaApprover = ExcelReport.testData.get("QAuserId");
			Product_Hold_Reusable.enterValuesInSpecificAutoPopulatedField(productHoldHomePage.qa_Approver_Dropdown,
					qaApprover);

			waitForObj(2000);
			set(productHoldHomePage.changeSummary_TxtField, changeSummaryText);
			waitForObj(5000);
			qaApproverName = text(productHoldHomePage.QAUserName);
			waitForObj(5000);
			// String ChangeSummary =
			// text(productHoldHomePage.changeSummary_TxtField);

			if (productHoldHomePage.BtnReview.isDisplayed() == true) {
				PDFResultReport.addStepDetails("In 'Send for QA Approval' screen enter/select the below fields as \n"
						+ "'QA Approver' : <QA Approver#1> -  select any value from the Dropdown \n"
						+ "'Change Summary': <Change Summary#1> :" + "Capture the screenshot and attach to the step",
						"'In 'Send for QA Approval' screen below field values are entered as, \n"
								+ "'QA Approver' : <QA Approver#1> \n" + "'Change Summary': <Change Summary#1>"
								+ "Screenshot is attached to the step",
						"'In 'Send for QA Approval' screen below field values are entered as, \n" + "'QA Approver' :"
								+ qaApprover + "\n" + "'Change Summary': " + changeSummaryText + "\n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails("In 'Send for QA Approval' screen enter/select the below fields as \n"
						+ "'QA Approver' : <QA Approver#1> -  select any value from the Dropdown \n"
						+ "'Change Summary': <Change Summary#1> :" + "Capture the screenshot and attach to the step",
						"'In 'Send for QA Approval' screen below field values are entered as, \n"
								+ "'QA Approver' : <QA Approver#1> \n" + "'Change Summary': <Change Summary#1>"
								+ "Screenshot is attached to the step",
						"'In 'Send for QA Approval' screen below field values are entered as, \n" + "'QA Approver' :"
								+ qaApprover + "\n" + "'Change Summary': " + changeSummaryText + "\n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 100 click on Review
	 */
	public static void click_Review_Button() {

		try {

			// ProductHold_HomePage productHoldHomePage = new
			// ProductHold_HomePage(driver);
			waitForObj(2000);
			click(productHoldHomePage.BtnReview);
			waitForObj(9000);
			String currentScreen = text(productHoldHomePage.currentScreenLabel);

			if (currentScreen.equalsIgnoreCase("HoldProduct Review")) {
				PDFResultReport.addStepDetails(
						"Click on [Review] Button \n" + "Capture the screenshot and attach to the step ",
						"'Hold Product Review'  screen is displayed in read only mode \n"
								+ "Screenshot is attached to the step ",
						"'Hold Product Review'  screen is displayed in read only mode \n"
								+ "Screenshot is attached to the step ",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Click on [Review] Button \n" + "Capture the screenshot and attach to the step ",
						"'Hold Product Review'  screen is displayed in read only mode \n"
								+ "Screenshot is attached to the step ",
						"'Hold Product Review'  screen is displayed in read only mode \n"
								+ "Screenshot is attached to the step ",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 110 verify 'In 'Hold Product Review' screen
	 */
	public static void verifyFieldsValue() {

		try {
			switchToDefaultFrame();
			waitForObj(5000);
			userNameOfLoginMember = text(productHoldHomePage.userNameOfLoginMember);
			switchFrame(productHoldHomePage.frame1);
			waitForObj(5000);
			// ProductHold_HomePage productHoldHomePage = new
			// ProductHold_HomePage(driver);
			waitForObj(7000);
			String initiatorName = text(productHoldHomePage.PH_Initiator_LabelField);
			System.out.println("Initiator Name is:" + initiatorName);
			Assert.assertEquals(initiatorName, userNameOfLoginMember);

			String catagory = text(productHoldHomePage.PH_Category_LabelField);
			System.out.println("Catagory is:" + catagory);
			Assert.assertEquals(catagory, "Non-Conforming Product Hold");

			String Exptitle = text(productHoldHomePage.PH_Title_LabelField);
			System.out.println("Title is:" + Exptitle);
			Assert.assertEquals(Exptitle, title);

			String expClosureDate = text(productHoldHomePage.PH_ExpClosure_Date_LabelField);
			System.out.println("Expected Closure Date is:" + expectedCloserDate);
			Assert.assertEquals(expClosureDate, expectedCloserDate);

			String modalities = text(productHoldHomePage.PH_Modalitied_Affected_LabelField);
			System.out.println("Modalities Affected is:" + modalities);
			Assert.assertEquals(modalities, modality);

			String trackwise = text(productHoldHomePage.PH_TrackWise_Inv_LabelField);
			System.out.println("Trackwise Investigation Number is:" + trackwise);
			Assert.assertEquals(trackwise, trackwise);

			String qaOwner = text(productHoldHomePage.PH_QA_Owner_LabelField);
			System.out.println("QA Owner Name is:" + qaOwner);
			Assert.assertEquals(qaOwner, qaApproverName);

			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)");
			List<WebElement> tableCols = driver
					.findElements(By.xpath("//table[@prim_page='pyWorkPage']/tbody/tr[2]/td"));
			int colSize = tableCols.size();
			System.out.println("Column Size is:" + colSize);

			for (int i = 1; i <= colSize - 1; i++) {

				WebElement col = driver
						.findElement(By.xpath("//table[@prim_page='pyWorkPage']/tbody/tr[2]/td[" + i + "]"));

				String colVal = col.getText();
				System.out.println("Col Value is:" + colVal);
				if (colVal.equalsIgnoreCase(partNumber)) {

					System.out.println("Part Number Matched");
					break;

				} else {
					System.out.println("Part Number didn't Match");
					continue;
				}
			}

			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,350)");
			List<WebElement> siteActionsCols = driver
					.findElements(By.xpath("//div[@gpropindex='PHoldActionsDataSource1']//table/tbody/tr[2]/td"));
			int siteActColSize = siteActionsCols.size();
			System.out.println("Column Size is:" + siteActColSize);

			for (int i = 1; i <= siteActColSize - 1; i++) {

				WebElement col = driver.findElement(
						By.xpath("//div[@gpropindex='PHoldActionsDataSource1']//table/tbody/tr[2]/td[" + i + "]"));

				String colVal = col.getText();
				System.out.println("Col Value is:" + colVal);
				/*
				 * if (colVal.equalsIgnoreCase("Action Needed")
				 * ||colVal.equalsIgnoreCase("Return to supplier/factory")) {
				 * 
				 * System.out.println("Site Action Value Matched"); break;
				 * 
				 * } else {
				 * System.out.println("Site Action Value didn't Match");
				 * continue; }
				 */
			}
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
					productHoldHomePage.PH_Change_Summary_LabelField);
			changeSummary = text(productHoldHomePage.PH_Change_Summary_LabelField);
			System.out.println("Change Summary Value is:" + changeSummary);
			Assert.assertEquals(changeSummary, "Need Approval");
			waitForObj(5000);

			if (changeSummary.equalsIgnoreCase("Need Approval")) {
				PDFResultReport.addStepDetails("'In 'Hold Product Review' screen,\n"
						+ "1.Verify that the below field values are displayed under 'PENDING HOLD REVIEW' section: \n"
						+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
						+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
						+ "'Modalities Affected':<Modalities Affected#1> \n"
						+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
						+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
						+ "2.Verify that the below field values are displayed under 'IMPACTED SITES' section: \n"
						+ "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
						+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
						+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n" + "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
						+ "3.Verify that the below field values are displayed under 'SITE ACTIONS' section: \n"
						+ "' HOLD ACTIONS': < HOLD ACTIONS#1> \n" + "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n"
						+ "'DUE DATE':<DD-MMM-YYYY> \n"
						+ "4. Verify that 'Change Summary' text box is displayed with below value,\n"
						+ "<Change Summary#1> \n" + "5.Click on [Submit for Approval] Button \n"
						+ "Capture and attach the screenshot to the step ",
						"'In 'Hold Product Review' screen,\n"
								+ "1.Below field values are displayed under 'PENDING HOLD REVIEW' section \n"
								+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
								+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
								+ "'Modalities Affected':<Modalities Affected#1> \n"
								+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
								+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
								+ "2.Below field values are displayed under 'IMPACTED SITES' section \n"
								+ "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
								+ "3.Below field values are displayed under 'SITE ACTIONS' section: \n"
								+ "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
								+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
								+ "4. 'Change Summary' text box is displayed with below value,\n"
								+ "<Change Summary#1> \n"
								+ "5. Parent Product Holds(PHLD#1) is displayed with the message, 'Thank you for your inputs' and the status is changed to 'Pending-Approval' \n"
								+ "Screenshot is attached to the step ",
						"'In 'Hold Product Review' screen,\n"
								+ "1.Below field values are displayed under 'PENDING HOLD REVIEW' section \n"
								+ "'Initiator' :" + initiatorName + "\n" + "'Title'- :" + Exptitle + " \n"
								+ "'Expected Closure date ':" + expClosureDate + " \n" + "'Modalities Affected':"
								+ modalities + " \n" + "'TrackWise Investigation Number ': " + trackwise + "\n"
								+ "'Category' :" + catagory + " \n" + "'QA Owner':" + qaOwner + " \n"
								+ "2.Below field values are displayed under 'IMPACTED SITES' section \n"
								+ "PART NUMBER:" + partNumber + " \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
								+ "3.Below field values are displayed under 'SITE ACTIONS' section: \n"
								+ "' HOLD ACTIONS': " + holdAction + " \n" + "'ACTION DESCRIPTION':" + actionDescr
								+ " \n" + "'DUE DATE':" + affectedOrgUnitFutureDate + "\n"
								+ "4. 'Change Summary' text box is displayed with below value,\n" + changeSummary + "\n"
								+ "5. Parent Product Holds" + ParentHoldId
								+ " is displayed with the message, 'Thank you for your inputs' and the status is changed to 'Pending-Approval' \n"
								+ "Screenshot is attached to the step ",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails("'In 'Hold Product Review' screen,\n"
						+ "1.Verify that the below field values are displayed under 'PENDING HOLD REVIEW' section: \n"
						+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
						+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
						+ "'Modalities Affected':<Modalities Affected#1> \n"
						+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
						+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
						+ "2.Verify that the below field values are displayed under 'IMPACTED SITES' section: \n"
						+ "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
						+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
						+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n" + "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
						+ "3.Verify that the below field values are displayed under 'SITE ACTIONS' section: \n"
						+ "' HOLD ACTIONS': < HOLD ACTIONS#1> \n" + "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n"
						+ "'DUE DATE':<DD-MMM-YYYY> \n"
						+ "4. Verify that 'Change Summary' text box is displayed with below value,\n"
						+ "<Change Summary#1> \n" + "5.Click on [Submit for Approval] Button \n"
						+ "Capture and attach the screenshot to the step ",
						"'In 'Hold Product Review' screen,\n"
								+ "1.Below field values are displayed under 'PENDING HOLD REVIEW' section \n"
								+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
								+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
								+ "'Modalities Affected':<Modalities Affected#1> \n"
								+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
								+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
								+ "2.Below field values are displayed under 'IMPACTED SITES' section \n"
								+ "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
								+ "3.Below field values are displayed under 'SITE ACTIONS' section: \n"
								+ "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
								+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
								+ "4. 'Change Summary' text box is displayed with below value,\n"
								+ "<Change Summary#1> \n"
								+ "5. Parent Product Holds(PHLD#1) is displayed with the message, 'Thank you for your inputs' and the status is changed to 'Pending-Approval' \n"
								+ "Screenshot is attached to the step ",
						"'In 'Hold Product Review' screen,\n"
								+ "1.Below field values are displayed under 'PENDING HOLD REVIEW' section \n"
								+ "'Initiator' :" + initiatorName + "\n" + "'Title'- :" + Exptitle + " \n"
								+ "'Expected Closure date ':" + expClosureDate + " \n" + "'Modalities Affected':"
								+ modalities + " \n" + "'TrackWise Investigation Number ': " + trackwise + "\n"
								+ "'Category' :" + catagory + " \n" + "'QA Owner':" + qaOwner + " \n"
								+ "2.Below field values are displayed under 'IMPACTED SITES' section \n"
								+ "PART NUMBER:" + partNumber + " \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
								+ "3.Below field values are displayed under 'SITE ACTIONS' section: \n"
								+ "' HOLD ACTIONS': " + holdAction + " \n" + "'ACTION DESCRIPTION':" + actionDescr
								+ " \n" + "'DUE DATE':" + affectedOrgUnitFutureDate + "\n"
								+ "4. 'Change Summary' text box is displayed with below value,\n" + changeSummary + "\n"
								+ "5. Parent Product Holds" + ParentHoldId
								+ " is displayed with the message, 'Thank you for your inputs' and the status is changed to 'Pending-Approval' \n"
								+ "Screenshot is attached to the step ",
						"FAIL", "Y");
			}

			waitForObj(5000);
			click(productHoldHomePage.BtnSubmitForApproval);
			waitForObj(7000);
			String confirmMsg = text(productHoldHomePage.parentHoldConfirmMsg).trim();
			Assert.assertEquals(confirmMsg, "Thank you for your input.");

			String status = text(productHoldHomePage.parentHoldStatus).trim();
			Assert.assertEquals(status, "Pending-Approval");

			if (confirmMsg.equalsIgnoreCase("Thank you for your input.")
					&& status.equalsIgnoreCase("Pending-Approval")) {
				PDFResultReport.addStepDetails("", "", "", "Pass", "Y");

			} else {
				PDFResultReport.addStepDetails("", "", "", "Fail", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 140 Verify that the table is displayed with below columns in
	 * 'My Cases' screen
	 */
	public static void verify_ColumnsIn_MyCasesScreen() {

		try {

			waitForObj(5000);

			ArrayList<String> ActualSubtabs = new ArrayList<String>();
			String ExpTabs = ExcelReport.testData.get("mycasesheaders");

			ArrayList<String> ExpectedSubtas = new ArrayList<String>();
			String MyCaseHeader_Subtab = null;

			waitForObj(2000);

			List<WebElement> Ele = driver
					.findElements(By.xpath("//table[@pl_prop_class='Assign-Worklist']/tbody/tr[1]/th"));
			waitForObj(2000);
			System.out.println("Subtabs size is " + Ele.size());
			for (WebElement Subtabs : Ele) {
				MyCaseHeader_Subtab = Subtabs.getText().trim();
				ActualSubtabs.add(MyCaseHeader_Subtab);
				System.out.println("My Case Header Sub tabs are " + ActualSubtabs);
			}

			String[] Expectedvalues = ExpTabs.split(",");
			for (int i = 0; i < Expectedvalues.length; i++) {
				ExpectedSubtas.add(Expectedvalues[i].trim());
				System.out.println("Expected Subtabs are " + ExpectedSubtas);
			}
			Assert.assertEquals(ActualSubtabs, ExpectedSubtas);

			waitForObj(5000);
			if (MyCaseHeader_Subtab.equalsIgnoreCase("INVENTORY ORG TYPE")) {
				PDFResultReport.addStepDetails(
						"Verify that the table is displayed with below columns in 'My Cases' screen \n" + "'URGENCY':\n"
								+ "'HOLD ID':\n" + "'HOLD SITE':\n" + "'EXPECTED CLOSURE':\n" + "'TITLE':\n"
								+ "'ASSIGNED TO':\n" + "'DATE CREATED':\n" + "'STATUS':\n" + "'MODALITY':\n"
								+ "'INVENTORY ORG TYPE'\n" + "Capture the screenshot and attach to the step\n",
						"The table is displayed with below columns in 'My Cases' screen\n" + "'URGENCY':\n"
								+ "'HOLD ID':\n" + "'HOLD SITE':\n" + "'EXPECTED CLOSURE':\n" + "'TITLE':\n"
								+ "'ASSIGNED TO':\n" + "'DATE CREATED':\n" + "'STATUS':\n" + "'MODALITY':\n"
								+ "'INVENTORY ORG TYPE'\n" + "Screenshot is attached to the step",
						"The table is displayed with below columns in 'My Cases' screen\n" + "'URGENCY':\n"
								+ "'HOLD ID':\n" + "'HOLD SITE':\n" + "'EXPECTED CLOSURE':\n" + "'TITLE':\n"
								+ "'ASSIGNED TO':\n" + "'DATE CREATED':\n" + "'STATUS':\n" + "'MODALITY':\n"
								+ "'INVENTORY ORG TYPE'\n" + "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Verify that the table is displayed with below columns in 'My Cases' screen \n" + "'URGENCY':\n"
								+ "'HOLD ID':\n" + "'HOLD SITE':\n" + "'EXPECTED CLOSURE':\n" + "'TITLE':\n"
								+ "'ASSIGNED TO':\n" + "'DATE CREATED':\n" + "'STATUS':\n" + "'MODALITY':\n"
								+ "'INVENTORY ORG TYPE'\n" + "Capture the screenshot and attach to the step\n",
						"The table is displayed with below columns in 'My Cases' screen\n" + "'URGENCY':\n"
								+ "'HOLD ID':\n" + "'HOLD SITE':\n" + "'EXPECTED CLOSURE':\n" + "'TITLE':\n"
								+ "'ASSIGNED TO':\n" + "'DATE CREATED':\n" + "'STATUS':\n" + "'MODALITY':\n"
								+ "'INVENTORY ORG TYPE'\n" + "Screenshot is attached to the step",
						"The table is displayed with below columns in 'My Cases' screen\n" + "'URGENCY':\n"
								+ "'HOLD ID':\n" + "'HOLD SITE':\n" + "'EXPECTED CLOSURE':\n" + "'TITLE':\n"
								+ "'ASSIGNED TO':\n" + "'DATE CREATED':\n" + "'STATUS':\n" + "'MODALITY':\n"
								+ "'INVENTORY ORG TYPE'\n" + "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 150 Click on 'Filter' icon present next to 'Hold ID' column
	 * header and search for Parent Hold Id
	 */
	public static void click_HoldId_FilterIcon() {

		try {

			waitForObj(2000);
			click(productHoldHomePage.holdIDFilter);
			waitForObj(5000);
			set(productHoldHomePage.holdIDFilterSearchTxtBox, ParentHoldId);

			boolean applyButton = isElementPresent(productHoldHomePage.holdIDFilterApplyButton);
			boolean cancelButton = isElementPresent(productHoldHomePage.holdIDFilterCancelButton);

			if (applyButton == true && cancelButton == true) {
				PDFResultReport.addStepDetails(
						"1.Click on 'Filter' icon present next to 'Hold ID' column header. \n"
								+ "2. Search for 'Parent Hold ID'<Parent Hold ID #1> as recorded  in  Step no:20. \n"
								+ "Click on <Parent Hold ID #1> \n" + "Capture the screenshot and attach to the step",
						"1.A popup window is displayed with all pending cases along with [Apply] and [Cancel] buttons. \n"
								+ "2.'ParentProduct Hold '<Parent Hold ID #1> is displayed \n"
								+ "Screenshot is attached to the step",
						"1.A popup window is displayed with all pending cases along with [Apply] and [Cancel] buttons. \n"
								+ "2.'ParentProduct Hold '<Parent Hold ID #1>" + ParentHoldId + " is displayed \n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"1.Click on 'Filter' icon present next to 'Hold ID' column header. \n"
								+ "2. Search for 'Parent Hold ID'<Parent Hold ID #1> as recorded  in  Step no:20. \n"
								+ "Click on <Parent Hold ID #1> \n" + "Capture the screenshot and attach to the step",
						"1.A popup window is displayed with all pending cases along with [Apply] and [Cancel] buttons. \n"
								+ "2.'ParentProduct Hold '<Parent Hold ID #1> is displayed \n"
								+ "Screenshot is attached to the step",
						"1.A popup window is displayed with all pending cases along with [Apply] and [Cancel] buttons. \n"
								+ "2.'ParentProduct Hold '<Parent Hold ID #1>" + ParentHoldId + " is displayed \n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

			click(productHoldHomePage.holdIDFilterApplyButton);
			waitForObj(2000);
			driver.findElement(By.linkText(ParentHoldId)).click();
			waitForObj(2000);
			switchFrame(productHoldHomePage.frame1);
			waitForObj(5000);
			String currentLayOut = text(productHoldHomePage.currentLayout).trim();

			if (currentLayOut.equalsIgnoreCase("QA Approval")) {
				PDFResultReport.addStepDetails("", "", "", "Pass", "Y");

			} else {
				PDFResultReport.addStepDetails("", "", "", "Fail", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 160 verify 'In 'ParentProduct Hold' screen
	 */
	public static void verifyFieldsValueInParentProductHoldScreen() {

		try {

			switchToDefaultFrame();
			waitForObj(5000);
			userNameOfQALoginMember = text(productHoldHomePage.userNameOfLoginMember);
			switchFrame(productHoldHomePage.frame1);
			waitForObj(5000);
			String initiatorName = text(productHoldHomePage.PH_Initiator_LabelField);
			System.out.println("Initiator Name is:" + initiatorName);
			Assert.assertEquals(initiatorName, holdInitiatorName);

			String catagory = text(productHoldHomePage.PH_Category_LabelField);
			System.out.println("Catagory is:" + catagory);
			Assert.assertEquals(catagory, "Non-Conforming Product Hold");

			String Exptitle = text(productHoldHomePage.PH_Title_LabelField);
			System.out.println("Title is:" + Exptitle);
			Assert.assertEquals(Exptitle, title);

			String expClosureDate = text(productHoldHomePage.PH_ExpClosure_Date_LabelField);
			System.out.println("Expected Closure Date is:" + expectedCloserDate);
			Assert.assertEquals(expClosureDate, expectedCloserDate);

			String modalities = text(productHoldHomePage.PH_Modalitied_Affected_LabelField);
			System.out.println("Modalities Affected is:" + modalities);
			Assert.assertEquals(modalities, modality);

			String trackwise = text(productHoldHomePage.PH_TrackWise_Inv_LabelField);
			System.out.println("Trackwise Investigation Number is:" + trackwise);
			Assert.assertEquals(trackwise, "PR" + trackwiseReference);

			String qaOwner = text(productHoldHomePage.PH_QA_Owner_LabelField);
			System.out.println("QA Owner Name is:" + qaOwner);
			Assert.assertEquals(qaOwner, userNameOfQALoginMember);

			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)");
			List<WebElement> tableCols = driver
					.findElements(By.xpath("//table[@prim_page='pyWorkPage']/tbody/tr[2]/td"));
			int colSize = tableCols.size();
			System.out.println("Column Size is:" + colSize);

			for (int i = 1; i <= colSize - 1; i++) {

				WebElement col = driver
						.findElement(By.xpath("//table[@prim_page='pyWorkPage']/tbody/tr[2]/td[" + i + "]"));

				String colVal = col.getText();
				System.out.println("Col Value is:" + colVal);
				if (colVal.equalsIgnoreCase(partNumber)) {

					System.out.println("Part Number Matched");
					break;

				} else {
					System.out.println("Part Number didn't Match");
					continue;
				}
			}

			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,350)");
			List<WebElement> siteActionsCols = driver
					.findElements(By.xpath("//div[@gpropindex='PHoldActionsDataSource1']//table/tbody/tr[2]/td"));
			int siteActColSize = siteActionsCols.size();
			System.out.println("Column Size is:" + siteActColSize);

			for (int i = 1; i <= siteActColSize - 1; i++) {

				WebElement col = driver.findElement(
						By.xpath("//div[@gpropindex='PHoldActionsDataSource1']//table/tbody/tr[2]/td[" + i + "]"));

				String colVal = col.getText();
				System.out.println("Col Value is:" + colVal);
				/*
				 * if (colVal.equalsIgnoreCase("Action Needed")
				 * ||colVal.equalsIgnoreCase("Return to supplier/factory")) {
				 * 
				 * System.out.println("Site Action Value Matched"); break;
				 * 
				 * } else {
				 * System.out.println("Site Action Value didn't Match");
				 * continue; }
				 */
			}
			WebElement dueDateCol = driver.findElement(By.xpath(
					"//div[@gpropindex='PHoldActionsDataSource1']//table/tbody/tr[2]/td[@data-attribute-name='Due Date']/div/span"));
			String dueDate = dueDateCol.getText().trim();

			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
					productHoldHomePage.PH_Change_Summary_LabelField);
			changeSummary = text(productHoldHomePage.PH_Change_Summary_LabelField);
			System.out.println("Change Summary Value is:" + changeSummary);
			Assert.assertEquals(changeSummary, "Need Approval");
			waitForObj(5000);
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)");
			boolean commentsTextBox = isElementPresent(productHoldHomePage.commentsTextBox);
			boolean rejectButton = isElementPresent(productHoldHomePage.QARejectButton);
			boolean approveButton = isElementPresent(productHoldHomePage.QAApproveButton);

			if (commentsTextBox == true && rejectButton == true && approveButton == true) {
				PDFResultReport.addStepDetails("In 'ParentProduct Hold' screen,\n"
						+ "1.Verify that the below field values are displayed under 'PENDING HOLD REVIEW' section\n"
						+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
						+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
						+ "'Modalities Affected':<Modalities Affected#1> \n"
						+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
						+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
						+ "2.Verify that the below field values are displayed under 'Impacted Sites' section\n"
						+ "IMPACTED SITES: \n" + "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
						+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
						+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n" + "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
						+ "SITE ACTIONS: \n" + "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
						+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
						+ "3. Verify that 'Change Summary' text box is displayed with below value,\n"
						+ "<Change Summary#1> \n"
						+ "4. Verify that the 'Comments' section, [Reject] and [Approve] buttons are displayed \n"
						+ "Capture and attach the screenshot to the step ",
						"In 'ParentProduct Hold' screen,\n"
								+ "1.Below field values are displayed under 'PENDING HOLD REVIEW' section \n"
								+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
								+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
								+ "'Modalities Affected':<Modalities Affected#1> \n"
								+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
								+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
								+ "2.Below field values are displayed under 'Impacted Sites' section \n"
								+ "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n" + "SITE ACTIONS: \n"
								+ "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
								+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
								+ "3. 'Change Summary' text box is displayed with below value,\n"
								+ "<Change Summary#1> \n"
								+ "4. 'Comments' section, [Reject] and [Approve] buttons are displayed \n"
								+ "Screenshot is attached to the step ",
						"'In 'Hold Product Review' screen,\n"
								+ "1.Below field values are displayed under 'PENDING HOLD REVIEW' section \n"
								+ "'Initiator' :" + initiatorName + "\n" + "'Title'- :" + Exptitle + " \n"
								+ "'Expected Closure date ':" + expClosureDate + " \n" + "'Modalities Affected':"
								+ modalities + " \n" + "'TrackWise Investigation Number ': " + trackwise + "\n"
								+ "'Category' :" + catagory + " \n" + "'QA Owner':" + qaOwner + " \n"
								+ "2.Below field values are displayed under 'Impacted Sites' section \n"
								+ "PART NUMBER:" + partNumber + " \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n" + "SITE ACTIONS: \n"
								+ "' HOLD ACTIONS': " + holdAction + " \n" + "'ACTION DESCRIPTION':" + actionDescr
								+ " \n" + "'DUE DATE':" + dueDate + "\n"
								+ "3. 'Change Summary' text box is displayed with below value,\n" + changeSummary + "\n"
								+ "4. 'Comments' section, [Reject] and [Approve] buttons are displayed \n"
								+ "Screenshot is attached to the step ",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails("In 'ParentProduct Hold' screen,\n"
						+ "1.Verify that the below field values are displayed under 'PENDING HOLD REVIEW' section\n"
						+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
						+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
						+ "'Modalities Affected':<Modalities Affected#1> \n"
						+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
						+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
						+ "2.Verify that the below field values are displayed under 'Impacted Sites' section\n"
						+ "IMPACTED SITES: \n" + "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
						+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
						+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n" + "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
						+ "SITE ACTIONS: \n" + "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
						+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
						+ "3. Verify that 'Change Summary' text box is displayed with below value,\n"
						+ "<Change Summary#1> \n"
						+ "4. Verify that the 'Comments' section, [Reject] and [Approve] buttons are displayed \n"
						+ "Capture and attach the screenshot to the step ",
						"In 'ParentProduct Hold' screen,\n"
								+ "1.Below field values are displayed under 'PENDING HOLD REVIEW' section \n"
								+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
								+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
								+ "'Modalities Affected':<Modalities Affected#1> \n"
								+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
								+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
								+ "2.Below field values are displayed under 'Impacted Sites' section \n"
								+ "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n" + "SITE ACTIONS: \n"
								+ "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
								+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
								+ "3. 'Change Summary' text box is displayed with below value,\n"
								+ "<Change Summary#1> \n"
								+ "4. 'Comments' section, [Reject] and [Approve] buttons are displayed \n"
								+ "Screenshot is attached to the step ",
						"'In 'Hold Product Review' screen,\n"
								+ "1.Below field values are displayed under 'PENDING HOLD REVIEW' section \n"
								+ "'Initiator' :" + initiatorName + "\n" + "'Title'- :" + Exptitle + " \n"
								+ "'Expected Closure date ':" + expClosureDate + " \n" + "'Modalities Affected':"
								+ modalities + " \n" + "'TrackWise Investigation Number ': " + trackwise + "\n"
								+ "'Category' :" + catagory + " \n" + "'QA Owner':" + qaOwner + " \n"
								+ "2.Below field values are displayed under 'Impacted Sites' section \n"
								+ "PART NUMBER:" + partNumber + " \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n" + "SITE ACTIONS: \n"
								+ "' HOLD ACTIONS': " + holdAction + " \n" + "'ACTION DESCRIPTION':" + actionDescr
								+ " \n" + "'DUE DATE':" + dueDate + "\n"
								+ "3. 'Change Summary' text box is displayed with below value,\n" + changeSummary + "\n"
								+ "4. 'Comments' section, [Reject] and [Approve] buttons are displayed \n"
								+ "Screenshot is attached to the step ",
						"FAIL", "Y");
			}

			waitForObj(5000);

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 170 Enter the comments in the 'Comments' textbox Click on
	 * [Reject] button Verify that user gets a success message.
	 */
	public static void click_Reject_Button() {

		try {
			waitForObj(5000);
			set(productHoldHomePage.commentsTextBox, "Rejected");
			click(productHoldHomePage.PH_Change_Summary_LabelField);
			waitForObj(2000);
			click(productHoldHomePage.QARejectButton);
			waitForObj(2000);
			String confirmationMsg = text(productHoldHomePage.parentHoldConfirmMsg);
			String statusPHID = text(productHoldHomePage.parentHoldStatus);

			if (statusPHID.equalsIgnoreCase("Open")) {
				PDFResultReport.addStepDetails(
						"'1. Enter the comments in the 'Comments' textbox\n" + "2. Click on [Reject] button \n"
								+ "Verify that user gets a success message. \n"
								+ "3. 'Verify that status of the Parent Hold is changed to 'Open' .\n"
								+ "Capture and attach the screenshot to the step",
						"'1. Comments are entered. \n"
								+ "2. Following success message is displayed, 'Thank you for your input'. \n"
								+ "3. Status of <Parent Hold ID #1> is changed to 'Open'. \n"
								+ "Screenshot is attached to the step",
						"'1. Comments are entered. \n" + "2. Following success message is displayed as,"
								+ confirmationMsg + "  \n" + "3. Status of " + ParentHoldId + " is changed to "
								+ statusPHID + " \n" + "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"'1. Enter the comments in the 'Comments' textbox\n" + "2. Click on [Reject] button \n"
								+ "Verify that user gets a success message. \n"
								+ "3. 'Verify that status of the Parent Hold is changed to 'Open' .\n"
								+ "Capture and attach the screenshot to the step",
						"'1. Comments are entered. \n"
								+ "2. Following success message is displayed, 'Thank you for your input'. \n"
								+ "3. Status of <Parent Hold ID #1> is changed to 'Open'. \n"
								+ "Screenshot is attached to the step ",
						"'1. Comments are entered. \n" + "2. Following success message is displayed as,"
								+ confirmationMsg + "  \n" + "3. Status of <Parent Hold ID #1> " + ParentHoldId
								+ " is changed to " + statusPHID + " \n" + "Screenshot is attached to the step ",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 190 this method is for to Login to the Application.
	 */
	public static void productHoldLoginWithHoldInitiator() {

		try {
			LogInPage loginPage = new LogInPage(driver);
			LoginUtils.loginIntoApplication(loginPage, "userId", "password");
			waitForObj(5000);
			userNameOfLoginMember = text(productHoldHomePage.userNameOfLoginMember);
			if (pageHeader.equalsIgnoreCase("PRODUCT HOLDS")) {
				PDFResultReport.addStepDetails(
						"'Login with the credentials of 'Product Hold User'  user role as recorded in prerequisite A(2). \n"
								+ "Click on the [Log In] button",
						"My Cases screen and the  <UserRoleName#1>  is displayed on the top Right corner. ",
						"My Cases screen and the  <UserRoleName#1>" + userNameOfLoginMember
								+ "  is displayed on the top Right corner. ",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"'Login with the credentials of 'Product Hold User'  user role as recorded in prerequisite A(2). \n"
								+ "Click on the [Log In] button",
						"My Cases screen and the  <UserRoleName#1>  is displayed on the top Right corner. ",
						"My Cases screen and the  <UserRoleName#1>" + userNameOfLoginMember
								+ "  is displayed on the top Right corner. ",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * Step No : 200 Enter the < Parent Hold ID #1 > in the 'Search' box. Click
	 * on [Search] button
	 */
	public static void SearchParentHoldId() {

		try {
			waitForObj(5000);
			Product_Hold_Reusable.searchPHIDAndClickOnPHIDLink(ParentHoldId);

			waitForObj(5000);
			String currentScreen = text(productHoldHomePage.currentScreenLabel);

			if (currentScreen.equalsIgnoreCase("Initiate Product Holds")) {
				PDFResultReport.addStepDetails(
						"Enter the < Parent Hold ID #1 > in the 'Search' box. \n" + "Click on [Search] button. \n"
								+ "Click on (Enter Information(Parent Hold Creation))  process link.\n"
								+ "Capture and attach the screenshot to the step",
						"Entered the <Parent Hold ID #1>" + ParentHoldId + " in the 'Search' box. \n"
								+ "'Parent Product Hold' screen is displayed with Case Contents Scetion. \n"
								+ "'Initiate Product Hold' screen is displayed. \n"
								+ "Screenshot is attached to the step",
						"Entered the <Parent Hold ID #1>" + ParentHoldId + " in the 'Search' box. \n"
								+ "'Parent Product Hold' screen is displayed with Case Contents Scetion. \n"
								+ currentScreen + " screen is displayed. \n" + "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Enter the < Parent Hold ID #1 > in the 'Search' box. \n" + "Click on [Search] button. \n"
								+ "Click on (Enter Information(Parent Hold Creation))  process link.\n"
								+ "Capture and attach the screenshot to the step",
						"Entered the <Parent Hold ID #1>" + ParentHoldId + " in the 'Search' box. \n"
								+ "'Parent Product Hold' screen is displayed with Case Contents Scetion. \n"
								+ "'Initiate Product Hold' screen is displayed. \n"
								+ "Screenshot is attached to the step",
						"Entered the <Parent Hold ID #1>" + ParentHoldId + " in the 'Search' box. \n"
								+ "'Parent Product Hold' screen is displayed with Case Contents Scetion. \n"
								+ currentScreen + " screen is displayed. \n" + "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 210 '1. Click on [Next] Button 2.'Click on [Next] Button
	 * 3.'Click on [Review] Button 4. 'Click on [Submit for Approval] Button
	 * 
	 */
	public static void clickOnSubmitForApprovalButton() {

		try {

			click(productHoldHomePage.PH_BtnNext);
			waitForObj(15000);
			boolean affectedOrgUnit = isElementPresent(productHoldHomePage.currentScreenLabel);

			if (affectedOrgUnit == true) {
				PDFResultReport.addStepDetails(
						"1. Click on [Next] Button \n" + "Capture the screenshot and attach to the step \n",
						"'Affected Org Unit' screen is displayed \n" + "Screenshot is attached to the step",
						"'Affected Org Unit' screen is displayed : " + affectedOrgUnit + "\n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"1. Click on [Next] Button \n" + "Capture the screenshot and attach to the step \n",
						"'Affected Org Unit' screen is displayed \n" + "Screenshot is attached to the step",
						"'Affected Org Unit' screen is displayed : " + affectedOrgUnit + "\n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}
			waitForObj(2000);
			click(productHoldHomePage.BtnNext);
			waitForObj(10000);

			String currentScreenName = text(productHoldHomePage.currentScreenLabel);
			if (currentScreenName.equalsIgnoreCase("Send for QA Approval")) {
				PDFResultReport.addStepDetails(
						"2. Click on [Next] Button \n" + "Capture the screenshot and attach to the step \n",
						"'Send for QA Approval' screen is displayed \n" + "Screenshot is attached to the step \n",
						"'Send for QA Approval' screen is displayed \n" + "Screenshot is attached to the step \n",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"2. Click on [Next] Button \n" + "Capture the screenshot and attach to the step \n",
						"'Send for QA Approval' screen is displayed \n" + "Screenshot is attached to the step \n",
						"'Send for QA Approval' screen is displayed \n" + "Screenshot is attached to the step \n",
						"FAIL", "Y");
			}

			waitForObj(2000);
			click(productHoldHomePage.BtnReview);
			waitForObj(9000);
			String currentScreen = text(productHoldHomePage.currentScreenLabel);

			if (currentScreen.equalsIgnoreCase("HoldProduct Review")) {
				PDFResultReport.addStepDetails(
						"3. Click on [Review] Button \n" + "Capture the screenshot and attach to the step ",
						"'Hold Product Review'  screen is displayed in read only mode \n"
								+ "Screenshot is attached to the step ",
						"'Hold Product Review'  screen is displayed in read only mode \n"
								+ "Screenshot is attached to the step ",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"3. Click on [Review] Button \n" + "Capture the screenshot and attach to the step ",
						"'Hold Product Review'  screen is displayed in read only mode \n"
								+ "Screenshot is attached to the step ",
						"'Hold Product Review'  screen is displayed in read only mode \n"
								+ "Screenshot is attached to the step ",
						"FAIL", "Y");
			}

			waitForObj(5000);
			click(productHoldHomePage.BtnSubmitForApproval);
			waitForObj(7000);
			String confirmMsg = text(productHoldHomePage.parentHoldConfirmMsg).trim();
			Assert.assertEquals(confirmMsg, "Thank you for your input.");

			String status = text(productHoldHomePage.parentHoldStatus).trim();
			Assert.assertEquals(status, "Pending-Approval");

			if (confirmMsg.equalsIgnoreCase("Thank you for your input.")
					&& status.equalsIgnoreCase("Pending-Approval")) {
				PDFResultReport
						.addStepDetails("4. 'Click on [Submit for Approval] Button \n",
								"4.'Parent Product Holds<PHLD#1> is displayed with the message, 'Thank you for your inputs' and the status is changed to 'Pending-Approval'.",
								"4.'Parent Product Holds" + ParentHoldId + " is displayed with the message as: , "
										+ confirmMsg + "\n" + "and the status is changed to" + status + "",
								"Pass", "Y");

			} else {
				PDFResultReport
						.addStepDetails("4. 'Click on [Submit for Approval] Button \n",
								"4.'Parent Product Holds<PHLD#1> is displayed with the message, 'Thank you for your inputs' and the status is changed to 'Pending-Approval'.",
								"4.'Parent Product Holds" + ParentHoldId + " is displayed with the message as: , "
										+ confirmMsg + "\n" + "and the status is changed to" + status + "",
								"Fail", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 240 Enter the <Parent Hold ID #1> in the 'Search' box.. Click
	 * on [Search] button
	 */
	public static void SearchParentHoldIdInQAApproverScreen() {

		try {
			waitForObj(5000);
			Product_Hold_Reusable.searchPHID(ParentHoldId);
			switchFrame(productHoldHomePage.frame1);
			waitForObj(5000);
			String currentScreenTitle = text(productHoldHomePage.screenTitle);

			if (currentScreenTitle.equalsIgnoreCase("Parent Product Holds")) {
				PDFResultReport.addStepDetails(
						"Enter the <Parent Hold ID #1>  in the 'Search' box. \n" + "Click on [Search] button.\n"
								+ "Capture and attach the screenshot to the step",
						"Entered the <Parent Hold ID #1> in the 'Search' box. \n"
								+ "'Parent Product Hold' screen is displayed with Case Contents Section - process link. \n"
								+ "Screenshot is attached to the step",
						"Entered the <Parent Hold ID #1>" + ParentHoldId + " in the 'Search' box. \n"
								+ currentScreenTitle
								+ " screen is displayed with Case Contents Scetion - process link.\n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Enter the <Parent Hold ID #1>  in the 'Search' box. \n" + "Click on [Search] button.\n"
								+ "Capture and attach the screenshot to the step",
						"Entered the <Parent Hold ID #1> in the 'Search' box. \n"
								+ "'Parent Product Hold' screen is displayed with Case Contents Section - process link. \n"
								+ "Screenshot is attached to the step",
						"Entered the <Parent Hold ID #1>" + ParentHoldId + " in the 'Search' box. \n"
								+ currentScreenTitle
								+ " screen is displayed with Case Contents Scetion - process link.\n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 250 Click on the process link Verify that [Approve] and
	 * [Reject]buttons are Disabled
	 */
	public static void click_Process_Link() {

		try {
			waitForObj(5000);
			click(productHoldHomePage.PHIDLink);
			waitForObj(8000);

			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)");

			boolean rejectButton = isElementPresent(productHoldHomePage.QARejectButton);
			boolean approveButton = isElementPresent(productHoldHomePage.QAApproveButton);

			boolean rejectBtnStatus = productHoldHomePage.QARejectButton.isEnabled();
			boolean approveBtnStatus = productHoldHomePage.QAApproveButton.isEnabled();

			if (rejectButton == true && approveButton == true) {
				PDFResultReport.addStepDetails(
						"Click on the process link \n" + "'Verify that [Approve] and [Reject]buttons are Disabled. \n"
								+ "Capture and attach the screenshot to the step",
						"'Initiate Product Hold' screen is displayed. \n"
								+ "Verified that [Approve] and [Reject] buttons are Disabled. \n"
								+ "Screenshot is attached to the step",
						"'Initiate Product Hold' screen is displayed. \n" + "Verified that [Approve] button status is "
								+ approveBtnStatus + " \n" + "and [Reject] button status is " + rejectBtnStatus + " \n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Click on the process link \n" + "'Verify that [Approve] and [Reject]buttons are Disabled. \n"
								+ "Capture and attach the screenshot to the step",
						"'Initiate Product Hold' screen is displayed. \n"
								+ "Verified that [Approve] and [Reject] buttons are Disabled. \n"
								+ "Screenshot is attached to the step",
						"'Initiate Product Hold' screen is displayed. \n" + "Verified that [Approve] button status is "
								+ approveBtnStatus + " \n" + "and [Reject] button status is " + rejectBtnStatus + " \n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 260 Enter the comments in the 'Comments' textbox Click on Click
	 * on [Approve] button
	 */
	public static void enterCommentAndClickOnApprove() {

		try {
			waitForObj(5000);
			set(productHoldHomePage.commentsTextBox, "Approved");
			click(productHoldHomePage.PH_Change_Summary_LabelField);
			waitForObj(6000);
			click(productHoldHomePage.QAApproveButton);
			waitForObj(2000);
			String popupTitle = text(productHoldHomePage.electronicSignaturePopupTitle).trim();

			if (popupTitle.equalsIgnoreCase("Electronic Signature")) {
				PDFResultReport.addStepDetails(
						"1. Enter the comments in the 'Comments' \n"
								+ "2. [Approve] and [Reject] buttons should be Enabled \n"
								+ "3. Click on [Approve] button\n" + "Capture and attach the screenshot to the step",
						"1. Comments are Entered \n" + "2. [Approve] and [Reject] buttons are Enabled \n"
								+ "3. 'Electronic Signature' popup window is displayed. \n"
								+ "Screenshot is attached to the step",
						"1. Comments are Entered \n" + "2. [Approve] and [Reject] buttons are Enabled \n" + "3. "
								+ popupTitle + " popup window is displayed. \n" + "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"1. Enter the comments in the 'Comments' \n"
								+ "2. [Approve] and [Reject] buttons should be Enabled \n"
								+ "3. Click on [Approve] button\n" + "Capture and attach the screenshot to the step",
						"1. Comments are Entered \n" + "2. [Approve] and [Reject] buttons are Enabled \n"
								+ "3. 'Electronic Signature' popup window is displayed. \n"
								+ "Screenshot is attached to the step",
						"1. Comments are Entered \n" + "2. [Approve] and [Reject] buttons are Enabled \n" + "3. "
								+ popupTitle + " popup window is displayed. \n" + "Screenshot is attached to the step",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 270
	 */
	// TODO
	public static void verifyEmail() {
		String parentHandle = driver.getWindowHandle();
		String windowname = driver.getWindowHandle();
		System.out.println("windowname " + parentHandle);
		waitForObj(1000);
		try {
			verifyWebMail();

			waitForObj(10000);

			WebElement expextecdLink = childDriver
					.findElement(By.xpath("//*[contains(text(),'" + ParentHoldId + "')]"));
			expextecdLink.click();
			expextecdLink.click();
			waitForObj(7000);
			System.out.println(text(productHoldHomePage.mailSubject));
			String mailSubject = (text(productHoldHomePage.mailSubject));
			waitForObj(10000);
			WebElement mailContentEle = childDriver.findElement(By.xpath("//div[@class='PlainText']"));
			String mailBody = mailContentEle.getText();

			System.out.println("Mail Content is: " + mailBody);
			String otpNum = mailBody.replaceAll("[^0-9]", "");
			otp = "GEHC-" + otpNum;
			System.out.println("OTP is: " + otp);

			waitForObj(10000);
			if (mailSubject.trim().contains("one time password (OTP) for approving this Hold: " + ParentHoldId + "")) {

				PDFResultReport.addStepDetails(
						"Login to GE Mail box and verify that user has received below mail, \n" + "Subject: \n"
								+ "one time password(OTP) for approving this Hold PHLD-XXXXXXXX \n",
						"'User has received the below mail,\n"
								+ "Subject :  'one time password(OTP) for approving this Hold PHLD-XXXXXXXX \n"
								+ "Screenshot is attached to the step\n",
						"'User has received the below mail,\n" + "Subject :  " + mailSubject + " \n"
								+ "Screenshot is attached to the step\n",
						"PASS", "Y");

			} else {
				PDFResultReport.addStepDetails(
						"Login to GE Mail box and verify that user has received below mail, \n" + "Subject: \n"
								+ "one time password(OTP) for approving this Hold PHLD-XXXXXXXX \n",
						"'User has received the below mail,\n"
								+ "Subject :  'one time password(OTP) for approving this Hold PHLD-XXXXXXXX \n"
								+ "Screenshot is attached to the step\n",
						"'User has received the below mail,\n" + "Subject :  " + mailSubject + " \n"
								+ "Screenshot is attached to the step\n",
						"FAIL", "Y");

			}
			waitForObj(3000);

			childDriver.close();
			driver.switchTo().window(windowname);
			// switchWindow(0);
			System.out.println(driver.getTitle());
			waitForObj(3000);
			switchToDefaultFrame();
			waitForObj(5000);

		} catch (Exception e) {
			waitForObj(5000);
			childDriver.close();
			waitForObj(2000);
			driver.switchTo().window(windowname);
			System.out.println(driver.getTitle());
			waitForObj(3000);
			switchWindow(0);
			waitForObj(2000);
		}

	}

	public static void verifyWebMail() {
		productHoldHomePage = new ProductHold_HomePage(driver);
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-extensions");
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\lib\\chromedriver.exe");
		childDriver = new ChromeDriver(options);
		childDriver.manage().window().maximize();
		waitForObj(2000);
		childDriver.get("https://na.private.o365.ge.com/owa/");
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(5000);
		childDriver.get("https://na.private.o365.ge.com/owa/");
		CommonUtils.waitUntilAjaxRequestCompletes(childDriver);
		waitForObj(5000);
		childDriver.navigate().refresh();
		CommonUtils.waitUntilAjaxRequestCompletes(childDriver);
		waitForObj(10000);
		childDriver.navigate().refresh();
		productHoldHomePage = new ProductHold_HomePage(childDriver);

		boolean mailIdField = isElementPresent(productHoldHomePage.mailId_TxtBox);
		System.out.println(mailIdField);
		boolean nextButton = isElementPresent(productHoldHomePage.next_Button);
		System.out.println(nextButton);
		if (mailIdField && nextButton == true) {
			productHoldHomePage = new ProductHold_HomePage(childDriver);
			set(productHoldHomePage.mailId_TxtBox, ExcelReport.testData.get("QAuserId").concat("@ge.com"));
			click(productHoldHomePage.next_Button);

			waitForObj(10000);
			boolean userNameField = isElementPresent(productHoldHomePage.Login_User);
			System.out.println(userNameField);
			boolean passwordField = isElementPresent(productHoldHomePage.Login_Pwd);
			System.out.println(passwordField);
			boolean loginButton = isElementPresent(productHoldHomePage.Login_Button);
			System.out.println(loginButton);
			if (userNameField && passwordField && loginButton == true) {
				productHoldHomePage = new ProductHold_HomePage(childDriver);
				set(productHoldHomePage.Login_User, ExcelReport.testData.get("QAuserId"));
				set(productHoldHomePage.Login_Pwd, ExcelReport.testData.get("mailpassword"));
				click(productHoldHomePage.Login_Button);
			} else {
				System.out.println("page Not Found");
				// pqmUtils = new PQM_Utils(childDriver);
				/*
				 * set(pqmUtils.userNameInPegaLogin,
				 * ExcelReport.testData.get("userid"));
				 * set(pqmUtils.passwordInPegaLogin,
				 * ExcelReport.testData.get("mailpassword"));
				 * click(pqmUtils.loginButtonInPegaLogin);
				 */
			}
		} else {

			boolean userNameField = isElementPresent(productHoldHomePage.Login_User);
			System.out.println(userNameField);
			boolean passwordField = isElementPresent(productHoldHomePage.Login_Pwd);
			System.out.println(passwordField);
			boolean loginButton = isElementPresent(productHoldHomePage.Login_Button);
			System.out.println(loginButton);
			if (userNameField && passwordField && loginButton == true) {
				productHoldHomePage = new ProductHold_HomePage(childDriver);
				set(productHoldHomePage.Login_User, ExcelReport.testData.get("QAuserId"));
				set(productHoldHomePage.Login_Pwd, ExcelReport.testData.get("mailpassword"));
				click(productHoldHomePage.Login_Button);
			} else {
				System.out.println("page Not Found");
				// pqmUtils = new PQM_Utils(childDriver);
				/*
				 * set(productHoldHomePage.userNameInPegaLogin,
				 * ExcelReport.testData.get("userid"));
				 * set(productHoldHomePage.passwordInPegaLogin,
				 * ExcelReport.testData.get("mailpassword"));
				 * click(productHoldHomePage.loginButtonInPegaLogin);
				 */
			}
		}

		CommonUtils.waitUntilAjaxRequestCompletes(childDriver);
		waitForObj(15000);
	}

	/**
	 * Step No : 280 Copy the OTP from the mail. Navigate to 'Parent Product
	 * Holds<PHLD#1> page.
	 */
	public static void enterOTPInElectronicSignature() {

		try {
			// switchFrame(productHoldHomePage.frame1);
			WebElement frame = driver.findElement(By.name("PegaGadget0Ifr"));
			driver.switchTo().frame(frame);
			waitForObj(5000);
			WebElement otpTextBox = driver.findElement(By.id("OTPEntered"));
			otpTextBox.clear();
			otpTextBox.sendKeys(otp);
			// set(productHoldHomePage.otpTxtBox, otp);
			waitForObj(2000);
			WebElement verifyButton = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_grid_triple content-inline_grid_triple  ']//div[3]/div/div/span/button"));
			boolean verifyButtonStatus = isElementPresent(verifyButton);

			if (verifyButtonStatus == true) {
				PDFResultReport.addStepDetails(
						"1. Copy the OTP from the mail. \n" + "2. Navigate to  'Parent Product Holds<PHLD#1>  page. \n"
								+ "In the 'Electronic Signature' popup, enter the copied OTP to the below field as,\n"
								+ "You will have received a mail on your GE ID with a one time password (OTP) for approving this Hold. Please enter the OTP here:' : < OTP >",
						"1. Copied the OTP to  'Parent Product Holds " + ParentHoldId + "  page. \n"
								+ "2. In to the 'Electronic Signature' popup window \n",
						"1. Copied the " + otp + " to  'Parent Product Holds " + ParentHoldId + "  page. \n"
								+ "2. In to the 'Electronic Signature' popup window \n",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"1. Copy the OTP from the mail. \n" + "2. Navigate to  'Parent Product Holds<PHLD#1>  page. \n"
								+ "In the 'Electronic Signature' popup, enter the copied OTP to the below field as,\n"
								+ "You will have received a mail on your GE ID with a one time password (OTP) for approving this Hold. Please enter the OTP here:' : < OTP >",
						"1. Copied the OTP to  'Parent Product Holds " + ParentHoldId + "  page. \n"
								+ "2. In to the 'Electronic Signature' popup window \n",
						"1. Copied the " + otp + " to  'Parent Product Holds " + ParentHoldId + "  page. \n"
								+ "2. In to the 'Electronic Signature' popup window \n",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 290 '1 Click on [Verify] button. Click on the [Submit] button
	 */
	public static void clickOnVerifyButton() {

		try {
			WebElement verifyButton = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_grid_triple content-inline_grid_triple  ']//div[3]/div/div/span/button"));
			verifyButton.click();
			// click(productHoldHomePage.verifyButton);
			waitForObj(10000);
			WebElement submitButton = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline content-inline  ']//div[2]/div/div/span/button"));
			boolean submitButtonStatus = isElementPresent(submitButton);
			// boolean submitButton =
			// isElementPresent(productHoldHomePage.electronicSignSubmitButton);

			if (submitButtonStatus == true) {
				PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			} else {
				PDFResultReport.addStepDetails("", "", "", "FAIL", "Y");
			}

			// click(productHoldHomePage.electronicSignSubmitButton);
			submitButton.click();
			waitForObj(80000);
			WebElement currentPage = driver.findElement(By.xpath("//span[@class='case_title']"));
			String currentPageTitle = currentPage.getText().trim();

			WebElement parentHoldIdStatus = driver.findElement(By.xpath("//span[@class='ellipsis']"));
			String phIDStatus = parentHoldIdStatus.getText().trim();
			// String phIDStatus =
			// text(productHoldHomePage.parentHoldStatus).trim();

			if (currentPageTitle.equalsIgnoreCase("Parent Product Holds") && phIDStatus.equalsIgnoreCase("Approved")) {
				PDFResultReport.addStepDetails(
						"1 Click on [Verify] button." + "2. Click on the [Submit] button \n"
								+ "Capture the screenshot and attach to the step",
						"1. Another popup window displays which contains [Submit] Button. \n"
								+ "2. 'Parent Product Holds' screen displayed with the status:  'Approved'\n"
								+ "Screenshot is attached to the step \n",
						"1. Another popup window displays which contains [Submit] Button. \n"
								+ "2. 'Parent Product Holds' screen displayed with the status:  " + phIDStatus + "\n"
								+ "Screenshot is attached to the step \n",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"1 Click on [Verify] button." + "2. Click on the [Submit] button \n"
								+ "Capture the screenshot and attach to the step",
						"1. Another popup window displays which contains [Submit] Button. \n"
								+ "2. 'Parent Product Holds' screen displayed with the status:  'Approved'\n"
								+ "Screenshot is attached to the step \n",
						"1. Another popup window displays which contains [Submit] Button. \n"
								+ "2. 'Parent Product Holds' screen displayed with the status:  " + phIDStatus + "\n"
								+ "Screenshot is attached to the step \n",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

	/**
	 * Step No : 300 verify Fields value after Approval 'In 'ParentProduct Hold'
	 * screen
	 */
	public static void verifyFieldsValueAfterApproval() {

		try {

			// switchFrame(productHoldHomePage.frame1);
			waitForObj(5000);
			WebElement currentParentHoldIdStatus = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_middle content-inline_middle chevron active ']/div/div/div/span/a"));
			String currentStatus = currentParentHoldIdStatus.getText().trim();
			// String currentStatus = text(productHoldHomePage.currentLayout);
			System.out.println("Current PHID Status is:" + currentStatus);
			Assert.assertEquals(currentStatus, "Approved");

			WebElement ParentHoldIdInitiatorName = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[1]/div/div/span"));
			String initiatorName = ParentHoldIdInitiatorName.getText().trim();
			// String initiatorName =
			// text(productHoldHomePage.PH_Initiator_LabelField);
			System.out.println("Initiator Name is:" + initiatorName);
			Assert.assertEquals(initiatorName, holdInitiatorName);

			WebElement ParentHoldIdCatagory = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[2]/div/div/span"));
			String catagory = ParentHoldIdCatagory.getText().trim();
			// String catagory =
			// text(productHoldHomePage.PH_Category_LabelField);
			System.out.println("Catagory is:" + catagory);
			Assert.assertEquals(catagory, "Non-Conforming Product Hold");

			WebElement ParentHoldIdExptitle = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[3]/div/div/span"));
			String Exptitle = ParentHoldIdExptitle.getText().trim();
			// String Exptitle = text(productHoldHomePage.PH_Title_LabelField);
			System.out.println("Title is:" + Exptitle);
			Assert.assertEquals(Exptitle, title);

			WebElement ParentHoldIdExpClosureDate = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[4]/div/div/span"));
			String expClosureDate = ParentHoldIdExpClosureDate.getText().trim();
			// String expClosureDate =
			// text(productHoldHomePage.PH_ExpClosure_Date_LabelField);
			System.out.println("Expected Closure Date is:" + expectedCloserDate);
			Assert.assertEquals(expClosureDate, expectedCloserDate);

			WebElement ParentHoldIdModalities = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[5]/div/div/span"));
			String modalities = ParentHoldIdModalities.getText().trim();
			// String modalities =
			// text(productHoldHomePage.PH_Modalitied_Affected_LabelField);
			System.out.println("Modalities Affected is:" + modalities);
			Assert.assertEquals(modalities, modality);

			WebElement ParentHoldIdTrackwise = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[6]/div/div/span"));
			String trackwise = ParentHoldIdTrackwise.getText().trim();
			// String trackwise =
			// text(productHoldHomePage.PH_TrackWise_Inv_LabelField);
			System.out.println("Trackwise Investigation Number is:" + trackwise);
			Assert.assertEquals(trackwise, "PR" + trackwiseReference);

			WebElement ParentHoldIdQAOwner = driver.findElement(By.xpath(
					"//div[@class='content layout-content-inline_grid_double content-inline_grid_double  ']/div[7]/div/div/span"));
			String qaOwner = ParentHoldIdQAOwner.getText().trim();
			// String qaOwner =
			// text(productHoldHomePage.PH_QA_Owner_LabelField);
			System.out.println("QA Owner Name is:" + qaOwner);
			Assert.assertEquals(qaOwner, userNameOfQALoginMember);

			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)");
			List<WebElement> tableCols = driver
					.findElements(By.xpath("//table[@prim_page='pyWorkPage']/tbody/tr[2]/td"));
			int colSize = tableCols.size();
			System.out.println("Column Size is:" + colSize);

			for (int i = 1; i <= colSize - 1; i++) {

				WebElement col = driver
						.findElement(By.xpath("//table[@prim_page='pyWorkPage']/tbody/tr[2]/td[" + i + "]"));

				String colVal = col.getText();
				System.out.println("Col Value is:" + colVal);
				if (colVal.equalsIgnoreCase(partNumber)) {

					System.out.println("Part Number Matched");
					break;

				} else {
					System.out.println("Part Number didn't Match");
					continue;
				}
			}

			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,350)");
			List<WebElement> siteActionsCols = driver
					.findElements(By.xpath("//div[@gpropindex='PHoldActionsDataSource1']//table/tbody/tr[2]/td"));
			int siteActColSize = siteActionsCols.size();
			System.out.println("Column Size is:" + siteActColSize);

			for (int i = 1; i <= siteActColSize - 1; i++) {

				WebElement col = driver.findElement(
						By.xpath("//div[@gpropindex='PHoldActionsDataSource1']//table/tbody/tr[2]/td[" + i + "]"));

				String colVal = col.getText();
				System.out.println("Col Value is:" + colVal);

			}
			WebElement dueDateCol = driver.findElement(By.xpath(
					"//div[@gpropindex='PHoldActionsDataSource1']//table/tbody/tr[2]/td[@data-attribute-name='Due Date']/div/span"));
			String dueDate = dueDateCol.getText().trim();

			WebElement ParentHoldIdChangeSummaryr = driver.findElement(By.xpath(
					"//div[@class='layout layout-noheader layout-noheader-default']/div/div/div/div/div/div/div/div/div/div/span"));
			changeSummary = ParentHoldIdChangeSummaryr.getText().trim();
			/*
			 * ((JavascriptExecutor)
			 * driver).executeScript("arguments[0].scrollIntoView(true);",
			 * productHoldHomePage.PH_Change_Summary_LabelField); changeSummary
			 * = text(productHoldHomePage.PH_Change_Summary_LabelField);
			 */
			System.out.println("Change Summary Value is:" + changeSummary);
			Assert.assertEquals(changeSummary, "Need Approval");
			waitForObj(5000);
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)");

			// Verify Child Hold Headers
			ArrayList<String> ActualSubtabs = new ArrayList<String>();
			String ExpTabs = ExcelReport.testData.get("childholdheaders");

			ArrayList<String> ExpectedSubtas = new ArrayList<String>();
			String ChildHold_Subtab = null;

			waitForObj(2000);

			List<WebElement> Ele = driver
					.findElements(By.xpath("//table[@pl_prop='RelatedProductHolds.pxResults']/tbody/tr[1]/th"));
			waitForObj(2000);
			System.out.println("Headers size is " + Ele.size());
			for (WebElement Subtabs : Ele) {
				ChildHold_Subtab = Subtabs.getText().trim();
				ActualSubtabs.add(ChildHold_Subtab);
				System.out.println("Child Hold Headers Fields are " + ActualSubtabs);
			}

			String[] Expectedvalues = ExpTabs.split(",");
			for (int i = 0; i < Expectedvalues.length; i++) {
				ExpectedSubtas.add(Expectedvalues[i].trim());
				System.out.println("Expected Headers Fields are " + ExpectedSubtas);
			}
			Assert.assertEquals(ActualSubtabs, ExpectedSubtas);

			// Verify QA Approver Comments

			ArrayList<String> Actualheaders = new ArrayList<String>();
			String Expheaders = ExcelReport.testData.get("qaApproverComments");

			ArrayList<String> ExpectedQAHeaders = new ArrayList<String>();
			String QAApprover_Headers = null;

			waitForObj(2000);
			List<WebElement> qaApproverEle = driver
					.findElements(By.xpath("//table[@pl_prop='.QAApprCmts']/tbody/tr[1]/th"));
			waitForObj(2000);
			System.out.println("QA Approver Headers size is " + qaApproverEle.size());
			for (WebElement qaapprover : qaApproverEle) {
				QAApprover_Headers = qaapprover.getText().trim();
				Actualheaders.add(QAApprover_Headers);
				System.out.println("QA Approver Headers Fields are " + ActualSubtabs);
			}

			String[] ExpHeaderValues = Expheaders.split(",");
			for (int i = 0; i < ExpHeaderValues.length; i++) {
				ExpectedQAHeaders.add(ExpHeaderValues[i].trim());
				System.out.println("Expected QA Approver Headers Fields are " + ExpectedQAHeaders);
			}
			Assert.assertEquals(Actualheaders, ExpectedQAHeaders);

			// Get Column values of QA Approver Comments Table
			String QAApproverColValues = null;
			ArrayList<String> ActualQAApproverColValues = new ArrayList<String>();

			List<WebElement> qaApproverRows = driver.findElements(By.xpath("//table[@pl_prop='.QAApprCmts']/tbody/tr"));
			int rowCount = qaApproverRows.size();
			for (int i = 2; i < rowCount; i++) {
				List<WebElement> cols = driver
						.findElements(By.xpath("//table[@pl_prop='.QAApprCmts']/tbody/tr[" + i + "]/td"));
				int colCount = cols.size();
				for (int j = 0; j < colCount; j++) {

					List<WebElement> colText = driver.findElements(
							By.xpath("//table[@pl_prop='.QAApprCmts']/tbody/tr[" + i + "]/td[" + j + "]/div"));
					for (WebElement col : colText) {
						QAApproverColValues = col.getText().trim();
						ActualQAApproverColValues.add(QAApproverColValues);
						System.out.println("QA Approver Column Values are " + ActualQAApproverColValues);
					}

				}
			}

			WebElement ParentHoldIdstatus = driver.findElement(By.xpath("//span[@class='ellipsis']"));
			String status = ParentHoldIdstatus.getText().trim();
			// String status=text(productHoldHomePage.parentHoldStatus).trim();

			if (status.equalsIgnoreCase("Approved")) {
				PDFResultReport.addStepDetails("In 'Parent Product Holds' screen,\n"
						+ "1.Verify that status of <PHLD#1> is changed to 'Approved'\n"
						+ "2..Verify that the below field values are displayed under 'PENDING HOLD REVIEW' section\n"
						+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
						+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
						+ "'Modalities Affected':<Modalities Affected#1> \n"
						+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
						+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
						+ "3.Verify that the below field values are displayed under 'Impacted Sites' section\n"
						+ "IMPACTED SITES: \n" + "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
						+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
						+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n" + "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
						+ "SITE ACTIONS: \n" + "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
						+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
						+ "4. Verify that 'Change Summary' text box is displayed with below value,\n"
						+ "<Change Summary#1> \n" + "5.CHILD HOLDS \n" + "CHILD HOLD ID :<CHILD HOLD ID> \n"
						+ "HOLD SITE :<HOLD SITE> \n" + "TITLE :<TITLE> \n" + "SITE OWNER :<SITE OWNER> \n"
						+ "DATE CREATED :<DATE CREATED> \n" + "EXPECTED CLOSURE :<EXPECTED CLOSURE>  \n"
						+ "DATE CLOSED:<DATE CLOSED>  \n" + "STATUS :<STATUS>  \n" + "MODALITY :<MODALITY>  \n"
						+ "6. Verify that the 'QA APPROVER COMMENTS' section, has 'DATE' and 'COMMENTS' columns, display the list of Comments Date wise \n"
						+ "Capture and attach the screenshot to the step",
						"In ' Parent Product Holds' screen,\n" + "1.'Status:' for <PHLD#1>contains 'Approved' \n"
								+ "2..Below field values are displayed under 'PENDING HOLD REVIEW' section"
								+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
								+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
								+ "'Modalities Affected':<Modalities Affected#1> \n"
								+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
								+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
								+ "3.Below field values are displayed under 'Impacted Sites' section \n"
								+ "IMPACTED SITES: \n" + "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n" + "SITE ACTIONS: \n"
								+ "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
								+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
								+ "4. 'Change Summary' text box is displayed with below value,\n"
								+ "<Change Summary#1> \n" + "5.CHILD HOLDS \n" + "CHILD HOLD ID :<CHILD HOLD ID> \n"
								+ "HOLD SITE :<HOLD SITE> \n" + "TITLE :<TITLE> \n" + "SITE OWNER :<SITE OWNER> \n"
								+ "DATE CREATED :<DATE CREATED> \n" + "EXPECTED CLOSURE :<EXPECTED CLOSURE>  \n"
								+ "DATE CLOSED:<DATE CLOSED>  \n" + "STATUS :<STATUS>  \n" + "MODALITY :<MODALITY>  \n"
								+ "6. Verify that the 'QA APPROVER COMMENTS' section, has 'DATE' and 'COMMENTS' columns, display the list of Comments Date wise \n"
								+ "Screenshot is attached to the step",
						"In ' Parent Product Holds' screen,\n" + "1.'Status:' for " + ParentHoldId + "contains "
								+ status + " \n" + "'Initiator' :" + initiatorName + "\n" + "'Title'- :" + Exptitle
								+ " \n" + "'Expected Closure date ':" + expClosureDate + " \n"
								+ "'Modalities Affected':" + modalities + " \n" + "'TrackWise Investigation Number ': "
								+ trackwise + "\n" + "'Category' :" + catagory + " \n" + "'QA Owner':" + qaOwner + " \n"
								+ "3.Below field values are displayed under 'Impacted Sites' section \n"
								+ "PART NUMBER:" + partNumber + " \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n" + "SITE ACTIONS: \n"
								+ "' HOLD ACTIONS': " + holdAction + " \n" + "'ACTION DESCRIPTION':" + actionDescr
								+ " \n" + "'DUE DATE':" + dueDate + "\n"
								+ "4. 'Change Summary' text box is displayed with below value,\n" + changeSummary + "\n"
								+ "<Change Summary#1> \n" + "5.CHILD HOLDS \n" + "CHILD HOLD ID :<CHILD HOLD ID> \n"
								+ "HOLD SITE :<HOLD SITE> \n" + "TITLE :<TITLE> \n" + "SITE OWNER :<SITE OWNER> \n"
								+ "DATE CREATED :<DATE CREATED> \n" + "EXPECTED CLOSURE :<EXPECTED CLOSURE>  \n"
								+ "DATE CLOSED:<DATE CLOSED>  \n" + "STATUS :<STATUS>  \n" + "MODALITY :<MODALITY>  \n"
								+ "6. Verify that the 'QA APPROVER COMMENTS' section, has 'DATE' and 'COMMENTS' columns, display the list of Comments Date wise \n"
								+ "Screenshot is attached to the step",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails("In 'Parent Product Holds' screen,\n"
						+ "1.Verify that status of <PHLD#1> is changed to 'Approved'\n"
						+ "2..Verify that the below field values are displayed under 'PENDING HOLD REVIEW' section\n"
						+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
						+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
						+ "'Modalities Affected':<Modalities Affected#1> \n"
						+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
						+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
						+ "3.Verify that the below field values are displayed under 'Impacted Sites' section\n"
						+ "IMPACTED SITES: \n" + "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
						+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
						+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n" + "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n"
						+ "SITE ACTIONS: \n" + "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
						+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
						+ "4. Verify that 'Change Summary' text box is displayed with below value,\n"
						+ "<Change Summary#1> \n" + "5.CHILD HOLDS \n" + "CHILD HOLD ID :<CHILD HOLD ID> \n"
						+ "HOLD SITE :<HOLD SITE> \n" + "TITLE :<TITLE> \n" + "SITE OWNER :<SITE OWNER> \n"
						+ "DATE CREATED :<DATE CREATED> \n" + "EXPECTED CLOSURE :<EXPECTED CLOSURE>  \n"
						+ "DATE CLOSED:<DATE CLOSED>  \n" + "STATUS :<STATUS>  \n" + "MODALITY :<MODALITY>  \n"
						+ "6. Verify that the 'QA APPROVER COMMENTS' section, has 'DATE' and 'COMMENTS' columns, display the list of Comments Date wise \n"
						+ "Capture and attach the screenshot to the step",
						"In ' Parent Product Holds' screen,\n" + "1.'Status:' for <PHLD#1>contains 'Approved' \n"
								+ "2..Below field values are displayed under 'PENDING HOLD REVIEW' section"
								+ "'Initiator' - <Initiator#1>\n" + "'Title'- <Title#1> \n"
								+ "'Expected Closure date ': <DD-MMM-YYYY> \n"
								+ "'Modalities Affected':<Modalities Affected#1> \n"
								+ "'TrackWise Investigation Number ': <PRTrackWise Investigation Number#1> \n"
								+ "'Category' '<Non-Conforming Product Hold > \n" + "'QA Owner':<QA Owner> \n"
								+ "3.Below field values are displayed under 'Impacted Sites' section \n"
								+ "IMPACTED SITES: \n" + "PART NUMBER:<PART NUMBER#1> \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n" + "SITE ACTIONS: \n"
								+ "' HOLD ACTIONS': < HOLD ACTIONS#1> \n"
								+ "'ACTION DESCRIPTION':<ACTION DESCRIPTION#1> \n" + "'DUE DATE':<DD-MMM-YYYY> \n"
								+ "4. 'Change Summary' text box is displayed with below value,\n"
								+ "<Change Summary#1> \n" + "5.CHILD HOLDS \n" + "CHILD HOLD ID :<CHILD HOLD ID> \n"
								+ "HOLD SITE :<HOLD SITE> \n" + "TITLE :<TITLE> \n" + "SITE OWNER :<SITE OWNER> \n"
								+ "DATE CREATED :<DATE CREATED> \n" + "EXPECTED CLOSURE :<EXPECTED CLOSURE>  \n"
								+ "DATE CLOSED:<DATE CLOSED>  \n" + "STATUS :<STATUS>  \n" + "MODALITY :<MODALITY>  \n"
								+ "6. Verify that the 'QA APPROVER COMMENTS' section, has 'DATE' and 'COMMENTS' columns, display the list of Comments Date wise \n"
								+ "Screenshot is attached to the step",
						"In ' Parent Product Holds' screen,\n" + "1.'Status:' for " + ParentHoldId + "contains "
								+ status + " \n" + "'Initiator' :" + initiatorName + "\n" + "'Title'- :" + Exptitle
								+ " \n" + "'Expected Closure date ':" + expClosureDate + " \n"
								+ "'Modalities Affected':" + modalities + " \n" + "'TrackWise Investigation Number ': "
								+ trackwise + "\n" + "'Category' :" + catagory + " \n" + "'QA Owner':" + qaOwner + " \n"
								+ "3.Below field values are displayed under 'Impacted Sites' section \n"
								+ "PART NUMBER:" + partNumber + " \n" + "HOLD SITE:<HOLD SITE#1> \n"
								+ "SITE HOLD CONTACT: <SITE HOLD CONTACT#1> \n" + "SITE DL:<SITE DL#1> \n"
								+ "PART DESCRIPTION:<PART DESCRIPTION#1> \n"
								+ "INVENTORY ORG TYPE: < INVENTORY ORG TYPE #1> \n" + "SITE ACTIONS: \n"
								+ "' HOLD ACTIONS': " + holdAction + " \n" + "'ACTION DESCRIPTION':" + actionDescr
								+ " \n" + "'DUE DATE':" + dueDate + "\n"
								+ "4. 'Change Summary' text box is displayed with below value,\n" + changeSummary + "\n"
								+ "<Change Summary#1> \n" + "5.CHILD HOLDS \n" + "CHILD HOLD ID :<CHILD HOLD ID> \n"
								+ "HOLD SITE :<HOLD SITE> \n" + "TITLE :<TITLE> \n" + "SITE OWNER :<SITE OWNER> \n"
								+ "DATE CREATED :<DATE CREATED> \n" + "EXPECTED CLOSURE :<EXPECTED CLOSURE>  \n"
								+ "DATE CLOSED:<DATE CLOSED>  \n" + "STATUS :<STATUS>  \n" + "MODALITY :<MODALITY>  \n"
								+ "6. Verify that the 'QA APPROVER COMMENTS' section, has 'DATE' and 'COMMENTS' columns, display the list of Comments Date wise \n"
								+ "Screenshot is attached to the step",
						"FAIL", "Y");
			}

			waitForObj(5000);

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}

	}

}
