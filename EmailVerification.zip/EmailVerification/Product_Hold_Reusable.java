package Components;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import BaseClass.BaseClass;
import BaseClass.ExcelReport;
import BaseClass.PDFResultReport;
import ObjectRepository.LogInPage;
import ObjectRepository.ProductHold_HomePage;

public class Product_Hold_Reusable extends BaseClass {
	public static String userNameOfLoginMember;
	public static ProductHold_HomePage productHoldHomePage = new ProductHold_HomePage(driver);
	public static String pageHeader;
	public static String userNameOfQALoginMember;
	public static JavascriptExecutor js = (JavascriptExecutor) driver;
	public static WebDriver childDriver;
	
	
	public static String getCurrentDate(String format) {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		String strDate = formatter.format(date);
		return strDate;
	}

	public static String getFutureDate(String format, int addDays) {
		// SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		c.add(Calendar.DATE, 180);
		String futureDate = dateFormat.format(c.getTime());
		return futureDate;

	}

	public static void productHoldLogin() {

		// Product_Hold_Reusable productHoldReusable=new
		// Product_Hold_Reusable();
		try {

			pageHeader = text(productHoldHomePage.pageHeader);
			userNameOfLoginMember = text(productHoldHomePage.userNameOfLoginMember);
			if (pageHeader.equalsIgnoreCase("PRODUCT HOLDS")) {
				PDFResultReport.addStepDetails(
						"Open a web browser and enter the SSO enabled URL <URL>of PQM application provided in Step A \n"
								+ "Enter the login credentials of Hold Member role using the SSO ID <Hold_Member_id>  recorded in Step A\n"
								+ "Click on the [Log In & Remember Me] button.\n"
								+ "Capture screenshot(s) of the Product Hold page.",
						"The SSO LOGIN page is displayed.\n" + "The Product Hold page is displayed with My Cases tab.\n"
								+ "Screenshot(s) Captured.",
						"The SSO LOGIN page is displayed.\n" + "The " + pageHeader
								+ " page is displayed with My Cases tab.",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"Open a web browser and enter the SSO enabled URL <URL>of PQM application provided in Step A \n"
								+ "Enter the login credentials of  Hold Member role using the SSO ID <Hold_Member_id>  recorded in Step A\n"
								+ "Click on the [Log In & Remember Me] button.\n"
								+ "Capture screenshot(s) of the Product Hold page.",
						"The SSO LOGIN page is displayed.\n" + "The Product Hold page is displayed with My Cases tab.\n"
								+ "Screenshot(s) Captured.",
						"The SSO LOGIN page is displayed.\n"
								+ "The  Product Hold page is not displayed with My Cases tab.",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	public static void productHoldQAMemberLogin() {

		try {
			LogInPage loginPage = new LogInPage(driver);
			launchApplication(ExcelReport.testData.get("url"));
			LoginUtils.loginIntoApplication(loginPage, "QAuserId", "QApassword");
			waitForObj(5000);
			pageHeader = text(productHoldHomePage.pageHeader);
			userNameOfQALoginMember = text(productHoldHomePage.userNameOfLoginMember);
			if (pageHeader.equalsIgnoreCase("PRODUCT HOLDS")) {
				PDFResultReport.addStepDetails(
						"'Login to the 'Product Holds' application using the login credentials of 'QA Approver' user role as provided in prerequisite A(3). \n"
								+ "Record the Login date and time\n" + "Click on [Log In]  button.\n",
						"'Home page of  'Product Holds' application is displayed with 'My Cases' tab details and the <UserRoleName2> is displayed on the top right corner.\n"
								+ "Login date and time is recorded.",
						"'Home page of  'Product Holds' application is displayed with 'My Cases' tab details and the <UserRoleName2>"
								+ userNameOfQALoginMember + " is displayed on the top right corner.\n"
								+ "Login date and time is recorded."+ Product_Hold_Reusable.store_current_date_and_time()+"",
						"PASS", "Y");
			} else {
				PDFResultReport.addStepDetails(
						"'Login to the 'Product Holds' application using the login credentials of 'QA Approver' user role as provided in prerequisite A(3). \n"
								+ "Record the Login date and time\n" + "Click on [Log In]  button.\n",
						"'Home page of  'Product Holds' application is displayed with 'My Cases' tab details and the <UserRoleName2> is displayed on the top right corner.\n"
								+ "Login date and time is recorded.",
						"'Home page of  'Product Holds' application is displayed with 'My Cases' tab details and the <UserRoleName2>"
								+ userNameOfQALoginMember + " is displayed on the top right corner.\n"
								+ "Login date and time is recorded."+ Product_Hold_Reusable.store_current_date_and_time()+"",
						"FAIL", "Y");
			}

		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	public static void logOffFromApplication() {
		try {

			switchToDefaultFrame();
			userNameOfLoginMember = text(productHoldHomePage.userNameOfLoginMember);
			System.out.println(userNameOfLoginMember);
			selectItemFromMenuLinksInHomePage(driver, userNameOfLoginMember, ProductHold_HomePage.LOG_OFF);
			PDFResultReport.addStepDetails(
					"Click on the  <UserRoleName1> dropdown in the top right corner and select 'Log off' from the list of values.\n"
							+ "Record the Log off date and time.",
					"User is logged out from the 'Product Holds' application.\n"
							+ "Log off date and time is recorded.\n",
					"User is logged out from the 'Product Holds' application.\n" + "Log off date and time is: "
							+ Product_Hold_Reusable.store_current_date_and_time() + " recorded.\n",
					"PASS", "Y");
			waitForObj(2000);

			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(2000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
			waitForObj(5000);
			PDFResultReport.addStepDetails("", "", "", "PASS", "Y");
		} catch (NoSuchElementException ne) {
			System.out.println("No Such Element was Present" + ne.getMessage());
		} catch (TimeoutException te) {
			System.out.println("Unable to Click on the Element" + te.getMessage());
		} catch (Exception e) {
			System.out.println("Unable to find the WebElement " + e.getMessage());
			e.printStackTrace();
		}
	}

	public static void selectItemFromMenuLinksInHomePage(WebDriver driver, String expectedMenuLink,
			String expectedSubLink) {
		/**
		 * To Click on the Main Link in Home Page
		 */
		// ProductHold_HomePage productHoldHomePage = new
		// ProductHold_HomePage(driver);
		for (WebElement mainLinkWebElement : productHoldHomePage.homePageMenuItemLinks) {
			if (mainLinkWebElement.getText().equalsIgnoreCase(expectedMenuLink)) {
				waitForObj(2000);
				System.out.println(mainLinkWebElement.getText());
				click(mainLinkWebElement);
				break;
			}
			waitForObj(1000);
		}
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		/**
		 * To Click on the Sub Link from the Main Link in Home Page
		 */
		for (WebElement subLinkWebelement : productHoldHomePage.homePageMenuItemSubLinks) {
			if (subLinkWebelement.getText().equalsIgnoreCase(expectedSubLink)) {
				System.out.println(subLinkWebelement.getText());
				click(subLinkWebelement);
				break;
			}
			waitForObj(1000);
		}
	}

	public static void enterValuesInSpecificAutoPopulatedField(WebElement expextedWebelement, String expectedValue) {
		try {
			// ProductHold_HomePage productHoldHomePage = new
			// ProductHold_HomePage(driver);
			waitForObj(1000);

			set(expextedWebelement, expectedValue);
			waitForObj(3000);
			new Actions(driver).sendKeys(expextedWebelement, Keys.ARROW_DOWN).build().perform();
			waitForObj(3000);
			for (WebElement list : productHoldHomePage.valuesInAutoPopulatedFields) {
				if (list.getText().trim().contains(expectedValue)) {
					waitForObj(1000);
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", list);
					// new
					// Actions(driver).moveToElement(list).build().perform();
					click(list);
					break;
				}
			}
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			waitForObj(5000);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * This Method is for to search and click on the Parent Hold ID
	 */
	public static void searchPHIDAndClickOnPHIDLink(String parentHoldId)
	{
		try
		{
			driver.navigate().refresh();
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			
			set(productHoldHomePage.PHIDTopSearchTxtBox, parentHoldId);
			click(productHoldHomePage.PHIDTopSearchButton);
			waitForObj(8000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			/*((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
					productHoldHomePage.PHIDLink);*/
			//new Actions(driver).click(productHoldHomePage.PHIDLink).build().perform();
			switchFrame(productHoldHomePage.frame1);
			click(productHoldHomePage.PHIDLink);
			//js.executeScript("arguments[0].click();", productHoldHomePage.PHIDLink);
			waitForObj(8000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
		}catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * This Method is for to search  Parent Hold ID
	 */
	public static void searchPHID(String parentHoldId)
	{
		try
		{
			driver.navigate().refresh();
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			
			set(productHoldHomePage.PHIDTopSearchTxtBox, parentHoldId);
			click(productHoldHomePage.PHIDTopSearchButton);
			waitForObj(8000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
			
		}catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public static void verifyWebMail()
	{
		productHoldHomePage = new ProductHold_HomePage(driver);
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-extensions");
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")
				+ "\\lib\\chromedriver.exe");
		childDriver = new ChromeDriver(options);
		childDriver.manage().window().maximize();
		waitForObj(2000);
		childDriver.get("https://na.private.o365.ge.com/owa/");
		CommonUtils.waitUntilAjaxRequestCompletes(driver);
		waitForObj(5000);
		childDriver.get("https://na.private.o365.ge.com/owa/");
		CommonUtils.waitUntilAjaxRequestCompletes(childDriver);
		waitForObj(5000);
		childDriver.navigate().refresh();
		CommonUtils.waitUntilAjaxRequestCompletes(childDriver);
		waitForObj(10000);
		childDriver.navigate().refresh();
		productHoldHomePage = new ProductHold_HomePage(childDriver);
		
		boolean mailIdField = isElementPresent(productHoldHomePage.mailId_TxtBox);
		System.out.println(mailIdField);
		boolean nextButton = isElementPresent(productHoldHomePage.next_Button);
		System.out.println(nextButton);
		if (mailIdField && nextButton == true) {
			productHoldHomePage = new ProductHold_HomePage(childDriver);
			set(productHoldHomePage.mailId_TxtBox, ExcelReport.testData.get("userid").concat("@ge.com"));
			click(productHoldHomePage.next_Button);

			waitForObj(10000);
			boolean userNameField = isElementPresent(productHoldHomePage.Login_User);
			System.out.println(userNameField);
			boolean passwordField = isElementPresent(productHoldHomePage.Login_Pwd);
			System.out.println(passwordField);
			boolean loginButton = isElementPresent(productHoldHomePage.Login_Button);
			System.out.println(loginButton);
			if (userNameField && passwordField && loginButton == true) {
				productHoldHomePage = new ProductHold_HomePage(childDriver);
				set(productHoldHomePage.Login_User, ExcelReport.testData.get("userid"));
				set(productHoldHomePage.Login_Pwd, ExcelReport.testData.get("mailpassword"));
				click(productHoldHomePage.Login_Button);
			} else {
				System.out.println("page Not Found");
				//pqmUtils = new PQM_Utils(childDriver);
				/*set(pqmUtils.userNameInPegaLogin, ExcelReport.testData.get("userid"));
				set(pqmUtils.passwordInPegaLogin, ExcelReport.testData.get("mailpassword"));
				click(pqmUtils.loginButtonInPegaLogin);*/
			}
		} else {

			boolean userNameField = isElementPresent(productHoldHomePage.Login_User);
			System.out.println(userNameField);
			boolean passwordField = isElementPresent(productHoldHomePage.Login_Pwd);
			System.out.println(passwordField);
			boolean loginButton = isElementPresent(productHoldHomePage.Login_Button);
			System.out.println(loginButton);
			if (userNameField && passwordField && loginButton == true) {
				productHoldHomePage = new ProductHold_HomePage(childDriver);
				set(productHoldHomePage.Login_User, ExcelReport.testData.get("userid"));
				set(productHoldHomePage.Login_Pwd, ExcelReport.testData.get("mailpassword"));
				click(productHoldHomePage.Login_Button);
			} else {
				System.out.println("page Not Found");
				//pqmUtils = new PQM_Utils(childDriver);
				/*set(productHoldHomePage.userNameInPegaLogin, ExcelReport.testData.get("userid"));
				set(productHoldHomePage.passwordInPegaLogin, ExcelReport.testData.get("mailpassword"));
				click(productHoldHomePage.loginButtonInPegaLogin);*/
			}
		}
		
		CommonUtils.waitUntilAjaxRequestCompletes(childDriver);
		waitForObj(15000);
	}
	
	/**
	 * This Method is to store system's current date and time
	 */
	public static String store_current_date_and_time(){
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	/**
	 * This Method is to select all modalities affected
	 */
	public static void selectAllModalities()
	{
		try
		{
			
			click(productHoldHomePage.modalitiesAffectedSelectAll);
			waitForObj(5000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
		}catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * This Method is to enter multiple part numbers
	 */
	public static void enterMultiplePartNumbers(String partNumbers)
	{
		try
		{
			if (partNumbers.length()>1) {
									
					String[] ActualPartNums = partNumbers.split(",");
					
					for (int i = 0; i < ActualPartNums.length; i++) 
					{
						int revisedI = i+1;
						
					System.out.println(ActualPartNums[i]);
					
						WebElement partNumberTextBox=driver.findElement(By.xpath("//input[@id='HoldPartNumbers"+revisedI+"']"));
						
						partNumberTextBox.clear();
						partNumberTextBox.sendKeys(ActualPartNums[i]);
						if (ActualPartNums.length==revisedI) {
							
							break;
						}
						click(productHoldHomePage.addRowPartNumber);
						
					}
										
				
			} else {
				set(productHoldHomePage.PH_PartNumber_TxtField, partNumbers);

			}
			
			waitForObj(5000);
			CommonUtils.waitUntilAjaxRequestCompletes(driver);
		}catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
